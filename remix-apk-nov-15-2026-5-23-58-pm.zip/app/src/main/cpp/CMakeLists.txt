cmake_minimum_required(VERSION 3.22.1)

project("core_engine" LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(
    core_engine
    SHARED
    native_engine.cpp
)

target_compile_options(
    core_engine
    PRIVATE
    -O3
    -ffunction-sections
    -fdata-sections
    -fvisibility=hidden
)

target_link_options(
    core_engine
    PRIVATE
    -Wl,--gc-sections
    -Wl,--strip-all
)

find_library(
    log-lib
    log
)

target_link_libraries(
    core_engine
    ${log-lib}
)
