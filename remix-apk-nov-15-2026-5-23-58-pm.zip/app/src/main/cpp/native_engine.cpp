#include <jni.h>
#include <string>
#include <vector>
#include <map>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <android/log.h>

#define LOG_TAG "CoreEngineNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace core_engine {

constexpr const char* ENGINE_VERSION = "CoreEngine-NDK-2.2.0-arm64";
constexpr size_t STREAM_BUFFER_SIZE = 64 * 1024;

/**
 * Escapes a C++ string for safe embedding in a JSON string literal.
 */
std::string escapeJsonString(const std::string& input) {
    std::ostringstream oss;
    for (char c : input) {
        switch (c) {
            case '"':  oss << "\\\""; break;
            case '\\': oss << "\\\\"; break;
            case '\b': oss << "\\b";  break;
            case '\f': oss << "\\f";  break;
            case '\n': oss << "\\n";  break;
            case '\r': oss << "\\r";  break;
            case '\t': oss << "\\t";  break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    oss << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                        << static_cast<int>(static_cast<unsigned char>(c)) << std::dec;
                } else {
                    oss << c;
                }
                break;
        }
    }
    return oss.str();
}

/**
 * Returns the built-in C++ modification instructions (`classDescriptor -> list of method blocks`)
 * stored directly inside `libcore_engine.so` for a target package.
 */
std::map<std::string, std::vector<std::string>> getNativePatchRulesForPackage(const std::string& targetId) {
    // Default C++ patch rules table (shared by "app.ninjavpn.android" and fallback targets)
    std::map<std::string, std::vector<std::string>> rules;

    rules["Lcom/example/TargetClass;"] = {
        ".method public isFeatureEnabled()Z\n"
        "    .locals 1\n"
        "\n"
        "    const/4 v0, 0x1\n"
        "    return v0\n"
        ".end method",

        ".method public getStatusMessage()Ljava/lang/String;\n"
        "    .locals 1\n"
        "\n"
        "    const-string v0, \"Smali Method Patched Successfully\"\n"
        "    return-object v0\n"
        ".end method"
    };

    rules["Lcom/example/SecondTargetClass;"] = {
        ".method public getSecurityLevel()I\n"
        "    .locals 1\n"
        "\n"
        "    const/16 v0, 0x64\n"
        "    return v0\n"
        ".end method"
    };

    // [EXTENSION POINT]: Add target-specific C++ class/method rules for specific package IDs here
    if (targetId == "app.ninjavpn.android") {
        return rules;
    }

    return rules;
}

/**
 * Parses serialized `CLASS:<descriptor>\n.method ... .end method` blocks from configData if provided;
 * otherwise returns the C++ built-in rules from `getNativePatchRulesForPackage(targetId)`.
 */
std::map<std::string, std::vector<std::string>> resolvePatchRulesInNative(
        const std::string& targetId,
        const std::string& configData) {
    if (configData.empty()) {
        return getNativePatchRulesForPackage(targetId);
    }

    std::map<std::string, std::vector<std::string>> parsed;
    std::istringstream stream(configData);
    std::string line;
    std::string currentClass;
    std::ostringstream currentMethod;
    bool inMethod = false;

    while (std::getline(stream, line)) {
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        if (line.rfind("CLASS:", 0) == 0) {
            currentClass = line.substr(6);
        } else if (line.find(".method ") != std::string::npos) {
            inMethod = true;
            currentMethod.str("");
            currentMethod.clear();
            currentMethod << line << "\n";
        } else if (inMethod) {
            currentMethod << line;
            if (line.find(".end method") != std::string::npos) {
                inMethod = false;
                std::string key = currentClass.empty() ? "Lcom/example/TargetClass;" : currentClass;
                parsed[key].push_back(currentMethod.str());
            } else {
                currentMethod << "\n";
            }
        }
    }

    if (parsed.empty()) {
        return getNativePatchRulesForPackage(targetId);
    }
    return parsed;
}

/**
 * Structured result returned by the C++ native task processor, including resolved modification
 * instructions (`patches`) for `dexlib2`.
 */
struct EngineTaskResult {
    bool success;
    int statusCode;
    uint64_t processedBytes;
    uint32_t checksumFnv1a;
    uint32_t ruleCount;
    std::string targetId;
    std::string summaryMessage;
    std::map<std::string, std::vector<std::string>> resolvedPatches;

    std::string toJsonString() const {
        std::ostringstream oss;
        oss << "{"
            << "\"success\":" << (success ? "true" : "false") << ","
            << "\"statusCode\":" << statusCode << ","
            << "\"processedBytes\":" << processedBytes << ","
            << "\"checksumHex\":\"0x" << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << checksumFnv1a << std::dec << "\","
            << "\"ruleCount\":" << ruleCount << ","
            << "\"targetId\":\"" << escapeJsonString(targetId) << "\","
            << "\"engineVersion\":\"" << ENGINE_VERSION << "\","
            << "\"summaryMessage\":\"" << escapeJsonString(summaryMessage) << "\","
            << "\"patches\":{";

        bool firstClass = true;
        for (const auto& entry : resolvedPatches) {
            if (!firstClass) oss << ",";
            firstClass = false;
            oss << "\"" << escapeJsonString(entry.first) << "\":[";
            for (size_t i = 0; i < entry.second.size(); ++i) {
                if (i > 0) oss << ",";
                oss << "\"" << escapeJsonString(entry.second[i]) << "\"";
            }
            oss << "]";
        }

        oss << "}}";
        return oss.str();
    }
};

/**
 * Computes a fast 32-bit FNV-1a hash over a raw byte buffer in C++.
 */
uint32_t computeFnv1aChecksum(const uint8_t* data, size_t length, uint32_t seed = 0x811C9DC5u) {
    uint32_t hash = seed;
    for (size_t i = 0; i < length; ++i) {
        hash ^= static_cast<uint32_t>(data[i]);
        hash *= 0x01000193u;
    }
    return hash;
}

/**
 * ================================================================================================
 * Primary Modular C++ Processing Handler (`libcore_engine.so`)
 * ================================================================================================
 * Resolves and validates the target package's DEX modification instructions directly in C++
 * and returns structured rules for `dexlib2` and `apksig`.
 */
EngineTaskResult processTaskPayload(const std::string& targetId, const std::string& configData) {
    EngineTaskResult result{};
    result.targetId = targetId;

    if (targetId.empty()) {
        result.success = false;
        result.statusCode = -1;
        result.summaryMessage = "Target identifier cannot be empty";
        return result;
    }

    // [EXTENSION POINT 1]: Resolve C++ patch rules & modification instructions for targetId
    result.resolvedPatches = resolvePatchRulesInNative(targetId, configData);

    uint32_t detectedRules = 0;
    uint32_t checksum = 0x811C9DC5u;
    uint64_t totalRuleBytes = 0;

    checksum = computeFnv1aChecksum(
        reinterpret_cast<const uint8_t*>(targetId.data()),
        targetId.size(),
        checksum
    );

    // [EXTENSION POINT 2]: Validate & hash resolved C++ modification rules
    for (const auto& pair : result.resolvedPatches) {
        checksum = computeFnv1aChecksum(
            reinterpret_cast<const uint8_t*>(pair.first.data()),
            pair.first.size(),
            checksum
        );
        for (const auto& methodBlock : pair.second) {
            ++detectedRules;
            totalRuleBytes += methodBlock.size();
            checksum = computeFnv1aChecksum(
                reinterpret_cast<const uint8_t*>(methodBlock.data()),
                methodBlock.size(),
                checksum
            );
        }
    }

    // [EXTENSION POINT 3]: Assemble structured response for Kotlin JNI bridge
    result.success = !result.resolvedPatches.empty();
    result.statusCode = result.success ? 0 : -2;
    result.processedBytes = totalRuleBytes;
    result.checksumFnv1a = checksum;
    result.ruleCount = detectedRules;
    result.summaryMessage = "Native C++ engine resolved " + std::to_string(detectedRules) +
                            " modification rules for " + targetId;

    LOGI("processTaskPayload completed: target=%s, classes=%zu, rules=%u, crc=0x%08X",
         targetId.c_str(),
         result.resolvedPatches.size(),
         detectedRules,
         result.checksumFnv1a);

    return result;
}

/**
 * High-speed native C++ file stream copy & integrity verification using a 64 KB buffer.
 */
int64_t processFileBufferNative(const std::string& inputPath, const std::string& outputPath) {
    if (inputPath.empty() || outputPath.empty()) {
        return -1;
    }
    if (inputPath == outputPath) {
        std::ifstream existing(inputPath, std::ios::binary | std::ios::ate);
        return existing.is_open() ? static_cast<int64_t>(existing.tellg()) : -1;
    }

    std::ifstream inFile(inputPath, std::ios::binary);
    if (!inFile.is_open()) {
        LOGE("Failed to open input file in C++: %s", inputPath.c_str());
        return -1;
    }

    std::ofstream outFile(outputPath, std::ios::binary | std::ios::trunc);
    if (!outFile.is_open()) {
        LOGE("Failed to open output file in C++: %s", outputPath.c_str());
        return -1;
    }

    std::vector<char> buffer(STREAM_BUFFER_SIZE);
    int64_t totalCopied = 0;

    while (inFile.good()) {
        inFile.read(buffer.data(), static_cast<std::streamsize>(buffer.size()));
        std::streamsize bytesRead = inFile.gcount();
        if (bytesRead > 0) {
            outFile.write(buffer.data(), bytesRead);
            if (!outFile.good()) {
                return -1;
            }
            totalCopied += static_cast<int64_t>(bytesRead);
        }
    }

    outFile.flush();
    return totalCopied;
}

} // namespace core_engine

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_example_engine_NativeEngineBridge_nativeGetEngineVersion(
        JNIEnv* env,
        jobject /* thiz */) {
    return env->NewStringUTF(core_engine::ENGINE_VERSION);
}

JNIEXPORT jstring JNICALL
Java_com_example_engine_NativeEngineBridge_nativeGetRegisteredPackages(
        JNIEnv* env,
        jobject /* thiz */) {
    return env->NewStringUTF("app.ninjavpn.android");
}

JNIEXPORT jstring JNICALL
Java_com_example_engine_NativeEngineBridge_nativeProcessTaskPayload(
        JNIEnv* env,
        jobject /* thiz */,
        jstring targetId,
        jstring configData) {
    const char* targetChars = targetId != nullptr ? env->GetStringUTFChars(targetId, nullptr) : "";
    const char* configChars = configData != nullptr ? env->GetStringUTFChars(configData, nullptr) : "";

    std::string targetStr(targetChars != nullptr ? targetChars : "");
    std::string configStr(configChars != nullptr ? configChars : "");

    if (targetId != nullptr && targetChars != nullptr) {
        env->ReleaseStringUTFChars(targetId, targetChars);
    }
    if (configData != nullptr && configChars != nullptr) {
        env->ReleaseStringUTFChars(configData, configChars);
    }

    core_engine::EngineTaskResult result = core_engine::processTaskPayload(targetStr, configStr);
    std::string jsonResponse = result.toJsonString();
    return env->NewStringUTF(jsonResponse.c_str());
}

JNIEXPORT jlong JNICALL
Java_com_example_engine_NativeEngineBridge_nativeProcessFileBuffer(
        JNIEnv* env,
        jobject /* thiz */,
        jstring inputPath,
        jstring outputPath) {
    if (inputPath == nullptr || outputPath == nullptr) {
        return -1L;
    }

    const char* inChars = env->GetStringUTFChars(inputPath, nullptr);
    const char* outChars = env->GetStringUTFChars(outputPath, nullptr);

    std::string inStr(inChars != nullptr ? inChars : "");
    std::string outStr(outChars != nullptr ? outChars : "");

    if (inChars != nullptr) env->ReleaseStringUTFChars(inputPath, inChars);
    if (outChars != nullptr) env->ReleaseStringUTFChars(outputPath, outChars);

    return static_cast<jlong>(core_engine::processFileBufferNative(inStr, outStr));
}

JNIEXPORT jbyteArray JNICALL
Java_com_example_engine_NativeEngineBridge_nativeTransformByteBuffer(
        JNIEnv* env,
        jobject /* thiz */,
        jbyteArray inputBytes,
        jstring ruleKey) {
    if (inputBytes == nullptr) {
        return env->NewByteArray(0);
    }

    jsize len = env->GetArrayLength(inputBytes);
    std::vector<jbyte> buffer(len);
    if (len > 0) {
        env->GetByteArrayRegion(inputBytes, 0, len, buffer.data());
    }

    if (ruleKey != nullptr) {
        const char* keyChars = env->GetStringUTFChars(ruleKey, nullptr);
        if (keyChars != nullptr) {
            env->ReleaseStringUTFChars(ruleKey, keyChars);
        }
    }

    jbyteArray outArray = env->NewByteArray(len);
    if (len > 0) {
        env->SetByteArrayRegion(outArray, 0, len, buffer.data());
    }
    return outArray;
}

} // extern "C"
