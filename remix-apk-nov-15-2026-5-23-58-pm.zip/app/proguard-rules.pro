# ================================================================================================
# ProGuard / R8 Rules for APK Package Fixer & Native C++ Bridge (libcore_engine.so)
# ================================================================================================

-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod,*Annotation*

# 1. Keep JNI Bridge & all native methods intact for libcore_engine.so
-keep class com.example.engine.NativeEngineBridge {
    *;
}
-keep class com.example.engine.NativeTaskExecutionReport {
    *;
}
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# 2. Keep REAndroid ARSCLib binary AXML & resources.arsc parser classes
-keep class com.reandroid.** { *; }
-dontwarn com.reandroid.**

# 3. Keep org.smali:dexlib2 DEX bytecode reader/writer classes
-keep class org.jf.dexlib2.** { *; }
-keep class org.jf.util.** { *; }
-dontwarn org.jf.**
-dontwarn com.google.common.**

# 4. Keep Google apksig (V1 + V2 + V3 APK Signer & Verifier)
-keep class com.android.apksig.** { *; }
-dontwarn com.android.apksig.**

# 5. Keep app engines & data models
-keep class com.example.engine.** { *; }
-keep class com.example.model.** { *; }
