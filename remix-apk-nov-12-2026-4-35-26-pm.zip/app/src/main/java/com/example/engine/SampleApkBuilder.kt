package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.zip.Adler32
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Generates a binary-valid, multi-architecture test APK file on disk containing:
 * - Valid DEX files (`classes.dex`, `classes2.dex`) with real `map_list`, `TYPE_CODE_ITEM` (0x2001),
 *   and `TYPE_DEBUG_INFO_ITEM` (0x2003) sections + valid SHA-1 & Adler32 headers.
 * - Valid 64-bit ELF `.so` libraries with real Section Headers (`SHF_ALLOC` text/rodata + non-alloc `.debug_info`).
 * - Real decodable PNG/WebP images (>2KB) in `drawable-hdpi` & `drawable-xxhdpi`, plus a `.9.png` nine-patch.
 * - Lottie/JSON animation files with long floating-point coordinates and indentation.
 * - `assets/dexopt/baseline.prof`, `META-INF/`, `kotlin/`, `DebugProbesKt.bin`, and root `.properties` bloat.
 */
object SampleApkBuilder {

    suspend fun createUnoptimizedSampleApk(targetFile: File): File = withContext(Dispatchers.IO) {
        FileOutputStream(targetFile).use { fos ->
            ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                zos.setLevel(Deflater.BEST_SPEED)

                // 1. Binary AndroidManifest.xml (AXML magic 0x00080003)
                writeEntry(
                    zos = zos,
                    name = "AndroidManifest.xml",
                    data = buildBinaryManifestPayload(18_432),
                    stored = false,
                    unalignedPadBytes = 7
                )

                // 2. resources.arsc (RES_TABLE_TYPE 0x0002, STORED and unaligned)
                writeEntry(
                    zos = zos,
                    name = "resources.arsc",
                    data = buildBinaryArscPayload(420_000),
                    stored = true,
                    unalignedPadBytes = 13
                )

                // 3. classes.dex & classes2.dex with real map_list, TYPE_CODE_ITEM, and TYPE_DEBUG_INFO_ITEM
                writeEntry(
                    zos = zos,
                    name = "classes.dex",
                    data = buildValidStructuredDexPayload(totalSize = 640_000, debugInfoSize = 240_000, seed = 1),
                    stored = false,
                    unalignedPadBytes = 19
                )
                writeEntry(
                    zos = zos,
                    name = "classes2.dex",
                    data = buildValidStructuredDexPayload(totalSize = 360_000, debugInfoSize = 140_000, seed = 2),
                    stored = false,
                    unalignedPadBytes = 5
                )

                // 4. Native 64-bit & 32-bit ELF .so libraries with real non-alloc .debug_info sections
                writeEntry(
                    zos = zos,
                    name = "lib/arm64-v8a/libmedia_engine.so",
                    data = buildValidElf64WithDebugSection(totalSize = 520_000, debugSectionSize = 240_000),
                    stored = true,
                    unalignedPadBytes = 11
                )
                writeEntry(
                    zos = zos,
                    name = "lib/armeabi-v7a/libmedia_engine.so",
                    data = buildValidElf64WithDebugSection(totalSize = 440_000, debugSectionSize = 180_000),
                    stored = true,
                    unalignedPadBytes = 9
                )
                writeEntry(
                    zos = zos,
                    name = "lib/x86_64/libmedia_engine.so",
                    data = buildValidElf64WithDebugSection(totalSize = 580_000, debugSectionSize = 220_000),
                    stored = true,
                    unalignedPadBytes = 15
                )

                // 5. Resource files (Real PNG > 2KB in xxhdpi and hdpi, Nine-Patch .9.png, Lottie JSON, WAV)
                writeEntry(
                    zos = zos,
                    name = "res/drawable-xxhdpi-v4/hero_splash.png",
                    data = buildRealOrSyntheticPngPayload(width = 640, height = 640, targetFallbackSize = 260_000),
                    stored = true,
                    unalignedPadBytes = 23
                )
                writeEntry(
                    zos = zos,
                    name = "res/drawable-hdpi-v4/gauge_bg.png",
                    data = buildRealOrSyntheticPngPayload(width = 320, height = 320, targetFallbackSize = 120_000),
                    stored = true,
                    unalignedPadBytes = 11
                )
                writeEntry(
                    zos = zos,
                    name = "res/drawable-xxhdpi-v4/button_frame.9.png",
                    data = buildPngFallbackPayload(24_000),
                    stored = true,
                    unalignedPadBytes = 17
                )
                writeEntry(
                    zos = zos,
                    name = "res/raw/speed_gauge_lottie.json",
                    data = buildLottieJsonPayload(180_000),
                    stored = true,
                    unalignedPadBytes = 7
                )
                writeEntry(
                    zos = zos,
                    name = "res/raw/shutter_sound.wav",
                    data = buildWavPayload(160_000),
                    stored = true,
                    unalignedPadBytes = 31
                )

                // 6. Assets (JSON catalog & Baseline profiles)
                writeEntry(
                    zos = zos,
                    name = "assets/offline_catalog_ar.json",
                    data = buildLottieJsonPayload(220_000),
                    stored = false,
                    unalignedPadBytes = 29
                )
                writeEntry(
                    zos = zos,
                    name = "assets/dexopt/baseline.prof",
                    data = ByteArray(42_000) { idx -> ((idx * 73 + 19) and 0xFF).toByte() },
                    stored = true,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "assets/dexopt/baseline.profm",
                    data = ByteArray(8_192) { idx -> ((idx * 41 + 7) and 0xFF).toByte() },
                    stored = true,
                    unalignedPadBytes = 0
                )

                // 7. META-INF, Kotlin metadata, DebugProbesKt.bin, and root .properties bloat
                writeEntry(
                    zos = zos,
                    name = "META-INF/MANIFEST.MF",
                    data = buildMetaInfPayload("Manifest-Version: 1.0\nCreated-By: Android Gradle 8.7.0\n", 48_000),
                    stored = false,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "META-INF/CERT.SF",
                    data = buildMetaInfPayload("Signature-Version: 1.0\nSHA-256-Digest-Manifest: 9F86D081884C7D659A2FEAA0C55AD015\n", 48_000),
                    stored = false,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "META-INF/CERT.RSA",
                    data = ByteArray(16_384) { idx -> ((idx * 37 + 11) and 0xFF).toByte() },
                    stored = false,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "META-INF/com/android/build/gradle/app-metadata.properties",
                    data = "appMetadataVersion=1.1\nandroidGradlePluginVersion=8.7.0\n".repeat(120).toByteArray(),
                    stored = false,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "kotlin/collections/Collections.kotlin_builtins",
                    data = "kotlin.collections.builtins.metadata.".repeat(600).toByteArray(),
                    stored = false,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "DebugProbesKt.bin",
                    data = "kotlinx.coroutines.debug.DebugProbesKt".repeat(400).toByteArray(),
                    stored = false,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "play-services-base.properties",
                    data = "version=18.5.0\nclient=play-services-base\n".repeat(150).toByteArray(),
                    stored = false,
                    unalignedPadBytes = 0
                )
                writeEntry(
                    zos = zos,
                    name = "client_analytics.proto",
                    data = "syntax = \"proto2\"; package wireless.android.play.playlog;".repeat(200).toByteArray(),
                    stored = false,
                    unalignedPadBytes = 0
                )

                zos.finish()
            }
        }
        targetFile
    }

    private fun writeEntry(
        zos: ZipOutputStream,
        name: String,
        data: ByteArray,
        stored: Boolean,
        unalignedPadBytes: Int = 0
    ) {
        val entry = ZipEntry(name)
        entry.time = 473385600000L
        if (unalignedPadBytes > 0) {
            entry.extra = ByteArray(unalignedPadBytes) { 0x00 }
        }
        if (stored) {
            entry.method = ZipEntry.STORED
            entry.size = data.size.toLong()
            entry.compressedSize = data.size.toLong()
            val crc = CRC32()
            crc.update(data)
            entry.crc = crc.value
        } else {
            entry.method = ZipEntry.DEFLATED
        }
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    /**
     * Builds a binary-valid DEX file with:
     * - Header [0..112) (`dex\n039\0`, `endian_tag = 0x12345678`, `file_size`, `map_off`)
     * - `TYPE_CODE_ITEM` (`0x2001`) section containing valid 4-byte-aligned `code_item` records pointing into debug section
     * - `TYPE_DEBUG_INFO_ITEM` (`0x2003`) section filled with high-entropy DWARF debug state machine bytes
     * - `TYPE_MAP_LIST` (`0x1000`) at the end of the file
     * - Valid SHA-1 signature and Adler32 checksum
     */
    private fun buildValidStructuredDexPayload(totalSize: Int, debugInfoSize: Int, seed: Int): ByteArray {
        val bytes = ByteArray(totalSize)
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        // DEX magic: "dex\n039\0"
        val magic = byteArrayOf(0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x39, 0x00)
        System.arraycopy(magic, 0, bytes, 0, magic.size)

        val codeSectionOffset = 128
        val codeCount = 8
        // Each code_item: 16-byte header + 8 bytes insns (4 code units, tries_size = 0) = 24 bytes
        val singleCodeItemSize = 24
        val debugSectionOffset = codeSectionOffset + codeCount * singleCodeItemSize
        val mapOff = totalSize - 64

        // Fill header fields
        bb.putInt(32, totalSize)       // file_size
        bb.putInt(36, 112)             // header_size
        bb.putInt(40, 0x12345678)      // endian_tag
        bb.putInt(52, mapOff)          // map_off

        // Write 8 valid code_item structures at codeSectionOffset
        for (i in 0 until codeCount) {
            val itemOff = codeSectionOffset + i * singleCodeItemSize
            bb.putShort(itemOff + 0, 4) // registers_size
            bb.putShort(itemOff + 2, 1) // ins_size
            bb.putShort(itemOff + 4, 1) // outs_size
            bb.putShort(itemOff + 6, 0) // tries_size = 0
            bb.putInt(itemOff + 8, debugSectionOffset + i * 32) // debug_info_off (> 0!)
            bb.putInt(itemOff + 12, 4)  // insns_size = 4 (8 bytes)
            bb.putInt(itemOff + 16, 0x000e0070) // return-void
            bb.putInt(itemOff + 20, 0x00000000)
        }

        // Fill TYPE_DEBUG_INFO_ITEM section with high-entropy pseudo-random DWARF line/local-var debug bytes
        val debugEnd = minOf(debugSectionOffset + debugInfoSize, mapOff)
        for (pos in debugSectionOffset until debugEnd) {
            bytes[pos] = ((pos * 131 + seed * 37 + (pos ushr 7)) and 0xFF).toByte()
        }

        // Fill remaining code/string pool area before mapOff
        val pattern = "Lcom/speedtest/engine/TelemetryService;onMeasureBandwidth;(JJ)V".toByteArray()
        var cursor = debugEnd
        while (cursor < mapOff) {
            val len = minOf(pattern.size, mapOff - cursor)
            System.arraycopy(pattern, 0, bytes, cursor, len)
            cursor += len
        }

        // Write map_list at mapOff (4 map_items: HEADER=0x0000, CODE=0x2001, DEBUG=0x2003, MAP=0x1000)
        bb.putInt(mapOff, 4) // map_size = 4
        var mPos = mapOff + 4
        // 1. Header
        bb.putShort(mPos, 0x0000.toShort())
        bb.putShort(mPos + 2, 0)
        bb.putInt(mPos + 4, 1)
        bb.putInt(mPos + 8, 0)
        mPos += 12
        // 2. TYPE_CODE_ITEM (0x2001)
        bb.putShort(mPos, 0x2001.toShort())
        bb.putShort(mPos + 2, 0)
        bb.putInt(mPos + 4, codeCount)
        bb.putInt(mPos + 8, codeSectionOffset)
        mPos += 12
        // 3. TYPE_DEBUG_INFO_ITEM (0x2003)
        bb.putShort(mPos, 0x2003.toShort())
        bb.putShort(mPos + 2, 0)
        bb.putInt(mPos + 4, codeCount)
        bb.putInt(mPos + 8, debugSectionOffset)
        mPos += 12
        // 4. TYPE_MAP_LIST (0x1000)
        bb.putShort(mPos, 0x1000.toShort())
        bb.putShort(mPos + 2, 0)
        bb.putInt(mPos + 4, 1)
        bb.putInt(mPos + 8, mapOff)

        // Compute SHA-1 (offset 12..31) over [32 .. totalSize)
        val sha1 = MessageDigest.getInstance("SHA-1").digest(bytes.copyOfRange(32, totalSize))
        System.arraycopy(sha1, 0, bytes, 12, 20)

        // Compute Adler32 (offset 8..11) over [12 .. totalSize)
        val adler = Adler32()
        adler.update(bytes, 12, totalSize - 12)
        bb.putInt(8, adler.value.toInt())

        return bytes
    }

    /**
     * Builds a valid 64-bit Little-Endian ELF shared library (`0x7F 'E' 'L' 'F'`) with:
     * - Section 0: SHT_NULL
     * - Section 1: `.shstrtab` (`SHT_STRTAB`, `e_shstrndx = 1`)
     * - Section 2: `.text` (`SHT_PROGBITS = 1`, `sh_flags = SHF_ALLOC | SHF_EXECINSTR = 0x6`)
     * - Section 3: `.debug_info` (`SHT_PROGBITS = 1`, `sh_flags = 0x0` non-alloc!) filled with high-entropy debug data
     */
    internal fun buildValidElf64WithDebugSection(totalSize: Int, debugSectionSize: Int): ByteArray {
        val bytes = ByteArray(totalSize)
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        // ELF Magic + 64-bit Little Endian
        bytes[0] = 0x7F
        bytes[1] = 'E'.code.toByte()
        bytes[2] = 'L'.code.toByte()
        bytes[3] = 'F'.code.toByte()
        bytes[4] = 2 // ELFCLASS64
        bytes[5] = 1 // ELFDATA2LSB
        bytes[6] = 1 // EV_CURRENT

        val shEntSize = 64
        val shNum = 4
        val shTableSize = shEntSize * shNum
        val eShoff = totalSize - shTableSize

        val shstrtabOffset = 128
        val shstrtabSize = 64
        val textOffset = 256
        val debugOffset = textOffset + (eShoff - textOffset - debugSectionSize).coerceAtLeast(1024)
        val textSize = debugOffset - textOffset

        // ELF64 Header fields
        bb.putShort(16, 3) // ET_DYN (.so)
        bb.putShort(18, 183) // EM_AARCH64
        bb.putInt(20, 1) // EV_CURRENT
        bb.putLong(32, 0L) // e_phoff = 0
        bb.putLong(40, eShoff.toLong()) // e_shoff
        bb.putShort(52, 64) // e_ehsize
        bb.putShort(58, shEntSize.toShort()) // e_shentsize = 64
        bb.putShort(60, shNum.toShort()) // e_shnum = 4
        bb.putShort(62, 1) // e_shstrndx = 1

        // Fill .text with repetitive instruction patterns
        val codePattern = "Java_com_speedtest_NativeCore_measureLatency\u0000libc.so\u0000".toByteArray()
        var pos = textOffset
        while (pos < debugOffset) {
            val len = minOf(codePattern.size, debugOffset - pos)
            System.arraycopy(codePattern, 0, bytes, pos, len)
            pos += len
        }

        // Fill non-alloc .debug_info [debugOffset .. eShoff) with high-entropy bytes
        for (i in debugOffset until eShoff) {
            bytes[i] = ((i * 197 + (i ushr 6) * 31 + 17) and 0xFF).toByte()
        }

        // Section 1: .shstrtab (SHT_STRTAB = 3)
        val sh1 = eShoff + 1 * shEntSize
        bb.putInt(sh1 + 4, 3) // SHT_STRTAB
        bb.putLong(sh1 + 8, 0L)
        bb.putLong(sh1 + 24, shstrtabOffset.toLong())
        bb.putLong(sh1 + 32, shstrtabSize.toLong())

        // Section 2: .text (SHT_PROGBITS = 1, SHF_ALLOC = 0x2)
        val sh2 = eShoff + 2 * shEntSize
        bb.putInt(sh2 + 4, 1) // SHT_PROGBITS
        bb.putLong(sh2 + 8, 0x6L) // SHF_ALLOC | SHF_EXECINSTR
        bb.putLong(sh2 + 24, textOffset.toLong())
        bb.putLong(sh2 + 32, textSize.toLong())

        // Section 3: .debug_info (SHT_PROGBITS = 1, sh_flags = 0x0 NON-ALLOC!)
        val sh3 = eShoff + 3 * shEntSize
        bb.putInt(sh3 + 4, 1) // SHT_PROGBITS
        bb.putLong(sh3 + 8, 0x0L) // NOT SHF_ALLOC!
        bb.putLong(sh3 + 24, debugOffset.toLong())
        bb.putLong(sh3 + 32, (eShoff - debugOffset).toLong())

        return bytes
    }

    private fun buildLottieJsonPayload(targetSize: Int): ByteArray {
        val frameSnippet = """
            {
                "v": "5.9.0",
                "fr": 59.94005994005994,
                "ip": 0.000000000,
                "op": 180.000000000,
                "w": 1080,
                "h": 1920,
                "nm": "SpeedGaugeAnimation",
                "layers": [
                    {
                        "ty": 4,
                        "nm": "NeedleLayer",
                        "ks": {
                            "o": { "a": 0, "k": 100.00000000 },
                            "r": { "a": 1, "k": [142.85714285714, 285.71428571428, 359.999999999] },
                            "p": { "a": 0, "k": [540.123456789, 960.987654321, 0.000000000] },
                            "s": { "a": 0, "k": [100.00000000, 100.00000000, 100.00000000] }
                        }
                    }
                ]
            },
        """.trimIndent().toByteArray(Charsets.UTF_8)

        val out = ByteArray(targetSize)
        out[0] = '['.code.toByte()
        var pos = 1
        while (pos < targetSize - 2) {
            val len = minOf(frameSnippet.size, targetSize - 2 - pos)
            System.arraycopy(frameSnippet, 0, out, pos, len)
            pos += len
        }
        out[targetSize - 2] = '{'.code.toByte()
        out[targetSize - 1] = ']'.code.toByte()
        return out
    }

    private fun buildRealOrSyntheticPngPayload(
        width: Int,
        height: Int,
        targetFallbackSize: Int
    ): ByteArray {
        return try {
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            try {
                val canvas = Canvas(bmp)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                paint.shader = LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    intArrayOf(Color.rgb(12, 24, 48), Color.rgb(16, 185, 129), Color.rgb(6, 182, 212)),
                    null,
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                for (i in 0 until 200) {
                    paint.shader = null
                    paint.color = Color.argb(190, (i * 47) % 255, (i * 93) % 255, (i * 151) % 255)
                    canvas.drawCircle(
                        ((i * 73) % width).toFloat(),
                        ((i * 119) % height).toFloat(),
                        (10 + (i % 48)).toFloat(),
                        paint
                    )
                }
                val out = ByteArrayOutputStream(65536)
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                val bytes = out.toByteArray()
                if (bytes.size > 4_000) bytes else buildPngFallbackPayload(targetFallbackSize)
            } finally {
                bmp.recycle()
            }
        } catch (_: Throwable) {
            buildPngFallbackPayload(targetFallbackSize)
        }
    }

    private fun buildPngFallbackPayload(size: Int): ByteArray {
        val bytes = ByteArray(size)
        val pngMagic = byteArrayOf(
            0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
        )
        System.arraycopy(pngMagic, 0, bytes, 0, pngMagic.size)
        val pattern = "IDAT_PIXEL_STREAM_RGBA_ROW_FILTER_SUB_UP_AVERAGE_PAETH_".toByteArray()
        var pos = 8
        while (pos < size) {
            val copyLen = minOf(pattern.size, size - pos)
            System.arraycopy(pattern, 0, bytes, pos, copyLen)
            pos += copyLen
        }
        return bytes
    }

    /**
     * Builds a spec-compliant Android Binary XML (AXML, `0x00080003`) `AndroidManifest.xml` containing:
     * - `RES_STRING_POOL_TYPE` (`0x0001`) with UTF-16LE strings
     * - `RES_XML_RESOURCE_MAP_TYPE` (`0x0180`) mapping attribute indices to Android `0x0101xxxx` resource IDs
     * - `<manifest>` start element with `android:isSplitRequired="true"` (`0xFFFFFFFF`) and `android:requiredSplitTypes`
     * - `<application>` start element with `android:extractNativeLibs="true"` and `android:isSplitRequired="true"`
     * - `<meta-data android:name="com.android.vending.splits" android:value="@xml/splits0" />`
     * - `<meta-data android:name="com.android.vending.splits.required" android:value="true" />`
     * - `<meta-data android:name="com.android.dynamic.apk.fused.modules" android:value="base" />`
     * - `<meta-data android:name="com.game.engine.vulkan" android:value="enabled" />` (non-split metadata)
     */
    internal fun buildBinaryManifestPayload(@Suppress("UNUSED_PARAMETER") minTargetSize: Int = 4096): ByteArray {
        val strings = listOf(
            "name",                                     // 0 -> 0x01010003
            "value",                                    // 1 -> 0x01010024
            "minSdkVersion",                            // 2 -> 0x0101020C
            "versionCode",                              // 3 -> 0x0101021B
            "versionName",                              // 4 -> 0x0101021C
            "targetSdkVersion",                         // 5 -> 0x01010270
            "extractNativeLibs",                        // 6 -> 0x010104EA
            "isSplitRequired",                          // 7 -> 0x01010591
            "requiredSplitTypes",                       // 8 -> 0x0101064E
            "splitTypes",                               // 9 -> 0x0101064F
            "http://schemas.android.com/apk/res/android", // 10 (namespace)
            "manifest",                                 // 11
            "uses-sdk",                                 // 12
            "application",                              // 13
            "meta-data",                                // 14
            "package",                                  // 15
            "com.example.samplelegacyapp",              // 16
            "1.0",                                      // 17
            "com.android.vending.splits",               // 18
            "com.android.vending.splits.required",      // 19
            "com.android.dynamic.apk.fused.modules",    // 20
            "com.game.engine.vulkan",                   // 21
            "base__abi,base__density",                  // 22
            "true",                                     // 23
            "base",                                     // 24
            "enabled"                                   // 25
        )
        val resIds = intArrayOf(
            0x01010003, // 0: name
            0x01010024, // 1: value
            0x0101020C, // 2: minSdkVersion
            0x0101021B, // 3: versionCode
            0x0101021C, // 4: versionName
            0x01010270, // 5: targetSdkVersion
            0x010104EA, // 6: extractNativeLibs
            0x01010591, // 7: isSplitRequired
            0x0101064E, // 8: requiredSplitTypes
            0x0101064F  // 9: splitTypes
        )

        // 1. Build RES_STRING_POOL_TYPE (0x0001) in UTF-16LE
        val stringDataBuffer = java.io.ByteArrayOutputStream()
        val stringOffsets = IntArray(strings.size)
        for (i in strings.indices) {
            stringOffsets[i] = stringDataBuffer.size()
            val s = strings[i]
            val charLen = s.length
            // 2-byte LE character length
            stringDataBuffer.write(charLen and 0xFF)
            stringDataBuffer.write((charLen ushr 8) and 0xFF)
            // UTF-16LE bytes
            stringDataBuffer.write(s.toByteArray(Charsets.UTF_16LE))
            // 2-byte null terminator
            stringDataBuffer.write(0)
            stringDataBuffer.write(0)
        }
        while (stringDataBuffer.size() % 4 != 0) {
            stringDataBuffer.write(0)
        }
        val stringDataBytes = stringDataBuffer.toByteArray()
        val stringPoolHeaderSize = 28
        val offsetsSize = strings.size * 4
        val stringsStart = stringPoolHeaderSize + offsetsSize
        val stringPoolChunkSize = stringsStart + stringDataBytes.size
        val stringPoolChunk = ByteBuffer.allocate(stringPoolChunkSize).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(0x0001.toShort()) // RES_STRING_POOL_TYPE
            putShort(stringPoolHeaderSize.toShort())
            putInt(stringPoolChunkSize)
            putInt(strings.size)       // stringCount
            putInt(0)                  // styleCount
            putInt(0)                  // flags (0 = UTF-16LE)
            putInt(stringsStart)       // stringsStart
            putInt(0)                  // stylesStart
            for (off in stringOffsets) {
                putInt(off)
            }
            put(stringDataBytes)
        }.array()

        // 2. Build RES_XML_RESOURCE_MAP_TYPE (0x0180)
        val resMapChunkSize = 8 + resIds.size * 4
        val resMapChunk = ByteBuffer.allocate(resMapChunkSize).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(0x0180.toShort()) // RES_XML_RESOURCE_MAP_TYPE
            putShort(8.toShort())
            putInt(resMapChunkSize)
            for (id in resIds) {
                putInt(id)
            }
        }.array()

        data class AxmlAttr(
            val nsIdx: Int,
            val nameIdx: Int,
            val rawValueIdx: Int,
            val dataType: Int,
            val data: Int
        )

        fun buildStartElementChunk(nameIdx: Int, attrs: List<AxmlAttr>): ByteArray {
            val chunkSize = 36 + attrs.size * 20
            return ByteBuffer.allocate(chunkSize).order(ByteOrder.LITTLE_ENDIAN).apply {
                putShort(0x0102.toShort()) // RES_XML_START_ELEMENT_TYPE
                putShort(16.toShort())     // headerSize
                putInt(chunkSize)
                putInt(1)                  // lineNumber
                putInt(-1)                 // comment
                putInt(-1)                 // ns
                putInt(nameIdx)            // name
                putShort(20.toShort())     // attributeStart
                putShort(20.toShort())     // attributeSize
                putShort(attrs.size.toShort()) // attributeCount
                putShort(0.toShort())      // idIndex
                putShort(0.toShort())      // classIndex
                putShort(0.toShort())      // styleIndex
                for (attr in attrs) {
                    putInt(attr.nsIdx)
                    putInt(attr.nameIdx)
                    putInt(attr.rawValueIdx)
                    putShort(8.toShort())  // typedValue.size = 8
                    put(0.toByte())        // typedValue.res0 = 0
                    put(attr.dataType.toByte())
                    putInt(attr.data)
                }
            }.array()
        }

        fun buildEndElementChunk(nameIdx: Int): ByteArray {
            return ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
                putShort(0x0103.toShort()) // RES_XML_END_ELEMENT_TYPE
                putShort(16.toShort())
                putInt(24)
                putInt(1)
                putInt(-1)
                putInt(-1)
                putInt(nameIdx)
            }.array()
        }

        val nsAndroid = 10
        // <manifest android:versionCode="1" android:versionName="1.0" android:isSplitRequired="true" android:requiredSplitTypes="base__abi,base__density" package="com.example.samplelegacyapp">
        val manifestStart = buildStartElementChunk(
            nameIdx = 11,
            attrs = listOf(
                AxmlAttr(nsAndroid, nameIdx = 3, rawValueIdx = -1, dataType = 0x10, data = 1),  // versionCode = 1
                AxmlAttr(nsAndroid, nameIdx = 4, rawValueIdx = 17, dataType = 0x03, data = 17), // versionName = "1.0"
                AxmlAttr(nsAndroid, nameIdx = 7, rawValueIdx = 23, dataType = 0x12, data = -1), // isSplitRequired = true
                AxmlAttr(nsAndroid, nameIdx = 8, rawValueIdx = 22, dataType = 0x03, data = 22), // requiredSplitTypes
                AxmlAttr(-1, nameIdx = 15, rawValueIdx = 16, dataType = 0x03, data = 16)        // package = "com.example.samplelegacyapp"
            )
        )
        // <uses-sdk android:minSdkVersion="34" android:targetSdkVersion="35" />
        val usesSdkStart = buildStartElementChunk(
            nameIdx = 12,
            attrs = listOf(
                AxmlAttr(nsAndroid, nameIdx = 2, rawValueIdx = -1, dataType = 0x10, data = 34), // minSdkVersion = 34
                AxmlAttr(nsAndroid, nameIdx = 5, rawValueIdx = -1, dataType = 0x10, data = 35)  // targetSdkVersion = 35
            )
        )
        val usesSdkEnd = buildEndElementChunk(12)

        // <application android:extractNativeLibs="true" android:isSplitRequired="true">
        val appStart = buildStartElementChunk(
            nameIdx = 13,
            attrs = listOf(
                AxmlAttr(nsAndroid, nameIdx = 6, rawValueIdx = 23, dataType = 0x12, data = -1), // extractNativeLibs = true
                AxmlAttr(nsAndroid, nameIdx = 7, rawValueIdx = 23, dataType = 0x12, data = -1)  // isSplitRequired = true
            )
        )
        // <meta-data android:name="com.android.vending.splits" android:value="true" />
        val metaSplitsStart = buildStartElementChunk(
            nameIdx = 14,
            attrs = listOf(
                AxmlAttr(nsAndroid, nameIdx = 0, rawValueIdx = 18, dataType = 0x03, data = 18),
                AxmlAttr(nsAndroid, nameIdx = 1, rawValueIdx = 23, dataType = 0x03, data = 23)
            )
        )
        val metaSplitsEnd = buildEndElementChunk(14)

        // <meta-data android:name="com.android.vending.splits.required" android:value="true" />
        val metaSplitsReqStart = buildStartElementChunk(
            nameIdx = 14,
            attrs = listOf(
                AxmlAttr(nsAndroid, nameIdx = 0, rawValueIdx = 19, dataType = 0x03, data = 19),
                AxmlAttr(nsAndroid, nameIdx = 1, rawValueIdx = 23, dataType = 0x12, data = -1)
            )
        )
        val metaSplitsReqEnd = buildEndElementChunk(14)

        // <meta-data android:name="com.android.dynamic.apk.fused.modules" android:value="base" />
        val metaFusedStart = buildStartElementChunk(
            nameIdx = 14,
            attrs = listOf(
                AxmlAttr(nsAndroid, nameIdx = 0, rawValueIdx = 20, dataType = 0x03, data = 20),
                AxmlAttr(nsAndroid, nameIdx = 1, rawValueIdx = 24, dataType = 0x03, data = 24)
            )
        )
        val metaFusedEnd = buildEndElementChunk(14)

        // <meta-data android:name="com.game.engine.vulkan" android:value="enabled" /> (normal non-split tag)
        val metaNormalStart = buildStartElementChunk(
            nameIdx = 14,
            attrs = listOf(
                AxmlAttr(nsAndroid, nameIdx = 0, rawValueIdx = 21, dataType = 0x03, data = 21),
                AxmlAttr(nsAndroid, nameIdx = 1, rawValueIdx = 25, dataType = 0x03, data = 25)
            )
        )
        val metaNormalEnd = buildEndElementChunk(14)

        val appEnd = buildEndElementChunk(13)
        val manifestEnd = buildEndElementChunk(11)

        val bodyOut = java.io.ByteArrayOutputStream()
        bodyOut.write(stringPoolChunk)
        bodyOut.write(resMapChunk)
        bodyOut.write(manifestStart)
        bodyOut.write(usesSdkStart)
        bodyOut.write(usesSdkEnd)
        bodyOut.write(appStart)
        bodyOut.write(metaSplitsStart)
        bodyOut.write(metaSplitsEnd)
        bodyOut.write(metaSplitsReqStart)
        bodyOut.write(metaSplitsReqEnd)
        bodyOut.write(metaFusedStart)
        bodyOut.write(metaFusedEnd)
        bodyOut.write(metaNormalStart)
        bodyOut.write(metaNormalEnd)
        bodyOut.write(appEnd)
        bodyOut.write(manifestEnd)

        val bodyBytes = bodyOut.toByteArray()
        val totalSize = 8 + bodyBytes.size
        return ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN).apply {
            putShort(0x0003.toShort()) // RES_XML_TYPE
            putShort(8.toShort())      // headerSize = 8
            putInt(totalSize)
            put(bodyBytes)
        }.array()
    }

    private fun buildBinaryArscPayload(size: Int): ByteArray {
        val bytes = ByteArray(size)
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        bb.putShort(0x0002.toShort())
        bb.putShort(12.toShort())
        bb.putInt(size)
        bb.putInt(1)
        val poolPattern = "res/drawable-xxhdpi/hero_splash.png\u0000res/layout/activity_main.xml\u0000string/app_name\u0000".toByteArray()
        var pos = 12
        while (pos < size) {
            val copyLen = minOf(poolPattern.size, size - pos)
            System.arraycopy(poolPattern, 0, bytes, pos, copyLen)
            pos += copyLen
        }
        return bytes
    }

    private fun buildWavPayload(size: Int): ByteArray {
        val bytes = ByteArray(size)
        val header = "RIFF....WAVEfmt ".toByteArray()
        System.arraycopy(header, 0, bytes, 0, header.size)
        val wavePattern = byteArrayOf(0, 32, 64, 96, 120, 96, 64, 32, 0, -32, -64, -96, -120, -96, -64, -32)
        var pos = header.size
        while (pos < size) {
            val copyLen = minOf(wavePattern.size, size - pos)
            System.arraycopy(wavePattern, 0, bytes, pos, copyLen)
            pos += copyLen
        }
        return bytes
    }

    private fun buildMetaInfPayload(header: String, size: Int): ByteArray {
        val line = (header + "Name: res/drawable-xxhdpi-v4/hero_splash.png\nSHA-256-Digest: 4B227777D4DD1FC61C6F884F48641D02B4D121D3FD328CB08B5531FCACDABF8A\n\n")
            .toByteArray(Charsets.UTF_8)
        val bytes = ByteArray(size)
        var pos = 0
        while (pos < size) {
            val copyLen = minOf(line.size, size - pos)
            System.arraycopy(line, 0, bytes, pos, copyLen)
            pos += copyLen
        }
        return bytes
    }

    /**
     * Generates Small (~2MB), Medium (~15MB), or Large (~50MB) benchmark APKs for validation testing.
     */
    suspend fun createBenchmarkApk(
        targetFile: File,
        dexCount: Int,
        dexSize: Int,
        soCountPerAbi: Int,
        soSize: Int,
        pngCount: Int,
        pngWidth: Int,
        pngHeight: Int,
        includeLargeStreamEntryBytes: Int = 0
    ): File = withContext(Dispatchers.IO) {
        val samplePng = buildRealOrSyntheticPngPayload(pngWidth, pngHeight, 120_000)
        val sampleSo = buildValidElf64WithDebugSection(soSize, soSize / 3)
        val sampleDex = buildValidStructuredDexPayload(dexSize, dexSize / 3, 1)

        FileOutputStream(targetFile).use { fos ->
            ZipOutputStream(BufferedOutputStream(fos, 64 * 1024)).use { zos ->
                zos.setLevel(Deflater.BEST_SPEED)

                writeEntry(zos, "AndroidManifest.xml", buildBinaryManifestPayload(24_000), stored = false, unalignedPadBytes = 9)
                writeEntry(zos, "resources.arsc", buildBinaryArscPayload(520_000), stored = true, unalignedPadBytes = 15)

                for (d in 1..dexCount) {
                    val dexName = if (d == 1) "classes.dex" else "classes$d.dex"
                    writeEntry(zos, dexName, sampleDex, stored = false, unalignedPadBytes = 7)
                }

                val abis = listOf("arm64-v8a", "armeabi-v7a", "x86_64")
                for (abi in abis) {
                    for (s in 1..soCountPerAbi) {
                        writeEntry(zos, "lib/$abi/libengine_$s.so", sampleSo, stored = true, unalignedPadBytes = 11)
                    }
                }

                for (p in 1..pngCount) {
                    val folder = if (p % 2 == 0) "drawable-xxhdpi-v4" else "drawable-hdpi-v4"
                    writeEntry(zos, "res/$folder/banner_$p.png", samplePng, stored = true, unalignedPadBytes = 19)
                }

                writeEntry(zos, "res/drawable-xxhdpi-v4/button_frame.9.png", buildPngFallbackPayload(24_000), stored = true, unalignedPadBytes = 17)
                writeEntry(zos, "res/raw/speed_gauge_lottie.json", buildLottieJsonPayload(200_000), stored = true, unalignedPadBytes = 7)
                writeEntry(zos, "res/raw/shutter_sound.wav", buildWavPayload(180_000), stored = true, unalignedPadBytes = 13)

                if (includeLargeStreamEntryBytes > 0) {
                    val largeRaw = ByteArray(includeLargeStreamEntryBytes) { idx -> ((idx * 31 + 7) and 0xFF).toByte() }
                    writeEntry(zos, "assets/large_media_pack.pak", largeRaw, stored = true, unalignedPadBytes = 5)
                }

                writeEntry(zos, "META-INF/MANIFEST.MF", buildMetaInfPayload("Manifest-Version: 1.0\n", 48_000), stored = false, unalignedPadBytes = 0)
                writeEntry(zos, "META-INF/CERT.SF", buildMetaInfPayload("Signature-Version: 1.0\n", 48_000), stored = false, unalignedPadBytes = 0)
                writeEntry(zos, "META-INF/CERT.RSA", ByteArray(16_384) { (it and 0xFF).toByte() }, stored = false, unalignedPadBytes = 0)

                zos.finish()
            }
        }
        targetFile
    }

    /**
     * Builds a complete, realistic Split Game archive (`.apks` or `.xapk`) on disk containing:
     * 1. `base.apk`:
     *    - Binary AXML `AndroidManifest.xml` with `android:isSplitRequired="true"` + split `<meta-data>` tags
     *    - `classes.dex` + `resources.arsc` + base `res/` & `assets/` + `META-INF/` signatures
     * 2. `split_config.arm64_v8a.apk`:
     *    - 64-bit native game engine libraries (`lib/arm64-v8a/libunreal_game.so`, `lib/arm64-v8a/libil2cpp.so`)
     * 3. `split_config.armeabi_v7a.apk`:
     *    - 32-bit native game engine library (`lib/armeabi-v7a/libunreal_game.so`)
     * 4. `split_config.xhdpi.apk`:
     *    - High-DPI screen density resources (`res/drawable-xhdpi-v4/hud_radar.png`, `res/drawable-xhdpi-v4/crosshair.png`)
     * 5. `split_config.ar.apk`:
     *    - Arabic language pack resources (`res/values-ar/strings.xml`, `res/raw-ar/narrator_intro.ogg`)
     * 6. `split_asset_pack.apk`:
     *    - Game engine containers (`assets/level1_world.pak`, `assets/bin/Data/sharedassets0.assets`, `assets/audio/fmod_music.bank`)
     * 7. If `isXapk == true`:
     *    - `Android/obb/com.example.game/main.100.com.example.game.obb` expansion file + `manifest.json`
     */
    suspend fun createSampleSplitGameArchive(targetFile: File, isXapk: Boolean): File = withContext(Dispatchers.IO) {
        val tempDir = File(targetFile.parentFile, "sample_split_src_${System.currentTimeMillis()}").apply { mkdirs() }
        val baseApkFile = File(tempDir, "base.apk")
        val arm64ApkFile = File(tempDir, "split_config.arm64_v8a.apk")
        val armv7ApkFile = File(tempDir, "split_config.armeabi_v7a.apk")
        val xhdpiApkFile = File(tempDir, "split_config.xhdpi.apk")
        val arLangApkFile = File(tempDir, "split_config.ar.apk")
        val assetPackApkFile = File(tempDir, "split_asset_pack.apk")

        try {
            // 1. Build base.apk (with Binary AXML AndroidManifest.xml where isSplitRequired="true")
            FileOutputStream(baseApkFile).use { fos ->
                ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                    writeEntry(zos, "AndroidManifest.xml", buildBinaryManifestPayload(), stored = false)
                    writeEntry(zos, "resources.arsc", buildBinaryArscPayload(120_000), stored = true, unalignedPadBytes = 11)
                    writeEntry(zos, "classes.dex", buildValidStructuredDexPayload(320_000, 100_000, seed = 10), stored = false)
                    writeEntry(zos, "assets/engine_config.json", """{"graphics":"vulkan","shadows":true,"target_fps":60}""".toByteArray(), stored = false)
                    writeEntry(zos, "META-INF/MANIFEST.MF", buildMetaInfPayload("Manifest-Version: 1.0\n", 12_000), stored = false)
                    writeEntry(zos, "META-INF/CERT.SF", buildMetaInfPayload("Signature-Version: 1.0\n", 12_000), stored = false)
                    writeEntry(zos, "META-INF/CERT.RSA", ByteArray(4_096) { (it and 0xFF).toByte() }, stored = false)
                    zos.finish()
                }
            }

            // 2. Build split_config.arm64_v8a.apk (64-bit native libraries)
            FileOutputStream(arm64ApkFile).use { fos ->
                ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                    writeEntry(zos, "AndroidManifest.xml", buildBinaryManifestPayload(), stored = false)
                    writeEntry(
                        zos,
                        "lib/arm64-v8a/libunreal_game.so",
                        buildValidElf64WithDebugSection(380_000, 120_000),
                        stored = true,
                        unalignedPadBytes = 13
                    )
                    writeEntry(
                        zos,
                        "lib/arm64-v8a/libil2cpp.so",
                        buildValidElf64WithDebugSection(260_000, 80_000),
                        stored = true,
                        unalignedPadBytes = 7
                    )
                    writeEntry(zos, "META-INF/MANIFEST.MF", buildMetaInfPayload("Manifest-Version: 1.0\n", 4_096), stored = false)
                    zos.finish()
                }
            }

            // 3. Build split_config.armeabi_v7a.apk (32-bit native library)
            FileOutputStream(armv7ApkFile).use { fos ->
                ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                    writeEntry(zos, "AndroidManifest.xml", buildBinaryManifestPayload(), stored = false)
                    writeEntry(
                        zos,
                        "lib/armeabi-v7a/libunreal_game.so",
                        buildValidElf64WithDebugSection(320_000, 100_000),
                        stored = true,
                        unalignedPadBytes = 7
                    )
                    writeEntry(zos, "META-INF/MANIFEST.MF", buildMetaInfPayload("Manifest-Version: 1.0\n", 4_096), stored = false)
                    zos.finish()
                }
            }

            // 4. Build split_config.xhdpi.apk (screen density resources)
            FileOutputStream(xhdpiApkFile).use { fos ->
                ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                    writeEntry(zos, "AndroidManifest.xml", buildBinaryManifestPayload(), stored = false)
                    writeEntry(zos, "res/drawable-xhdpi-v4/hud_radar.png", buildPngFallbackPayload(48_000), stored = false)
                    writeEntry(zos, "res/drawable-xhdpi-v4/weapon_crosshair.png", buildPngFallbackPayload(32_000), stored = false)
                    writeEntry(zos, "res/layout/game_hud_overlay.xml", "<FrameLayout/>".repeat(200).toByteArray(), stored = false)
                    writeEntry(zos, "META-INF/MANIFEST.MF", buildMetaInfPayload("Manifest-Version: 1.0\n", 4_096), stored = false)
                    zos.finish()
                }
            }

            // 5. Build split_config.ar.apk (language pack resources)
            FileOutputStream(arLangApkFile).use { fos ->
                ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                    writeEntry(zos, "AndroidManifest.xml", buildBinaryManifestPayload(), stored = false)
                    writeEntry(zos, "res/values-ar/strings.xml", "<resources><string name=\"start\">ابدأ اللعب</string></resources>".repeat(120).toByteArray(), stored = false)
                    writeEntry(zos, "res/raw-ar/voice_intro.wav", buildWavPayload(64_000), stored = false)
                    writeEntry(zos, "META-INF/MANIFEST.MF", buildMetaInfPayload("Manifest-Version: 1.0\n", 4_096), stored = false)
                    zos.finish()
                }
            }

            // 6. Build split_asset_pack.apk (game engine .pak, .assets, .bank)
            FileOutputStream(assetPackApkFile).use { fos ->
                ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                    writeEntry(zos, "AndroidManifest.xml", buildBinaryManifestPayload(), stored = false)
                    val pakPayload = ByteArray(180_000) { ((it * 13 + 7) and 0xFF).toByte() }
                    writeEntry(zos, "assets/level1_world.pak", pakPayload, stored = false, unalignedPadBytes = 15)

                    val unityAssetPayload = ByteArray(140_000) { ((it * 5 + 3) and 0xFF).toByte() }
                    writeEntry(zos, "assets/bin/Data/sharedassets0.assets", unityAssetPayload, stored = false, unalignedPadBytes = 3)

                    val unityResSPayload = ByteArray(110_000) { ((it * 11 + 5) and 0xFF).toByte() }
                    writeEntry(zos, "assets/bin/Data/sharedassets0.assets.resS", unityResSPayload, stored = false, unalignedPadBytes = 5)

                    val bankPayload = ByteArray(96_000) { ((it * 19 + 11) and 0xFF).toByte() }
                    writeEntry(zos, "assets/audio/fmod_music.bank", bankPayload, stored = false)
                    writeEntry(zos, "META-INF/MANIFEST.MF", buildMetaInfPayload("Manifest-Version: 1.0\n", 4_096), stored = false)
                    zos.finish()
                }
            }

            // Repackage all into targetFile (.apks or .xapk)
            FileOutputStream(targetFile).use { fos ->
                ZipOutputStream(BufferedOutputStream(fos)).use { zos ->
                    zos.setLevel(Deflater.BEST_SPEED)

                    writeEntry(zos, "base.apk", baseApkFile.readBytes(), stored = false)
                    writeEntry(zos, "split_config.arm64_v8a.apk", arm64ApkFile.readBytes(), stored = false)
                    writeEntry(zos, "split_config.armeabi_v7a.apk", armv7ApkFile.readBytes(), stored = false)
                    writeEntry(zos, "split_config.xhdpi.apk", xhdpiApkFile.readBytes(), stored = false)
                    writeEntry(zos, "split_config.ar.apk", arLangApkFile.readBytes(), stored = false)
                    writeEntry(zos, "split_asset_pack.apk", assetPackApkFile.readBytes(), stored = false)

                    val manifestJson = """
                        {
                            "package_name": "com.example.universalgame",
                            "version_code": 100,
                            "version_name": "1.0.0",
                            "split_apks": [
                                "base.apk",
                                "split_config.arm64_v8a.apk",
                                "split_config.armeabi_v7a.apk",
                                "split_config.xhdpi.apk",
                                "split_config.ar.apk",
                                "split_asset_pack.apk"
                            ]
                        }
                    """.trimIndent().toByteArray(Charsets.UTF_8)
                    writeEntry(zos, "manifest.json", manifestJson, stored = false)

                    if (isXapk) {
                        val obbPayload = ByteArray(220_000) { ((it * 7 + 1) and 0xFF).toByte() }
                        writeEntry(
                            zos,
                            "Android/obb/com.example.universalgame/main.100.com.example.universalgame.obb",
                            obbPayload,
                            stored = true,
                            unalignedPadBytes = 9
                        )
                    }

                    zos.finish()
                }
            }
        } finally {
            tempDir.deleteRecursively()
        }
        targetFile
    }
}
