package com.example.engine

import org.jf.dexlib2.AccessFlags
import org.jf.dexlib2.Opcode
import org.jf.dexlib2.Opcodes
import org.jf.dexlib2.iface.ClassDef
import org.jf.dexlib2.iface.Method
import org.jf.dexlib2.iface.instruction.Instruction
import org.jf.dexlib2.immutable.ImmutableClassDef
import org.jf.dexlib2.immutable.ImmutableField
import org.jf.dexlib2.immutable.ImmutableMethod
import org.jf.dexlib2.immutable.ImmutableMethodImplementation
import org.jf.dexlib2.immutable.ImmutableMethodParameter
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction10t
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction10x
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction11n
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction11x
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction12x
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction20t
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction21c
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction21ih
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction21lh
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction21s
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction21t
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction22b
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction22c
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction22s
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction22t
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction22x
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction23x
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction31c
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction31i
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction35c
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction3rc
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction51l
import org.jf.dexlib2.immutable.reference.ImmutableFieldReference
import org.jf.dexlib2.immutable.reference.ImmutableMethodReference
import org.jf.dexlib2.immutable.reference.ImmutableStringReference
import org.jf.dexlib2.immutable.reference.ImmutableTypeReference
import org.jf.dexlib2.immutable.value.ImmutableBooleanEncodedValue
import org.jf.dexlib2.immutable.value.ImmutableEncodedValue
import org.jf.dexlib2.immutable.value.ImmutableIntEncodedValue
import org.jf.dexlib2.immutable.value.ImmutableNullEncodedValue
import org.jf.dexlib2.immutable.value.ImmutableStringEncodedValue
import org.jf.dexlib2.writer.io.FileDataStore
import org.jf.dexlib2.writer.pool.DexPool
import java.io.File

/**
 * ================================================================================================
 * Pure `dexlib2` Direct Bytecode & Method Builder (`Dexlib2SmaliAssembler.kt`)
 * ================================================================================================
 *
 * Replaces the heavy `org.smali:smali` and `org.smali:baksmali` dependencies by constructing
 * `ImmutableClassDef`, `ImmutableField`, `ImmutableMethod`, and `ImmutableInstruction` objects
 * directly through `org.smali:dexlib2:2.5.2`.
 */
object Dexlib2SmaliAssembler {

    /**
     * Parses one or more `.class ...` blocks and writes them directly to [outputDexFile]
     * using `org.jf.dexlib2.writer.pool.DexPool`.
     */
    fun assembleSmaliSourcesToDexFile(
        smaliSources: List<String>,
        outputDexFile: File,
        apiLevel: Int = 26
    ): Boolean {
        val classes = mutableListOf<ImmutableClassDef>()
        for (source in smaliSources) {
            classes.addAll(parseSmaliClasses(source))
        }
        if (classes.isEmpty()) return false

        val dexPool = DexPool(Opcodes.forApi(apiLevel.coerceAtLeast(15)))
        for (cls in classes) {
            dexPool.internClass(cls)
        }
        outputDexFile.parentFile?.mkdirs()
        dexPool.writeTo(FileDataStore(outputDexFile))
        return outputDexFile.exists() && outputDexFile.length() > 0L
    }

    /**
     * Parses a raw string containing one or more `.class ...` definitions into [ImmutableClassDef]s
     * using pure `dexlib2` immutable models.
     */
    fun parseSmaliClasses(rawSmaliText: String): List<ImmutableClassDef> {
        val classBlocks = splitIntoClassBlocks(rawSmaliText)
        return classBlocks.map { parseSingleClassBlock(it) }
    }

    /**
     * Disassembles a [ClassDef] into clean, human-readable Smali text using pure `dexlib2`
     * without requiring `org.smali:baksmali`.
     */
    fun disassembleClassDefToSmali(classDef: ClassDef): String {
        return buildString {
            appendLine(".class public ${classDef.type}")
            appendLine(".super ${classDef.superclass ?: "Ljava/lang/Object;"}")
            classDef.sourceFile?.let { appendLine(".source \"$it\"") }
            appendLine()

            for (field in classDef.fields) {
                val flags = AccessFlags.formatAccessFlagsForField(field.accessFlags)
                val flagPart = if (flags.isNotEmpty()) "$flags " else ""
                appendLine(".field $flagPart${field.name}:${field.type}")
            }
            if (classDef.fields.any()) appendLine()

            for (method in classDef.methods) {
                val flags = AccessFlags.formatAccessFlagsForMethod(method.accessFlags)
                val flagPart = if (flags.isNotEmpty()) "$flags " else ""
                val params = method.parameterTypes.joinToString("")
                appendLine(".method $flagPart${method.name}($params)${method.returnType}")
                val impl = method.implementation
                if (impl != null) {
                    val paramRegs = countParameterRegisters(
                        isStatic = (method.accessFlags and AccessFlags.STATIC.value) != 0,
                        parameterTypes = method.parameterTypes.map { it.toString() }
                    )
                    val locals = (impl.registerCount - paramRegs).coerceAtLeast(0)
                    appendLine("    .locals $locals")
                    for (insn in impl.instructions) {
                        appendLine("    ${insn.opcode.name.lowercase().replace('_', '-')}")
                    }
                }
                appendLine(".end method")
                appendLine()
            }
        }.trimEnd()
    }

    private fun splitIntoClassBlocks(rawSmali: String): List<String> {
        val blocks = mutableListOf<StringBuilder>()
        var current: StringBuilder? = null
        for (line in rawSmali.lines()) {
            val trimmed = line.trimStart()
            if (trimmed.startsWith(".class ")) {
                current?.let {
                    if (it.isNotBlank()) blocks.add(it)
                }
                current = StringBuilder().appendLine(line)
            } else {
                current?.appendLine(line)
            }
        }
        current?.let {
            if (it.isNotBlank()) blocks.add(it)
        }
        return blocks.map { it.toString() }
    }

    private data class SourceLine(
        val lineNumber: Int,
        val methodLineNumber: Int,
        val text: String
    )

    private fun parseSingleClassBlock(classBlock: String): ImmutableClassDef {
        var classDescriptor = ""
        var classAccessFlags = AccessFlags.PUBLIC.value
        var superclassDescriptor = "Ljava/lang/Object;"
        val interfaces = mutableListOf<String>()
        var sourceFile: String? = null
        val staticFields = mutableListOf<ImmutableField>()
        val instanceFields = mutableListOf<ImmutableField>()
        val directMethods = mutableListOf<ImmutableMethod>()
        val virtualMethods = mutableListOf<ImmutableMethod>()

        val lines = classBlock.lines()
        var idx = 0
        while (idx < lines.size) {
            val lineNum = idx + 1
            val rawLine = lines[idx]
            val line = stripComment(rawLine).trim()
            if (line.isEmpty()) {
                idx++
                continue
            }

            try {
                when {
                    line.startsWith(".class ") -> {
                        val tokens = line.removePrefix(".class ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                        require(tokens.isNotEmpty()) { "Empty .class directive at line $lineNum" }
                        classDescriptor = normalizeTypeDescriptor(tokens.last())
                        classAccessFlags = parseClassAccessFlags(tokens.dropLast(1))
                        if (classAccessFlags == 0) classAccessFlags = AccessFlags.PUBLIC.value
                    }
                    line.startsWith(".super ") -> {
                        superclassDescriptor = normalizeTypeDescriptor(line.removePrefix(".super ").trim())
                    }
                    line.startsWith(".implements ") -> {
                        interfaces.add(normalizeTypeDescriptor(line.removePrefix(".implements ").trim()))
                    }
                    line.startsWith(".source ") -> {
                        sourceFile = line.removePrefix(".source ").trim().removeSurrounding("\"")
                    }
                    line.startsWith(".annotation") -> {
                        while (idx < lines.size) {
                            val aLine = stripComment(lines[idx]).trim()
                            if (aLine.startsWith(".end annotation")) break
                            idx++
                        }
                    }
                    line.startsWith(".field ") -> {
                        val field = parseFieldDirective(classDescriptor, line)
                        if ((field.accessFlags and AccessFlags.STATIC.value) != 0) {
                            staticFields.add(field)
                        } else {
                            instanceFields.add(field)
                        }
                        // If field has a multi-line .annotation block, skip until .end field
                        if (idx + 1 < lines.size) {
                            var lookAhead = idx + 1
                            var hasEndField = false
                            while (lookAhead < lines.size) {
                                val nextClean = stripComment(lines[lookAhead]).trim()
                                if (nextClean.isEmpty()) {
                                    lookAhead++
                                    continue
                                }
                                if (nextClean.startsWith(".annotation")) {
                                    hasEndField = true
                                    break
                                } else {
                                    break
                                }
                            }
                            if (hasEndField) {
                                while (idx < lines.size) {
                                    val fLine = stripComment(lines[idx]).trim()
                                    if (fLine.startsWith(".end field")) break
                                    idx++
                                }
                            }
                        }
                    }
                    line.startsWith(".method ") -> {
                        val methodStartLine = lineNum
                        val methodLines = mutableListOf<SourceLine>()
                        methodLines.add(SourceLine(lineNumber = lineNum, methodLineNumber = 1, text = line))
                        idx++
                        var foundEnd = false
                        var relLine = 2
                        while (idx < lines.size) {
                            val mLineNum = idx + 1
                            val mLine = stripComment(lines[idx]).trim()
                            methodLines.add(
                                SourceLine(
                                    lineNumber = mLineNum,
                                    methodLineNumber = relLine,
                                    text = mLine
                                )
                            )
                            relLine++
                            if (mLine.startsWith(".end method")) {
                                foundEnd = true
                                break
                            }
                            idx++
                        }
                        require(foundEnd) {
                            "Syntax error at line $methodStartLine: Method block in class ($classDescriptor) is missing '.end method'."
                        }
                        val method = parseMethodBlock(classDescriptor, methodLines)
                        val isDirect = (method.accessFlags and (AccessFlags.STATIC.value or AccessFlags.PRIVATE.value or AccessFlags.CONSTRUCTOR.value)) != 0 ||
                            method.name == "<init>" || method.name == "<clinit>"
                        if (isDirect) {
                            directMethods.add(method)
                        } else {
                            virtualMethods.add(method)
                        }
                    }
                    else -> {
                        throw IllegalArgumentException(
                            "Unexpected class-level directive at line $lineNum: '$line'"
                        )
                    }
                }
            } catch (e: Exception) {
                if (e.message?.contains("Line ", ignoreCase = true) == true) {
                    throw e
                }
                throw IllegalArgumentException(
                    "Smali syntax error at Line $lineNum ('$line'): ${e.message}",
                    e
                )
            }
            idx++
        }

        require(classDescriptor.isNotEmpty()) {
            "Smali syntax error at Line 1: Missing valid '.class' header."
        }

        return ImmutableClassDef(
            classDescriptor,
            classAccessFlags,
            superclassDescriptor,
            interfaces,
            sourceFile,
            emptySet(),
            staticFields,
            instanceFields,
            directMethods,
            virtualMethods
        )
    }

    private fun parseFieldDirective(definingClass: String, line: String): ImmutableField {
        val body = line.removePrefix(".field ").trim()
        val beforeEq = body.substringBefore("=").trim()
        val initialValRaw = if (body.contains("=")) body.substringAfter("=").trim() else null

        val tokens = beforeEq.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val nameAndType = tokens.last()
        require(nameAndType.contains(":")) {
            "صياغة الحقل غير صالحة (Invalid field syntax): $line"
        }
        val fieldName = nameAndType.substringBefore(":").trim()
        val fieldType = nameAndType.substringAfter(":").trim()
        val accessFlags = parseFieldAccessFlags(tokens.dropLast(1))

        val initialValue: ImmutableEncodedValue? = if (initialValRaw != null) {
            parseFieldInitialValue(fieldType, initialValRaw)
        } else {
            null
        }

        return ImmutableField(
            definingClass,
            fieldName,
            fieldType,
            accessFlags,
            initialValue,
            emptySet(),
            emptySet()
        )
    }

    private fun parseFieldInitialValue(fieldType: String, rawVal: String): ImmutableEncodedValue? {
        return when {
            rawVal == "null" -> ImmutableNullEncodedValue.INSTANCE
            rawVal.startsWith("\"") && rawVal.endsWith("\"") -> {
                ImmutableStringEncodedValue(unescapeSmaliString(rawVal.substring(1, rawVal.length - 1)))
            }
            fieldType == "Z" -> {
                val boolVal = rawVal.equals("true", ignoreCase = true) || rawVal == "0x1" || rawVal == "1"
                ImmutableBooleanEncodedValue.forBoolean(boolVal)
            }
            fieldType == "I" || fieldType == "S" || fieldType == "B" -> {
                ImmutableIntEncodedValue(parseSmaliIntLiteral(rawVal))
            }
            else -> null
        }
    }

    private fun parseMethodBlock(definingClass: String, methodLines: List<SourceLine>): ImmutableMethod {
        val headerSourceLine = methodLines.first()
        val header = headerSourceLine.text.removePrefix(".method ").trim()
        val headerTokens = header.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val sigToken = headerTokens.lastOrNull().orEmpty()
        require(sigToken.contains("(") && sigToken.contains(")")) {
            "Smali syntax error at Line ${headerSourceLine.methodLineNumber} (source line ${headerSourceLine.lineNumber}): Invalid method signature '${headerSourceLine.text}'"
        }

        val methodName = sigToken.substringBefore("(").trim()
        val paramsDesc = sigToken.substringAfter("(").substringBefore(")").trim()
        val returnType = sigToken.substringAfter(")").trim()
        require(methodName.isNotEmpty() && returnType.isNotEmpty()) {
            "Smali syntax error at Line ${headerSourceLine.methodLineNumber} (source line ${headerSourceLine.lineNumber}): Empty method name or return type in '${headerSourceLine.text}'"
        }

        var accessFlags = parseMethodAccessFlags(headerTokens.dropLast(1))
        if (methodName == "<init>" || methodName == "<clinit>") {
            accessFlags = accessFlags or AccessFlags.CONSTRUCTOR.value
        }
        if (accessFlags == 0) {
            accessFlags = AccessFlags.PUBLIC.value
        }

        val paramTypes = try {
            splitParameterDescriptors(paramsDesc)
        } catch (e: Exception) {
            throw IllegalArgumentException(
                "Smali syntax error at Line ${headerSourceLine.methodLineNumber} (source line ${headerSourceLine.lineNumber}) in parameter list '($paramsDesc)': ${e.message}",
                e
            )
        }
        val isStatic = (accessFlags and AccessFlags.STATIC.value) != 0
        val paramRegCount = countParameterRegisters(isStatic, paramTypes)

        var localsCount = 0
        var explicitRegistersCount: Int? = null
        val paramNames = HashMap<Int, String>()

        val bodyLines = methodLines.drop(1).dropLast(1)
        val rawStatements = mutableListOf<SourceLine>()

        var bIdx = 0
        while (bIdx < bodyLines.size) {
            val srcLine = bodyLines[bIdx]
            val stmt = srcLine.text.trim()
            if (stmt.isEmpty()) {
                bIdx++
                continue
            }
            when {
                stmt.startsWith(".locals ") -> {
                    val rawNum = stmt.removePrefix(".locals ").trim()
                    localsCount = rawNum.toIntOrNull()
                        ?: throw IllegalArgumentException(
                            "Smali syntax error at Line ${srcLine.methodLineNumber} (source line ${srcLine.lineNumber}): Invalid .locals count '$rawNum' in '$stmt'"
                        )
                }
                stmt.startsWith(".registers ") -> {
                    val rawNum = stmt.removePrefix(".registers ").trim()
                    explicitRegistersCount = rawNum.toIntOrNull()
                        ?: throw IllegalArgumentException(
                            "Smali syntax error at Line ${srcLine.methodLineNumber} (source line ${srcLine.lineNumber}): Invalid .registers count '$rawNum' in '$stmt'"
                        )
                }
                stmt.startsWith(".param ") -> {
                    val pMatch = Regex("""\.param\s+p(\d+)(?:,\s*"([^"]*)")?""").find(stmt)
                    if (pMatch != null) {
                        val pIdx = pMatch.groupValues[1].toIntOrNull() ?: 0
                        val pName = pMatch.groupValues.getOrNull(2)?.takeIf { it.isNotEmpty() }
                        if (pName != null) paramNames[pIdx] = pName
                    }
                }
                stmt.startsWith(".annotation") -> {
                    while (bIdx < bodyLines.size) {
                        if (bodyLines[bIdx].text.trim().startsWith(".end annotation")) break
                        bIdx++
                    }
                }
                stmt.startsWith(".subannotation") -> {
                    while (bIdx < bodyLines.size) {
                        if (bodyLines[bIdx].text.trim().startsWith(".end subannotation")) break
                        bIdx++
                    }
                }
                stmt.startsWith(".prologue") ||
                    stmt.startsWith(".line ") ||
                    stmt.startsWith(".local ") ||
                    stmt.startsWith(".end local") ||
                    stmt.startsWith(".restart local") ||
                    stmt.startsWith(".end param") ||
                    stmt.startsWith(".catch ") ||
                    stmt.startsWith(".catchall ") ||
                    stmt.startsWith(".end annotation") -> {
                    // Skip non-bytecode debug/metadata directives
                }
                else -> {
                    rawStatements.add(srcLine.copy(text = stmt))
                }
            }
            bIdx++
        }

        val totalRegisters = explicitRegistersCount ?: (localsCount + paramRegCount)
        val resolvedLocals = (totalRegisters - paramRegCount).coerceAtLeast(0)

        val methodParams = paramTypes.mapIndexed { i, typeStr ->
            val name = paramNames[if (isStatic) i else i + 1]
            ImmutableMethodParameter(typeStr, emptySet(), name)
        }

        val isAbstractOrNative = (accessFlags and (AccessFlags.ABSTRACT.value or AccessFlags.NATIVE.value)) != 0
        if (isAbstractOrNative) {
            return ImmutableMethod(
                definingClass,
                methodName,
                methodParams,
                returnType,
                accessFlags,
                emptySet(),
                emptySet(),
                null
            )
        }

        val instructions = parseInstructionsTwoPass(
            statements = rawStatements,
            localsCount = resolvedLocals,
            paramRegCount = paramRegCount,
            methodSignature = "$definingClass->$sigToken"
        )

        val implementation = ImmutableMethodImplementation(
            totalRegisters.coerceAtLeast(paramRegCount),
            instructions,
            emptyList(),
            emptyList()
        )

        return ImmutableMethod(
            definingClass,
            methodName,
            methodParams,
            returnType,
            accessFlags,
            emptySet(),
            emptySet(),
            implementation
        )
    }

    private sealed class ParsedStatement {
        data class Label(val name: String) : ParsedStatement()
        data class Insn(
            val lineNumber: Int,
            val methodLineNumber: Int,
            val rawLine: String,
            val opcodeName: String,
            val argsText: String,
            val codeUnits: Int,
            val startCodeOffset: Int
        ) : ParsedStatement()
    }

    private fun parseInstructionsTwoPass(
        statements: List<SourceLine>,
        localsCount: Int,
        paramRegCount: Int,
        methodSignature: String
    ): List<Instruction> {
        val labelOffsets = HashMap<String, Int>()
        val insnList = mutableListOf<ParsedStatement.Insn>()
        var currentCodeOffset = 0

        for (srcLine in statements) {
            val stmt = srcLine.text
            if (stmt.startsWith(":")) {
                val labelName = stmt.substringBefore(" ").trim()
                labelOffsets[labelName] = currentCodeOffset
            } else {
                val spaceIdx = stmt.indexOfFirst { it.isWhitespace() }
                val opName = if (spaceIdx > 0) stmt.substring(0, spaceIdx).trim() else stmt
                val argsText = if (spaceIdx > 0) stmt.substring(spaceIdx + 1).trim() else ""
                val units = try {
                    estimateInstructionCodeUnits(opName)
                } catch (e: Exception) {
                    throw IllegalArgumentException(
                        "Smali syntax error in $methodSignature at Line ${srcLine.methodLineNumber} (source line ${srcLine.lineNumber}) ['$stmt']: ${e.message}",
                        e
                    )
                }
                insnList.add(
                    ParsedStatement.Insn(
                        lineNumber = srcLine.lineNumber,
                        methodLineNumber = srcLine.methodLineNumber,
                        rawLine = stmt,
                        opcodeName = opName,
                        argsText = argsText,
                        codeUnits = units,
                        startCodeOffset = currentCodeOffset
                    )
                )
                currentCodeOffset += units
            }
        }

        return insnList.map { insn ->
            try {
                buildImmutableInstruction(
                    insn = insn,
                    localsCount = localsCount,
                    paramRegCount = paramRegCount,
                    labelOffsets = labelOffsets
                )
            } catch (e: Exception) {
                throw IllegalArgumentException(
                    "Smali syntax error in $methodSignature at Line ${insn.methodLineNumber} (source line ${insn.lineNumber}) ['${insn.rawLine}']: ${e.message}",
                    e
                )
            }
        }
    }

    private fun estimateInstructionCodeUnits(opName: String): Int {
        return when (opName) {
            "nop",
            "return-void",
            "return",
            "return-wide",
            "return-object",
            "move",
            "move-wide",
            "move-object",
            "move-result",
            "move-result-wide",
            "move-result-object",
            "move-exception",
            "const/4",
            "goto",
            "and-int/2addr",
            "or-int/2addr",
            "xor-int/2addr",
            "add-int/2addr",
            "sub-int/2addr",
            "mul-int/2addr",
            "div-int/2addr" -> 1

            "const/16",
            "const/high16",
            "const-wide/16",
            "const-wide/high16",
            "const-string",
            "const-class",
            "check-cast",
            "new-instance",
            "new-array",
            "instance-of",
            "array-length",
            "goto/16",
            "if-eq",
            "if-ne",
            "if-lt",
            "if-ge",
            "if-gt",
            "if-le",
            "if-eqz",
            "if-nez",
            "if-ltz",
            "if-gez",
            "if-gtz",
            "if-lez",
            "sget",
            "sget-wide",
            "sget-object",
            "sget-boolean",
            "sget-byte",
            "sget-char",
            "sget-short",
            "sput",
            "sput-wide",
            "sput-object",
            "sput-boolean",
            "sput-byte",
            "sput-char",
            "sput-short",
            "iget",
            "iget-wide",
            "iget-object",
            "iget-boolean",
            "iget-byte",
            "iget-char",
            "iget-short",
            "iput",
            "iput-wide",
            "iput-object",
            "iput-boolean",
            "iput-byte",
            "iput-char",
            "iput-short",
            "add-int/lit8",
            "rsub-int/lit8",
            "mul-int/lit8",
            "div-int/lit8",
            "rem-int/lit8",
            "and-int/lit8",
            "or-int/lit8",
            "xor-int/lit8",
            "add-int/lit16",
            "rsub-int",
            "mul-int/lit16",
            "div-int/lit16",
            "rem-int/lit16",
            "and-int/lit16",
            "or-int/lit16",
            "xor-int/lit16",
            "add-int",
            "sub-int",
            "mul-int",
            "div-int",
            "rem-int",
            "and-int",
            "or-int",
            "xor-int",
            "move/from16",
            "move-wide/from16",
            "move-object/from16" -> 2

            "const",
            "const-wide/32",
            "const-string/jumbo",
            "invoke-virtual",
            "invoke-super",
            "invoke-direct",
            "invoke-static",
            "invoke-interface",
            "invoke-virtual/range",
            "invoke-super/range",
            "invoke-direct/range",
            "invoke-static/range",
            "invoke-interface/range" -> 3

            "const-wide" -> 5
            else -> throw IllegalArgumentException("تعليمة Smali غير مدعومة أو تحتوي على خطأ صياغة: $opName")
        }
    }

    private fun buildImmutableInstruction(
        insn: ParsedStatement.Insn,
        localsCount: Int,
        paramRegCount: Int,
        labelOffsets: Map<String, Int>
    ): Instruction {
        val opName = insn.opcodeName
        val args = insn.argsText

        fun reg(token: String): Int = parseRegisterIndex(token.trim(), localsCount, paramRegCount)

        return when (opName) {
            "nop" -> ImmutableInstruction10x(Opcode.NOP)
            "return-void" -> ImmutableInstruction10x(Opcode.RETURN_VOID)

            "return" -> ImmutableInstruction11x(Opcode.RETURN, reg(args))
            "return-wide" -> ImmutableInstruction11x(Opcode.RETURN_WIDE, reg(args))
            "return-object" -> ImmutableInstruction11x(Opcode.RETURN_OBJECT, reg(args))
            "move-result" -> ImmutableInstruction11x(Opcode.MOVE_RESULT, reg(args))
            "move-result-wide" -> ImmutableInstruction11x(Opcode.MOVE_RESULT_WIDE, reg(args))
            "move-result-object" -> ImmutableInstruction11x(Opcode.MOVE_RESULT_OBJECT, reg(args))
            "move-exception" -> ImmutableInstruction11x(Opcode.MOVE_EXCEPTION, reg(args))

            "const/4" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const/4 غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction11n(Opcode.CONST_4, reg(parts[0]), parseSmaliIntLiteral(parts[1]))
            }

            "const/16" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const/16 غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction21s(Opcode.CONST_16, reg(parts[0]), parseSmaliIntLiteral(parts[1]))
            }

            "const" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction31i(Opcode.CONST, reg(parts[0]), parseSmaliIntLiteral(parts[1]))
            }

            "const/high16" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const/high16 غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction21ih(Opcode.CONST_HIGH16, reg(parts[0]), parseSmaliIntLiteral(parts[1]))
            }

            "const-wide/16" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const-wide/16 غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction21s(Opcode.CONST_WIDE_16, reg(parts[0]), parseSmaliIntLiteral(parts[1]))
            }

            "const-wide/32" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const-wide/32 غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction31i(Opcode.CONST_WIDE_32, reg(parts[0]), parseSmaliIntLiteral(parts[1]))
            }

            "const-wide/high16" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const-wide/high16 غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction21lh(Opcode.CONST_WIDE_HIGH16, reg(parts[0]), parseSmaliLongLiteral(parts[1]))
            }

            "const-wide" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة const-wide غير صالحة: ${insn.rawLine}" }
                ImmutableInstruction51l(Opcode.CONST_WIDE, reg(parts[0]), parseSmaliLongLiteral(parts[1]))
            }

            "const-string" -> {
                val commaIdx = args.indexOf(',')
                require(commaIdx > 0) { "صياغة const-string غير صالحة: ${insn.rawLine}" }
                val regNum = reg(args.substring(0, commaIdx))
                val rawStr = args.substring(commaIdx + 1).trim()
                require(rawStr.startsWith("\"") && rawStr.endsWith("\"")) {
                    "نص const-string يجب أن يكون محاطاً بعلامتي تنصيص: ${insn.rawLine}"
                }
                val strVal = unescapeSmaliString(rawStr.substring(1, rawStr.length - 1))
                ImmutableInstruction21c(Opcode.CONST_STRING, regNum, ImmutableStringReference(strVal))
            }

            "const-string/jumbo" -> {
                val commaIdx = args.indexOf(',')
                require(commaIdx > 0) { "صياغة const-string/jumbo غير صالحة: ${insn.rawLine}" }
                val regNum = reg(args.substring(0, commaIdx))
                val rawStr = args.substring(commaIdx + 1).trim().removeSurrounding("\"")
                ImmutableInstruction31c(Opcode.CONST_STRING_JUMBO, regNum, ImmutableStringReference(unescapeSmaliString(rawStr)))
            }

            "const-class", "check-cast", "new-instance" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val opcode = when (opName) {
                    "const-class" -> Opcode.CONST_CLASS
                    "check-cast" -> Opcode.CHECK_CAST
                    else -> Opcode.NEW_INSTANCE
                }
                ImmutableInstruction21c(opcode, reg(parts[0]), ImmutableTypeReference(normalizeTypeDescriptor(parts[1])))
            }

            "move", "move-wide", "move-object",
            "and-int/2addr", "or-int/2addr", "xor-int/2addr",
            "add-int/2addr", "sub-int/2addr", "mul-int/2addr", "div-int/2addr" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val opcode = when (opName) {
                    "move" -> Opcode.MOVE
                    "move-wide" -> Opcode.MOVE_WIDE
                    "move-object" -> Opcode.MOVE_OBJECT
                    "and-int/2addr" -> Opcode.AND_INT_2ADDR
                    "or-int/2addr" -> Opcode.OR_INT_2ADDR
                    "xor-int/2addr" -> Opcode.XOR_INT_2ADDR
                    "add-int/2addr" -> Opcode.ADD_INT_2ADDR
                    "sub-int/2addr" -> Opcode.SUB_INT_2ADDR
                    "mul-int/2addr" -> Opcode.MUL_INT_2ADDR
                    else -> Opcode.DIV_INT_2ADDR
                }
                ImmutableInstruction12x(opcode, reg(parts[0]), reg(parts[1]))
            }

            "move/from16", "move-wide/from16", "move-object/from16" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val opcode = when (opName) {
                    "move/from16" -> Opcode.MOVE_FROM16
                    "move-wide/from16" -> Opcode.MOVE_WIDE_FROM16
                    else -> Opcode.MOVE_OBJECT_FROM16
                }
                ImmutableInstruction22x(opcode, reg(parts[0]), reg(parts[1]))
            }

            "add-int", "sub-int", "mul-int", "div-int", "rem-int", "and-int", "or-int", "xor-int" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 3) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val opcode = when (opName) {
                    "add-int" -> Opcode.ADD_INT
                    "sub-int" -> Opcode.SUB_INT
                    "mul-int" -> Opcode.MUL_INT
                    "div-int" -> Opcode.DIV_INT
                    "rem-int" -> Opcode.REM_INT
                    "and-int" -> Opcode.AND_INT
                    "or-int" -> Opcode.OR_INT
                    else -> Opcode.XOR_INT
                }
                ImmutableInstruction23x(opcode, reg(parts[0]), reg(parts[1]), reg(parts[2]))
            }

            "add-int/lit8", "rsub-int/lit8", "mul-int/lit8", "div-int/lit8",
            "rem-int/lit8", "and-int/lit8", "or-int/lit8", "xor-int/lit8" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 3) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val opcode = when (opName) {
                    "add-int/lit8" -> Opcode.ADD_INT_LIT8
                    "rsub-int/lit8" -> Opcode.RSUB_INT_LIT8
                    "mul-int/lit8" -> Opcode.MUL_INT_LIT8
                    "div-int/lit8" -> Opcode.DIV_INT_LIT8
                    "rem-int/lit8" -> Opcode.REM_INT_LIT8
                    "and-int/lit8" -> Opcode.AND_INT_LIT8
                    "or-int/lit8" -> Opcode.OR_INT_LIT8
                    else -> Opcode.XOR_INT_LIT8
                }
                ImmutableInstruction22b(opcode, reg(parts[0]), reg(parts[1]), parseSmaliIntLiteral(parts[2]))
            }

            "add-int/lit16", "rsub-int", "mul-int/lit16", "div-int/lit16",
            "rem-int/lit16", "and-int/lit16", "or-int/lit16", "xor-int/lit16" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 3) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val opcode = when (opName) {
                    "add-int/lit16" -> Opcode.ADD_INT_LIT16
                    "rsub-int" -> Opcode.RSUB_INT
                    "mul-int/lit16" -> Opcode.MUL_INT_LIT16
                    "div-int/lit16" -> Opcode.DIV_INT_LIT16
                    "rem-int/lit16" -> Opcode.REM_INT_LIT16
                    "and-int/lit16" -> Opcode.AND_INT_LIT16
                    "or-int/lit16" -> Opcode.OR_INT_LIT16
                    else -> Opcode.XOR_INT_LIT16
                }
                ImmutableInstruction22s(opcode, reg(parts[0]), reg(parts[1]), parseSmaliIntLiteral(parts[2]))
            }

            "goto" -> {
                val targetOffset = labelOffsets[args.trim()]
                    ?: throw IllegalArgumentException("التسمية (Label) غير موجودة: $args")
                ImmutableInstruction10t(Opcode.GOTO, targetOffset - insn.startCodeOffset)
            }

            "goto/16" -> {
                val targetOffset = labelOffsets[args.trim()]
                    ?: throw IllegalArgumentException("التسمية (Label) غير موجودة: $args")
                ImmutableInstruction20t(Opcode.GOTO_16, targetOffset - insn.startCodeOffset)
            }

            "if-eqz", "if-nez", "if-ltz", "if-gez", "if-gtz", "if-lez" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val targetOffset = labelOffsets[parts[1].trim()]
                    ?: throw IllegalArgumentException("التسمية (Label) غير موجودة: ${parts[1]}")
                val opcode = when (opName) {
                    "if-eqz" -> Opcode.IF_EQZ
                    "if-nez" -> Opcode.IF_NEZ
                    "if-ltz" -> Opcode.IF_LTZ
                    "if-gez" -> Opcode.IF_GEZ
                    "if-gtz" -> Opcode.IF_GTZ
                    else -> Opcode.IF_LEZ
                }
                ImmutableInstruction21t(opcode, reg(parts[0]), targetOffset - insn.startCodeOffset)
            }

            "if-eq", "if-ne", "if-lt", "if-ge", "if-gt", "if-le" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 3) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val targetOffset = labelOffsets[parts[2].trim()]
                    ?: throw IllegalArgumentException("التسمية (Label) غير موجودة: ${parts[2]}")
                val opcode = when (opName) {
                    "if-eq" -> Opcode.IF_EQ
                    "if-ne" -> Opcode.IF_NE
                    "if-lt" -> Opcode.IF_LT
                    "if-ge" -> Opcode.IF_GE
                    "if-gt" -> Opcode.IF_GT
                    else -> Opcode.IF_LE
                }
                ImmutableInstruction22t(opcode, reg(parts[0]), reg(parts[1]), targetOffset - insn.startCodeOffset)
            }

            "sget", "sget-wide", "sget-object", "sget-boolean", "sget-byte", "sget-char", "sget-short",
            "sput", "sput-wide", "sput-object", "sput-boolean", "sput-byte", "sput-char", "sput-short" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 2) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val fieldRef = parseFieldReference(parts[1])
                val opcode = when (opName) {
                    "sget" -> Opcode.SGET
                    "sget-wide" -> Opcode.SGET_WIDE
                    "sget-object" -> Opcode.SGET_OBJECT
                    "sget-boolean" -> Opcode.SGET_BOOLEAN
                    "sget-byte" -> Opcode.SGET_BYTE
                    "sget-char" -> Opcode.SGET_CHAR
                    "sget-short" -> Opcode.SGET_SHORT
                    "sput" -> Opcode.SPUT
                    "sput-wide" -> Opcode.SPUT_WIDE
                    "sput-object" -> Opcode.SPUT_OBJECT
                    "sput-boolean" -> Opcode.SPUT_BOOLEAN
                    "sput-byte" -> Opcode.SPUT_BYTE
                    "sput-char" -> Opcode.SPUT_CHAR
                    else -> Opcode.SPUT_SHORT
                }
                ImmutableInstruction21c(opcode, reg(parts[0]), fieldRef)
            }

            "iget", "iget-wide", "iget-object", "iget-boolean", "iget-byte", "iget-char", "iget-short",
            "iput", "iput-wide", "iput-object", "iput-boolean", "iput-byte", "iput-char", "iput-short" -> {
                val parts = splitTopLevelComma(args)
                require(parts.size == 3) { "صياغة $opName غير صالحة: ${insn.rawLine}" }
                val fieldRef = parseFieldReference(parts[2])
                val opcode = when (opName) {
                    "iget" -> Opcode.IGET
                    "iget-wide" -> Opcode.IGET_WIDE
                    "iget-object" -> Opcode.IGET_OBJECT
                    "iget-boolean" -> Opcode.IGET_BOOLEAN
                    "iget-byte" -> Opcode.IGET_BYTE
                    "iget-char" -> Opcode.IGET_CHAR
                    "iget-short" -> Opcode.IGET_SHORT
                    "iput" -> Opcode.IPUT
                    "iput-wide" -> Opcode.IPUT_WIDE
                    "iput-object" -> Opcode.IPUT_OBJECT
                    "iput-boolean" -> Opcode.IPUT_BOOLEAN
                    "iput-byte" -> Opcode.IPUT_BYTE
                    "iput-char" -> Opcode.IPUT_CHAR
                    else -> Opcode.IPUT_SHORT
                }
                ImmutableInstruction22c(opcode, reg(parts[0]), reg(parts[1]), fieldRef)
            }

            "invoke-virtual", "invoke-super", "invoke-direct", "invoke-static", "invoke-interface" -> {
                val braceOpen = args.indexOf('{')
                val braceClose = args.indexOf('}')
                require(braceOpen >= 0 && braceClose > braceOpen) {
                    "صياغة $opName تفتقد أقواس السجلات {...}: ${insn.rawLine}"
                }
                val regsInside = args.substring(braceOpen + 1, braceClose).trim()
                val regList = if (regsInside.isEmpty()) {
                    emptyList()
                } else {
                    regsInside.split(',').map { reg(it) }
                }
                require(regList.size <= 5) {
                    "تعليمة $opName تقبل حتى 5 سجلات: ${insn.rawLine}"
                }
                val methodRefStr = args.substring(braceClose + 1).trim().removePrefix(",").trim()
                val methodRef = parseMethodReference(methodRefStr)
                val opcode = when (opName) {
                    "invoke-virtual" -> Opcode.INVOKE_VIRTUAL
                    "invoke-super" -> Opcode.INVOKE_SUPER
                    "invoke-direct" -> Opcode.INVOKE_DIRECT
                    "invoke-static" -> Opcode.INVOKE_STATIC
                    else -> Opcode.INVOKE_INTERFACE
                }
                ImmutableInstruction35c(
                    opcode,
                    regList.size,
                    regList.getOrElse(0) { 0 },
                    regList.getOrElse(1) { 0 },
                    regList.getOrElse(2) { 0 },
                    regList.getOrElse(3) { 0 },
                    regList.getOrElse(4) { 0 },
                    methodRef
                )
            }

            "invoke-virtual/range", "invoke-super/range", "invoke-direct/range",
            "invoke-static/range", "invoke-interface/range" -> {
                val braceOpen = args.indexOf('{')
                val braceClose = args.indexOf('}')
                require(braceOpen >= 0 && braceClose > braceOpen) {
                    "صياغة $opName تفتقد أقواس السجلات {...}: ${insn.rawLine}"
                }
                val regsInside = args.substring(braceOpen + 1, braceClose).trim()
                val (startReg, regCount) = if (regsInside.isEmpty()) {
                    0 to 0
                } else if (regsInside.contains("..")) {
                    val s = reg(regsInside.substringBefore(".."))
                    val e = reg(regsInside.substringAfter(".."))
                    s to (e - s + 1).coerceAtLeast(0)
                } else {
                    reg(regsInside) to 1
                }
                val methodRefStr = args.substring(braceClose + 1).trim().removePrefix(",").trim()
                val methodRef = parseMethodReference(methodRefStr)
                val opcode = when (opName) {
                    "invoke-virtual/range" -> Opcode.INVOKE_VIRTUAL_RANGE
                    "invoke-super/range" -> Opcode.INVOKE_SUPER_RANGE
                    "invoke-direct/range" -> Opcode.INVOKE_DIRECT_RANGE
                    "invoke-static/range" -> Opcode.INVOKE_STATIC_RANGE
                    else -> Opcode.INVOKE_INTERFACE_RANGE
                }
                ImmutableInstruction3rc(opcode, startReg, regCount, methodRef)
            }

            else -> throw IllegalArgumentException("تعليمة Smali غير مدعومة: ${insn.rawLine}")
        }
    }

    private fun parseFieldReference(rawRef: String): ImmutableFieldReference {
        val trimmed = rawRef.trim()
        require(trimmed.contains("->") && trimmed.contains(":")) {
            "مرجع الحقل غير صالح: $rawRef"
        }
        val definingClass = normalizeTypeDescriptor(trimmed.substringBefore("->"))
        val afterArrow = trimmed.substringAfter("->")
        val name = afterArrow.substringBefore(":").trim()
        val type = afterArrow.substringAfter(":").trim()
        return ImmutableFieldReference(definingClass, name, type)
    }

    private fun parseMethodReference(rawRef: String): ImmutableMethodReference {
        val trimmed = rawRef.trim()
        require(trimmed.contains("->") && trimmed.contains("(") && trimmed.contains(")")) {
            "مرجع الدالة غير صالح: $rawRef"
        }
        val definingClass = normalizeTypeDescriptor(trimmed.substringBefore("->"))
        val afterArrow = trimmed.substringAfter("->")
        val name = afterArrow.substringBefore("(").trim()
        val paramsDesc = afterArrow.substringAfter("(").substringBefore(")").trim()
        val returnType = afterArrow.substringAfter(")").trim()
        val params = splitParameterDescriptors(paramsDesc)
        return ImmutableMethodReference(definingClass, name, params, returnType)
    }

    private fun parseRegisterIndex(token: String, localsCount: Int, paramRegCount: Int): Int {
        val clean = token.trim()
        return when {
            clean.startsWith("v") -> {
                clean.removePrefix("v").toIntOrNull()
                    ?: throw IllegalArgumentException("اسم سجل محلي غير صالح: $token")
            }
            clean.startsWith("p") -> {
                val pIdx = clean.removePrefix("p").toIntOrNull()
                    ?: throw IllegalArgumentException("اسم سجل معامل غير صالح: $token")
                require(pIdx in 0 until paramRegCount.coerceAtLeast(16)) {
                    "سجل المعامل $token خارج النطاق."
                }
                localsCount + pIdx
            }
            else -> throw IllegalArgumentException("اسم السجل يجب أن يبدأ بـ v أو p: $token")
        }
    }

    private fun parseSmaliIntLiteral(raw: String): Int {
        val t = raw.trim().lowercase().removeSuffix("t").removeSuffix("s")
        val negative = t.startsWith("-")
        val clean = if (negative || t.startsWith("+")) t.substring(1) else t
        val magnitude = if (clean.startsWith("0x")) {
            clean.removePrefix("0x").toLong(16)
        } else {
            clean.toLong(10)
        }
        val signed = if (negative) -magnitude else magnitude
        return signed.toInt()
    }

    private fun parseSmaliLongLiteral(raw: String): Long {
        val t = raw.trim().lowercase().removeSuffix("l")
        val negative = t.startsWith("-")
        val clean = if (negative || t.startsWith("+")) t.substring(1) else t
        val magnitude = if (clean.startsWith("0x")) {
            java.lang.Long.parseUnsignedLong(clean.removePrefix("0x"), 16)
        } else {
            clean.toLong(10)
        }
        return if (negative) -magnitude else magnitude
    }

    private fun unescapeSmaliString(escaped: String): String {
        val sb = StringBuilder(escaped.length)
        var i = 0
        while (i < escaped.length) {
            val c = escaped[i]
            if (c == '\\' && i + 1 < escaped.length) {
                when (val next = escaped[i + 1]) {
                    'n' -> { sb.append('\n'); i += 2 }
                    'r' -> { sb.append('\r'); i += 2 }
                    't' -> { sb.append('\t'); i += 2 }
                    '"' -> { sb.append('"'); i += 2 }
                    '\'' -> { sb.append('\''); i += 2 }
                    '\\' -> { sb.append('\\'); i += 2 }
                    'u' -> {
                        if (i + 5 < escaped.length) {
                            val hex = escaped.substring(i + 2, i + 6)
                            sb.append(hex.toInt(16).toChar())
                            i += 6
                        } else {
                            sb.append(c)
                            i++
                        }
                    }
                    else -> {
                        sb.append(next)
                        i += 2
                    }
                }
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }

    private fun splitTopLevelComma(text: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var braceDepth = 0
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                c == '\\' && inQuotes && i + 1 < text.length -> {
                    current.append(c).append(text[i + 1])
                    i += 2
                    continue
                }
                c == '"' -> {
                    inQuotes = !inQuotes
                    current.append(c)
                }
                !inQuotes && c == '{' -> {
                    braceDepth++
                    current.append(c)
                }
                !inQuotes && c == '}' -> {
                    braceDepth = (braceDepth - 1).coerceAtLeast(0)
                    current.append(c)
                }
                !inQuotes && braceDepth == 0 && c == ',' -> {
                    result.add(current.toString().trim())
                    current.clear()
                }
                else -> current.append(c)
            }
            i++
        }
        if (current.isNotEmpty()) {
            result.add(current.toString().trim())
        }
        return result
    }

    private fun stripComment(line: String): String {
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '\\' && inQuotes && i + 1 < line.length) {
                i += 2
                continue
            }
            if (c == '"') {
                inQuotes = !inQuotes
            } else if (c == '#' && !inQuotes) {
                return line.substring(0, i)
            }
            i++
        }
        return line
    }

    fun splitParameterDescriptors(paramsDesc: String): List<String> {
        val result = mutableListOf<String>()
        var i = 0
        while (i < paramsDesc.length) {
            val start = i
            while (i < paramsDesc.length && paramsDesc[i] == '[') {
                i++
            }
            if (i >= paramsDesc.length) break
            if (paramsDesc[i] == 'L') {
                val semi = paramsDesc.indexOf(';', i)
                require(semi > i) { "وصف معامل الكلاس غير مكتمل بـ (;): $paramsDesc" }
                i = semi + 1
            } else {
                i++
            }
            result.add(paramsDesc.substring(start, i))
        }
        return result
    }

    private fun countParameterRegisters(isStatic: Boolean, parameterTypes: List<String>): Int {
        var count = if (isStatic) 0 else 1
        for (p in parameterTypes) {
            count += if (p == "J" || p == "D") 2 else 1
        }
        return count
    }

    private fun normalizeTypeDescriptor(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.startsWith("[") || (trimmed.startsWith("L") && trimmed.endsWith(";"))) {
            return trimmed
        }
        if (trimmed in setOf("V", "Z", "B", "S", "C", "I", "J", "F", "D")) {
            return trimmed
        }
        return "L${trimmed.removePrefix("L").removeSuffix(";").replace('.', '/')};"
    }

    private fun parseClassAccessFlags(tokens: List<String>): Int {
        var flags = 0
        for (t in tokens) {
            AccessFlags.getAccessFlag(t)?.let { flags = flags or it.value }
        }
        return flags
    }

    private fun parseFieldAccessFlags(tokens: List<String>): Int {
        var flags = 0
        for (t in tokens) {
            AccessFlags.getAccessFlag(t)?.let { flags = flags or it.value }
        }
        return flags
    }

    private fun parseMethodAccessFlags(tokens: List<String>): Int {
        var flags = 0
        for (t in tokens) {
            AccessFlags.getAccessFlag(t)?.let { flags = flags or it.value }
        }
        return flags
    }
}
