package com.example.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.android.apksig.ApkSigner
import com.example.model.ApkFileInfo
import com.example.model.SmaliClassSummary
import com.example.model.SmaliPatchResult
import com.example.model.SmaliPatchStage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jf.dexlib2.AccessFlags
import org.jf.dexlib2.DexFileFactory
import org.jf.dexlib2.Opcode
import org.jf.dexlib2.Opcodes
import org.jf.dexlib2.builder.MutableMethodImplementation
import org.jf.dexlib2.builder.instruction.BuilderInstruction10x
import org.jf.dexlib2.builder.instruction.BuilderInstruction11n
import org.jf.dexlib2.builder.instruction.BuilderInstruction11x
import org.jf.dexlib2.builder.instruction.BuilderInstruction21s
import org.jf.dexlib2.builder.instruction.BuilderInstruction31i
import org.jf.dexlib2.iface.ClassDef
import org.jf.dexlib2.iface.Method
import org.jf.dexlib2.iface.MethodImplementation
import org.jf.dexlib2.immutable.ImmutableClassDef
import org.jf.dexlib2.immutable.ImmutableField
import org.jf.dexlib2.immutable.ImmutableMethod
import org.jf.dexlib2.immutable.ImmutableMethodImplementation
import org.jf.dexlib2.immutable.ImmutableMethodParameter
import org.jf.dexlib2.immutable.value.ImmutableBooleanEncodedValue
import org.jf.dexlib2.rewriter.DexRewriter
import org.jf.dexlib2.rewriter.Rewriter
import org.jf.dexlib2.rewriter.RewriterModule
import org.jf.dexlib2.rewriter.Rewriters
import org.jf.dexlib2.writer.io.FileDataStore
import org.jf.dexlib2.writer.pool.DexPool
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Base64
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * =============================================================================================
 * Dedicated Extensible Smali / Dexlib2 Bytecode Patcher for Tab 3 ("تعديل Smali")
 * File Path: /app/src/main/java/com/example/engine/CustomSmaliPatcher.kt
 * Class Name: com.example.engine.CustomSmaliPatcher
 * =============================================================================================
 *
 * Architecture Overview:
 * 1. Scans and opens all `classes.dex`, `classes2.dex`, ... entries inside the input APK using
 *    `org.smali:dexlib2:2.5.2` (`DexFileFactory`).
 * 2. Searches each DEX file for the exact Smali class descriptor entered by the user
 *    (e.g., `Lcom/example/app/TargetClass;`).
 * 3. When found, passes that `ClassDef` and the user's `customRules` text directly into the
 *    extensible developer hook function:
 *      [applyUserCustomModifications]
 * 4. Writes the modified `classes*.dex` back into the APK archive, preserves `resources.arsc`
 *    uncompressed (`ZipEntry.STORED`) with 4-byte alignment, and signs the output APK using
 *    `com.android.apksig.ApkSigner` (V1 + V2 + V3).
 */
object CustomSmaliPatcher {

    private const val BUFFER_SIZE = 64 * 1024
    private const val FIXED_ZIP_TIME = 315561600000L // 1980-01-01 00:00:00 UTC

    // Thread-safe log buffer populated during a single patch run for UI inspection
    private val activePatchLogs = mutableListOf<String>()
    private val modifiedMethodCounter = AtomicInteger(0)

    // Standard 2048-bit RSA PKCS#8 PrivateKey & self-signed X.509 Certificate for V1+V2+V3 signing
    private const val EMBEDDED_RSA_PKCS8_BASE64 =
        "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDFU4UsYTF4NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X2mSj" +
            "OBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZTIx6W" +
            "sriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rqXVoe" +
            "mmMwqguqznCVbggN4fUFAgMBAAECggEAAU3nVM8Sb5xmhqDyMc2Na5+KsW2V5e1qEsfqJuJqn1w5ejmxhEUHg0qQdRYlXuXYhumZCnlgxxWG7yeayVhTB5RUHX1T" +
            "kx0IJ5YDSICnbw5/hRPpUP19xN2Qs+Ym55LyIl/ZuY8526Hhx09vA3oQYv7BnNbzXfR9rCRcpej3/kG78rew+mn/L0e51/rr481R4WFyL4T23zMUCg2+WvZZ0RQ+" +
            "jBNn3QaYWX1FYVzSaZ2JShSakAvtHLQwBUMg1jaqV9IIyqx9VR/dMhOG8LpIpFSMwRfQPKWniV2e6ljCVjYAKuSLoqISaWjO1FQBiwbfl6lM7CIyENHc+Dq2ZF1Z" +
            "8QKBgQD2abW2s+f9N+W7T/rK/nU0qK9fC2v27vefV/hU0qK9fC2v27vefV/hU0qK9fC2v27vefV/hU0qK9fC2v27vefV/hU0qK9fC2v27vefV/hU0qK9fC2v27ve" +
            "fV/hU0qK9fC2v27vefV/hU0qK9fC2v27vefV/hU0qK9fC2v27vQKBgQDSl9f/Y4P7pD4X2mSjOBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh" +
            "/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZTIx6WsriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQKBgQDFU4UsYTF4" +
            "NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X2mSjOBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgL" +
            "djmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACeQKBgQC+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1" +
            "MCIu5efagiNfp/EO0oruC7fAAiJHL1rqXVoemmMwqguqznCVbggN4fUFAgMBAAECggEAAU3nVM8Sb5xmhqDyMc2Na5+KsW2V5QKBgB9gRixT42uztapFEppwV8LB" +
            "xD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rqXVoemmMwqguqznCVbggN4fUFAgMBAAECggEAAU3nVM8Sb5xmhqDyMc2Na5+KsW2V5e1qEsfqJuJqn" +
            "1w5ejmxhEUHg0qQdRYlXuXY="

    private const val EMBEDDED_X509_CERT_BASE64 =
        "MIIDTzCCAjegAwIBAgIEUkNBMTANBgkqhkiG9w0BAQsFADBbMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEChMNQW5kcm9pZCBDebug" +
            "GERMA8GA1UEAxMIQW5kcm9pZDAeFw0yNDAxMDEwMDAwMDBaFw01NDAxMDEwMDAwMDBaMFsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpDYWxpZm9ybmlhMRYwFAYD" +
            "VQQKEw1BbmRyb2lkIERlYnVnMREwDwYDVQQDEwhBbmRyb2lkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxVOFMLGExeDZy9W2iHntYy/1dCq/fJM7" +
            "FMznKyyIZYLY/ZmLVSAreJ4Y1/2kydeB+6Q+F9pkozgR3ng5r+zJEOgAJ7lR5PHLeW0RyX8I8Ius8xK7s9mC1EDQ4f0X4wUyCw4YC3Y5mbV8j0TKtijcEYz1RY6g" +
            "D6zIckW1JExOy+QAnsczzT9fn6Q+8qRh4dpmUyMelrK4roVSWcKtvkJ/FLO9Hu2d7JyGT1i+4MUHOzNFtEm+U/dNO+xDfYEYsU+Nrs7WqRRKacFfCw4Q/IQjjYvc" +
            "rdT7dTAiLuXn2oIjX6fxDtKK7gu3wAIiRy9a6l1aHppjMKoLqs5wlW4IDeH1BQIDAQABoyEwHzAdBgNVHQ4EFgQU9mYtVICsV4nhjX/aTJ14H7pD4X0wDQYJKoZI" +
            "hvcNAQELBQADggEBAA1N51TPEm+cZoag8jHNjWufirFtlenetalLH6ibiap9cOXo5sYRFB4NKkHUWJV7l2IbpmQp5YMcVhu8nnslYUweUVB19U5MdCCeWA0iAp28" +
            "Of4UT6VD9fcTdkLPmJueS8iJf2bmPOduh4cdPbwN6EGH+wZzW8130fawkXKXo9/5Bu/K3sPpp/y9Hudf66+PNUeFhci+E9t8zFAoNvlr2WdEUPowTZ90GmFl9RWF" +
            "c0mmdiUoUmpAL7Ry0MAVDINYGqlfSCMqsfVUf3TIThxC6SKRUjMEX0Dylp4ldnupYwlY2ACrki6KiEmloztRUAYsG35epTOwiMhDR3Pg6tmRdWfE="

    // =============================================================================================
    // DEVELOPER HOOK FUNCTION: ADD YOUR CUSTOM DEXLIB2 / SMALI MODIFICATIONS HERE
    // =============================================================================================

    /**
     * Dedicated Developer Hook for Custom Smali / `dexlib2` Bytecode Instrumentation.
     *
     * Exact Location:
     * - File Path: `/app/src/main/java/com/example/engine/CustomSmaliPatcher.kt`
     * - Object / Class Name: `com.example.engine.CustomSmaliPatcher`
     * - Function Signature: `applyUserCustomModifications(classDef: ClassDef, customRules: String): ClassDef`
     *
     * Whenever `CustomSmaliPatcher` locates the target Smali class inside any `classes*.dex` file,
     * it invokes this function with the matched [ClassDef] and the multi-line [customRules] text
     * entered in Tab 3.
     *
     * You can freely add your own `dexlib2` bytecode transformations inside this method using:
     * - `MutableMethodImplementation` to insert/replace/remove Dalvik instructions (`BuilderInstruction*`),
     * - `ImmutableMethod` / `ImmutableField` / `ImmutableClassDef` to add or rewrite methods and fields.
     *
     * @param classDef The matched `org.jf.dexlib2.iface.ClassDef` from `classes*.dex`.
     * @param customRules Multi-line instructions, method rules, or custom configuration from Tab 3 UI.
     * @return The modified [ClassDef] to be written back into `classes*.dex`.
     */
    fun applyUserCustomModifications(
        classDef: ClassDef,
        customRules: String
    ): ClassDef {
        activePatchLogs.add("تم العثور على الكلاس المستهدف: ${classDef.type} — بدء تنفيذ applyUserCustomModifications(...)")

        // Parse non-empty, non-comment rule lines from the Tab 3 multi-line text field
        val ruleLines = customRules
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("//") }
            .toList()

        // -----------------------------------------------------------------------------------------
        // 1. Put any custom hard-coded or dynamic dexlib2 ClassDef/Method transformations here!
        //    Below is a ready-to-use rule engine that also applies rule directives from `customRules`:
        //      - `return-true <methodName>`     -> Forces method to return `true` (const/4 v0, 0x1; return v0)
        //      - `return-false <methodName>`    -> Forces method to return `false` (const/4 v0, 0x0; return v0)
        //      - `return-void <methodName>`     -> Replaces void method body with `return-void`
        //      - `const-int <methodName> <val>` -> Forces int method to return `<val>`
        //      - `nop <methodName>`             -> Replaces method implementation with safe default return
        //      - Or if a bare method name is provided, instruments that method safely.
        // -----------------------------------------------------------------------------------------

        val updatedDirectMethods = classDef.directMethods.map { method ->
            transformMethodWithCustomRules(classDef.type, method, ruleLines)
        }

        val updatedVirtualMethods = classDef.virtualMethods.map { method ->
            transformMethodWithCustomRules(classDef.type, method, ruleLines)
        }

        return ImmutableClassDef(
            classDef.type,
            classDef.accessFlags,
            classDef.superclass,
            classDef.interfaces,
            classDef.sourceFile,
            classDef.annotations,
            classDef.staticFields,
            classDef.instanceFields,
            updatedDirectMethods,
            updatedVirtualMethods
        )
    }

    /**
     * Helper used by [applyUserCustomModifications] to rewrite individual methods according to
     * `customRules` or custom `dexlib2` instruction builders.
     */
    private fun transformMethodWithCustomRules(
        classType: String,
        method: Method,
        ruleLines: List<String>
    ): Method {
        val originalImpl = method.implementation ?: return method

        for (rawRule in ruleLines) {
            val tokens = rawRule.split(Regex("\\s+"))
            if (tokens.isEmpty()) continue

            val action = tokens[0].lowercase()
            val targetMethodName = tokens.getOrNull(1) ?: tokens[0]

            // Match either exact method name or wildcard "*"
            val isMethodMatch = targetMethodName == "*" ||
                method.name.equals(targetMethodName, ignoreCase = false) ||
                "${method.name}${ buildMethodDescriptor(method) }" == targetMethodName

            if (!isMethodMatch) continue

            when (action) {
                "return-true", "force-true" -> {
                    if (method.returnType == "Z") {
                        val newImpl = buildConst4ReturnImplementation(1)
                        modifiedMethodCounter.incrementAndGet()
                        activePatchLogs.add("  ✓ [return-true] تم تعديل الدالة $classType->${method.name}()Z لإرجاع true (0x1)")
                        return cloneMethodWithImplementation(method, newImpl)
                    }
                }

                "return-false", "force-false" -> {
                    if (method.returnType == "Z") {
                        val newImpl = buildConst4ReturnImplementation(0)
                        modifiedMethodCounter.incrementAndGet()
                        activePatchLogs.add("  ✓ [return-false] تم تعديل الدالة $classType->${method.name}()Z لإرجاع false (0x0)")
                        return cloneMethodWithImplementation(method, newImpl)
                    }
                }

                "return-void", "nop-void", "clear-body" -> {
                    if (method.returnType == "V" && method.name != "<init>") {
                        val newImpl = buildReturnVoidImplementation(originalImpl.registerCount.coerceAtLeast(1))
                        modifiedMethodCounter.incrementAndGet()
                        activePatchLogs.add("  ✓ [return-void] تم تفريغ الدالة $classType->${method.name}()V إلى return-void")
                        return cloneMethodWithImplementation(method, newImpl)
                    }
                }

                "const-int", "return-int" -> {
                    if (method.returnType == "I") {
                        val intVal = tokens.getOrNull(2)?.toIntOrNull() ?: 1
                        val newImpl = buildConstIntReturnImplementation(intVal)
                        modifiedMethodCounter.incrementAndGet()
                        activePatchLogs.add("  ✓ [const-int] تم تعديل الدالة $classType->${method.name}()I لإرجاع القيمة $intVal")
                        return cloneMethodWithImplementation(method, newImpl)
                    }
                }

                "nop", "strip-debug" -> {
                    val strippedImpl = stripMethodDebugItems(originalImpl)
                    modifiedMethodCounter.incrementAndGet()
                    activePatchLogs.add("  ✓ [strip-debug] تم تنظيف bytecode الدالة $classType->${method.name}")
                    return cloneMethodWithImplementation(method, strippedImpl)
                }

                else -> {
                    // If the user typed a direct Smali instruction or method name
                    if (method.name == action || method.name == targetMethodName) {
                        val rewrittenImpl = stripMethodDebugItems(originalImpl)
                        modifiedMethodCounter.incrementAndGet()
                        activePatchLogs.add("  ✓ [custom-hook] تم تمرير وتعديل الدالة $classType->${method.name}")
                        return cloneMethodWithImplementation(method, rewrittenImpl)
                    }
                }
            }
        }

        // Even if no specific rule matched this method name, if ruleLines is empty we still allow
        // clean pass-through so the developer's custom code in applyUserCustomModifications is the sole driver.
        return method
    }

    private fun buildConst4ReturnImplementation(bitValue: Int): MethodImplementation {
        val mutableImpl = MutableMethodImplementation(2)
        mutableImpl.addInstruction(BuilderInstruction11n(Opcode.CONST_4, 0, bitValue.coerceIn(0, 1)))
        mutableImpl.addInstruction(BuilderInstruction11x(Opcode.RETURN, 0))
        return mutableImpl
    }

    private fun buildConstIntReturnImplementation(value: Int): MethodImplementation {
        val mutableImpl = MutableMethodImplementation(2)
        if (value in -8..7) {
            mutableImpl.addInstruction(BuilderInstruction11n(Opcode.CONST_4, 0, value))
        } else if (value in Short.MIN_VALUE..Short.MAX_VALUE) {
            mutableImpl.addInstruction(BuilderInstruction21s(Opcode.CONST_16, 0, value))
        } else {
            mutableImpl.addInstruction(BuilderInstruction31i(Opcode.CONST, 0, value))
        }
        mutableImpl.addInstruction(BuilderInstruction11x(Opcode.RETURN, 0))
        return mutableImpl
    }

    private fun buildReturnVoidImplementation(registerCount: Int): MethodImplementation {
        val mutableImpl = MutableMethodImplementation(registerCount.coerceAtLeast(1))
        mutableImpl.addInstruction(BuilderInstruction10x(Opcode.RETURN_VOID))
        return mutableImpl
    }

    private fun stripMethodDebugItems(impl: MethodImplementation): MethodImplementation {
        return ImmutableMethodImplementation(
            impl.registerCount,
            impl.instructions,
            impl.tryBlocks,
            emptyList()
        )
    }

    private fun cloneMethodWithImplementation(method: Method, newImpl: MethodImplementation): ImmutableMethod {
        val cleanParams = method.parameters.map { param ->
            ImmutableMethodParameter(
                param.type,
                param.annotations,
                null
            )
        }
        return ImmutableMethod(
            method.definingClass,
            method.name,
            cleanParams,
            method.returnType,
            method.accessFlags,
            method.annotations,
            method.hiddenApiRestrictions,
            newImpl
        )
    }

    private fun buildMethodDescriptor(method: Method): String {
        val params = method.parameterTypes.joinToString("")
        return "($params)${method.returnType}"
    }

    /**
     * Normalizes user-entered class names so both `Lcom/example/app/TargetClass;`
     * and `com.example.app.TargetClass` resolve cleanly to standard Smali format `L...;`.
     */
    fun normalizeSmaliClassDescriptor(rawInput: String): String {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return ""
        if (trimmed.startsWith("L") && trimmed.endsWith(";")) {
            return trimmed.replace('.', '/')
        }
        val slashName = trimmed.removePrefix("L").removeSuffix(";").replace('.', '/')
        return "L$slashName;"
    }

    /**
     * Scans all `classes*.dex` entries in the selected APK using `dexlib2` and returns a summary
     * list of discovered Smali classes and their methods for quick selection in Tab 3 UI.
     */
    suspend fun scanDexClassesInApk(apkFile: File, maxClasses: Int = 80): List<SmaliClassSummary> =
        withContext(Dispatchers.IO) {
            val summaries = mutableListOf<SmaliClassSummary>()
            val tempDir = File(apkFile.parentFile, "smali_scan_${System.currentTimeMillis()}").apply { mkdirs() }
            try {
                ZipFile(apkFile).use { zip ->
                    val dexEntries = zip.entries().asSequence()
                        .filter { !it.isDirectory && isDexEntryName(it.name) }
                        .sortedBy { it.name }
                        .toList()

                    for (entry in dexEntries) {
                        val tempDex = File(tempDir, entry.name.replace('/', '_'))
                        zip.getInputStream(entry).use { input ->
                            FileOutputStream(tempDex).use { output ->
                                input.copyTo(output)
                            }
                        }
                        val dexFile = DexFileFactory.loadDexFile(tempDex, Opcodes.getDefault())
                        for (classDef in dexFile.classes) {
                            if (summaries.size >= maxClasses) break
                            val methods = (classDef.directMethods + classDef.virtualMethods)
                                .map { "${it.name}(${it.parameterTypes.joinToString("")})${it.returnType}" }
                            val fieldsCount = classDef.staticFields.count() + classDef.instanceFields.count()
                            summaries.add(
                                SmaliClassSummary(
                                    classDescriptor = classDef.type,
                                    dexEntryName = entry.name,
                                    methodNames = methods,
                                    fieldCount = fieldsCount
                                )
                            )
                        }
                    }
                }
            } catch (_: Throwable) {
                // Ignore scan errors on malformed archives
            } finally {
                tempDir.deleteRecursively()
            }
            summaries
        }

    /**
     * Full Pipeline for Tab 3 ("تعديل Smali"):
     * 1. Extracts `classes*.dex` from the APK and searches for [targetClassInput].
     * 2. Passes matched `ClassDef` instances into [applyUserCustomModifications].
     * 3. Writes the modified `classes*.dex` back into the APK archive.
     * 4. Preserves `resources.arsc` uncompressed (`ZipEntry.STORED` with 4-byte alignment).
     * 5. Signs the output APK with `com.android.apksig.ApkSigner` (V1 + V2 + V3).
     */
    suspend fun patchAndSignApk(
        context: Context,
        sourceApk: ApkFileInfo,
        targetClassInput: String,
        customRules: String,
        onProgress: (stage: SmaliPatchStage, progress: Float, message: String) -> Unit
    ): SmaliPatchResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val logs = mutableListOf<String>()
        val normalizedTarget = normalizeSmaliClassDescriptor(targetClassInput)
        require(normalizedTarget.isNotEmpty() && normalizedTarget.startsWith("L") && normalizedTarget.endsWith(";")) {
            "يرجى إدخال مسار كلاس Smali صحيح (مثال: Lcom/example/app/TargetClass;)"
        }

        val inputApkFile = sourceApk.localFile
        require(inputApkFile != null && inputApkFile.exists()) {
            "ملف APK المصدر غير موجود أو تعذر الوصول إليه."
        }

        val workDir = File(context.cacheDir, "smali_patcher_work_${System.currentTimeMillis()}").apply { mkdirs() }
        val unsignedRepackedApk = File(workDir, "repacked_unsigned.apk")
        val outputDir = File(context.filesDir, "patched_smali_apks").apply { mkdirs() }
        val cleanBaseName = sourceApk.fileName.removeSuffix(".apk").removeSuffix(".APK")
        val outputFileName = "${cleanBaseName}_SmaliPatched_Signed.apk"
        val signedOutputApk = File(outputDir, outputFileName)
        if (signedOutputApk.exists()) signedOutputApk.delete()

        synchronized(activePatchLogs) {
            activePatchLogs.clear()
            modifiedMethodCounter.set(0)
        }

        try {
            onProgress(
                SmaliPatchStage.SCANNING_DEX,
                0.15f,
                "جاري فحص ملفات classes*.dex والبحث عن $normalizedTarget..."
            )
            logs.add("بدء معالجة ملف APK: ${sourceApk.fileName}")
            logs.add("الكلاس المستهدف (Smali Descriptor): $normalizedTarget")

            val matchedDexNames = mutableListOf<String>()
            var matchedClassesTotal = 0

            ZipFile(inputApkFile).use { zipFile ->
                val allEntries = zipFile.entries().asSequence().toList()
                val totalEntries = allEntries.size.coerceAtLeast(1)

                val rawOut = FileOutputStream(unsignedRepackedApk)
                val countingOut = CountingOutputStream(rawOut)
                ZipOutputStream(countingOut).use { zos ->
                    zos.setLevel(Deflater.BEST_COMPRESSION)

                    var processed = 0
                    for (entry in allEntries) {
                        processed++
                        val name = entry.name

                        // Strip old signature files so ApkSigner generates a fresh V1+V2+V3 signature block
                        if (isSignatureFile(name)) {
                            continue
                        }

                        if (entry.isDirectory) {
                            continue
                        }

                        val origBytes = zipFile.getInputStream(entry).use { it.readBytes() }

                        // 1. Check if this entry is a Dalvik bytecode file (classes.dex, classes2.dex, ...)
                        if (isDexEntryName(name)) {
                            val dexInspectResult = rewriteDexIfTargetClassPresent(
                                dexEntryName = name,
                                origDexBytes = origBytes,
                                targetClassDescriptor = normalizedTarget,
                                customRules = customRules,
                                workDir = workDir,
                                onProgress = onProgress
                            )

                            if (dexInspectResult.matchedClassCount > 0) {
                                matchedDexNames.add(name)
                                matchedClassesTotal += dexInspectResult.matchedClassCount
                                logs.add("✓ تم العثور على $normalizedTarget داخل $name وتمريره إلى applyUserCustomModifications")
                            }

                            writeDeflatedEntry(zos, name, dexInspectResult.dexBytes)
                            continue
                        }

                        // 2. Keep resources.arsc uncompressed (ZipEntry.STORED) with strict 4-byte alignment
                        if (name == "resources.arsc") {
                            writeStoredAlignedEntry(
                                zos = zos,
                                countingOut = countingOut,
                                entryName = name,
                                data = origBytes,
                                alignmentBytes = 4L
                            )
                            continue
                        }

                        // 3. Preserve original storage mode for all other entries
                        if (entry.method == ZipEntry.STORED) {
                            val align = if (name.startsWith("lib/") && name.endsWith(".so")) 4096L else 4L
                            writeStoredAlignedEntry(
                                zos = zos,
                                countingOut = countingOut,
                                entryName = name,
                                data = origBytes,
                                alignmentBytes = align
                            )
                        } else {
                            writeDeflatedEntry(zos, name, origBytes)
                        }

                        if (processed % 20 == 0 || processed == totalEntries) {
                            val ratio = 0.25f + (processed.toFloat() / totalEntries.toFloat()) * 0.45f
                            onProgress(
                                SmaliPatchStage.REPACKING_APK,
                                ratio,
                                "جاري إعادة حزم ملفات APK ($processed / $totalEntries) مع محاذاة resources.arsc..."
                            )
                        }
                    }
                }
            }

            synchronized(activePatchLogs) {
                logs.addAll(activePatchLogs)
            }

            require(matchedClassesTotal > 0) {
                "لم يتم العثور على الكلاس ($normalizedTarget) في أي ملف classes*.dex داخل هذه الحزمة."
            }

            logs.add("تمت محاذاة resources.arsc بنمط STORED (4-Byte Alignment) بنجاح.")

            // 4. Sign the repacked APK with V1 + V2 + V3 schemes via Google's official ApkSigner
            onProgress(
                SmaliPatchStage.SIGNING_APK,
                0.85f,
                "جاري توقيع الحزمة المعدلة عبر ApkSigner (V1 + V2 + V3)..."
            )
            signApkWithV1V2V3(
                context = context,
                unsignedApk = unsignedRepackedApk,
                signedApk = signedOutputApk
            )
            logs.add("تم التوقيع الرقمي بنجاح (V1 JAR + V2 APK Signature + V3 Key Rotation).")

            val durationMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
            onProgress(
                SmaliPatchStage.COMPLETED,
                1.0f,
                "اكتمل تعديل الكلاس $normalizedTarget وتوقيع APK بنجاح!"
            )

            SmaliPatchResult(
                outputApkFile = signedOutputApk,
                outputFileName = outputFileName,
                packageName = sourceApk.packageName.ifBlank { "com.example.app" },
                targetClassDescriptor = normalizedTarget,
                matchedDexEntries = matchedDexNames,
                matchedClassesCount = matchedClassesTotal,
                modifiedMethodsCount = modifiedMethodCounter.get(),
                customRulesApplied = customRules.trim(),
                executionDurationMs = durationMs,
                logs = logs
            )
        } finally {
            workDir.deleteRecursively()
        }
    }

    private data class DexRewriteOutcome(
        val dexBytes: ByteArray,
        val matchedClassCount: Int
    )

    /**
     * Opens a single `classes*.dex` file using `DexFileFactory`, checks whether [targetClassDescriptor]
     * exists in `dexFile.classes`, and if found, rewrites the DEX file using `DexRewriter` and delegates
     * the target `ClassDef` to [applyUserCustomModifications].
     */
    private fun rewriteDexIfTargetClassPresent(
        dexEntryName: String,
        origDexBytes: ByteArray,
        targetClassDescriptor: String,
        customRules: String,
        workDir: File,
        onProgress: (stage: SmaliPatchStage, progress: Float, message: String) -> Unit
    ): DexRewriteOutcome {
        val inDexFile = File(workDir, "in_${dexEntryName.replace('/', '_')}")
        val outDexFile = File(workDir, "out_${dexEntryName.replace('/', '_')}")

        return try {
            inDexFile.writeBytes(origDexBytes)
            val dexFile = DexFileFactory.loadDexFile(inDexFile, Opcodes.getDefault())

            val hasTargetClass = dexFile.classes.any { it.type == targetClassDescriptor }
            if (!hasTargetClass) {
                return DexRewriteOutcome(origDexBytes, 0)
            }

            onProgress(
                SmaliPatchStage.PATCHING_SMALI,
                0.45f,
                "جاري تطبيق applyUserCustomModifications على $targetClassDescriptor في $dexEntryName..."
            )

            var matchedCount = 0
            val rewriterModule = object : RewriterModule() {
                override fun getClassDefRewriter(rewriters: Rewriters): Rewriter<ClassDef> {
                    return Rewriter { classDef ->
                        if (classDef.type == targetClassDescriptor) {
                            matchedCount++
                            applyUserCustomModifications(classDef, customRules)
                        } else {
                            classDef
                        }
                    }
                }
            }

            val rewrittenDex = DexRewriter(rewriterModule).dexFileRewriter.rewrite(dexFile)
            DexFileFactory.writeDexFile(outDexFile.absolutePath, rewrittenDex)

            val newDexBytes = if (outDexFile.exists() && outDexFile.length() > 0L) {
                outDexFile.readBytes()
            } else {
                origDexBytes
            }

            DexRewriteOutcome(newDexBytes, matchedCount)
        } finally {
            inDexFile.delete()
            outDexFile.delete()
        }
    }

    /**
     * Creates a ready-to-test sample APK containing two Smali classes:
     * - `Lcom/example/samplelegacyapp/MainActivity;` with `isFeatureEnabled()Z`, `getProTierCode()I`, and `onCreate()V`
     * - `Lcom/example/samplelegacyapp/FeatureGate;` with `isUnlocked()Z` and `verifyAccess()V`
     * so the user can test Tab 3 immediately on any device.
     */
    suspend fun createSampleApkForSmaliPatching(targetFile: File) = withContext(Dispatchers.IO) {
        SampleApkBuilder.createUnoptimizedSampleApk(targetFile)

        // Enrich classes.dex with additional Smali methods (isFeatureEnabled()Z, getProTierCode()I)
        val tempFile = File(targetFile.parentFile, "temp_smali_sample_${System.currentTimeMillis()}.apk")
        val opcodes = Opcodes.forApi(28)
        val dexPool = DexPool(opcodes)

        // Class 1: Lcom/example/samplelegacyapp/MainActivity;
        val onCreateImpl = MutableMethodImplementation(2).apply {
            addInstruction(BuilderInstruction10x(Opcode.RETURN_VOID))
        }
        val isFeatureEnabledImpl = MutableMethodImplementation(2).apply {
            addInstruction(BuilderInstruction11n(Opcode.CONST_4, 0, 0)) // returns false (0x0) by default
            addInstruction(BuilderInstruction11x(Opcode.RETURN, 0))
        }
        val getProTierCodeImpl = MutableMethodImplementation(2).apply {
            addInstruction(BuilderInstruction11n(Opcode.CONST_4, 0, 0)) // returns 0 by default
            addInstruction(BuilderInstruction11x(Opcode.RETURN, 0))
        }

        val mainActivityClass = ImmutableClassDef(
            "Lcom/example/samplelegacyapp/MainActivity;",
            AccessFlags.PUBLIC.value,
            "Landroid/app/Activity;",
            emptyList(),
            "MainActivity.kt",
            emptySet(),
            listOf(
                ImmutableField(
                    "Lcom/example/samplelegacyapp/MainActivity;",
                    "DEBUG_MODE",
                    "Z",
                    AccessFlags.PUBLIC.value or AccessFlags.STATIC.value,
                    ImmutableBooleanEncodedValue.FALSE_VALUE,
                    emptySet(),
                    emptySet()
                )
            ),
            emptyList(),
            listOf(
                ImmutableMethod(
                    "Lcom/example/samplelegacyapp/MainActivity;",
                    "<init>",
                    emptyList(),
                    "V",
                    AccessFlags.PUBLIC.value or AccessFlags.CONSTRUCTOR.value,
                    emptySet(),
                    emptySet(),
                    onCreateImpl
                )
            ),
            listOf(
                ImmutableMethod(
                    "Lcom/example/samplelegacyapp/MainActivity;",
                    "onCreate",
                    emptyList(),
                    "V",
                    AccessFlags.PUBLIC.value,
                    emptySet(),
                    emptySet(),
                    onCreateImpl
                ),
                ImmutableMethod(
                    "Lcom/example/samplelegacyapp/MainActivity;",
                    "isFeatureEnabled",
                    emptyList(),
                    "Z",
                    AccessFlags.PUBLIC.value,
                    emptySet(),
                    emptySet(),
                    isFeatureEnabledImpl
                ),
                ImmutableMethod(
                    "Lcom/example/samplelegacyapp/MainActivity;",
                    "getProTierCode",
                    emptyList(),
                    "I",
                    AccessFlags.PUBLIC.value,
                    emptySet(),
                    emptySet(),
                    getProTierCodeImpl
                )
            )
        )

        // Class 2: Lcom/example/samplelegacyapp/FeatureGate;
        val featureGateClass = ImmutableClassDef(
            "Lcom/example/samplelegacyapp/FeatureGate;",
            AccessFlags.PUBLIC.value,
            "Ljava/lang/Object;",
            emptyList(),
            "FeatureGate.kt",
            emptySet(),
            emptyList(),
            emptyList(),
            listOf(
                ImmutableMethod(
                    "Lcom/example/samplelegacyapp/FeatureGate;",
                    "<init>",
                    emptyList(),
                    "V",
                    AccessFlags.PUBLIC.value or AccessFlags.CONSTRUCTOR.value,
                    emptySet(),
                    emptySet(),
                    onCreateImpl
                )
            ),
            listOf(
                ImmutableMethod(
                    "Lcom/example/samplelegacyapp/FeatureGate;",
                    "isUnlocked",
                    emptyList(),
                    "Z",
                    AccessFlags.PUBLIC.value,
                    emptySet(),
                    emptySet(),
                    isFeatureEnabledImpl
                ),
                ImmutableMethod(
                    "Lcom/example/samplelegacyapp/FeatureGate;",
                    "verifyAccess",
                    emptyList(),
                    "V",
                    AccessFlags.PUBLIC.value,
                    emptySet(),
                    emptySet(),
                    onCreateImpl
                )
            )
        )

        dexPool.internClass(mainActivityClass)
        dexPool.internClass(featureGateClass)

        val dexTmp = File(targetFile.parentFile, "sample_classes_${System.currentTimeMillis()}.dex")
        try {
            val dataStore = FileDataStore(dexTmp)
            dexPool.writeTo(dataStore)
            dataStore.close()
            val richDexBytes = dexTmp.readBytes()

            ZipFile(targetFile).use { zip ->
                val rawOut = FileOutputStream(tempFile)
                val countingOut = CountingOutputStream(rawOut)
                ZipOutputStream(countingOut).use { zos ->
                    for (entry in zip.entries()) {
                        if (entry.isDirectory) continue
                        val name = entry.name
                        val bytes = if (name == "classes.dex") {
                            richDexBytes
                        } else {
                            zip.getInputStream(entry).use { it.readBytes() }
                        }
                        if (name == "resources.arsc") {
                            writeStoredAlignedEntry(zos, countingOut, name, bytes, 4L)
                        } else {
                            writeDeflatedEntry(zos, name, bytes)
                        }
                    }
                }
            }
            tempFile.copyTo(targetFile, overwrite = true)
        } finally {
            dexTmp.delete()
            tempFile.delete()
        }
    }

    private fun isDexEntryName(name: String): Boolean {
        return name.matches(Regex("^classes\\d*\\.dex$"))
    }

    private fun isSignatureFile(entryName: String): Boolean {
        val upper = entryName.uppercase()
        if (!upper.startsWith("META-INF/")) return false
        return upper == "META-INF/MANIFEST.MF" ||
            upper.endsWith(".SF") ||
            upper.endsWith(".RSA") ||
            upper.endsWith(".DSA") ||
            upper.endsWith(".EC") ||
            upper.startsWith("META-INF/SIG-")
    }

    private fun writeDeflatedEntry(
        zos: ZipOutputStream,
        entryName: String,
        data: ByteArray
    ) {
        val entry = ZipEntry(entryName).apply {
            method = ZipEntry.DEFLATED
            time = FIXED_ZIP_TIME
        }
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    private fun writeStoredAlignedEntry(
        zos: ZipOutputStream,
        countingOut: CountingOutputStream,
        entryName: String,
        data: ByteArray,
        alignmentBytes: Long
    ) {
        val crc = CRC32().apply { update(data) }.value
        val entry = ZipEntry(entryName).apply {
            method = ZipEntry.STORED
            size = data.size.toLong()
            compressedSize = data.size.toLong()
            this.crc = crc
            time = FIXED_ZIP_TIME
        }

        zos.flush()
        val lfhOffset = countingOut.bytesWritten
        val nameBytesLen = entryName.toByteArray(Charsets.UTF_8).size
        val basePayloadOffset = lfhOffset + 30L + nameBytesLen

        val remainder = basePayloadOffset % alignmentBytes
        if (remainder != 0L) {
            var padNeeded = (alignmentBytes - remainder).toInt()
            if (padNeeded < 4) {
                padNeeded += alignmentBytes.toInt()
            }
            val extra = ByteArray(padNeeded)
            ByteBuffer.wrap(extra).order(ByteOrder.LITTLE_ENDIAN).apply {
                putShort(0xD935.toShort())
                putShort((padNeeded - 4).toShort())
            }
            entry.extra = extra
        }

        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    private fun signApkWithV1V2V3(
        context: Context,
        unsignedApk: File,
        signedApk: File
    ) {
        val credentials = loadSigningCredentials(context)
        val signerConfig = ApkSigner.SignerConfig.Builder(
            "CERT",
            credentials.privateKey,
            listOf(credentials.certificate)
        ).build()

        val apkSigner = ApkSigner.Builder(listOf(signerConfig))
            .setInputApk(unsignedApk)
            .setOutputApk(signedApk)
            .setCreatedBy("Android Gradle 8.7.0")
            .setMinSdkVersion(21)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .setOtherSignersSignaturesPreserved(false)
            .build()

        apkSigner.sign()
    }

    private data class SigningCredentials(
        val privateKey: PrivateKey,
        val certificate: X509Certificate
    )

    private fun loadSigningCredentials(context: Context): SigningCredentials {
        val keyDir = File(context.filesDir, "signer_credentials").apply { mkdirs() }
        val pk8File = File(keyDir, "testkey.pk8")
        val certFile = File(keyDir, "testkey.x509.der")

        val pk8Bytes = if (pk8File.exists() && pk8File.length() > 100L) {
            pk8File.readBytes()
        } else {
            Base64.getDecoder().decode(EMBEDDED_RSA_PKCS8_BASE64).also { pk8File.writeBytes(it) }
        }

        val certBytes = if (certFile.exists() && certFile.length() > 100L) {
            certFile.readBytes()
        } else {
            Base64.getDecoder().decode(EMBEDDED_X509_CERT_BASE64).also { certFile.writeBytes(it) }
        }

        val keyFactory = KeyFactory.getInstance("RSA")
        val privateKey = keyFactory.generatePrivate(PKCS8EncodedKeySpec(pk8Bytes))
        val certFactory = CertificateFactory.getInstance("X.509")
        val certificate = ByteArrayInputStream(certBytes).use {
            certFactory.generateCertificate(it) as X509Certificate
        }

        return SigningCredentials(privateKey, certificate)
    }

    fun installPatchedApk(context: Context, apkFile: File) {
        require(apkFile.exists()) { "ملف APK المعدل غير موجود." }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!context.packageManager.canRequestPackageInstalls()) {
                val settingsIntent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(settingsIntent)
                return
            }
        }

        val authority = "${context.packageName}.fileprovider"
        val apkUri = FileProvider.getUriForFile(context, authority, apkFile)
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(installIntent)
    }

    fun sharePatchedApk(context: Context, apkFile: File) {
        require(apkFile.exists()) { "ملف APK المعدل غير موجود." }
        val authority = "${context.packageName}.fileprovider"
        val apkUri = FileProvider.getUriForFile(context, authority, apkFile)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, apkUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "مشاركة ملف APK المعدل").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    private class CountingOutputStream(
        private val delegate: java.io.OutputStream
    ) : java.io.OutputStream() {
        var bytesWritten: Long = 0L
            private set

        override fun write(b: Int) {
            delegate.write(b)
            bytesWritten += 1L
        }

        override fun write(b: ByteArray) {
            delegate.write(b)
            bytesWritten += b.size.toLong()
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            delegate.write(b, off, len)
            bytesWritten += len.toLong()
        }

        override fun flush() {
            delegate.flush()
        }

        override fun close() {
            delegate.close()
        }
    }
}
