package com.example.model

import java.io.File

/**
 * Summary of a Smali class discovered inside `classes*.dex` of the selected APK.
 */
data class SmaliClassSummary(
    val classDescriptor: String,
    val dexEntryName: String,
    val methodNames: List<String>,
    val fieldCount: Int
)

/**
 * Stages of the Tab 3 Custom Smali Patching & Signing pipeline.
 */
enum class SmaliPatchStage(val stepIndex: Int, val labelAr: String) {
    IDLE(0, "جاهز لتعديل كود Smali وتوقيع الحزمة"),
    SCANNING_DEX(1, "جاري فحص ملفات classes*.dex والبحث عن الكلاس المستهدف..."),
    PATCHING_SMALI(2, "جاري تطبيق تعديلات Bytecode عبر applyUserCustomModifications..."),
    REPACKING_APK(3, "جاري إعادة بناء ملف DEX ومحاذاة resources.arsc (4-Byte STORED)..."),
    SIGNING_APK(4, "جاري التوقيع الرقمي الرسمي عبر ApkSigner (V1 + V2 + V3)..."),
    COMPLETED(5, "اكتمل تعديل كود Smali وتوقيع ملف APK بنجاح!"),
    FAILED(-1, "فشلت عملية تعديل Smali")
}

/**
 * Final output result of the Custom Smali Patcher pipeline.
 */
data class SmaliPatchResult(
    val outputApkFile: File,
    val outputFileName: String,
    val packageName: String,
    val targetClassDescriptor: String,
    val matchedDexEntries: List<String>,
    val matchedClassesCount: Int,
    val modifiedMethodsCount: Int,
    val customRulesApplied: String,
    val signedSchemesSummary: String = "V1 (JAR) + V2 + V3 (RSA-2048)",
    val executionDurationMs: Long,
    val logs: List<String>
)

/**
 * UI State for Tab 3 ("تعديل Smali" / Custom Smali Bytecode Editor).
 */
data class CustomSmaliUiState(
    val selectedApk: ApkFileInfo? = null,
    val discoveredClasses: List<SmaliClassSummary> = emptyList(),
    val targetClassDescriptor: String = "Lcom/example/samplelegacyapp/MainActivity;",
    val customRulesText: String = "# قواعد تعديل Smali / dexlib2:\n" +
        "# الصيغ المدعومة مباشرة أو عبر دالة applyUserCustomModifications:\n" +
        "return-true isFeatureEnabled\n" +
        "return-void onCreate",
    val isProcessing: Boolean = false,
    val currentStage: SmaliPatchStage = SmaliPatchStage.IDLE,
    val progressFloat: Float = 0f,
    val statusMessage: String = "",
    val logs: List<String> = emptyList(),
    val result: SmaliPatchResult? = null,
    val errorMessage: String? = null
)
