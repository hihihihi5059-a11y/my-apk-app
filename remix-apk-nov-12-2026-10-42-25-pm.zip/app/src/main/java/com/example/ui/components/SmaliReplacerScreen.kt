package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ReplacedSmaliMethodInfo
import com.example.model.SmaliPatchResult
import com.example.model.SmaliReplacerUiState
import com.example.ui.theme.CoralError
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanAccentGlow
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.DeepNavyBorder
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceElevated
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.OnCyanAccent

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SmaliReplacerScreen(
    uiState: SmaliReplacerUiState,
    onSelectApkClick: () -> Unit,
    onGenerateSampleClick: () -> Unit,
    onTargetClassChanged: (String) -> Unit,
    onSmaliMethodChanged: (Int, String) -> Unit,
    onAddMethodBlock: () -> Unit,
    onRemoveMethodBlock: (Int) -> Unit,
    onResetToDefaults: () -> Unit,
    onApplyPatchAndSignClick: () -> Unit,
    onInstallPatchedClick: () -> Unit,
    onSavePatchedClick: () -> Unit,
    onSharePatchedClick: () -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var showInlineSmaliEditor by rememberSaveable { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            DeepNavyBackground,
                            Color(0xFF0A1426),
                            DeepNavyBackground
                        )
                    )
                )
                .testTag("smali_replacer_screen"),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Header Banner explaining Flexible Smali Method Replacer
                SmaliEngineBannerCard()

                // 2. APK Upload & Multi-DEX Detection Card
                SmaliApkUploadCard(
                    uiState = uiState,
                    onSelectApkClick = onSelectApkClick,
                    onGenerateSampleClick = onGenerateSampleClick
                )

                // 3. Target Class & Smali Methods Configuration Card (synced with SmaliMethodReplacer.kt)
                SmaliConfigCard(
                    targetClassDescriptor = uiState.targetClassDescriptor,
                    rawSmaliMethods = uiState.rawSmaliMethodsText,
                    showEditor = showInlineSmaliEditor,
                    enabled = !uiState.isProcessing,
                    onToggleEditor = { showInlineSmaliEditor = !showInlineSmaliEditor },
                    onTargetClassChanged = onTargetClassChanged,
                    onSmaliMethodChanged = onSmaliMethodChanged,
                    onAddMethodBlock = onAddMethodBlock,
                    onRemoveMethodBlock = onRemoveMethodBlock,
                    onResetToDefaults = onResetToDefaults
                )

                // 4. Error Banner if any
                AnimatedVisibility(visible = uiState.errorMessage != null) {
                    uiState.errorMessage?.let { msg ->
                        SmaliErrorCard(
                            errorMessage = msg,
                            onDismiss = onDismissError
                        )
                    }
                }

                // 5. Primary Action Button: "تطبيق التعديل وتوقيع APK"
                val canExecute = uiState.selectedApk != null && !uiState.isProcessing
                Button(
                    onClick = onApplyPatchAndSignClick,
                    enabled = canExecute,
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = OnCyanAccent,
                        disabledContainerColor = DeepNavySurfaceElevated,
                        disabledContentColor = DarkTextMuted
                    ),
                    contentPadding = PaddingValues(vertical = 16.dp, horizontal = 24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .testTag("apply_smali_patch_button")
                ) {
                    if (uiState.isProcessing) {
                        CircularProgressIndicator(
                            color = OnCyanAccent,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "جاري تجميع Smali وتعديل DEX وتوقيع APK...",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "تطبيق التعديل وتوقيع APK",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                // 6. Real-Time Status & Live Log Console
                AnimatedVisibility(
                    visible = uiState.isProcessing || uiState.logs.isNotEmpty()
                ) {
                    SmaliRealTimeLogsCard(
                        isProcessing = uiState.isProcessing,
                        progressPercent = uiState.progressPercent,
                        statusText = uiState.statusText,
                        logs = uiState.logs
                    )
                }

                // 7. Patch Result Card with Replaced Methods List + Install & Save Buttons
                AnimatedVisibility(visible = uiState.result != null) {
                    uiState.result?.let { res ->
                        SmaliPatchResultCard(
                            result = res,
                            onInstallClick = onInstallPatchedClick,
                            onSaveClick = onSavePatchedClick,
                            onShareClick = onSharePatchedClick
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SmaliEngineBannerCard() {
    Surface(
        color = DeepNavySurface,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyanAccent.copy(alpha = 0.14f))
                    .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Code,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(24.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "محرك استبدال دوال Smali المرن (smali + dexlib2)",
                    style = MaterialTheme.typography.titleSmall,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "يقوم بتجميع أي عدد من دوال .method ... .end method في SmaliMethodReplacer.kt واستبدالها داخل classes*.dex مع محاذاة 4-Byte وتوقيع V1/V2/V3.",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SmaliApkUploadCard(
    uiState: SmaliReplacerUiState,
    onSelectApkClick: () -> Unit,
    onGenerateSampleClick: () -> Unit
) {
    val selectedApk = uiState.selectedApk
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smali_apk_upload_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(
            width = 1.5.dp,
            color = if (selectedApk != null) CyanAccent.copy(alpha = 0.75f) else DeepNavyBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(CyanAccent.copy(alpha = 0.14f))
                    .border(1.5.dp, CyanAccent.copy(alpha = 0.65f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (selectedApk != null) Icons.Default.Android else Icons.Default.UploadFile,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(32.dp)
                )
            }

            if (selectedApk == null) {
                Text(
                    text = "ارفع ملف APK لتعديل دوال Smali بداخله",
                    style = MaterialTheme.typography.titleMedium,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "سيتم فحص جميع ملفات classes.dex, classes2.dex, classes3.dex... تلقائياً للعثور على الكلاس المستهدف",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary,
                    textAlign = TextAlign.Center
                )
            } else {
                Surface(
                    color = DeepNavySurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = selectedApk.fileName,
                                style = MaterialTheme.typography.titleSmall,
                                color = DarkTextPrimary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Surface(
                                color = CyanAccent.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = selectedApk.formattedSize,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Text(
                                text = "pkg: ${selectedApk.packageName}",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = CyanAccentGlow
                            )
                        }

                        if (uiState.detectedDexFiles.isNotEmpty()) {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                uiState.detectedDexFiles.forEach { dexName ->
                                    Surface(
                                        color = DeepNavySurface,
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, DeepNavyBorder)
                                    ) {
                                        Text(
                                            text = dexName,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = FontFamily.Monospace,
                                            color = DarkTextSecondary,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onSelectApkClick,
                    enabled = !uiState.isProcessing,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = OnCyanAccent
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("select_smali_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.UploadFile,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedApk == null) "اختر ملف APK" else "تغيير ملف APK",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onGenerateSampleClick,
                    enabled = !uiState.isProcessing,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent),
                    modifier = Modifier
                        .height(50.dp)
                        .testTag("generate_smali_sample_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ملف تجريبي",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun SmaliConfigCard(
    targetClassDescriptor: String,
    rawSmaliMethods: List<String>,
    showEditor: Boolean,
    enabled: Boolean,
    onToggleEditor: () -> Unit,
    onTargetClassChanged: (String) -> Unit,
    onSmaliMethodChanged: (Int, String) -> Unit,
    onAddMethodBlock: () -> Unit,
    onRemoveMethodBlock: (Int) -> Unit,
    onResetToDefaults: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smali_config_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, DeepNavyBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "إعدادات SmaliMethodReplacer.kt",
                            style = MaterialTheme.typography.titleSmall,
                            color = DarkTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "عدد الدوال المجهزة للاستبدال: ${rawSmaliMethods.size} دالة",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary
                        )
                    }
                }

                TextButton(
                    onClick = onToggleEditor,
                    modifier = Modifier.testTag("toggle_smali_editor_button")
                ) {
                    Text(
                        text = if (showEditor) "إخفاء المحرر" else "تعديل مباشر",
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Target class descriptor summary badge
            Surface(
                color = DeepNavySurfaceElevated,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, DeepNavyBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "TARGET_CLASS_DESCRIPTOR:",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = targetClassDescriptor,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyanAccentGlow,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Optional inline editor so the user can edit in code OR directly in the UI
            AnimatedVisibility(visible = showEditor) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = targetClassDescriptor,
                            onValueChange = onTargetClassChanged,
                            enabled = enabled,
                            label = { Text("TARGET_CLASS_DESCRIPTOR") },
                            singleLine = true,
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                color = DarkTextPrimary
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = DeepNavyBorder,
                                focusedLabelColor = CyanAccent,
                                unfocusedLabelColor = DarkTextSecondary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("target_class_input")
                        )

                        rawSmaliMethods.forEachIndexed { index, methodCode ->
                            Column(
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Method Block #${index + 1} (.method ... .end method)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = CyanAccent,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    if (rawSmaliMethods.size > 1) {
                                        IconButton(
                                            onClick = { onRemoveMethodBlock(index) },
                                            enabled = enabled,
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "حذف الدالة",
                                                tint = CoralError,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = methodCode,
                                    onValueChange = { onSmaliMethodChanged(index, it) },
                                    enabled = enabled,
                                    minLines = 5,
                                    maxLines = 14,
                                    textStyle = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = DarkTextPrimary
                                    ),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyanAccent,
                                        unfocusedBorderColor = DeepNavyBorder
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("smali_method_input_$index")
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OutlinedButton(
                                onClick = onAddMethodBlock,
                                enabled = enabled,
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add .method Block")
                            }

                            TextButton(
                                onClick = onResetToDefaults,
                                enabled = enabled
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = DarkTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reset to SmaliMethodReplacer.kt", color = DarkTextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmaliRealTimeLogsCard(
    isProcessing: Boolean,
    progressPercent: Int,
    statusText: String,
    logs: List<String>
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smali_logs_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "سجل التجميع والتعديل المباشر (Real-Time Logs)",
                        style = MaterialTheme.typography.titleSmall,
                        color = DarkTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (isProcessing || progressPercent > 0) {
                    Text(
                        text = "$progressPercent%",
                        style = MaterialTheme.typography.labelLarge,
                        color = CyanAccent,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            if (isProcessing) {
                LinearProgressIndicator(
                    progress = { (progressPercent / 100f).coerceIn(0f, 1f) },
                    color = CyanAccent,
                    trackColor = DeepNavySurfaceElevated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
            }

            if (statusText.isNotEmpty()) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodySmall,
                    color = CyanAccentGlow,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Surface(
                color = Color(0xFF050A14),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, DeepNavyBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        logs.forEach { logLine ->
                            val lineColor = when {
                                logLine.startsWith("✓") || logLine.startsWith("★") -> EmeraldSuccess
                                logLine.startsWith("⚠") -> GoldWarning
                                logLine.startsWith("✖") -> CoralError
                                else -> DarkTextSecondary
                            }
                            Text(
                                text = logLine,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = lineColor
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmaliPatchResultCard(
    result: SmaliPatchResult,
    onInstallClick: () -> Unit,
    onSaveClick: () -> Unit,
    onShareClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smali_patch_result_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.5.dp, EmeraldSuccess.copy(alpha = 0.8f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(EmeraldSuccess.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = EmeraldSuccess,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "تم تعديل دوال Smali وتوقيع APK بنجاح!",
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "الملف المعدّل: ${result.modifiedDexFileName} • الدوال المستبدلة: ${result.replacedMethods.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = EmeraldSuccess
                    )
                }
            }

            HorizontalDivider(color = DeepNavyBorder)

            // Summary Details
            Surface(
                color = DeepNavySurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, DeepNavyBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "DEX Modified: ${result.modifiedDexFileName}",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyanAccentGlow,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Target Class: ${result.targetClassDescriptor}",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Replaced Methods (${result.replacedMethods.size}):",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        result.replacedMethods.forEach { methodInfo: ReplacedSmaliMethodInfo ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "${methodInfo.name}(${methodInfo.parameterTypes.joinToString("")})${methodInfo.returnType}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = EmeraldSuccess,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // Primary Install Button
            Button(
                onClick = onInstallClick,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldSuccess,
                    contentColor = Color(0xFF041F14)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("install_smali_patched_apk_button")
            ) {
                Icon(
                    imageVector = Icons.Default.InstallMobile,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تثبيت الـ APK المعدّل مباشرة",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            // Secondary Save & Share Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSaveClick,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyanAccent),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_smali_patched_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SaveAlt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "حفظ نسخة APK",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onShareClick,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkTextPrimary),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("share_smali_patched_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "مشاركة",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun SmaliErrorCard(
    errorMessage: String,
    onDismiss: () -> Unit
) {
    Surface(
        color = CoralError.copy(alpha = 0.14f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CoralError.copy(alpha = 0.7f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smali_error_banner")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = CoralError,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = DarkTextPrimary,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onDismiss) {
                Text("إغلاق", color = CoralError, fontWeight = FontWeight.Bold)
            }
        }
    }
}
