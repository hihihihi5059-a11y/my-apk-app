# APK Package Fixer (مصلح حزم التطبيقات للأندرويد)

تطبيق أندرويد متكامل بلغة Kotlin و Jetpack Compose بتصميم Material Design 3 (أزرق داكن Deep Navy مع لمسات سيان مضيئة Cyan Accent) لإصلاح مشاكل تثبيت وتحليل الحزم (Parse Error / "There was a problem parsing the package") في ملفات APK القديمة والحديثة عن طريق تعديل `minSdkVersion` و `targetSdkVersion` وفرض وسم `android:exported="true"` على المكونات وإعادة التوقيع الرقمي بمفتاح موثوق.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> تم استخلاص الخيارات التلقائية بناءً على طلبك مع إضافة دعم توليد APK تجريبي فوري داخل التطبيق ليتمكن المستخدم من تجربة الفحص والإصلاح مباشرة حتى وإن لم يتوفر لديه ملف APK خارجي على الجهاز، بجانب إمكانية اختيار أي ملف APK من الذاكرة عبر منتقي ملفات النظام (Storage Access Framework).

- **مظهر وثيم التطبيق**: أزرق بحري داكن (`#0A1128` / `#001F3F`) مع خلفيات ليلية عميقة ولمسات سيان نيون مشعة (`#00F2FE` / `#00E5FF`) وتصميم Material 3 متناسق يدعم الوضعين الداكن والفاتح.
- **إصلاحات البيان (Binary AndroidManifest.xml)**:
  - تعديل `minSdkVersion` إلى 24 (أندرويد 7.0) لتوسيع نطاق التوافق.
  - تعيين `targetSdkVersion` بحسب اختيار المستخدم (أندرويد 10=29، 11=30، 12=31، 13=33، 14=34، 15=35، والتوافق الشامل).
  - الفحص الذاتي للـ `<intent-filter>` في وسوم `<activity>` و `<service>` و `<receiver>` وإضافة خاصية `android:exported="true"` (مفتاح حل خطأ التثبيت في أندرويد 12 فما فوق).
- **إعادة التوقيع والحفظ والتثبيت**:
  - استخدام محرك التوقيع الرقمي المدمج (V1 + V2 Scheme) عبر شهادة Debug مدمجة بمكتبة `apksig`.
  - حفظ الملف في مجلد التنزيلات باسم `Fixed_<AppName>.apk`.
  - توفير نافذة منبثقة تفاعلية عند اكتمال العملية تتضمن زري: "حفظ التطبيق المعدل" و "تثبيت مباشرة" عبر `FileProvider`.

---

## 1. Overview & Core Concept

تطبيق **APK Package Fixer** يقدم حلاً عملياً مباشراً على الهاتف لمشكلة شائعة يواجهها مستخدمو ومطورو الأندرويد: فشل تثبيت التطبيقات القديمة على الهواتف الحديثة وظهور رسالة خطأ التحليل ("There was a problem parsing the package"). يقوم التطبيق باستقبال أي ملف APK، تفكيكه في مساحة معزولة (Cache Directory)، تصحيح بيانات التوافق في ملف `AndroidManifest.xml` الثنائي بصيغة AXML، إعادة تجميع الحزمة بدقة مع محاذاة الملفات وتوقيعها رقمياً، ثم منح المستخدم خيار تثبيتها أو حفظها في مجلد Downloads.

---

## 2. User Experience & Visual Design

### التسلسل البصري في الشاشة الرئيسية (حسب الترتيب المطلوب):
1. **الشريط العلوي (Top App Bar)**:
   - اسم التطبيق البارز: **APK Package Fixer** بخط واضح وتدرج لوني خفيف.
   - شارة حالة النظام: "Offline Engine • V1/V2 Signer".
2. **بطاقة الرفع التفاعلية الكبيرة (Large Interactive Card)**:
   - زوايا دائرية عريضة (Rounded Corner 24dp) مع إطار متوهج بلون السيان.
   - أيقونة رفع مميزة ومنطقة استلام تفاعلية.
   - زر بارز: **اختر ملف APK (Select APK File)** يفتح منتقي ملفات الأندرويد بصيغة `application/vnd.android.package-archive` أو `*/*`.
   - زر مساعد خفيف: "توليد ملف APK تجريبي للتجربة الفورية".
   - عند اختيار الملف: عرض اسم الحزمة، حجم الملف بالـ MB، وعدد المكونات المكتشفة.
3. **القائمة المنسدلة الأنيقة (Target Android Dropdown Menu)**:
   - عنوان القائمة: **اختر إصدار الأندرويد المستهدف (Select Target Android Version)**.
   - الخيارات المتاحة:
     - Android 10 (API 29)
     - Android 11 (API 30)
     - Android 12 (API 31 - Exported Tags Required)
     - Android 13 (API 33)
     - Android 14 (API 34)
     - Android 15 (API 35)
     - توافق شامل (من أندرويد 8 إلى 15) [Recommended]
4. **الزر الرئيسي البارز (Fix & Rebuild APK Button)**:
   - زر كبير ملون بالسماوي المضيء (Cyan Accent) مع نص داكن واضح: **إصلاح وبناء التطبيق (Fix & Rebuild APK)**.
   - تأثير تموج حركي (Ripple Effect) وحالة تعطيل ذكية إذا لم يتم اختيار ملف.
5. **شريط التقدم الدائري ومؤشر الحالة (Progress Indicator & Live Status)**:
   - مؤشر دائري أنيق (Circular Progress Indicator) يظهر أثناء المعالجة.
   - نص ديناميكي متحرك يوضح المرحلة اللحظية:
     - "جاري قراءة وفك ضغط ملف APK..."
     - "جاري فحص وتعديل AndroidManifest.xml (minSdk, targetSdk, exported)..."
     - "جاري إعادة ضغط الحزمة وحزم الأصول..."
     - "جاري التوقيع الرقمي بحزمة V1/V2 Keystore..."
     - "تم اكتمال العملية بنجاح!"
6. **نافذة اكتمال المعالجة (Completion Dialog)**:
   - نافذة منبثقة أنيقة مع أيقونة نجاح خضراء وميضية.
   - تفاصيل الملف المصلح: الاسم، الحجم، التعديلات المطبقة (`minSdk 24`, `targetSdk`, `exported=true`).
   - زر **تثبيت مباشرة (Install Directly)**: يطلق معالج التثبيت الرسمي لنظام أندرويد باستخدام `FileProvider`.
   - زر **حفظ التطبيق المعدل (Save Fixed APK)**: لتصدير الملف أو نسخه لمجلد التنزيلات الرسمي.

---

## 3. Technical Architecture & Component Flow

```
┌────────────────────────────────────────────────────────┐
│                   MainActivity                         │
│            (Scaffold, TopAppBar, Theme)                │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│              ApkPackageFixerScreen                     │
│  - File Picker Card (Dropzone + Metadata)              │
│  - Android Version Dropdown Selector                   │
│  - Fix & Rebuild Action Button                         │
│  - Circular Progress & Step Telemetry                  │
│  - Result Completion Dialog (Install / Save)           │
└───────────────────────────┬────────────────────────────┘
                            │ StateFlow & Events
┌───────────────────────────▼────────────────────────────┐
│              ApkFixerViewModel                         │
│  - Handles UI State (Selected APK, Target Version)     │
│  - Background Coroutines (Dispatchers.IO)              │
│  - Progress step notifications                         │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│              ApkFixerEngine                            │
│  1. ZipExtractor (Unpacks APK to cacheDir)             │
│  2. BinaryManifestEditor (Parses & edits AXML binary)  │
│     - Patches minSdkVersion, targetSdkVersion          │
│     - Injects android:exported="true" for filters      │
│  3. ZipRebuilder (Repacks APK with Deflate)            │
│  4. ApkSignerHelper (Signs via apksig v1/v2 schema)    │
│  5. Export & Installer (FileProvider URI intent)       │
└────────────────────────────────────────────────────────┘
```

---

## 4. Proposed Implementation Steps

1. **إعداد الألوان والثيم والخطوط**:
   - تحديث `Color.kt` ليعكس الألوان المطلوبة: الأزرق الداكن (`DeepNavyBackground = 0xFF070D1E`، `DeepNavySurface = 0xFF0F1B38`، `CyanAccent = 0xFF00E5FF`، `CyanGlow = 0xFF80F0FF`).
   - تحديث `Theme.kt` لدعم التباين العالي وتنسيقات Material 3.
   - ضبط `strings.xml` بجميع النصوص العربية والإنجليزية المطلوبة.

2. **بناء محرك تعديل الـ Manifest الثنائي (Binary Manifest Editor)**:
   - قراءة الـ Binary XML (AXML) الخاص بـ `AndroidManifest.xml`.
   - تعديل أو حقن سمات `minSdkVersion` و `targetSdkVersion` في عقدة `<uses-sdk>`.
   - فحص جميع وسوم `<activity>`, `<service>`, `<receiver>`: في حال وجود وسوم `<intent-filter>` فرعية، يتم التأكد من وجود السمة `android:exported="true"` أو إضافتها لضمان قبول أندرويد 12 و 13 و 14 و 15 لتثبيت الحزمة.

3. **محرك التجميع وإعادة التوقيع (Repack & Sign Engine)**:
   - إعادة ضغط محتويات الحزمة باستخدام `ZipOutputStream` مع الحفاظ على سلامة ملفات DEX والموارد.
   - توقيع الحزمة المخرجة بواسطة شهادة Debug مدمجة باستخدام مكتبة `apksig` لتوليد تواقيع APK Signature Scheme v1 و v2، مما يجعل الملف صالحاً للتثبيت الفوري على أي جهاز أندرويد دون تحذيرات تلف الحزمة.

4. **تطوير واجهة المستخدم الكاملة (Jetpack Compose Screen)**:
   - بناء الشاشة بجميع المكونات الستة بالترتيب والتفصيل الدقيق المطلوب.
   - ربط أزرار التثبيت المباشر بنظام `FileProvider` مع أذونات `REQUEST_INSTALL_PACKAGES` المناسبة.

5. **فحص وبناء التطبيق والتحقق**:
   - التحقق من تجميع الكود عبر `compile_applet` والتأكد من خلوه من أي مشاكل.
