# ضاغط ومُحسِّن ملفات APK (APK Compressor & Optimizer)

تطبيق أندرويد أصلي متكامل (Native Android) مبني بلغة Kotlin و Jetpack Compose (Material 3) بواجهة عربية كاملة (RTL) وتصميم ليلي احترافي (Obsidian Dark)، يعمل كمحرك حقيقي لضغط وتحسين ومحاذاة ملفات APK ثنائياً باستخدام `java.util.zip` وخوارزميات محاذاة 4KB (`zipalign`) على مستوى البايت.

### User Review & Critical Decisions

> [!IMPORTANT]
> نظراً لتجاوز أسئلة التخصيص المبدئية، تم اعتماد الخيارات الموصى بها لضمان تجربة متكاملة وقابلة للاختبار الفوري على جميع الأجهزة والمحاكيات:

- **مصادر تحميل ملفات APK (Confirmed Default)**: دعم اختيار أي ملف `.apk` خارجي عبر `ActivityResultContracts.OpenDocument` (Storage Access Framework)، بالإضافة إلى خيار **"فحص حزمة التطبيق الحالية / توليد ملف APK نموذجي للاختبار"** لتمكين التجربة الفورية داخل المحاكي حتى في حال عدم وجود ملفات APK محمّلة مسبقاً.
- **أدوات التحسين والفحص المتقدمة (Confirmed Default)**: تضمين مستكشف تفاعلي لملفات الأرشيف (Interactive APK Entry Browser) يعرض نسبة الضغط وحالة المحاذاة لكل ملف، مع خيار تصفية معماريات المعالج (ABI Architecture Filter) وخيار إزالة تواقيع `META-INF/` القديمة لتجهيز الملف للتوقيع النظيف.
- **الهوية البصرية (Confirmed Default)**: ثيم ليلي تقني (Obsidian & Emerald/Cyan Technical Dark Theme) مع خطوط عربية واضحة (`Cairo` للعناوين والنصوص و `JetBrains Mono` للمؤشرات الرقمية والسجلات الحية) وتخطيط RTL أصيل.

---

### 1. Overview & Core Concept

- **What It Does**: يقوم التطبيق بقراءة وتحليل ملفات `.apk` على مستوى التدفق الثنائي (Binary Stream)، ويعرض تفصيلاً دقيقاً لأحجام المكونات (`classes*.dex`, `resources.arsc`, `lib/`, `res/`, `assets/`, `META-INF/`)، ثم يعيد بناء وضغط حزمة APK وفق وضع التحسين المختار مع حساب CRC32 الدقيق وضبط محاذاة 4096-byte (4KB Alignment) لملفات `STORED`.
- **Target Audience / Persona**: مطورو تطبيقات أندرويد، مهندسو الأداء (Performance Engineers)، والمستخدمون المتقدمون الراغبون في تقليص حجم حزم APK أو تسريع تحميل الموارد والمكتبات الأصلية في الذاكرة (`mmap`).
- **Key Value**: معالجة ثنائية حقيقية 100% على الجهاز (`Dispatchers.IO`) بدون أي بيانات وهمية، مع تحكم كامل في توازن "سرعة الأداء وذاكرة mmap" مقابل "أقل حجم ممكن للملف".

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **الاختيار والتحليل (Selection & Inspection)**: يختار المستخدم ملف `.apk` عبر منتقي الملفات أو يحمّل حزمة التطبيق الحالية للاختبار؛ يقوم المحرك فوراً بمسح جدول محتويات ZIP وعرض الحجم الأصلي، عدد الملفات، ومخطط التوزيع (`classes*.dex`, `resources.arsc`, `lib/`, `res/`, `assets/`).
  2. **ضبط وضع الضغط (Compression Configuration)**: يختار المستخدم بين بطاقتي الوضع الأساسيتين (**أولوية الأداء** أو **أولوية حجم الملف**)، ويضبط المفاتيح الإضافية (**الضغط الشديد Ultra Deflate Level 9**، **توافق أندرويد 11+ لملف `resources.arsc`**، **إزالة تواقيع `META-INF/`**، وتصفية معماريات `lib/`).
  3. **المعالجة الحية (Live Stream Telemetry)**: عند بدء الضغط، يظهر شريط التقدم اللحظي، اسم المدخل الجاري معالجته، عدد البايتات المعالجة، وسجل أوامر حي (Live Console Log) يوضح حالة كل ملف (`STORED [4K Aligned]` أو `DEFLATED [Ultra Lv9]`).
  4. **النتيجة والتصدير (Summary & Export)**: بطاقة مقارنة شاملة تعرض الحجم الأصلي مقابل الحجم الجديد، المساحة الموفرة بالميجابايت والنسبة المئوية، مع أزرار لحفظ ملف APK المحسّن عبر `ActivityResultContracts.CreateDocument` أو مشاركته عبر `FileProvider`.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: واجهة تقنية احترافية مستوحاة من أدوات تحليل الأنظمة (Precision Binary Inspector)، تجمع بين التباين العالي والوضوح الهندسي.
  - *Color Palette & Mood*:
    - الخلفية الأساسية (`Background`): `#0B0F17` (Obsidian Night)
    - البطاقات والأسطح (`Surface` / `SurfaceVariant`): `#131B2E` و `#1C2742`
    - اللون الأساسي (`Primary`): `#10B981` (Emerald Matrix) لمؤشرات النجاح والتوفير
    - اللون الثانوي (`Secondary`): `#06B6D4` (Cyan Pulse) لمؤشرات المحاذاة 4K والتدفق الحي
    - لون التنبيه (`Tertiary` / `Warning`): `#F59E0B` (Amber) لتنبيهات التوافق والتواقيع
  - *Typography & Hierarchy*: خط `Cairo` للنصوص والواجهات العربية مع خط `JetBrains Mono` للأحجام، العناوين السداسية (CRC32 / Offsets)، وسجل العمليات الحي.
  - *Component Styling & Layout*: دعم كامل لاتجاه `LayoutDirection.Rtl`، بطاقات اختيار تفاعلية بحواف مضيئة عند التحديد، وشريط تقدم متعدد الألوان يوضح توزيع مكونات APK.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: محاذاة 4KB حقيقية عبر حقل Extra Field في ترويسة ZIP المحلية**
  - *Chosen Approach*: حساب إزاحة بداية البيانات الفعلية (Data Offset = Current Stream Byte Offset + 30 + Filename Length) لكل ملف يُكتب بطريقة `ZipEntry.STORED`، وإضافة بايتات حشو (Padding) دقيقة في `ZipEntry.extra` بحيث يبدأ محتوى الملف دائماً عند مضاعف للعدد `4096` (4KB).
  - *Why*: نظام أندرويد (خصوصاً Android 11 API 30 فما فوق لملف `resources.arsc` والمكتبات `.so` عند تفعيل `extractNativeLibs="false"`) يتطلب محاذاة 4KB ليتمكن من عمل `mmap` مباشر للموارد من داخل الـ APK دون نسخها للذاكرة.
  - *Alternatives Considered*: الاعتماد على `ZipOutputStream` الافتراضي بدون حشو، لكنه ينتج إزاحات عشوائية تؤدي لفشل التثبيت على أندرويد 11+ عند عدم ضغط `resources.arsc`.

- **Decision 2: إعادة الضغط الشديد (Ultra Deflate Level 9) على مرحلتين لتجنب descriptors الزائدة**
  - *Chosen Approach*: عند تفعيل **الضغط الشديد**، يتم فك ضغط بيانات المدخل وإعادة ضغطها باستخدام `Deflater(Deflater.BEST_COMPRESSION, true)` وتمريرها عبر تدفق مخصص يحسب الحجم المضغوط و CRC32 بدقة عالية.
  - *Why*: يمنح أقصى تقليص ممكن لحجم ملفات `classes*.dex` و `assets/` والملفات القابلة للضغط مع الحفاظ على سلامة الترويسات الثنائية.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:
```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Arabic RTL Compose UI Layer (M3)                     │
│  ┌────────────────────┐  ┌────────────────────┐  ┌───────────────────┐  │
│  │ APK Inspector Card │  │ Mode & Flags Panel │  │ Live Telemetry &  │  │
│  │ (Breakdown & List) │  │ (Perf/Size/Ultra)  │  │ Summary Export UI │  │
│  └─────────┬──────────┘  └─────────┬──────────┘  └─────────┬─────────┘  │
└────────────┼───────────────────────┼───────────────────────┼────────────┘
             │                       │                       │
             ▼                       ▼                       ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                 ApkOptimizerViewModel (StateFlow / MVVM)                │
│  • Holds ApkAnalysisReport, OptimizationConfig, ProcessingProgress      │
│  • Coordinates SAF URI streams, Sample APK builder & Share intents      │
└────────────────────────────────────┬────────────────────────────────────┘
                                     │ Coroutines (Dispatchers.IO)
                                     ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                   Binary ApkCompressionEngine (Core)                    │
│  ┌─────────────────────────┐  ┌─────────────────────────┐               │
│  │ ApkAnalyzer             │  │ AlignedZipOutputStream  │               │
│  │ • Category breakdown    │  │ • Exact Byte Counter    │               │
│  │ • Entry CRC/Size reader │  │ • 4096-byte Extra Pad   │               │
│  └─────────────────────────┘  │ • Deflater Level 9      │               │
│                               └─────────────────────────┘               │
└─────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - `CompressionMode`:
    - `PERFORMANCE_PRIORITY`: يضع الصور (`.png`, `.webp`, `.jpg`, `.jpeg`)، الصوتيات (`.mp3`, `.ogg`, `.wav`)، `resources.arsc`، ومكتبات `.so` في وضع `ZipEntry.STORED` مع محاذاة 4KB (`4096` بايت)، ويضغط باقي الملفات مثل `classes*.dex` بوضع `DEFLATED`.
    - `FILE_SIZE_PRIORITY`: يضغط جميع الملفات لتقليل الحجم لأقصى درجة، مع احترام خيار **"توافق أندرويد 11+ (إبقاء resources.arsc بدون ضغط)"** عند تفعيله.
  - `OptimizationConfig`: يضم `mode`, `ultraCompressionEnabled`, `keepArscUncompressedForAndroid11`, `stripMetaInfSignatures`, و `selectedAbis`.
  - `ApkAnalysisReport`: يحتوي على اسم الملف، الحجم الكلي، عدد المدخلات، وتفصيل الأحجام حسب الفئة (`dexBytes`, `arscBytes`, `libBytes`, `resBytes`, `assetsBytes`, `otherBytes`) وقائمة المدخلات الفردية.
  - `OptimizationResult`: يحتوي على المسار المؤقت للملف الناتج، الحجم الأصلي، الحجم الجديد، مقدار التوفير بالبايت والنسبة المئوية، عدد الملفات المحاذاة بـ 4KB، والزمن المستغرق.

- **Interactive Component & State Mapping**:
  - **اختيار ملف APK**: يستدعي `OpenDocument` بفلتر `application/vnd.android.package-archive` (أو `*/*` لدعم كافة مديري الملفات)، أو يقرأ `context.applicationInfo.sourceDir` لفحص وتجربة حزمة APK حقيقية فوراً على المحاكي.
  - **تبديل أوضاع الضغط والمفاتيح**: يحدث `OptimizationConfig` في `ViewModel` ويعرض تقديراً فورياً لسلوك المحرك مع النصوص العربية المطلوبة حرفياً.
  - **محرك الضغط الحي**: يبث تحديثات `Flow<ProcessingProgress>` تحتوي على النسبة المئوية، اسم الملف الحالي، البايتات المعالجة، وسجل العمليات، مع إمكانية الإلغاء الآمن.
  - **الحفظ والمشاركة**: ينسخ الملف الناتج إلى الوجهة المختارة عبر `CreateDocument("application/vnd.android.package-archive")` أو يشاركه عبر `FileProvider` و `Intent.ACTION_SEND`.
