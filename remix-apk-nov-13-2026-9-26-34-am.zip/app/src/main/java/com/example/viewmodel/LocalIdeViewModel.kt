package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.LocalApkIdeEngine
import com.example.engine.LocalGgufAiEngine
import com.example.model.AiEngineStatus
import com.example.model.CodeChunkResult
import com.example.model.HardwareTelemetryState
import com.example.model.IdeScreenTab
import com.example.model.InstalledAppItem
import com.example.model.LocalAiTaskType
import com.example.model.LocalBuildState
import com.example.model.LocalDecompiledProject
import com.example.model.LocalGgufModelState
import com.example.model.ProjectFileNode
import com.example.model.ProjectFileType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LocalIdeUiState(
    val activeTab: IdeScreenTab = IdeScreenTab.DASHBOARD,
    val telemetry: HardwareTelemetryState = HardwareTelemetryState(),
    val ggufModel: LocalGgufModelState = LocalGgufModelState(),
    val projects: List<LocalDecompiledProject> = emptyList(),
    val activeProject: LocalDecompiledProject? = null,
    val installedApps: List<InstalledAppItem> = emptyList(),
    val showInstalledAppsSheet: Boolean = false,
    val isDecompiling: Boolean = false,
    val statusMessage: String? = null,
    val errorMessage: String? = null,

    // Screen 2: Local Project Tree State
    val treeSearchQuery: String = "",
    val selectedFolderFilter: String = "ALL", // ALL, smali, res, root

    // Screen 3: Local AI Code Editor State
    val selectedFileNode: ProjectFileNode? = null,
    val isSplitViewEnabled: Boolean = true,
    val editorJavaText: String = "",
    val editorSmaliText: String = "",
    val isAiAnalyzing: Boolean = false,
    val aiChunkProgressText: String = "",
    val latestAiResult: CodeChunkResult? = null,
    val showAiSheet: Boolean = false,

    // Screen 4: Local Build & Sign Console State
    val buildState: LocalBuildState = LocalBuildState()
)

class LocalIdeViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(LocalIdeUiState())
    val uiState: StateFlow<LocalIdeUiState> = _uiState.asStateFlow()

    private var initialized = false

    init {
        startHardwareTelemetryMonitor()
    }

    private fun startHardwareTelemetryMonitor() {
        viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                val runtime = Runtime.getRuntime()
                val totalMem = runtime.maxMemory().coerceAtLeast(128L * 1024L * 1024L)
                val allocatedMem = runtime.totalMemory() - runtime.freeMemory()
                val usedMb = (allocatedMem / (1024L * 1024L)).coerceAtLeast(92L)
                val maxMb = (totalMem / (1024L * 1024L)).coerceAtLeast(256L)
                val ramPct = ((usedMb * 100L) / maxMb).toInt().coerceIn(12, 94)

                val isBusy = _uiState.value.isAiAnalyzing ||
                    _uiState.value.isDecompiling ||
                    _uiState.value.buildState.isBuilding

                val simulatedCpu = if (isBusy) (54..82).random() else (9..21).random()
                val aiStatus = when {
                    _uiState.value.isAiAnalyzing -> AiEngineStatus.ANALYZING
                    _uiState.value.ggufModel.isCustomFileImported -> AiEngineStatus.MODEL_LOADED
                    else -> AiEngineStatus.READY
                }

                _uiState.update { state ->
                    state.copy(
                        telemetry = state.telemetry.copy(
                            usedRamMb = usedMb,
                            totalRamMb = maxMb,
                            ramUsagePercent = ramPct,
                            cpuLoadPercent = simulatedCpu,
                            aiStatus = aiStatus
                        )
                    )
                }
                delay(2000L)
            }
        }
    }

    fun initializeDefaultWorkspaceIfNeeded(context: Context) {
        if (initialized) return
        initialized = true
        viewModelScope.launch {
            _uiState.update { it.copy(isDecompiling = true) }
            try {
                val ideEngine = LocalApkIdeEngine(context)
                val sampleProject = ideEngine.createAndDecompileSampleProject()
                val firstSmali = sampleProject.files.firstOrNull { it.fileType == ProjectFileType.SMALI }
                    ?: sampleProject.files.firstOrNull()

                _uiState.update { state ->
                    state.copy(
                        isDecompiling = false,
                        projects = listOf(sampleProject),
                        activeProject = sampleProject,
                        selectedFileNode = firstSmali,
                        editorJavaText = firstSmali?.javaContent.orEmpty(),
                        editorSmaliText = firstSmali?.smaliContent.orEmpty(),
                        statusMessage = "تم تجهيز مساحة العمل المحلية وفك حزمة ${sampleProject.appName} بنجاح (100% Offline)"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isDecompiling = false,
                        errorMessage = "تعذر تهيئة المشروع الافتراضي: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun selectTab(tab: IdeScreenTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(statusMessage = null, errorMessage = null) }
    }

    /**
     * Imports a .gguf model file from device storage and verifies its binary GGUF header.
     */
    fun onGgufModelSelected(context: Context, uri: Uri) {
        viewModelScope.launch {
            val (name, size) = resolveUriDisplayNameAndSize(context, uri, "Qwen2.5-Coder-1.5B-Q4_K_M.gguf")
            val aiEngine = LocalGgufAiEngine(context)
            val modelState = aiEngine.inspectAndRegisterGgufModel(uri, name, size)
            _uiState.update {
                it.copy(
                    ggufModel = modelState,
                    statusMessage = "تم ربط نموذج الذكاء الاصطناعي المحلي (${modelState.modelName}) للعمل بدون إنترنت"
                )
            }
        }
    }

    /**
     * Switches between preset GGUF model profiles (Qwen2.5-Coder-1.5B, DeepSeek-Coder-1.3B, Gemma-2-2B).
     */
    fun selectPresetGgufProfile(modelName: String, arch: String, sizeMb: Long) {
        _uiState.update { state ->
            state.copy(
                ggufModel = state.ggufModel.copy(
                    modelName = modelName,
                    architecture = arch,
                    fileSizeMb = sizeMb,
                    quantization = "Q4_K_M (4-bit Quantized)",
                    headerMagicVerified = true
                ),
                statusMessage = "تم التبديل إلى ملف تعريف النموذج المحلي: $modelName"
            )
        }
    }

    /**
     * Imports and decompiles an external .apk file selected via SAF OpenDocument.
     */
    fun onExternalApkSelected(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isDecompiling = true,
                    statusMessage = "جاري فك تجميع ملف APK واستخراج ملفات Smali و Java محلياً..."
                )
            }
            try {
                val (displayName, _) = resolveUriDisplayNameAndSize(context, uri, "ExternalApp.apk")
                val engine = LocalApkIdeEngine(context)
                val project = engine.importAndDecompileUri(uri, displayName)
                activateDecompiledProject(project, navigateToTree = true)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isDecompiling = false,
                        errorMessage = "فشل فك حزمة APK: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun openInstalledAppsPicker(context: Context) {
        viewModelScope.launch {
            val engine = LocalApkIdeEngine(context)
            val installed = engine.listInstalledApps()
            _uiState.update {
                it.copy(
                    installedApps = installed,
                    showInstalledAppsSheet = true
                )
            }
        }
    }

    fun closeInstalledAppsPicker() {
        _uiState.update { it.copy(showInstalledAppsSheet = false) }
    }

    fun importInstalledApp(context: Context, appItem: InstalledAppItem) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    showInstalledAppsSheet = false,
                    isDecompiling = true,
                    statusMessage = "جاري فك تجميع تطبيق ${appItem.appName} (${appItem.packageName})..."
                )
            }
            try {
                val engine = LocalApkIdeEngine(context)
                val project = engine.decompileApkFile(
                    apkFile = File(appItem.sourceApkPath),
                    customTitle = appItem.appName,
                    customPackage = appItem.packageName
                )
                activateDecompiledProject(project, navigateToTree = true)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isDecompiling = false,
                        errorMessage = "تعذر فك التطبيق المحدد: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun generateNewSampleProject(context: Context) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isDecompiling = true,
                    statusMessage = "جاري بناء وفك مشروع APK نموذجي جديد داخل filesDir..."
                )
            }
            try {
                val engine = LocalApkIdeEngine(context)
                val project = engine.createAndDecompileSampleProject()
                activateDecompiledProject(project, navigateToTree = true)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isDecompiling = false,
                        errorMessage = "حدث خطأ أثناء إنشاء المشروع النموذجي: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun selectExistingProject(project: LocalDecompiledProject) {
        val firstNode = project.files.firstOrNull { it.fileType == ProjectFileType.SMALI }
            ?: project.files.firstOrNull()
        _uiState.update {
            it.copy(
                activeProject = project,
                selectedFileNode = firstNode,
                editorJavaText = firstNode?.javaContent.orEmpty(),
                editorSmaliText = firstNode?.smaliContent.orEmpty(),
                activeTab = IdeScreenTab.PROJECT_TREE,
                statusMessage = "تم فتح المشروع المحلي: ${project.appName}"
            )
        }
    }

    private fun activateDecompiledProject(project: LocalDecompiledProject, navigateToTree: Boolean) {
        val firstNode = project.files.firstOrNull { it.fileType == ProjectFileType.SMALI }
            ?: project.files.firstOrNull()
        _uiState.update { state ->
            val updatedList = listOf(project) + state.projects.filterNot { it.projectId == project.projectId }
            state.copy(
                isDecompiling = false,
                projects = updatedList,
                activeProject = project,
                selectedFileNode = firstNode,
                editorJavaText = firstNode?.javaContent.orEmpty(),
                editorSmaliText = firstNode?.smaliContent.orEmpty(),
                activeTab = if (navigateToTree) IdeScreenTab.PROJECT_TREE else state.activeTab,
                statusMessage = "تم فك ${project.appName}: ${project.smaliClassesCount} ملف Smali و ${project.xmlResourcesCount} ملف XML جاهز للتعديل"
            )
        }
    }

    // Screen 2: Project Tree Actions
    fun updateTreeSearchQuery(query: String) {
        _uiState.update { it.copy(treeSearchQuery = query) }
    }

    fun selectFolderFilter(folder: String) {
        _uiState.update { it.copy(selectedFolderFilter = folder) }
    }

    fun openFileInEditor(node: ProjectFileNode) {
        _uiState.update {
            it.copy(
                selectedFileNode = node,
                editorJavaText = node.javaContent,
                editorSmaliText = node.smaliContent,
                latestAiResult = null,
                activeTab = IdeScreenTab.CODE_EDITOR
            )
        }
    }

    // Screen 3: Local AI Code Editor Actions
    fun toggleSplitView() {
        _uiState.update { it.copy(isSplitViewEnabled = !it.isSplitViewEnabled) }
    }

    fun updateEditorJavaText(context: Context, newJava: String) {
        val engine = LocalApkIdeEngine(context)
        val currentSmali = _uiState.value.editorSmaliText
        val syncedSmali = engine.transpileJavaEditsToSmali(newJava, currentSmali)
        persistActiveEditorBuffers(newJava, syncedSmali)
    }

    fun updateEditorSmaliText(newSmali: String) {
        val currentJava = _uiState.value.editorJavaText
        persistActiveEditorBuffers(currentJava, newSmali)
    }

    private fun persistActiveEditorBuffers(newJava: String, newSmali: String) {
        _uiState.update { state ->
            val currentNode = state.selectedFileNode ?: return@update state
            val updatedNode = currentNode.copy(
                javaContent = newJava,
                smaliContent = newSmali,
                xmlContent = if (currentNode.fileType != ProjectFileType.SMALI) newJava else currentNode.xmlContent,
                isModified = true
            )
            val currentProject = state.activeProject
            val updatedProject = currentProject?.copy(
                files = currentProject.files.map { if (it.id == updatedNode.id) updatedNode else it },
                lastModifiedTimestamp = System.currentTimeMillis()
            )
            state.copy(
                editorJavaText = newJava,
                editorSmaliText = newSmali,
                selectedFileNode = updatedNode,
                activeProject = updatedProject,
                projects = state.projects.map {
                    if (updatedProject != null && it.projectId == updatedProject.projectId) updatedProject else it
                }
            )
        }
    }

    fun setShowAiSheet(visible: Boolean) {
        _uiState.update { it.copy(showAiSheet = visible) }
    }

    fun runLocalAiTask(context: Context, taskType: LocalAiTaskType) {
        val stateSnap = _uiState.value
        val javaInput = stateSnap.editorJavaText
        val smaliInput = stateSnap.editorSmaliText

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isAiAnalyzing = true,
                    showAiSheet = true,
                    aiChunkProgressText = "جاري تقسيم الكود (Chunking) لتجنب استهلاك RAM..."
                )
            }
            try {
                val aiEngine = LocalGgufAiEngine(context)
                val result = aiEngine.analyzeAndTransformCode(
                    taskType = taskType,
                    javaCode = javaInput,
                    smaliCode = smaliInput,
                    modelState = stateSnap.ggufModel,
                    onChunkProgress = { idx, total ->
                        _uiState.update { s ->
                            s.copy(
                                telemetry = s.telemetry.copy(activeChunkCount = total),
                                aiChunkProgressText = "معالجة الدفعة $idx من $total عبر ${stateSnap.ggufModel.modelName}..."
                            )
                        }
                    }
                )
                // Automatically apply refactored code if task is RENAME_VARIABLES or SUGGEST_CLEAN_PATCH
                if (taskType == LocalAiTaskType.RENAME_VARIABLES ||
                    taskType == LocalAiTaskType.SUGGEST_CLEAN_PATCH
                ) {
                    persistActiveEditorBuffers(result.refactoredJava, result.refactoredSmali)
                }

                _uiState.update {
                    it.copy(
                        isAiAnalyzing = false,
                        latestAiResult = result,
                        aiChunkProgressText = "اكتمل التحليل المحلي (${result.totalChunks} Chunks) بدون اتصال بالشبكة"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isAiAnalyzing = false,
                        errorMessage = "خطأ في محرك الذكاء الاصطناعي المحلي: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun applyAiResultToEditor() {
        val result = _uiState.value.latestAiResult ?: return
        persistActiveEditorBuffers(result.refactoredJava, result.refactoredSmali)
        _uiState.update {
            it.copy(
                showAiSheet = false,
                statusMessage = "تم تطبيق تعديلات الذكاء الاصطناعي المحلي ومزامنة كود Smali و Java"
            )
        }
    }

    // Screen 4: Local Build & Sign Console Actions
    fun startLocalBuildAndSign(context: Context) {
        val project = _uiState.value.activeProject ?: return
        if (_uiState.value.buildState.isBuilding) return

        viewModelScope.launch {
            val timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
            _uiState.update {
                it.copy(
                    activeTab = IdeScreenTab.BUILD_CONSOLE,
                    buildState = LocalBuildState(
                        isBuilding = true,
                        progressPercent = 5,
                        consoleLogs = listOf(
                            "[$timestamp] بدء بناء المشروع المحلي: ${project.appName} (${project.packageName})",
                            "[$timestamp] مسار التخزين الداخلي: ${project.workspaceDirPath}"
                        )
                    )
                )
            }

            val engine = LocalApkIdeEngine(context)
            val buildResult = engine.buildAndSignProject(
                project = project,
                onStepUpdate = { steps, percent, logLine ->
                    val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
                    _uiState.update { state ->
                        state.copy(
                            buildState = state.buildState.copy(
                                steps = steps,
                                progressPercent = percent,
                                consoleLogs = state.buildState.consoleLogs + "[$ts] $logLine"
                            )
                        )
                    }
                }
            )

            buildResult.fold(
                onSuccess = { signedFile ->
                    _uiState.update { state ->
                        val updatedProj = state.activeProject?.copy(signedOutputApkPath = signedFile.absolutePath)
                        state.copy(
                            activeProject = updatedProj,
                            buildState = state.buildState.copy(
                                isBuilding = false,
                                progressPercent = 100,
                                outputSignedApkPath = signedFile.absolutePath,
                                signatureVerified = true
                            ),
                            statusMessage = "تم تجميع وتوقيع ${signedFile.name} محلياً بنجاح!"
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update { state ->
                        state.copy(
                            buildState = state.buildState.copy(
                                isBuilding = false,
                                buildError = err.localizedMessage ?: "خطأ غير متوقع أثناء التجميع"
                            ),
                            errorMessage = "فشل البناء المحلي: ${err.localizedMessage}"
                        )
                    }
                }
            )
        }
    }

    fun installSignedApkDirectly(context: Context) {
        val apkPath = _uiState.value.buildState.outputSignedApkPath ?: return
        val file = File(apkPath)
        if (!file.exists()) {
            _uiState.update { it.copy(errorMessage = "ملف APK الموقع غير موجود، يرجى تشغيل البناء أولاً.") }
            return
        }
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(installIntent, "تثبيت APK المعدل محلياً"))
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر فتح مثبت الحزم: ${e.localizedMessage}")
            }
        }
    }

    fun exportSignedApkToUri(context: Context, targetUri: Uri) {
        val apkPath = _uiState.value.buildState.outputSignedApkPath ?: return
        val file = File(apkPath)
        if (!file.exists()) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                context.contentResolver.openOutputStream(targetUri)?.use { out ->
                    FileInputStream(file).use { input ->
                        input.copyTo(out)
                    }
                }
                _uiState.update {
                    it.copy(statusMessage = "تم حفظ ملف APK الموقع بنجاح في ذاكرة الجهاز")
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "تعذر حفظ الملف: ${e.localizedMessage}")
                }
            }
        }
    }

    private suspend fun resolveUriDisplayNameAndSize(
        context: Context,
        uri: Uri,
        fallbackName: String
    ): Pair<String, Long> = withContext(Dispatchers.IO) {
        var name = fallbackName
        var size = 1024L * 1024L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: fallbackName
                    if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
                }
            }
        } catch (_: Exception) {
        }
        name to size
    }
}
