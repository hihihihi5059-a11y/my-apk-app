package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.CodeInjectorEngine
import com.example.model.InjectionRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class InjectionUiState(
    val apkFilePath: String = "",
    val apkDisplayName: String = "",
    val targetClassName: String = "Lcom/example/MainActivity;",
    val methodSignature: String = "onCreate(Landroid/os/Bundle;)V",
    val replacementSmali: String = ".method protected onCreate(Landroid/os/Bundle;)V\n    .registers 2\n    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V\n    return-void\n.end method",
    val isProcessing: Boolean = false,
    val progressPercent: Int = 0,
    val logs: List<String> = listOf("جاهز لاستقبال إعدادات الحقن..."),
    val outputPath: String? = null,
    val errorMessage: String? = null
)

class InjectionViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(InjectionUiState())
    val uiState: StateFlow<InjectionUiState> = _uiState.asStateFlow()

    fun onApkUriSelected(context: Context, uri: Uri) {
        val displayName = resolveDisplayName(context, uri) ?: uri.lastPathSegment ?: "selected.apk"
        val displayPath = uri.toString()
        _uiState.update { state ->
            state.copy(
                apkFilePath = displayPath,
                apkDisplayName = displayName,
                errorMessage = null,
                logs = state.logs + "تم اختيار ملف APK: $displayName ($displayPath)"
            )
        }
    }

    fun updateApkFilePath(path: String) {
        _uiState.update { it.copy(apkFilePath = path, errorMessage = null) }
    }

    fun updateTargetClassName(className: String) {
        _uiState.update { it.copy(targetClassName = className, errorMessage = null) }
    }

    fun updateMethodSignature(signature: String) {
        _uiState.update { it.copy(methodSignature = signature, errorMessage = null) }
    }

    fun updateReplacementSmali(smali: String) {
        _uiState.update { it.copy(replacementSmali = smali, errorMessage = null) }
    }

    fun clearLogs() {
        _uiState.update {
            it.copy(
                logs = listOf("تم مسح السجل."),
                progressPercent = 0,
                outputPath = null,
                errorMessage = null
            )
        }
    }

    fun startInjection(context: Context) {
        val currentState = _uiState.value
        if (currentState.apkFilePath.isBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "يرجى اختيار ملف APK أولاً",
                    logs = it.logs + "⚠️ خطأ: لم يتم تحديد مسار ملف APK."
                )
            }
            return
        }
        if (currentState.targetClassName.isBlank() || currentState.methodSignature.isBlank()) {
            _uiState.update {
                it.copy(
                    errorMessage = "يرجى إدخال اسم الكلاس وتوقيع الدالة المستهدفة",
                    logs = it.logs + "⚠️ خطأ: حقول الكلاس أو الدالة فارغة."
                )
            }
            return
        }

        val request = InjectionRequest(
            apkFilePath = currentState.apkFilePath,
            targetClassName = currentState.targetClassName.trim(),
            methodSignature = currentState.methodSignature.trim(),
            replacementSmali = currentState.replacementSmali
        )

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    progressPercent = 10,
                    errorMessage = null,
                    outputPath = null,
                    logs = it.logs + listOf(
                        "جاري القراءة: ${currentState.apkDisplayName.ifBlank { currentState.apkFilePath }}...",
                        "الكلاس المستهدف: ${request.targetClassName}",
                        "توقيع الدالة: ${request.methodSignature}"
                    )
                )
            }

            val engine = CodeInjectorEngine(context.applicationContext)
            val listener = object : CodeInjectorEngine.LogListener {
                override fun onLog(message: String) {
                    _uiState.update { state ->
                        state.copy(logs = state.logs + message)
                    }
                }

                override fun onProgress(percent: Int) {
                    _uiState.update { state ->
                        state.copy(progressPercent = percent.coerceIn(0, 100))
                    }
                }

                override fun onSuccess(outputPath: String) {
                    _uiState.update { state ->
                        state.copy(
                            isProcessing = false,
                            progressPercent = 100,
                            outputPath = outputPath,
                            logs = state.logs + "تم الحقن بنجاح: $outputPath"
                        )
                    }
                }

                override fun onError(error: String) {
                    _uiState.update { state ->
                        state.copy(
                            isProcessing = false,
                            errorMessage = error,
                            logs = state.logs + "❌ خطأ: $error"
                        )
                    }
                }
            }

            try {
                engine.validateApk(request.apkFilePath)
                engine.injectCode(request, listener)
            } catch (notImplemented: NotImplementedError) {
                // Gracefully surface the stub status in the UI console & state
                _uiState.update { state ->
                    state.copy(
                        isProcessing = false,
                        progressPercent = 100,
                        logs = state.logs + listOf(
                            "تم استدعاء CodeInjectorEngine بنجاح (وضع الهيكل البرمجي Stub).",
                            "TODO: ${notImplemented.message}"
                        )
                    )
                }
            } catch (e: Exception) {
                listener.onError(e.localizedMessage ?: "حدث خطأ غير متوقع")
            }
        }
    }

    private fun resolveDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) cursor.getString(idx) else null
                    } else null
                }
        } catch (_: Exception) {
            uri.lastPathSegment
        }
    }
}
