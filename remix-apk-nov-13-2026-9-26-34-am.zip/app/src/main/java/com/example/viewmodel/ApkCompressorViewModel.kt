package com.example.viewmodel

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.ApkCompressorEngine
import com.example.model.ApkFileInfo
import com.example.model.CompressorProgressStage
import com.example.model.CompressorUiState
import com.reandroid.arsc.chunk.xml.AndroidManifestBlock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

class ApkCompressorViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CompressorUiState())
    val uiState: StateFlow<CompressorUiState> = _uiState.asStateFlow()

    fun onApkFileSelected(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                _uiState.update {
                    it.copy(
                        statusMessage = "جاري قراءة الحزمة المختارة للضغط...",
                        errorMessage = null
                    )
                }
                val apkInfo = importApkForCompressor(context, uri)
                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        statusMessage = "تم اختيار: ${apkInfo.fileName} (${apkInfo.formattedSize})",
                        errorMessage = null,
                        result = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "تعذر قراءة ملف APK: ${e.localizedMessage}")
                }
            }
        }
    }

    fun generateSampleApkForCompression(context: Context) {
        viewModelScope.launch {
            try {
                _uiState.update {
                    it.copy(
                        statusMessage = "جاري توليد حزمة APK تجريبية غنية (DEX + 8 لغات ARSC + صور PNG + 4 معماريات .so)...",
                        errorMessage = null
                    )
                }
                val sampleDir = File(context.cacheDir, "compressor_samples").apply { mkdirs() }
                val sampleFile = File(sampleDir, "Sample_Bloated_MultiArch_App.apk")

                ApkCompressorEngine.createRichSampleApkForCompression(sampleFile)
                val apkInfo = inspectLocalApk(sampleFile, isSample = true)

                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        statusMessage = "تم تجهيز الحزمة التجريبية (${apkInfo.formattedSize}) — جاهزة للضغط العميق!",
                        errorMessage = null,
                        result = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "فشل توليد الحزمة التجريبية: ${e.localizedMessage}")
                }
            }
        }
    }

    fun setStripDexDebugAndBloat(enabled: Boolean) {
        _uiState.update { it.copy(options = it.options.copy(stripDexDebugAndBloat = enabled)) }
    }

    fun setKeepOnlyArEnLanguages(enabled: Boolean) {
        _uiState.update { it.copy(options = it.options.copy(keepOnlyArEnLanguages = enabled)) }
    }

    fun setConvertImagesToWebp(enabled: Boolean) {
        _uiState.update { it.copy(options = it.options.copy(convertImagesToWebp = enabled)) }
    }

    fun setKeepOnlyArm64NativeLibs(enabled: Boolean) {
        _uiState.update { it.copy(options = it.options.copy(keepOnlyArm64NativeLibs = enabled)) }
    }

    fun setUseLevel9BestCompression(enabled: Boolean) {
        _uiState.update { it.copy(options = it.options.copy(useLevel9BestCompression = enabled)) }
    }

    fun startDeepCompression(context: Context) {
        val currentApk = _uiState.value.selectedApk ?: return
        if (_uiState.value.isProcessing) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    currentStage = CompressorProgressStage.ANALYZING_APK,
                    progressFloat = 0.08f,
                    statusMessage = "جاري بدء الضغط والتحسين العميق...",
                    errorMessage = null
                )
            }

            try {
                val result = ApkCompressorEngine.compressAndOptimizeApk(
                    context = context,
                    sourceApk = currentApk,
                    options = _uiState.value.options,
                    onProgress = { stage, progress, message ->
                        _uiState.update {
                            it.copy(
                                currentStage = stage,
                                progressFloat = progress,
                                statusMessage = message
                            )
                        }
                    }
                )

                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        currentStage = CompressorProgressStage.COMPLETED,
                        progressFloat = 1.0f,
                        statusMessage = "تم تقليص الحجم بنسبة ${result.totalBreakdown.formattedPercent} وتوقيع الحزمة بنجاح!",
                        result = result,
                        logs = result.logs
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        currentStage = CompressorProgressStage.FAILED,
                        errorMessage = "حدث خطأ أثناء ضغط الحزمة: ${e.localizedMessage}",
                        statusMessage = "فشلت عملية الضغط"
                    )
                }
            }
        }
    }

    fun installCompressedApk(context: Context) {
        val file = _uiState.value.result?.outputApkFile ?: return
        try {
            ApkCompressorEngine.installCompressedApk(context, file)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر تشغيل مثبت الحزم: ${e.localizedMessage}")
            }
        }
    }

    fun shareCompressedApk(context: Context) {
        val file = _uiState.value.result?.outputApkFile ?: return
        try {
            ApkCompressorEngine.shareCompressedApk(context, file)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر مشاركة الحزمة المضغوطة: ${e.localizedMessage}")
            }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private suspend fun importApkForCompressor(context: Context, uri: Uri): ApkFileInfo = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var displayName = "Selected_App.apk"
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIdx != -1) {
                cursor.getString(nameIdx)?.let { displayName = it }
            }
        }
        if (!displayName.endsWith(".apk", ignoreCase = true)) {
            displayName = "$displayName.apk"
        }

        val dir = File(context.cacheDir, "compressor_imports").apply { mkdirs() }
        val targetFile = File(dir, displayName)
        resolver.openInputStream(uri)?.use { input ->
            FileOutputStream(targetFile).use { output ->
                input.copyTo(output, bufferSize = 64 * 1024)
                output.flush()
            }
        } ?: throw IllegalStateException("تعذر فتح الملف المختار")

        inspectLocalApk(targetFile, uri = uri, displayName = displayName, isSample = false)
    }

    private suspend fun inspectLocalApk(
        file: File,
        uri: Uri? = null,
        displayName: String = file.name,
        isSample: Boolean = false
    ): ApkFileInfo = withContext(Dispatchers.IO) {
        var pkgName = "com.app.apk"
        var minSdk: Int? = null
        var targetSdk: Int? = null

        try {
            ZipFile(file).use { zip ->
                val entry = zip.getEntry("AndroidManifest.xml")
                if (entry != null) {
                    val manifestBlock = AndroidManifestBlock.load(zip.getInputStream(entry))
                    manifestBlock.packageName?.takeIf { it.isNotBlank() }?.let { pkgName = it }
                    minSdk = manifestBlock.minSdkVersion
                    targetSdk = manifestBlock.targetSdkVersion
                }
            }
        } catch (_: Throwable) {
            // Keep defaults
        }

        ApkFileInfo(
            fileName = displayName,
            fileSizeBytes = file.length(),
            fileUri = uri,
            localFile = file,
            packageName = pkgName,
            detectedMinSdk = minSdk,
            detectedTargetSdk = targetSdk,
            isSample = isSample
        )
    }
}
