package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.ApkMergeEngine
import com.example.engine.SampleApkBuilder
import com.example.model.AbiFilterMode
import com.example.model.ApkAnalysisReport
import com.example.model.ApkEntryCategory
import com.example.model.MergeConfig
import com.example.model.MergePhase
import com.example.model.MergeResult
import com.example.model.ProcessingProgress
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

data class ApkOptimizerUiState(
    val isAnalyzing: Boolean = false,
    val analysisReport: ApkAnalysisReport? = null,
    val config: MergeConfig = MergeConfig(),
    val progress: ProcessingProgress = ProcessingProgress(),
    val latestResult: MergeResult? = null,
    val historyResults: List<MergeResult> = emptyList(),
    val statusBannerMessage: String? = null,
    val errorMessage: String? = null,
    val showEntryExplorerSheet: Boolean = false,
    val selectedCategoryFilter: ApkEntryCategory? = null,
    val entrySearchQuery: String = ""
)

class ApkOptimizerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ApkOptimizerUiState())
    val uiState: StateFlow<ApkOptimizerUiState> = _uiState.asStateFlow()

    private var activeSourceArchiveFile: File? = null
    private var mergeJob: Job? = null
    private var initializedDefault = false

    fun initializeWithDefaultApkIfNeeded(context: Context) {
        if (initializedDefault) return
        initializedDefault = true
        loadSampleSplitArchive(context, isXapk = false)
    }

    fun loadExternalArchiveUri(context: Context, uri: Uri) {
        mergeJob?.cancel()
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isAnalyzing = true,
                    errorMessage = null,
                    statusBannerMessage = "جاري قراءة وفحص أرشيف اللعبة المجزأ (.apks / .xapk) بتدفق 512KB..."
                )
            }
            try {
                val displayName = resolveDisplayName(context, uri) ?: "selected_game_bundle.apks"
                val ext = displayName.substringAfterLast('.', "apks").lowercase(Locale.US)
                val workDir = File(context.cacheDir, "apk_merger_workspace").apply { mkdirs() }
                val copiedFile = File(workDir, "input_${System.currentTimeMillis()}.$ext")

                withContext(Dispatchers.IO) {
                    activeSourceArchiveFile?.let { old ->
                        if (old.absolutePath.contains("apk_merger_workspace") && old != copiedFile) {
                            old.delete()
                        }
                    }
                    workDir.listFiles()?.forEach { f ->
                        if (f != copiedFile && f.name.startsWith("input_")) {
                            f.delete()
                        }
                    }

                    val buffer = ByteArray(ApkMergeEngine.STREAM_BUFFER_SIZE)
                    context.contentResolver.openInputStream(uri)?.use { rawInput ->
                        BufferedInputStream(rawInput, ApkMergeEngine.STREAM_BUFFER_SIZE).use { input ->
                            BufferedOutputStream(FileOutputStream(copiedFile), ApkMergeEngine.STREAM_BUFFER_SIZE).use { output ->
                                var r: Int
                                while (input.read(buffer).also { r = it } != -1) {
                                    output.write(buffer, 0, r)
                                }
                            }
                        }
                    } ?: throw IllegalStateException("تعذر فتح دفق البيانات للأرشيف المختار")
                }

                activeSourceArchiveFile = copiedFile

                val archiveType = ApkMergeEngine.detectArchiveType(copiedFile)
                val sourceLabel = when (archiveType) {
                    ApkMergeEngine.PackageArchiveType.XAPK -> "أرشيف ألعاب XAPK خارجي (Base + Splits + OBB)"
                    ApkMergeEngine.PackageArchiveType.APKS -> "حزمة ألعاب مجزأة APKS (Base + Split Configs)"
                    ApkMergeEngine.PackageArchiveType.APK -> "حزمة APK خارجية (فحص وتوحيد Anti-Split)"
                }

                val report = ApkMergeEngine.analyzeArchive(
                    archiveFile = copiedFile,
                    displayFileName = displayName,
                    sourceLabelAr = sourceLabel
                )

                _uiState.update { state ->
                    state.copy(
                        isAnalyzing = false,
                        analysisReport = report,
                        latestResult = null,
                        statusBannerMessage = "تم اكتشاف ${report.discoveredSplits.size} حزم داخل الأرشيف (${report.totalEntryCount} ملف • ${report.detectedAbis.joinToString(", ").ifEmpty { "Universal" }})",
                        errorMessage = null
                    )
                }
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        errorMessage = "فشل تحليل الأرشيف: ${e.localizedMessage ?: "ملف غير صالح"}",
                        statusBannerMessage = null
                    )
                }
            }
        }
    }

    fun loadSampleSplitArchive(context: Context, isXapk: Boolean) {
        mergeJob?.cancel()
        viewModelScope.launch {
            val formatLabel = if (isXapk) ".xapk" else ".apks"
            _uiState.update {
                it.copy(
                    isAnalyzing = true,
                    errorMessage = null,
                    statusBannerMessage = "جاري إنشاء وتجهيز أرشيف ألعاب مجزأ ($formatLabel) يحتوي على base.apk + 5 ملفات split_*.apk..."
                )
            }
            try {
                val workDir = File(context.cacheDir, "apk_merger_workspace").apply { mkdirs() }
                val ext = if (isXapk) "xapk" else "apks"
                val sampleFile = File(workDir, "sample_split_game.$ext")
                SampleApkBuilder.createSampleSplitGameArchive(sampleFile, isXapk)
                activeSourceArchiveFile = sampleFile

                val report = ApkMergeEngine.analyzeArchive(
                    archiveFile = sampleFile,
                    displayFileName = sampleFile.name,
                    sourceLabelAr = if (isXapk) {
                        "أرشيف ألعاب XAPK (base + arm64 + armeabi + xhdpi + ar + assets + OBB)"
                    } else {
                        "أرشيف ألعاب مجزأ APKS (base + arm64 + armeabi + xhdpi + ar + assets)"
                    }
                )

                _uiState.update { state ->
                    state.copy(
                        isAnalyzing = false,
                        analysisReport = report,
                        latestResult = null,
                        statusBannerMessage = "جاهز للدمج إلى Universal_Game.apk — تم اكتشاف ${report.innerApkCount} حزم APK مجزأة و isSplitRequired=\"true\"",
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        errorMessage = "فشل إنشاء أرشيف الاختبار: ${e.localizedMessage}",
                        statusBannerMessage = null
                    )
                }
            }
        }
    }

    fun setPatchBinaryManifest(enabled: Boolean) {
        _uiState.update { state ->
            state.copy(config = state.config.copy(patchBinaryManifest = enabled))
        }
    }

    fun setEnforce4kAlignment(enabled: Boolean) {
        _uiState.update { state ->
            state.copy(config = state.config.copy(enforce4kAlignmentForSoAndGameAssets = enabled))
        }
    }

    fun setStripMetaInfSignatures(enabled: Boolean) {
        _uiState.update { state ->
            state.copy(config = state.config.copy(stripMetaInfSignatures = enabled))
        }
    }

    fun setMergeObbIntoAssets(enabled: Boolean) {
        _uiState.update { state ->
            state.copy(config = state.config.copy(mergeObbIntoAssets = enabled))
        }
    }

    fun setAbiFilterMode(abiMode: AbiFilterMode) {
        _uiState.update { state ->
            state.copy(config = state.config.copy(abiFilterMode = abiMode))
        }
    }

    fun startMerging(context: Context) {
        val sourceFile = activeSourceArchiveFile
        val currentReport = _uiState.value.analysisReport
        if (sourceFile == null || !sourceFile.exists() || currentReport == null) {
            _uiState.update {
                it.copy(errorMessage = "يرجى اختيار أرشيف لعبة مجزأ (.apks / .xapk) أولاً قبل بدء الدمج")
            }
            return
        }

        mergeJob?.cancel()
        mergeJob = viewModelScope.launch {
            val outDir = File(context.cacheDir, "universal_outputs").apply { mkdirs() }
            val outFile = File(outDir, "Universal_Game.apk")

            _uiState.update {
                it.copy(
                    errorMessage = null,
                    statusBannerMessage = null,
                    progress = ProcessingProgress(
                        isRunning = true,
                        currentPhase = MergePhase.EXTRACTING_ARCHIVE,
                        currentPhaseTitle = MergePhase.EXTRACTING_ARCHIVE.titleEn,
                        currentEntryName = currentReport.fileName,
                        currentActionTag = "INIT 512KB",
                        processedEntries = 0,
                        totalEntries = currentReport.totalEntryCount,
                        processedBytes = 0L,
                        totalBytes = currentReport.uncompressedTotalSize,
                        liveLogs = listOf("🚀 Starting Smart Game Merger on ${currentReport.fileName}...")
                    )
                )
            }

            try {
                val result = ApkMergeEngine.mergeSplitGameToUniversalApk(
                    sourceArchiveFile = sourceFile,
                    outputUniversalApkFile = outFile,
                    config = _uiState.value.config,
                    onProgress = { liveProgress ->
                        _uiState.update { state ->
                            state.copy(progress = liveProgress)
                        }
                    }
                )

                _uiState.update { state ->
                    val compactHistory = state.historyResults.take(9).map {
                        it.copy(entryComparisons = emptyList(), finalLogs = emptyList())
                    }
                    val updatedHistory = listOf(result) + compactHistory
                    state.copy(
                        progress = state.progress.copy(
                            isRunning = false,
                            currentPhase = MergePhase.COMPLETED,
                            currentPhaseTitle = MergePhase.COMPLETED.titleEn
                        ),
                        latestResult = result,
                        historyResults = updatedHistory,
                        statusBannerMessage = "اكتمل بناء ${result.outputFileName} بنجاح! تم دمج ${result.mergedSplitApksCount} حزم وتعديل البيان الثنائي ومحاذاة ${result.stored4kAlignedCount} ملف بدقة 4K."
                    )
                }
            } catch (_: CancellationException) {
                _uiState.update { state ->
                    state.copy(
                        progress = state.progress.copy(isRunning = false),
                        statusBannerMessage = "تم إلغاء عملية الدمج بناءً على طلب المستخدم."
                    )
                }
            } catch (e: Throwable) {
                System.gc()
                _uiState.update { state ->
                    state.copy(
                        progress = state.progress.copy(isRunning = false),
                        errorMessage = "فشلت عملية دمج الألعاب: ${e.localizedMessage ?: "خطأ غير متوقع"}"
                    )
                }
            }
        }
    }

    fun cancelMerging() {
        mergeJob?.cancel()
    }

    fun saveUniversalApkToUri(context: Context, targetUri: Uri) {
        val result = _uiState.value.latestResult ?: return
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val buffer = ByteArray(ApkMergeEngine.STREAM_BUFFER_SIZE)
                    context.contentResolver.openOutputStream(targetUri)?.use { rawOut ->
                        BufferedOutputStream(rawOut, ApkMergeEngine.STREAM_BUFFER_SIZE).use { out ->
                            BufferedInputStream(result.outputFile.inputStream(), ApkMergeEngine.STREAM_BUFFER_SIZE).use { input ->
                                var r: Int
                                while (input.read(buffer).also { r = it } != -1) {
                                    out.write(buffer, 0, r)
                                }
                            }
                        }
                    } ?: throw IllegalStateException("تعذر فتح مسار الحفظ المختار")
                }
                _uiState.update {
                    it.copy(
                        statusBannerMessage = "تم حفظ الملف الموحد (${result.outputFileName}) بنجاح في الذاكرة!",
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "تعذر حفظ الملف: ${e.localizedMessage}")
                }
            }
        }
    }

    fun shareUniversalApk(context: Context) {
        val result = _uiState.value.latestResult ?: return
        try {
            val authority = "${context.packageName}.fileprovider"
            val contentUri = FileProvider.getUriForFile(context, authority, result.outputFile)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(
                    Intent.EXTRA_SUBJECT,
                    "Universal Game APK (${result.outputFileName})"
                )
                putExtra(
                    Intent.EXTRA_TEXT,
                    "تم دمج الحزم المجزأة في ملف ${result.outputFileName} موحد (${
                        ApkMergeEngine.formatBytesShort(result.universalApkSize)
                    } • ${result.mergedSplitApksCount} Splits Merged • 4K Aligned)"
                )
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "مشاركة Universal_Game.apk").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر فتح نافذة المشاركة: ${e.localizedMessage}")
            }
        }
    }

    fun setShowEntryExplorer(show: Boolean) {
        _uiState.update { it.copy(showEntryExplorerSheet = show) }
    }

    fun setCategoryFilter(category: ApkEntryCategory?) {
        _uiState.update { it.copy(selectedCategoryFilter = category) }
    }

    fun setEntrySearchQuery(query: String) {
        _uiState.update { it.copy(entrySearchQuery = query) }
    }

    fun dismissMessages() {
        _uiState.update { it.copy(errorMessage = null, statusBannerMessage = null) }
    }

    private fun resolveDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) cursor.getString(idx) else null
                    } else null
                }
        } catch (_: Exception) {
            uri.lastPathSegment
        }
    }
}
