package com.example.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.ApkFixerEngine
import com.example.engine.SampleApkBuilder
import com.example.model.FixProgressStage
import com.example.model.FixUiState
import com.example.model.TargetAndroidVersion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

class ApkFixerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(FixUiState())
    val uiState: StateFlow<FixUiState> = _uiState.asStateFlow()

    fun onApkFileSelected(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(statusMessage = "جاري قراءة الحزمة المختارة...") }
                val apkInfo = ApkFixerEngine.importApkFromUri(context, uri)
                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        statusMessage = "تم اختيار: ${apkInfo.fileName}",
                        errorMessage = null,
                        fixResult = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "تعذر قراءة ملف APK: ${e.localizedMessage}")
                }
            }
        }
    }

    fun generateSampleApk(context: Context) {
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(statusMessage = "جاري توليد ملف APK تجريبي للاختبار...") }
                val sampleDir = File(context.cacheDir, "sample_apks").apply { mkdirs() }
                val sampleFile = File(sampleDir, "Sample_Legacy_App.apk")

                SampleApkBuilder.createUnoptimizedSampleApk(sampleFile)
                val apkInfo = ApkFixerEngine.inspectApkFile(
                    file = sampleFile,
                    fileName = sampleFile.name,
                    isSample = true
                )

                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        statusMessage = "تم توليد ملف APK تجريبي بنجاح (minSdk=34)!",
                        errorMessage = null,
                        fixResult = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "فشل توليد الحزمة التجريبية: ${e.localizedMessage}")
                }
            }
        }
    }

    fun selectTargetVersion(version: TargetAndroidVersion) {
        _uiState.update { it.copy(selectedTargetVersion = version) }
    }

    fun setAlsoUpdateTargetSdk(enabled: Boolean) {
        _uiState.update { it.copy(alsoUpdateTargetSdk = enabled) }
    }

    fun startFixAndRebuild(context: Context) {
        val currentApk = _uiState.value.selectedApk ?: return
        if (_uiState.value.isProcessing) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    currentStage = FixProgressStage.EXTRACTING,
                    progressFloat = 0.1f,
                    statusMessage = "جاري بدء التعديل السريع وبناء الحزمة...",
                    errorMessage = null
                )
            }

            try {
                val result = ApkFixerEngine.fixAndRebuildApk(
                    context = context,
                    sourceApk = currentApk,
                    targetVersion = _uiState.value.selectedTargetVersion,
                    alsoUpdateTargetSdk = _uiState.value.alsoUpdateTargetSdk,
                    onProgress = { stage, progress, message ->
                        _uiState.update {
                            it.copy(
                                currentStage = stage,
                                progressFloat = progress,
                                statusMessage = message
                            )
                        }
                    }
                )

                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        currentStage = FixProgressStage.COMPLETED,
                        progressFloat = 1.0f,
                        statusMessage = "تم إصلاح وتوقيع التطبيق بنجاح!",
                        fixResult = result,
                        logs = result.logs,
                        showCompletionDialog = true
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        currentStage = FixProgressStage.FAILED,
                        errorMessage = "حدث خطأ أثناء معالجة الحزمة: ${e.localizedMessage}",
                        statusMessage = "فشلت العملية"
                    )
                }
            }
        }
    }

    fun installFixedApk(context: Context) {
        val file = _uiState.value.fixResult?.outputApkFile ?: return
        try {
            ApkFixerEngine.installApkDirectly(context, file)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر تشغيل مثبت الحزم: ${e.localizedMessage}")
            }
        }
    }

    fun shareFixedApk(context: Context) {
        val file = _uiState.value.fixResult?.outputApkFile ?: return
        try {
            ApkFixerEngine.shareFixedApk(context, file)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر مشاركة الحزمة: ${e.localizedMessage}")
            }
        }
    }

    fun dismissCompletionDialog() {
        _uiState.update { it.copy(showCompletionDialog = false) }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}
