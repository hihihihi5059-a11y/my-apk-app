package com.example.model

import android.net.Uri
import java.io.File

/**
 * Android versions supported for minSdkVersion (and optional targetSdkVersion) patching in <uses-sdk>.
 */
enum class TargetAndroidVersion(
    val titleAr: String,
    val titleEn: String,
    val apiLevel: Int,
    val minSdk: Int,
    val description: String
) {
    ANDROID_10(
        titleAr = "Android 10 (API 29)",
        titleEn = "Android 10 (API 29)",
        apiLevel = 29,
        minSdk = 29,
        description = "تعيين minSdkVersion = 29 للسماح بالتثبيت على أجهزة أندرويد 10 فما فوق"
    ),
    ANDROID_11(
        titleAr = "Android 11 (API 30)",
        titleEn = "Android 11 (API 30)",
        apiLevel = 30,
        minSdk = 30,
        description = "تعيين minSdkVersion = 30 للسماح بالتثبيت على أجهزة أندرويد 11 فما فوق"
    ),
    ANDROID_12(
        titleAr = "Android 12 (API 31)",
        titleEn = "Android 12 (API 31)",
        apiLevel = 31,
        minSdk = 31,
        description = "تعيين minSdkVersion = 31 للسماح بالتثبيت على أجهزة أندرويد 12 فما فوق"
    ),
    ANDROID_13(
        titleAr = "Android 13 (API 33)",
        titleEn = "Android 13 (API 33)",
        apiLevel = 33,
        minSdk = 33,
        description = "تعيين minSdkVersion = 33 للسماح بالتثبيت على أجهزة أندرويد 13 فما فوق"
    ),
    ANDROID_14(
        titleAr = "Android 14 (API 34)",
        titleEn = "Android 14 (API 34)",
        apiLevel = 34,
        minSdk = 34,
        description = "تعيين minSdkVersion = 34 للتوافق مع أندرويد 14 فما فوق"
    ),
    ANDROID_15(
        titleAr = "Android 15 (API 35)",
        titleEn = "Android 15 (API 35)",
        apiLevel = 35,
        minSdk = 35,
        description = "تعيين minSdkVersion = 35 للتوافق مع أندرويد 15"
    ),
    UNIVERSAL(
        titleAr = "توافق شامل (من أندرويد 8 إلى 15 - API 24)",
        titleEn = "Universal Compatibility (Android 7/8 to 15 - API 24)",
        apiLevel = 34,
        minSdk = 24,
        description = "توصية: خفض minSdkVersion إلى 24 ليعمل التطبيق على جميع الأجهزة بدون حظر"
    )
}

data class ApkFileInfo(
    val fileName: String,
    val fileSizeBytes: Long,
    val fileUri: Uri? = null,
    val localFile: File,
    val packageName: String = "com.app.apk",
    val detectedMinSdk: Int? = null,
    val detectedTargetSdk: Int? = null,
    val isSample: Boolean = false
) {
    val formattedSize: String
        get() {
            if (fileSizeBytes < 1024) return "$fileSizeBytes B"
            val kb = fileSizeBytes / 1024.0
            if (kb < 1024) return String.format("%.1f KB", kb)
            val mb = kb / 1024.0
            return String.format("%.2f MB", mb)
        }
}

enum class FixProgressStage(val stepIndex: Int, val labelAr: String) {
    IDLE(0, "جاهز للبدء"),
    EXTRACTING(1, "جاري قراءة الحزمة وفحص Binary AndroidManifest.xml..."),
    MODIFYING_MANIFEST(2, "جاري تعديل minSdkVersion داخل <uses-sdk> ثنائياً..."),
    REBUILDING_APK(3, "جاري إعادة بناء APK بمحاذاة 4-Byte لـ resources.arsc و 4K للمكتبات..."),
    SIGNING_APK(4, "جاري التوقيع الرقمي الرسمي (APK Signature Scheme v1 + v2 + v3)..."),
    COMPLETED(5, "تم إصلاح وتوقيع التطبيق بنجاح!"),
    FAILED(-1, "فشلت العملية")
}

data class FixResult(
    val outputApkFile: File,
    val outputFileName: String,
    val packageName: String,
    val originalSizeBytes: Long,
    val finalSizeBytes: Long,
    val originalMinSdk: Int?,
    val originalTargetSdk: Int?,
    val patchedMinSdk: Int,
    val patchedTargetSdk: Int,
    val storedAlignedEntriesCount: Int,
    val strippedMetaInfSignaturesCount: Int,
    val signedSchemesSummary: String = "v1 (JAR) + v2 + v3 (RSA-2048)",
    val exportedComponentsCount: Int = 0,
    val executionDurationMs: Long,
    val logs: List<String>
) {
    val formattedFinalSize: String
        get() {
            val mb = finalSizeBytes / (1024.0 * 1024.0)
            return String.format("%.2f MB", mb)
        }
}

data class FixUiState(
    val selectedApk: ApkFileInfo? = null,
    val selectedTargetVersion: TargetAndroidVersion = TargetAndroidVersion.UNIVERSAL,
    val alsoUpdateTargetSdk: Boolean = false,
    val isProcessing: Boolean = false,
    val currentStage: FixProgressStage = FixProgressStage.IDLE,
    val progressFloat: Float = 0f,
    val statusMessage: String = "",
    val logs: List<String> = emptyList(),
    val showCompletionDialog: Boolean = false,
    val fixResult: FixResult? = null,
    val errorMessage: String? = null
)
