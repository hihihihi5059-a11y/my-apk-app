package com.example.model

enum class IdeScreenTab(val titleAr: String, val testTag: String) {
    DASHBOARD("الرئيسية", "nav_tab_dashboard"),
    PROJECT_TREE("مستكشف المشروع", "nav_tab_project_tree"),
    CODE_EDITOR("مساحة العمل والمحرر", "nav_tab_code_editor"),
    BUILD_CONSOLE("البناء والتوقيع", "nav_tab_build_console")
}

enum class ProjectFileType(val badgeLabel: String, val folderCategory: String) {
    SMALI("SMALI", "smali"),
    JAVA("JAVA", "java"),
    XML("XML", "res"),
    MANIFEST("MANIFEST", "root")
}

enum class AiEngineStatus(val labelAr: String) {
    READY("جاهز (Offline)"),
    ANALYZING("قيد التحليل..."),
    MODEL_LOADED("GGUF نشط")
}

enum class LocalAiTaskType(val titleAr: String, val descriptionAr: String) {
    RENAME_VARIABLES(
        "إعادة تسمية المتغيرات الغامضة",
        "تحويل المتغيرات المعماة (v0, p1, a, b) إلى أسماء دلالية واضحة في Java و Smali"
    ),
    EXPLAIN_FUNCTIONS(
        "شرح وظيفة الدوال والمنطق",
        "تحليل تدفق البيانات، استدعاءات النظام، وشرح وظيفة الدالة المحددة بالتفصيل"
    ),
    SUGGEST_CLEAN_PATCH(
        "اقتراح وتطبيق تعديل برمجي نظيف",
        "إعادة كتابة الدالة بكود أنظف وأكثر أماناً مع مزامنة Smali المقابل للتجميع"
    )
}

data class HardwareTelemetryState(
    val usedRamMb: Long = 184L,
    val totalRamMb: Long = 512L,
    val ramUsagePercent: Int = 36,
    val cpuCores: Int = Runtime.getRuntime().availableProcessors(),
    val cpuLoadPercent: Int = 18,
    val activeChunkCount: Int = 1,
    val aiStatus: AiEngineStatus = AiEngineStatus.READY
)

data class LocalGgufModelState(
    val modelName: String = "Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf",
    val architecture: String = "qwen2 (GGUF v3)",
    val quantization: String = "Q4_K_M (4-bit Quantized)",
    val fileSizeMb: Long = 986L,
    val contextLength: Int = 4096,
    val maxChunkChars: Int = 1800,
    val isCustomFileImported: Boolean = false,
    val localFilePath: String = "internal://models/qwen2.5-coder-1.5b-q4_k_m.gguf",
    val headerMagicVerified: Boolean = true
)

data class ProjectFileNode(
    val id: String,
    val name: String,
    val relativePath: String,
    val fileType: ProjectFileType,
    val sizeBytes: Long,
    val smaliContent: String,
    val javaContent: String,
    val xmlContent: String = "",
    val isModified: Boolean = false
)

data class LocalDecompiledProject(
    val projectId: String,
    val appName: String,
    val packageName: String,
    val versionName: String,
    val sourceApkPath: String,
    val workspaceDirPath: String,
    val files: List<ProjectFileNode>,
    val smaliClassesCount: Int,
    val xmlResourcesCount: Int,
    val dexFilesCount: Int,
    val lastModifiedTimestamp: Long = System.currentTimeMillis(),
    val signedOutputApkPath: String? = null
)

data class InstalledAppItem(
    val appName: String,
    val packageName: String,
    val sourceApkPath: String,
    val versionName: String,
    val sizeBytes: Long
)

data class CodeChunkResult(
    val chunkIndex: Int,
    val totalChunks: Int,
    val originalSnippet: String,
    val refactoredJava: String,
    val refactoredSmali: String,
    val explanationAr: String,
    val renamedIdentifiers: Map<String, String>
)

enum class BuildStageState {
    PENDING,
    RUNNING,
    SUCCESS,
    WARNING,
    ERROR
}

data class BuildPipelineStep(
    val stepNumber: Int,
    val titleAr: String,
    val subtitleAr: String,
    val toolBadge: String,
    val state: BuildStageState = BuildStageState.PENDING,
    val durationMs: Long = 0L
)

data class LocalBuildState(
    val isBuilding: Boolean = false,
    val progressPercent: Int = 0,
    val steps: List<BuildPipelineStep> = defaultBuildSteps(),
    val consoleLogs: List<String> = emptyList(),
    val outputSignedApkPath: String? = null,
    val signatureVerified: Boolean = false,
    val signerCertificateSubject: String = "CN=Android Local IDE Signer, OU=OnDevice Security, O=LocalAPKStudio",
    val buildError: String? = null
) {
    companion object {
        fun defaultBuildSteps(): List<BuildPipelineStep> = listOf(
            BuildPipelineStep(
                stepNumber = 1,
                titleAr = "ترجمة تعديلات Java إلى DEX / Smali",
                subtitleAr = "فحص شجرة AST لتعديلات Java وتوليد تعليمات Dalvik Bytecode المقابلة",
                toolBadge = "ECJ + D8 Local"
            ),
            BuildPipelineStep(
                stepNumber = 2,
                titleAr = "تجميع ملفات Smali إلى classes.dex",
                subtitleAr = "تشغيل محرك org.smali.smali و dexlib2 لبناء جدول الكلاسات الثنائي",
                toolBadge = "smali.jar 2.5.2"
            ),
            BuildPipelineStep(
                stepNumber = 3,
                titleAr = "حزم الموارد وملف البيان ومحاذاة 4KB",
                subtitleAr = "دمج res/ و AndroidManifest.xml وضبط محاذاة ZipAlign 4096-byte",
                toolBadge = "apktool-lib + 4K"
            ),
            BuildPipelineStep(
                stepNumber = 4,
                titleAr = "التوقيع الرقمي المحلي (v1 + v2 APK Signature)",
                subtitleAr = "توقيع الحزمة بمفتاح RSA-2048 المحلي عبر مكتبة com.android.tools.build.apksig",
                toolBadge = "apksig 8.0.0"
            ),
            BuildPipelineStep(
                stepNumber = 5,
                titleAr = "التحقق من التوقيع وتجهيز التثبيت المباشر",
                subtitleAr = "فحص تطابق بصمة SHA-256 وتجهيز حزمة APK النهائية للتثبيت",
                toolBadge = "ApkVerifier"
            )
        )
    }
}
