package com.example.model

import android.net.Uri
import java.io.File
import java.util.Locale

/**
 * User-configurable optimization toggles for Tab 2 ("ضغط APK" / APK Size Compressor).
 */
data class CompressorOptions(
    val stripDexDebugAndBloat: Boolean = true,
    val keepOnlyArEnLanguages: Boolean = true,
    val convertImagesToWebp: Boolean = true,
    val keepOnlyArm64NativeLibs: Boolean = true,
    val useLevel9BestCompression: Boolean = true
)

/**
 * Exact before/after size metrics for a specific APK category (DEX, Resources/Images, Native Libs, or Total).
 */
data class CategorySizeSaving(
    val categoryNameAr: String,
    val categoryNameEn: String,
    val beforeBytes: Long,
    val afterBytes: Long,
    val detailsAr: String
) {
    val savedBytes: Long
        get() = (beforeBytes - afterBytes).coerceAtLeast(0L)

    val savedPercent: Float
        get() = if (beforeBytes > 0L) {
            ((beforeBytes - afterBytes).toFloat() / beforeBytes.toFloat() * 100f).coerceIn(0f, 99.9f)
        } else {
            0f
        }

    val formattedBefore: String
        get() = formatBytes(beforeBytes)

    val formattedAfter: String
        get() = formatBytes(afterBytes)

    val formattedSaved: String
        get() = formatBytes(savedBytes)

    val formattedPercent: String
        get() = String.format(Locale.US, "%.1f%%", savedPercent)

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0L) return "0 B"
            if (bytes < 1024L) return "$bytes B"
            val kb = bytes / 1024.0
            if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
            val mb = kb / 1024.0
            return String.format(Locale.US, "%.2f MB", mb)
        }
    }
}

enum class CompressorProgressStage(val stepIndex: Int, val labelAr: String) {
    IDLE(0, "جاهز للضغط والتحسين العميق"),
    ANALYZING_APK(1, "جاري تحليل مكونات الحزمة (DEX، ARSC، الصور، المكتبات)..."),
    OPTIMIZING_DEX(2, "جاري تحسين ملفات classes*.dex عبر dexlib2 وحذف بيانات التصحيح..."),
    PRUNING_RESOURCES_AND_WEBP(3, "جاري تقليص اللغات في resources.arsc عبر ARSCLib وتحويل الصور إلى WebP..."),
    FILTERING_NATIVE_LIBS(4, "جاري تصفية مكتبات المعالج (arm64-v8a) وضغط الحزمة بالمستوى التاسع (Level 9)..."),
    ZIPALIGN_AND_SIGNING(5, "جاري محاذاة Zipalign (4B/4096B) والتوقيع الرسمي (V1 + V2 + V3)..."),
    COMPLETED(6, "اكتمل ضغط وتحسين وتوقيع الحزمة بنجاح!"),
    FAILED(-1, "فشلت عملية الضغط")
}

data class CompressionBreakdownResult(
    val outputApkFile: File,
    val outputFileName: String,
    val packageName: String,
    val dexBreakdown: CategorySizeSaving,
    val resourcesBreakdown: CategorySizeSaving,
    val nativeLibsBreakdown: CategorySizeSaving,
    val totalBreakdown: CategorySizeSaving,
    val dexFilesOptimizedCount: Int,
    val strippedBloatEntriesCount: Int,
    val prunedLocalesCount: Int,
    val convertedWebpImagesCount: Int,
    val strippedNativeLibsCount: Int,
    val storedAlignedEntriesCount: Int,
    val signedSchemesSummary: String = "V1 (JAR) + V2 + V3 (RSA-2048)",
    val executionDurationMs: Long,
    val logs: List<String>
)

data class CompressorUiState(
    val selectedApk: ApkFileInfo? = null,
    val options: CompressorOptions = CompressorOptions(),
    val isProcessing: Boolean = false,
    val currentStage: CompressorProgressStage = CompressorProgressStage.IDLE,
    val progressFloat: Float = 0f,
    val statusMessage: String = "",
    val logs: List<String> = emptyList(),
    val result: CompressionBreakdownResult? = null,
    val errorMessage: String? = null
)
