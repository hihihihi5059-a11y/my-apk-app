package com.example.model

import android.graphics.Bitmap
import java.io.File

/**
 * Details of a single Smali method that was assembled and replaced inside a target class.
 * Kept 100% compatible with `SmaliMethodReplacer.kt`.
 */
data class ReplacedSmaliMethodInfo(
    val classDescriptor: String = "",
    val methodName: String,
    val parameterTypes: List<String>,
    val returnType: String,
    val isDirectMethod: Boolean,
    val dexFileName: String
) {
    val name: String
        get() = methodName

    val fullSignature: String
        get() = "$name(${parameterTypes.joinToString("")})$returnType"
}

/**
 * Final result returned after `SmaliMethodReplacer` patches one or more classes across `classes*.dex`,
 * aligns `resources.arsc` (4-byte STORED), and signs with V1 + V2 + V3.
 */
data class SmaliPatchResult(
    val outputApkFile: File,
    val outputFileName: String,
    val packageName: String,
    val patchedClassDescriptors: List<String>,
    val modifiedDexFileNames: List<String>,
    val scannedDexFiles: List<String>,
    val replacedMethods: List<ReplacedSmaliMethodInfo>,
    val unmatchedMethodSignatures: List<String>,
    val totalMethodsInPatchedClasses: Int,
    val outputSizeBytes: Long,
    val isSignedV1V2V3: Boolean
) {
    val targetClassDescriptor: String
        get() = patchedClassDescriptors.joinToString(", ")

    val modifiedDexFileName: String
        get() = modifiedDexFileNames.joinToString(", ")

    val totalMethodsInTargetClass: Int
        get() = totalMethodsInPatchedClasses
}

/**
 * Progress stages for `SmaliMethodReplacer` mapped to clean, non-technical Arabic UI steps.
 */
enum class SmaliReplacerStage(val titleAr: String) {
    IDLE("جاهز للتعديل"),
    ASSEMBLING_SMALI("جاري سحب نسخة التطبيق..."),
    SCANNING_DEX("جاري سحب نسخة التطبيق..."),
    PATCHING_DEX("جاري تطبيق التعديلات الذكية..."),
    REBUILDING_APK("جاري إعادة البناء والتوقيع..."),
    SIGNING_APK("جاري إعادة البناء والتوقيع..."),
    COMPLETED("تم التعديل بنجاح! اضغط للتثبيت."),
    FAILED("تعذر إكمال التعديل")
}

/**
 * Represents a non-system user application discovered via Android's `PackageManager`.
 */
data class InstalledUserAppInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val sourceApkPath: String,
    val iconBitmap: Bitmap? = null,
    val hasAvailablePatch: Boolean
) {
    val statusBadgeTextAr: String
        get() = if (hasAvailablePatch) "تم العثور على تعديل" else "لم يتم العثور على تعديل"
}

/**
 * Immutable UI state for Tab 3 ("تعديل Smali" — Installed User Apps Patch Manager).
 */
data class SmaliReplacerUiState(
    val isLoadingApps: Boolean = false,
    val installedApps: List<InstalledUserAppInfo> = emptyList(),
    val selectedAppForSheet: InstalledUserAppInfo? = null,
    val selectedApk: ApkFileInfo? = null,
    val detectedDexFiles: List<String> = emptyList(),
    val patches: Map<String, List<String>> = emptyMap(),
    val isProcessing: Boolean = false,
    val stage: SmaliReplacerStage = SmaliReplacerStage.IDLE,
    val currentStepNumber: Int = 0, // 1..4 corresponding to the 4 clean Arabic steps
    val progressPercent: Int = 0,
    val statusText: String = "",
    val logs: List<String> = emptyList(),
    val result: SmaliPatchResult? = null,
    val errorMessage: String? = null
)
