package com.example.model

import java.io.File

enum class SplitModuleType(
    val labelAr: String,
    val shortTag: String
) {
    BASE("الحزمة الأساسية (base.apk)", "BASE"),
    ABI("معمارية المعالج (lib/ ABI Split)", "ABI"),
    DENSITY("كثافة الشاشة (res/ DPI Split)", "DPI"),
    LANGUAGE("حزمة اللغة (Language Split)", "LANG"),
    ASSET_PACK("حزمة أصول المحرك (assets/ Pack)", "ASSETS"),
    FEATURE("وحدة ميزة إضافية (Feature Split)", "FEAT")
}

data class DiscoveredSplitApk(
    val fileName: String,
    val moduleType: SplitModuleType,
    val compressedSize: Long,
    val uncompressedSize: Long,
    val entryCount: Int,
    val detectedAbi: String? = null
)

enum class AbiFilterMode(
    val titleAr: String,
    val subtitleAr: String,
    val targetAbi: String?
) {
    KEEP_ALL(
        titleAr = "دمج جميع المعماريات (Universal)",
        subtitleAr = "دمج مكتبات arm64-v8a و armeabi-v7a و x86_64 معاً في مجلد lib/",
        targetAbi = null
    ),
    ARM64_ONLY(
        titleAr = "arm64-v8a فقط (64-Bit)",
        subtitleAr = "دمج مكتبات 64-bit فقط وتجاهل split_config.armeabi_v7a",
        targetAbi = "arm64-v8a"
    ),
    ARMEABI_V7A_ONLY(
        titleAr = "armeabi-v7a فقط (32-Bit)",
        subtitleAr = "دمج مكتبات 32-bit فقط للأجهزة القديمة",
        targetAbi = "armeabi-v7a"
    )
}

enum class MergePhase(
    val titleEn: String,
    val titleAr: String
) {
    IDLE(
        titleEn = "Waiting for Split Archive (.apks / .xapk)...",
        titleAr = "في انتظار اختيار أرشيف الألعاب المجزأ (.apks / .xapk)..."
    ),
    EXTRACTING_ARCHIVE(
        titleEn = "Extracting Split Archive (.apks / .xapk)...",
        titleAr = "استخراج حزم base.apk و split_*.apk إلى الذاكرة المؤقتة..."
    ),
    PATCHING_MANIFEST(
        titleEn = "Patching Manifest (isSplitRequired=false & Stripping Split Meta-Data)...",
        titleAr = "تعديل AndroidManifest.xml الثنائي (isSplitRequired=false وحذف وسوم التقسيم)..."
    ),
    MERGING_BASE(
        titleEn = "Merging Base APK Core (classes*.dex & resources.arsc)...",
        titleAr = "دمج ملفات الحزمة الأساسية (classes*.dex و resources.arsc)..."
    ),
    MERGING_LIBS(
        titleEn = "Merging Native Libraries (lib/arm64-v8a & ABI Splits • 4K STORED)...",
        titleAr = "دمج المكتبات الأصلية (.so) في مجلد lib/ مع محاذاة 4096-byte STORED..."
    ),
    MERGING_ASSETS(
        titleEn = "Merging Game Engine Assets (assets/, .pak, .obb, .assets • 4K STORED)...",
        titleAr = "دمج أصول المحرك (.pak / .obb / .assets) في مجلد assets/ بمحاذاة 4K STORED..."
    ),
    MERGING_RESOURCES(
        titleEn = "Merging Split Resources (res/ Densities & Language Packs)...",
        titleAr = "دمج موارد الشاشات واللغات (res/ و XML والصور) في الحزمة الموحدة..."
    ),
    FINALIZING_UNIVERSAL(
        titleEn = "Finalizing Universal_Game.apk (Stripping META-INF & Verifying 4K Offsets)...",
        titleAr = "إتمام بناء Universal_Game.apk وحذف تواقيع META-INF القديمة..."
    ),
    COMPLETED(
        titleEn = "Universal_Game.apk Ready!",
        titleAr = "اكتمل بناء Universal_Game.apk الموحد بنجاح!"
    )
}

enum class ApkEntryCategory(
    val labelAr: String,
    val shortTag: String
) {
    DEX("ملفات الكود (classes*.dex)", "DEX"),
    ARSC("جدول الموارد (resources.arsc)", "ARSC"),
    LIB("المكتبات الأصلية (lib/*.so)", "LIB"),
    RES("الموارد والوسائط (res/)", "RES"),
    ASSETS("أصول اللعبة والمحرك (assets/, .pak, .obb)", "ASSETS"),
    OTHER("البيان والتواقيع (AndroidManifest & META-INF)", "META")
}

data class MergeConfig(
    val patchBinaryManifest: Boolean = true,
    val enforce4kAlignmentForSoAndGameAssets: Boolean = true,
    val stripMetaInfSignatures: Boolean = true,
    val mergeObbIntoAssets: Boolean = true,
    val abiFilterMode: AbiFilterMode = AbiFilterMode.KEEP_ALL
)

data class ManifestSplitInspection(
    val isBinaryAxml: Boolean = true,
    val hasIsSplitRequiredTrue: Boolean = false,
    val hasExtractNativeLibsTrue: Boolean = false,
    val splitMetaDataNames: List<String> = emptyList()
)

data class ApkEntryInfo(
    val name: String,
    val sourceApkName: String = "base.apk",
    val compressedSize: Long,
    val uncompressedSize: Long,
    val method: Int,
    val crc: Long,
    val dataOffset: Long,
    val is4kAligned: Boolean,
    val category: ApkEntryCategory,
    val abi: String? = null
)

data class CategoryBreakdown(
    val dexBytes: Long = 0L,
    val arscBytes: Long = 0L,
    val libBytes: Long = 0L,
    val resBytes: Long = 0L,
    val assetsBytes: Long = 0L,
    val otherBytes: Long = 0L,
    val dexCount: Int = 0,
    val arscCount: Int = 0,
    val libCount: Int = 0,
    val resCount: Int = 0,
    val assetsCount: Int = 0,
    val otherCount: Int = 0
) {
    val totalCompressedBytes: Long
        get() = (dexBytes + arscBytes + libBytes + resBytes + assetsBytes + otherBytes).coerceAtLeast(1L)
}

data class ApkAnalysisReport(
    val fileName: String,
    val sourceLabelAr: String,
    val sourceFilePath: String,
    val originalFileSize: Long,
    val totalEntryCount: Int,
    val uncompressedTotalSize: Long,
    val breakdown: CategoryBreakdown,
    val detectedAbis: List<String>,
    val bloatAndSignatureFilesCount: Int,
    val bloatAndSignatureBytes: Long,
    val aligned4kStoredCount: Int,
    val totalStoredCount: Int,
    val entries: List<ApkEntryInfo>,
    val isSplitArchive: Boolean = true,
    val innerApkCount: Int = 0,
    val discoveredSplits: List<DiscoveredSplitApk> = emptyList(),
    val manifestInspection: ManifestSplitInspection = ManifestSplitInspection()
)

data class ProcessingProgress(
    val isRunning: Boolean = false,
    val currentPhase: MergePhase = MergePhase.IDLE,
    val currentPhaseTitle: String = "",
    val currentEntryName: String = "",
    val currentActionTag: String = "",
    val currentInnerApkName: String? = null,
    val processedEntries: Int = 0,
    val totalEntries: Int = 0,
    val processedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val alignedEntriesSoFar: Int = 0,
    val mergedLibsSoFar: Int = 0,
    val mergedAssetsSoFar: Int = 0,
    val mergedResSoFar: Int = 0,
    val strippedMetaInfSoFar: Int = 0,
    val bufferSizeKb: Int = 512,
    val liveLogs: List<String> = emptyList()
) {
    val fraction: Float
        get() = if (totalEntries > 0) {
            (processedEntries.toFloat() / totalEntries.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

data class EntryComparisonItem(
    val name: String,
    val sourceSplitName: String,
    val category: ApkEntryCategory,
    val uncompressedSize: Long,
    val newMethod: Int,
    val dataOffset: Long,
    val is4kAligned: Boolean,
    val mergeBadge: String? = null
)

data class ManifestPatchSummary(
    val wasManifestPatched: Boolean = false,
    val isSplitRequiredSetToFalse: Boolean = false,
    val splitAttributesClearedCount: Int = 0,
    val removedSplitMetaDataTags: List<String> = emptyList(),
    val originalManifestBytes: Int = 0,
    val patchedManifestBytes: Int = 0
)

data class MergeResult(
    val outputFile: File,
    val outputFileName: String = "Universal_Game.apk",
    val originalArchiveSize: Long,
    val universalApkSize: Long,
    val mergedSplitApksCount: Int,
    val totalEntriesMerged: Int,
    val mergedNativeLibsCount: Int,
    val mergedAssetsCount: Int,
    val mergedResourcesCount: Int,
    val mergedDexCount: Int,
    val stored4kAlignedCount: Int,
    val deflatedEntryCount: Int,
    val strippedMetaInfCount: Int,
    val manifestPatchSummary: ManifestPatchSummary,
    val elapsedTimeMs: Long,
    val throughputMbPerSec: Float,
    val entryComparisons: List<EntryComparisonItem>,
    val finalLogs: List<String>,
    val requiresResign: Boolean = true
)
