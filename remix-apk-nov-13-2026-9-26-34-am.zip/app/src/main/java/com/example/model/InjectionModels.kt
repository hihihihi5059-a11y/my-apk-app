package com.example.model

/**
 * Data model representing a code injection configuration request.
 */
data class InjectionRequest(
    val apkFilePath: String,
    val targetClassName: String,
    val methodSignature: String,
    val replacementSmali: String
)
