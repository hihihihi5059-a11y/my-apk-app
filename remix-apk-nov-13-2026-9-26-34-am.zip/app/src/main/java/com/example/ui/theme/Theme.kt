package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val DarkNavyColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = OnCyanAccent,
    primaryContainer = CyanAccentContainer,
    onPrimaryContainer = OnCyanAccentContainer,
    secondary = EmeraldSuccess,
    onSecondary = OnEmeraldSuccess,
    secondaryContainer = EmeraldSuccessContainer,
    onSecondaryContainer = Color(0xFFB9F6CA),
    tertiary = GoldWarning,
    onTertiary = Color(0xFF2B2000),
    tertiaryContainer = GoldWarningContainer,
    onTertiaryContainer = Color(0xFFFFECB3),
    background = DeepNavyBackground,
    onBackground = DarkTextPrimary,
    surface = DeepNavySurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DeepNavySurfaceElevated,
    onSurfaceVariant = DarkTextSecondary,
    outline = DeepNavyBorder,
    error = CoralDanger,
    errorContainer = CoralDangerContainer,
    onError = OnCoralDanger
)

private val LightNavyColorScheme = lightColorScheme(
    primary = LightNavyPrimary,
    onPrimary = Color.White,
    primaryContainer = LightNavySurfaceElevated,
    onPrimaryContainer = LightNavyPrimary,
    secondary = LightCyanAccent,
    onSecondary = LightOnCyanAccent,
    secondaryContainer = Color(0xFFD6F5FA),
    onSecondaryContainer = Color(0xFF004D56),
    tertiary = Color(0xFFB28900),
    onTertiary = Color.White,
    tertiaryContainer = GoldWarningLightContainer,
    onTertiaryContainer = Color(0xFF473600),
    background = LightNavyBackground,
    onBackground = LightTextPrimary,
    surface = LightNavySurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightNavySurfaceElevated,
    onSurfaceVariant = LightTextSecondary,
    outline = LightNavyBorder,
    error = CoralDanger,
    errorContainer = CoralDangerLightContainer,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to stunning Deep Navy Dark Theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkNavyColorScheme else LightNavyColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
