package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.ApkFileInfo
import com.example.model.CategorySizeSaving
import com.example.model.CompressionBreakdownResult
import com.example.model.CompressorOptions
import com.example.model.CompressorProgressStage
import com.example.model.CompressorUiState
import com.example.ui.theme.CoralDanger
import com.example.ui.theme.CoralDangerContainer
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanAccentContainer
import com.example.ui.theme.CyanAccentGlow
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.DeepNavyBorder
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceElevated
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.EmeraldSuccessContainer
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.OnCyanAccent

/**
 * Tab 2 Screen: "ضغط APK" / Deep APK Size Compressor & Optimizer.
 */
@Composable
fun ApkCompressorScreen(
    uiState: CompressorUiState,
    onSelectApkClick: () -> Unit,
    onGenerateSampleClick: () -> Unit,
    onToggleDexOptimization: (Boolean) -> Unit,
    onToggleKeepArEnOnly: (Boolean) -> Unit,
    onToggleWebpConversion: (Boolean) -> Unit,
    onToggleArm64Only: (Boolean) -> Unit,
    onStartCompressionClick: () -> Unit,
    onInstallDirectlyClick: () -> Unit,
    onSaveCompressedClick: () -> Unit,
    onShareCompressedClick: () -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .testTag("apk_compressor_screen"),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .verticalScroll(scrollState)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Error banner if any
            AnimatedVisibility(visible = uiState.errorMessage != null) {
                Surface(
                    color = CoralDangerContainer,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CoralDanger),
                    modifier = Modifier.fillMaxWidth().testTag("compressor_error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = CoralDanger,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = uiState.errorMessage.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextPrimary
                            )
                        }
                        IconButton(
                            onClick = onDismissError,
                            modifier = Modifier.size(28.dp).minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = DarkTextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // 1. Source APK Selection Card
            CompressorUploadCard(
                selectedApk = uiState.selectedApk,
                isProcessing = uiState.isProcessing,
                onSelectApkClick = onSelectApkClick,
                onGenerateSampleClick = onGenerateSampleClick
            )

            // 2. Deep Optimization Toggles Card (dexlib2 + ARSCLib + WebP + arm64-v8a)
            DeepOptimizationTogglesCard(
                options = uiState.options,
                isEnabled = !uiState.isProcessing,
                onToggleDexOptimization = onToggleDexOptimization,
                onToggleKeepArEnOnly = onToggleKeepArEnOnly,
                onToggleWebpConversion = onToggleWebpConversion,
                onToggleArm64Only = onToggleArm64Only
            )

            // 3. Primary Action Button: Start Deep Compression & Signing
            StartCompressionButton(
                isEnabled = uiState.selectedApk != null && !uiState.isProcessing,
                isProcessing = uiState.isProcessing,
                onClick = onStartCompressionClick
            )

            // 4. Live Progress Indicator Card
            AnimatedVisibility(
                visible = uiState.isProcessing || uiState.currentStage != CompressorProgressStage.IDLE,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                CompressorProgressCard(
                    stage = uiState.currentStage,
                    progress = uiState.progressFloat,
                    statusMessage = uiState.statusMessage
                )
            }

            // 5. Detailed Size Breakdown Card (Before -> After & % Saved + Install & Save buttons)
            if (uiState.result != null) {
                DetailedSizeBreakdownCard(
                    result = uiState.result,
                    onInstallDirectlyClick = onInstallDirectlyClick,
                    onSaveCompressedClick = onSaveCompressedClick,
                    onShareCompressedClick = onShareCompressedClick
                )
            }

            // 6. Live Execution Logs Card
            if (uiState.logs.isNotEmpty()) {
                CompressorLogsCard(logs = uiState.logs)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CompressorUploadCard(
    selectedApk: ApkFileInfo?,
    isProcessing: Boolean,
    onSelectApkClick: () -> Unit,
    onGenerateSampleClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(
            width = if (selectedApk != null) 1.5.dp else 1.dp,
            color = if (selectedApk != null) CyanAccent.copy(alpha = 0.8f) else DeepNavyBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth().testTag("compressor_upload_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(CyanAccent.copy(alpha = 0.25f), DeepNavySurfaceElevated)
                        )
                    )
                    .border(1.5.dp, CyanAccent.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (selectedApk != null) Icons.Default.Verified else Icons.Default.Compress,
                    contentDescription = "أيقونة ضغط الحزمة",
                    tint = if (selectedApk != null) EmeraldSuccess else CyanAccent,
                    modifier = Modifier.size(32.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "ضغط وتحسين حجم APK العميق (Deep APK Optimizer)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "تقليص حجم ملفات DEX عبر dexlib2، وتنظيف اللغات من resources.arsc عبر ARSCLib، وتحويل الصور إلى WebP، مع محاذاة Zipalign وتوقيع V1/V2/V3",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
            }

            Button(
                onClick = onSelectApkClick,
                enabled = !isProcessing,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanAccentContainer,
                    contentColor = CyanAccent
                ),
                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("compressor_select_apk_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FileOpen,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "اختر ملف APK للضغط (Select APK File)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (selectedApk != null) {
                Surface(
                    color = DeepNavySurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    modifier = Modifier.fillMaxWidth().testTag("compressor_selected_file_box")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Android,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = selectedApk.fileName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Surface(
                                color = GoldWarning.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, GoldWarning.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = "الحجم الأصلي: ${selectedApk.formattedSize}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldWarning,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = "الحزمة: ${selectedApk.packageName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            } else {
                TextButton(
                    onClick = onGenerateSampleClick,
                    enabled = !isProcessing,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("compressor_generate_sample_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CyanAccentGlow,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "توليد ملف APK تجريبي غني (DEX + 8 لغات ARSC + PNG + 4 معماريات) للاختبار",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyanAccentGlow,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeepOptimizationTogglesCard(
    options: CompressorOptions,
    isEnabled: Boolean,
    onToggleDexOptimization: (Boolean) -> Unit,
    onToggleKeepArEnOnly: (Boolean) -> Unit,
    onToggleWebpConversion: (Boolean) -> Unit,
    onToggleArm64Only: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier.fillMaxWidth().testTag("compressor_toggles_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "خيارات الضغط والتحسين العميق (Deep Optimization)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
            }

            // Toggle 1: Deep DEX Bytecode Optimization (dexlib2)
            OptimizationOptionSwitchRow(
                title = "تحسين بايت كود DEX وحذف بيانات التصحيح (dexlib2)",
                subtitle = "إعادة كتابة classes*.dex عبر DexFileFactory لحذف DebugItem وأسماء المتغيرات وحذف ملفات kotlin_module و DebugProbesKt.bin",
                badge = "dexlib2",
                icon = Icons.Default.Code,
                accentColor = CyanAccent,
                checked = options.stripDexDebugAndBloat,
                enabled = isEnabled,
                onCheckedChange = onToggleDexOptimization,
                testTag = "toggle_dex_optimization"
            )

            // Toggle 2: Keep Only Essential Languages (Arabic & English) via ARSCLib
            OptimizationOptionSwitchRow(
                title = "الإبقاء على اللغات الأساسية فقط (العربية والإنجليزية)",
                subtitle = "استخدام ARSCLib (TableBlock & ResConfig) لحذف ترجمات اللغات الأجنبية غير المستخدمة من resources.arsc مع حفظ الافتراضية و ar و en",
                badge = "ARSCLib",
                icon = Icons.Default.Language,
                accentColor = EmeraldSuccess,
                checked = options.keepOnlyArEnLanguages,
                enabled = isEnabled,
                onCheckedChange = onToggleKeepArEnOnly,
                testTag = "toggle_keep_ar_en_languages"
            )

            // Toggle 3: Smart WebP Image Conversion
            OptimizationOptionSwitchRow(
                title = "تحويل الصور الثقيلة إلى WebP ذكي (Quality 85)",
                subtitle = "تحويل صور .png و .jpg في res/drawable إلى صيغة WebP عالية الكفاءة (مع تخطي ملفات .9.png وأيقونات الإطلاق تلقائياً)",
                badge = "WebP 85%",
                icon = Icons.Default.Image,
                accentColor = GoldWarning,
                checked = options.convertImagesToWebp,
                enabled = isEnabled,
                onCheckedChange = onToggleWebpConversion,
                testTag = "toggle_webp_conversion"
            )

            // Toggle 4: Keep Only arm64-v8a Native Libraries
            OptimizationOptionSwitchRow(
                title = "الإبقاء على مكتبات arm64-v8a فقط (64-Bit Native)",
                subtitle = "حذف معماريات المعالج غير المستخدمة (x86, x86_64, armeabi-v7a) من مجلد lib/ لتوفير مساحة ضخمة",
                badge = "arm64-v8a",
                icon = Icons.Default.DeveloperBoard,
                accentColor = CyanAccentGlow,
                checked = options.keepOnlyArm64NativeLibs,
                enabled = isEnabled,
                onCheckedChange = onToggleArm64Only,
                testTag = "toggle_keep_arm64_only"
            )
        }
    }
}

@Composable
private fun OptimizationOptionSwitchRow(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    accentColor: Color,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (checked) DeepNavySurfaceElevated else DeepNavySurfaceElevated.copy(alpha = 0.55f),
        border = BorderStroke(
            width = 1.dp,
            color = if (checked) accentColor.copy(alpha = 0.55f) else DeepNavyBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Surface(
                        color = accentColor.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall,
                            color = accentColor,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkTextSecondary
                )
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                enabled = enabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = OnCyanAccent,
                    checkedTrackColor = accentColor
                ),
                modifier = Modifier.testTag(testTag)
            )
        }
    }
}

@Composable
private fun StartCompressionButton(
    isEnabled: Boolean,
    isProcessing: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = isEnabled,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = CyanAccent,
            contentColor = OnCyanAccent,
            disabledContainerColor = CyanAccentContainer.copy(alpha = 0.35f),
            disabledContentColor = DarkTextMuted
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp, pressedElevation = 10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("start_deep_compression_button")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isProcessing) {
                CircularProgressIndicator(
                    color = OnCyanAccent,
                    strokeWidth = 2.5.dp,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Compress,
                    contentDescription = null,
                    tint = if (isEnabled) OnCyanAccent else DarkTextMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
            Text(
                text = "ضغط وتحسين وتوقيع الحزمة (Compress & Sign APK)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun CompressorProgressCard(
    stage: CompressorProgressStage,
    progress: Float,
    statusMessage: String
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().testTag("compressor_progress_card")
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { progress },
                    color = CyanAccent,
                    trackColor = DeepNavySurfaceElevated,
                    strokeWidth = 3.5.dp,
                    modifier = Modifier.size(46.dp)
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stage.labelAr,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Text(
                    text = statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary
                )
            }
        }
    }
}

/**
 * 4. Detailed Size Breakdown UI Card showing Before -> After and % saved across
 * DEX, Resources/Images, Native Libs, and Total Size, with direct Install and Save buttons.
 */
@Composable
private fun DetailedSizeBreakdownCard(
    result: CompressionBreakdownResult,
    onInstallDirectlyClick: () -> Unit,
    onSaveCompressedClick: () -> Unit,
    onShareCompressedClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.5.dp, EmeraldSuccess.copy(alpha = 0.7f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier.fillMaxWidth().testTag("detailed_size_breakdown_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header with total savings badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(EmeraldSuccessContainer)
                            .border(1.dp, EmeraldSuccess, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "تقرير التوفير التفصيلي للحجم (Size Breakdown)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = DarkTextPrimary
                        )
                        Text(
                            text = "${result.outputFileName} • ${result.signedSchemesSummary}",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary
                        )
                    }
                }

                Surface(
                    color = EmeraldSuccess.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, EmeraldSuccess)
                ) {
                    Text(
                        text = "-${result.totalBreakdown.formattedPercent}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldSuccess,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            // Hero Total Size Comparison Banner (Before -> After & % Saved)
            Surface(
                color = DeepNavySurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "الحجم الإجمالي (قبل ⬅ بعد)",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary
                        )
                        Text(
                            text = "${result.totalBreakdown.formattedBefore} ➔ ${result.totalBreakdown.formattedAfter}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "المساحة الموفرة",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary
                        )
                        Text(
                            text = "${result.totalBreakdown.formattedSaved} (${result.totalBreakdown.formattedPercent})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess
                        )
                    }
                }
            }

            // Category Breakdown Rows: DEX, Resources/Images, Native Libs
            CategoryBreakdownItemRow(
                saving = result.dexBreakdown,
                accentColor = CyanAccent,
                testTag = "breakdown_row_dex"
            )
            CategoryBreakdownItemRow(
                saving = result.resourcesBreakdown,
                accentColor = GoldWarning,
                testTag = "breakdown_row_resources"
            )
            CategoryBreakdownItemRow(
                saving = result.nativeLibsBreakdown,
                accentColor = EmeraldSuccess,
                testTag = "breakdown_row_native_libs"
            )

            // Direct Action Buttons: Install Directly & Save Compressed APK
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onInstallDirectlyClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = OnCyanAccent
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("compressor_install_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Android,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تثبيت مباشرة",
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onSaveCompressedClick,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyanAccent),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("compressor_save_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "حفظ التطبيق المضغوط",
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "محاذاة Zipalign (4B/4K): ${result.storedAlignedEntriesCount} ملف STORED",
                    style = MaterialTheme.typography.labelSmall,
                    color = DarkTextSecondary
                )
                TextButton(
                    onClick = onShareCompressedClick,
                    modifier = Modifier.testTag("compressor_share_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "مشاركة الحزمة", color = CyanAccent)
                }
            }
        }
    }
}

@Composable
private fun CategoryBreakdownItemRow(
    saving: CategorySizeSaving,
    accentColor: Color,
    testTag: String
) {
    val ratioAfter = if (saving.beforeBytes > 0L) {
        (saving.afterBytes.toFloat() / saving.beforeBytes.toFloat()).coerceIn(0.05f, 1f)
    } else {
        1f
    }

    Surface(
        color = DeepNavySurfaceElevated.copy(alpha = 0.7f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier.fillMaxWidth().testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = saving.categoryNameAr,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Text(
                    text = "${saving.formattedBefore} ➔ ${saving.formattedAfter} (-${saving.formattedPercent})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
            }

            LinearProgressIndicator(
                progress = { ratioAfter },
                color = accentColor,
                trackColor = DeepNavyBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )

            Text(
                text = saving.detailsAr,
                style = MaterialTheme.typography.labelSmall,
                color = DarkTextSecondary
            )
        }
    }
}

@Composable
private fun CompressorLogsCard(logs: List<String>) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier.fillMaxWidth().testTag("compressor_logs_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "سجل عمليات الضغط والتوقيع (Compression Console)",
                    style = MaterialTheme.typography.labelLarge,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            Surface(
                color = DeepNavyBackground,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, DeepNavyBorder.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    logs.takeLast(8).forEach { line ->
                        Text(
                            text = line,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (line.startsWith("✍️") || line.startsWith("🎉") || line.startsWith("⚡")) EmeraldSuccess
                            else DarkTextSecondary,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
