package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AiEngineStatus
import com.example.model.HardwareTelemetryState
import com.example.model.InstalledAppItem
import com.example.model.LocalDecompiledProject
import com.example.model.LocalGgufModelState
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan

/**
 * Top Hardware & Local AI Performance Bar (100% Offline - No Internet Indicators).
 * Displays CPU Load, RAM consumption, and Local AI engine status.
 */
@Composable
fun LocalHardwareTelemetryBar(
    telemetry: HardwareTelemetryState,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CyberSurface,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 0.5.dp, color = CyberBorder)
            .testTag("local_hardware_telemetry_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // RAM Usage Indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Memory,
                    contentDescription = "استهلاك الذاكرة",
                    tint = NeonCyan,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "RAM: ${telemetry.usedRamMb}/${telemetry.totalRamMb} MB (${telemetry.ramUsagePercent}%)",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = CyberTextPrimary
                )
            }

            // CPU Load Indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeveloperBoard,
                    contentDescription = "المعالج",
                    tint = EmeraldSuccess,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "CPU (${telemetry.cpuCores}C): ${telemetry.cpuLoadPercent}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = CyberTextSecondary
                )
            }

            // Local AI Status Pill
            val statusColor = when (telemetry.aiStatus) {
                AiEngineStatus.READY -> EmeraldSuccess
                AiEngineStatus.ANALYZING -> GoldWarning
                AiEngineStatus.MODEL_LOADED -> NeonCyan
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(statusColor.copy(alpha = 0.14f))
                    .border(1.dp, statusColor.copy(alpha = 0.45f), RoundedCornerShape(50))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Text(
                    text = "الذكاء المحلي: ${telemetry.aiStatus.labelAr}",
                    style = MaterialTheme.typography.labelSmall,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Screen 1: الشاشة الرئيسية (Offline Dashboard)
 * - Import APK from device storage or installed apps
 * - Local GGUF AI Model Manager Card (with .gguf file picker & preset profiles)
 * - Local Decompiled Projects list inside context.filesDir
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfflineDashboardScreen(
    ggufModel: LocalGgufModelState,
    projects: List<LocalDecompiledProject>,
    activeProject: LocalDecompiledProject?,
    installedApps: List<InstalledAppItem>,
    showInstalledAppsSheet: Boolean,
    isDecompiling: Boolean,
    onPickApkFromStorage: () -> Unit,
    onOpenInstalledApps: () -> Unit,
    onCloseInstalledApps: () -> Unit,
    onSelectInstalledApp: (InstalledAppItem) -> Unit,
    onGenerateSampleApk: () -> Unit,
    onPickGgufModelFile: () -> Unit,
    onSelectPresetGguf: (String, String, Long) -> Unit,
    onOpenProject: (LocalDecompiledProject) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("offline_dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero APK Import & Decompiler Engine Card
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(NeonCyan.copy(alpha = 0.14f))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "محرك الفك والتجميع المحلي (100% Offline IDE)",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "baksmali • smali • dexlib2 • jadx-ast • ecj/d8 • apksig",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = NeonCyan
                        )
                    }
                }

                Text(
                    text = "قم باستيراد أي حزمة APK من ذاكرة الهاتف أو من التطبيقات المثبتة لفك ملفات Smali والموارد محلياً داخل مسار التخزين الداخلي (filesDir) وتحويل DEX إلى كود Java مقروء.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextSecondary
                )

                if (isDecompiling) {
                    LinearProgressIndicator(
                        color = NeonCyan,
                        trackColor = CyberBackground,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50))
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onPickApkFromStorage,
                        enabled = !isDecompiling,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCyan,
                            contentColor = Color(0xFF002026)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_import_apk_storage")
                    ) {
                        Icon(
                            imageVector = Icons.Default.UploadFile,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "استيراد APK من الجهاز",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onOpenInstalledApps,
                        enabled = !isDecompiling,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_import_installed_app")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Android,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "التطبيقات المثبتة",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                OutlinedButton(
                    onClick = onGenerateSampleApk,
                    enabled = !isDecompiling,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberTextSecondary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .testTag("btn_generate_sample_project")
                ) {
                    Text(
                        text = "إنشاء وفك مشروع APK أمني نموذجي للاختبار الفوري (CyberVault.apk)",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // 2. On-Device Local GGUF AI Model Manager Card
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("gguf_model_manager_card")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = "مدير نموذج الذكاء الاصطناعي المحلي (GGUF Engine)",
                                style = MaterialTheme.typography.titleMedium,
                                color = CyberTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "يعمل على معالج الهاتف (CPU/GPU) عبر تقسيم الملفات (Chunking) بدون إنترنت",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                    }

                    Surface(
                        color = EmeraldSuccess.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = if (ggufModel.headerMagicVerified) "GGUF v3 جاهز" else "محلي نشط",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // Active Model Info Box
                Surface(
                    color = CyberBackground,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = ggufModel.modelName,
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "المعمارية: ${ggufModel.architecture}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextSecondary
                            )
                            Text(
                                text = "الضغط: ${ggufModel.quantization}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextSecondary
                            )
                            Text(
                                text = "الحجم: ${ggufModel.fileSizeMb} MB",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldSuccess
                            )
                        }
                    }
                }

                // Preset Model Selector Chips
                Text(
                    text = "النماذج البرمجية المحلية المدعومة (تبديل سريع أو استيراد ملف .gguf):",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val presets = listOf(
                        Triple("Qwen2.5-Coder-1.5B-Q4_K_M.gguf", "qwen2 (GGUF v3)", 986L),
                        Triple("DeepSeek-Coder-1.3B-Q4_K_M.gguf", "deepseek2 (GGUF v3)", 870L),
                        Triple("Gemma-2-2B-It-Q4_K_M.gguf", "gemma2 (GGUF v3)", 1420L)
                    )
                    presets.forEach { (name, arch, size) ->
                        val selected = ggufModel.modelName.startsWith(name.substringBefore("-Q4"))
                        Surface(
                            color = if (selected) NeonCyan.copy(alpha = 0.18f) else CyberSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (selected) NeonCyan else CyberBorder
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectPresetGguf(name, arch, size) }
                        ) {
                            Text(
                                text = name.substringBefore("-Q4"),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) NeonCyan else CyberTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = onPickGgufModelFile,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_select_gguf_model")
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "اختيار ملف نموذج (.gguf) من ذاكرة الهاتف",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 3. Local Decompiled Projects List in context.filesDir
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "المشاريع المحلية المفكوكة (context.filesDir)",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${projects.size} مشروع",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                }

                projects.forEach { project ->
                    val isCurrent = activeProject?.projectId == project.projectId
                    Surface(
                        color = if (isCurrent) CyberSurfaceElevated else CyberBackground,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isCurrent) NeonCyan.copy(alpha = 0.6f) else CyberBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenProject(project) }
                            .testTag("project_item_${project.projectId}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = project.appName,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = CyberTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (isCurrent) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "نشط",
                                            tint = EmeraldSuccess,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = project.packageName,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = NeonCyan
                                )
                                Text(
                                    text = "Smali: ${project.smaliClassesCount} كلاس • XML: ${project.xmlResourcesCount} مورد • DEX: ${project.dexFilesCount}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }

                            Button(
                                onClick = { onOpenProject(project) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonCyan.copy(alpha = 0.16f),
                                    contentColor = NeonCyan
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "تصفح الكود",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet for picking an installed APK from the device
    if (showInstalledAppsSheet) {
        ModalBottomSheet(
            onDismissRequest = onCloseInstalledApps,
            containerColor = CyberSurface,
            contentColor = CyberTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "اختر تطبيقاً مثبتاً لفكه محلياً",
                    style = MaterialTheme.typography.titleMedium,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(installedApps) { app ->
                        Surface(
                            color = CyberBackground,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectInstalledApp(app) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.appName,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = CyberTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = app.packageName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFontFamily,
                                        color = NeonCyan
                                    )
                                }
                                Text(
                                    text = "${app.sizeBytes / (1024 * 1024)} MB",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
