package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.engine.ApkMergeEngine
import com.example.model.ApkAnalysisReport
import com.example.model.ApkEntryCategory
import com.example.model.MergePhase
import com.example.model.MergeResult
import com.example.model.ProcessingProgress
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.ColorAssets
import com.example.ui.theme.ColorLib
import com.example.ui.theme.ColorRes
import com.example.ui.theme.CoralError
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextSecondary
import java.util.Locale
import java.util.zip.ZipEntry

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ActionAndLiveTelemetrySection(
    hasLoadedApk: Boolean,
    isAnalyzing: Boolean,
    progress: ProcessingProgress,
    onStartMerging: () -> Unit,
    onCancelMerging: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!progress.isRunning) {
            Button(
                onClick = onStartMerging,
                enabled = hasLoadedApk && !isAnalyzing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("start_compression_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = Color(0xFF042F2E)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.MergeType,
                    contentDescription = null,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.start_compression_button),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Live Progress Bar & Phase Telemetry Card
        AnimatedVisibility(visible = progress.isRunning || progress.liveLogs.isNotEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.5.dp,
                        if (progress.isRunning) CyanSecondary else ObsidianBorder,
                        RoundedCornerShape(18.dp)
                    )
                    .testTag("live_telemetry_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = ObsidianCardElevated)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Terminal,
                                contentDescription = null,
                                tint = CyanSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = stringResource(R.string.section_live_telemetry),
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White
                            )
                        }

                        if (progress.isRunning) {
                            OutlinedButton(
                                onClick = onCancelMerging,
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("cancel_compression_button"),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CoralError)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Cancel,
                                    contentDescription = null,
                                    tint = CoralError,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = stringResource(R.string.cancel_compression_button),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CoralError
                                )
                            }
                        } else {
                            Surface(
                                color = EmeraldPrimary.copy(alpha = 0.18f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "Universal_Game.apk Ready (100%)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Active Merging Phase Banner (English + Arabic)
                    Surface(
                        color = ObsidianSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (progress.isRunning) CyanSecondary.copy(alpha = 0.5f) else EmeraldPrimary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("live_merge_phase_banner")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = progress.currentPhaseTitle.ifEmpty { progress.currentPhase.titleEn },
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontFamily = JetBrainsMonoFontFamily
                                ),
                                color = if (progress.isRunning) CyanSecondary else EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = progress.currentPhase.titleAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                        }
                    }

                    // Pipeline Phase Chips
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val phases = listOf(
                            Pair(MergePhase.EXTRACTING_ARCHIVE, "1. Extract Splits"),
                            Pair(MergePhase.PATCHING_MANIFEST, "2. Patch Manifest"),
                            Pair(MergePhase.MERGING_LIBS, "3. Merge lib/*.so"),
                            Pair(MergePhase.MERGING_ASSETS, "4. Merge assets/"),
                            Pair(MergePhase.MERGING_RESOURCES, "5. Merge res/"),
                            Pair(MergePhase.FINALIZING_UNIVERSAL, "6. Universal APK")
                        )
                        phases.forEach { (phase, label) ->
                            val isActive = progress.currentPhase == phase
                            val isCompleted = progress.currentPhase.ordinal > phase.ordinal || !progress.isRunning
                            val chipColor = when {
                                isActive -> CyanSecondary
                                isCompleted -> EmeraldPrimary
                                else -> TextSecondary
                            }
                            Surface(
                                color = chipColor.copy(alpha = if (isActive) 0.22f else 0.1f),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    chipColor.copy(alpha = if (isActive || isCompleted) 0.6f else 0.25f)
                                )
                            ) {
                                Text(
                                    text = if (isCompleted && !isActive) "✓ $label" else label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = chipColor,
                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Live Progress Bar
                    LinearProgressIndicator(
                        progress = { if (progress.isRunning) progress.fraction else 1f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(50))
                            .testTag("merge_progress_bar"),
                        color = CyanSecondary,
                        trackColor = ObsidianSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            if (!progress.currentInnerApkName.isNullOrEmpty()) {
                                Surface(
                                    color = CyanSecondary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.padding(bottom = 4.dp)
                                ) {
                                    Text(
                                        text = "Source Split: ${progress.currentInnerApkName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyanSecondary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Current Entry: ${progress.currentEntryName.ifEmpty { "—" }}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Streamed: ${ApkMergeEngine.formatBytesShort(progress.processedBytes)} / ${ApkMergeEngine.formatBytesShort(progress.totalBytes)} • ${progress.bufferSizeKb}KB Buffer",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${progress.processedEntries} / ${progress.totalEntries} (${(progress.fraction * 100).toInt()}%)",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily
                                ),
                                color = CyanSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "4K STORED: ${progress.alignedEntriesSoFar} • .so: ${progress.mergedLibsSoFar}",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldPrimary
                            )
                        }
                    }

                    // Live Console Log Box
                    Surface(
                        color = Color(0xFF070A10),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            progress.liveLogs.takeLast(8).forEach { logLine ->
                                Text(
                                    text = "› $logLine",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = JetBrainsMonoFontFamily
                                    ),
                                    color = when {
                                        logLine.contains("Patched") || logLine.contains("✅") -> EmeraldPrimary
                                        logLine.contains("4K STORED") || logLine.contains("Merging") -> CyanSecondary
                                        logLine.contains("Skipping") || logLine.contains("⚠️") -> AmberTertiary
                                        else -> Color(0xFFCBD5E1)
                                    },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OptimizationSummaryResultCard(
    result: MergeResult,
    history: List<MergeResult>,
    onSaveApk: () -> Unit,
    onShareApk: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, EmeraldPrimary.copy(alpha = 0.8f), RoundedCornerShape(20.dp))
            .testTag("summary_result_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCardElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            EmeraldPrimary.copy(alpha = 0.12f),
                            ObsidianCardElevated
                        )
                    )
                )
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(EmeraldPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.section_result_summary),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = buildString {
                                append(result.outputFileName)
                                append(" • ${result.mergedSplitApksCount} Splits Merged")
                                if (result.throughputMbPerSec > 0f) {
                                    append(String.format(Locale.US, " • %.1f MB/s", result.throughputMbPerSec))
                                }
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = EmeraldPrimary
                        )
                    }
                }

                Surface(
                    color = EmeraldPrimary.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(50),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary)
                ) {
                    Text(
                        text = "${result.elapsedTimeMs} ms",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // V1/V2 Signing Notice Banner
            if (result.requiresResign) {
                Surface(
                    color = AmberTertiary.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AmberTertiary.copy(alpha = 0.7f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("requires_resign_warning_banner")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "🔐 جاهز للتوقيع الموحد V1/V2 (META-INF Signatures Wiped)",
                            style = MaterialTheme.typography.titleSmall,
                            color = AmberTertiary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "تم مسح ${result.strippedMetaInfCount} ملف توقيع قديم من مجلد META-INF ومحاذاة جميع مكتبات .so وملفات المحرك (.pak/.obb/.assets) بدقة 4096-byte. لتثبيت Universal_Game.apk مباشرة قم بتوقيعه عبر:\napksigner sign --ks keystore.jks Universal_Game.apk",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                    }
                }
            }

            // Original Split Archive vs Universal_Game.apk Size Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryMetricCard(
                    title = "حجم الأرشيف المجزأ",
                    value = ApkMergeEngine.formatBytesShort(result.originalArchiveSize),
                    subValue = "${result.mergedSplitApksCount} حزم مجزأة",
                    valueColor = TextSecondary,
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    title = "حجم Universal_Game.apk",
                    value = ApkMergeEngine.formatBytesShort(result.universalApkSize),
                    subValue = "${result.totalEntriesMerged} ملف مدمج",
                    valueColor = EmeraldPrimary,
                    modifier = Modifier.weight(1f)
                )
            }

            // Binary Manifest Patching Verification Card
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "توثيق تعديل البيان الثنائي (Binary AndroidManifest.xml Patch):",
                            style = MaterialTheme.typography.titleSmall,
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "• android:isSplitRequired=\"true\"  ➔  android:isSplitRequired=\"false\" (0x00000000)",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = Color.White
                    )
                    Text(
                        text = "• Removed Split <meta-data> Tags (${result.manifestPatchSummary.removedSplitMetaDataTags.size}): ${
                            result.manifestPatchSummary.removedSplitMetaDataTags.joinToString(", ").ifEmpty { "vending.splits" }
                        }",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = CyanSecondary
                    )
                }
            }

            // Deep Merge Breakdown Rows
            Surface(
                color = ObsidianSurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "تفاصيل الدمج العميق ومحاذاة الذاكرة (Smart Deep Merge):",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    MergeBreakdownRow(
                        title = "دمج المكتبات الأصلية للمعالج (lib/<abi>/*.so)",
                        subtitle = "نسخ ودمج ملفات .so من حزم المعماريات مع محاذاة 4096-byte STORED",
                        badgeText = "${result.mergedNativeLibsCount} .so Merged",
                        accentColor = ColorLib
                    )

                    MergeBreakdownRow(
                        title = "دمج أصول المحرك واللعبة (assets/, .pak, .obb, .assets)",
                        subtitle = "دمج حزم الأصول وملفات التوسعة بوضع ZipEntry.STORED ومحاذاة 4K",
                        badgeText = "${result.mergedAssetsCount} Assets",
                        accentColor = ColorAssets
                    )

                    MergeBreakdownRow(
                        title = "دمج موارد الشاشات واللغات (res/ DPI & Language Splits)",
                        subtitle = "توحيد الصور والتخطيطات والترجمات من الحزم الفرعية إلى الحزمة الأساسية",
                        badgeText = "${result.mergedResourcesCount} Resources",
                        accentColor = ColorRes
                    )

                    MergeBreakdownRow(
                        title = "محاذاة الذاكرة المباشرة (4K Page Alignment • ZipEntry.STORED)",
                        subtitle = "جميع ملفات .so و .pak و .obb و .assets و resources.arsc محاذاة على 0x1000",
                        badgeText = "${result.stored4kAlignedCount} 4K STORED",
                        accentColor = EmeraldPrimary
                    )
                }
            }

            // Top Merged Entries & 4K Offset Verification List
            if (result.entryComparisons.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "أبرز الملفات المدمجة وتوثيق إزاحة 4K (Offsets):",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White
                    )
                    result.entryComparisons.take(6).forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(ObsidianSurface.copy(alpha = 0.75f))
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = buildString {
                                        append("[${item.sourceSplitName}] • ")
                                        if (item.newMethod == ZipEntry.STORED) {
                                            append(String.format(Locale.US, "STORED • Offset 0x%08X (4K✓)", item.dataOffset))
                                        } else {
                                            append(String.format(Locale.US, "DEFLATED • Offset 0x%08X", item.dataOffset))
                                        }
                                        if (item.mergeBadge != null) {
                                            append(" • ${item.mergeBadge}")
                                        }
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (item.is4kAligned) CyanSecondary else AmberTertiary
                                )
                            }
                            Text(
                                text = ApkMergeEngine.formatBytesShort(item.uncompressedSize),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = JetBrainsMonoFontFamily
                                ),
                                color = EmeraldPrimary
                            )
                        }
                    }
                }
            }

            // Save & Share Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onSaveApk,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("save_apk_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = Color(0xFF042F2E)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.save_apk_button),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onShareApk,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("share_apk_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyanSecondary)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        tint = CyanSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.share_apk_button),
                        style = MaterialTheme.typography.titleSmall,
                        color = CyanSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Session History
            if (history.size > 1) {
                HorizontalDivider(color = ObsidianBorder)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "عمليات الدمج السابقة في هذه الجلسة (${history.size}):",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                history.take(3).forEachIndexed { idx, hist ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "#${idx + 1} ${hist.outputFileName} (${hist.mergedSplitApksCount} Splits)",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                        Text(
                            text = "${ApkMergeEngine.formatBytesShort(hist.universalApkSize)} • ${hist.stored4kAlignedCount} 4K STORED",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryMetricCard(
    title: String,
    value: String,
    subValue: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = ObsidianSurface,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = JetBrainsMonoFontFamily
                ),
                color = valueColor,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subValue,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun MergeBreakdownRow(
    title: String,
    subtitle: String,
    badgeText: String,
    accentColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianCardElevated.copy(alpha = 0.7f))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = Color.White,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Surface(
            color = accentColor.copy(alpha = 0.16f),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
        ) {
            Text(
                text = badgeText,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = JetBrainsMonoFontFamily
                ),
                color = accentColor,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun EntryExplorerDialog(
    report: ApkAnalysisReport,
    selectedCategory: ApkEntryCategory?,
    searchQuery: String,
    onSelectCategory: (ApkEntryCategory?) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val filteredEntries = report.entries.filter { entry ->
        val matchesCat = selectedCategory == null || entry.category == selectedCategory
        val matchesQuery = searchQuery.isBlank() ||
            entry.name.contains(searchQuery, ignoreCase = true) ||
            entry.sourceApkName.contains(searchQuery, ignoreCase = true)
        matchesCat && matchesQuery
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.86f)
                .border(1.dp, ObsidianBorder, RoundedCornerShape(22.dp)),
            shape = RoundedCornerShape(22.dp),
            color = ObsidianBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "مستكشف ملفات الحزم المجزأة (${filteredEntries.size})",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = report.fileName,
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color.White
                        )
                    }
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("entry_search_input"),
                    placeholder = {
                        Text("ابحث باسم الملف أو الحزمة (مثال: .so أو .pak أو arm64)")
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { onSelectCategory(null) },
                        label = { Text("الكل (${report.entries.size})") }
                    )
                    ApkEntryCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { onSelectCategory(cat) },
                            label = { Text(cat.shortTag) }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredEntries, key = { "${it.sourceApkName}:${it.name}" }) { entry ->
                        Surface(
                            color = ObsidianSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = entry.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        color = CyanSecondary.copy(alpha = 0.18f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = entry.sourceApkName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CyanSecondary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "الحجم: ${ApkMergeEngine.formatBytesShort(entry.uncompressedSize)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = if (entry.method == ZipEntry.STORED) "STORED" else "DEFLATED",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (entry.method == ZipEntry.STORED) EmeraldPrimary else TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
