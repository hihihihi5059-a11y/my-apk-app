package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.model.BuildPipelineStep
import com.example.model.BuildStageState
import com.example.model.LocalBuildState
import com.example.model.LocalDecompiledProject
import com.example.ui.theme.CoralDanger
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan

/**
 * Screen 4: وحدة البناء والتوقيع (Local Build Console)
 * Displays the 5-stage pipeline (Java -> DEX -> Smali -> Repackage 4K -> ApkSig v1/v2 Sign)
 * with live terminal logs, signature verification badge, and direct APK installation button.
 */
@Composable
fun LocalBuildConsoleScreen(
    project: LocalDecompiledProject?,
    buildState: LocalBuildState,
    onStartBuildAndSign: () -> Unit,
    onInstallSignedApk: () -> Unit,
    onExportSignedApk: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("local_build_console_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Build Pipeline Control Header Card
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "وحدة البناء والتوقيع المحلية (Local Build & ApkSig)",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "المشروع المستهدف: ${project?.appName ?: "CyberVault Security Pro"} (${project?.packageName ?: "com.cybervault.security"})",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }

                    Surface(
                        color = if (buildState.signatureVerified) EmeraldSuccess.copy(alpha = 0.16f) else NeonCyan.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (buildState.signatureVerified) EmeraldSuccess else NeonCyan
                        )
                    ) {
                        Text(
                            text = if (buildState.signatureVerified) "مُوقّع (v1+v2)" else "${buildState.progressPercent}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = if (buildState.signatureVerified) EmeraldSuccess else NeonCyan,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { (buildState.progressPercent / 100f).coerceIn(0f, 1f) },
                    color = if (buildState.signatureVerified) EmeraldSuccess else NeonCyan,
                    trackColor = CyberBackground,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(50))
                )

                Button(
                    onClick = onStartBuildAndSign,
                    enabled = !buildState.isBuilding && project != null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan,
                        contentColor = Color(0xFF002026)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_start_local_build")
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (buildState.isBuilding) {
                            "جاري تحويل Java -> Smali وتجميع وتوقيع APK..."
                        } else {
                            "بدء التجميع وإعادة الحزم والتوقيع المحلي (Build & Sign)"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 2. Step-by-Step Compiler & Signer Pipeline Card
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "خطوات سلسلة التجميع المحلية (Compiler & Signer Stages)",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )

                buildState.steps.forEach { step ->
                    BuildStepRow(step = step)
                }
            }
        }

        // 3. Signed Output & Direct Install Card (Emerald #00E676 when ready)
        if (buildState.outputSignedApkPath != null) {
            Surface(
                color = CyberSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, EmeraldSuccess),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signed_apk_ready_card")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(26.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "اكتمل بناء وتوقيع ملف APK بنجاح!",
                                style = MaterialTheme.typography.titleMedium,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = buildState.signerCertificateSubject,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = CyberTextSecondary
                            )
                        }
                    }

                    Text(
                        text = "المسار المحلي: ${buildState.outputSignedApkPath}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = NeonCyan
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onInstallSignedApk,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldSuccess,
                                contentColor = Color(0xFF002410)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("btn_install_signed_apk")
                        ) {
                            Icon(
                                imageVector = Icons.Default.InstallMobile,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تثبيت مباشر (Install)",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = onExportSignedApk,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldSuccess),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("btn_export_signed_apk")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SaveAlt,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "حفظ APK في الذاكرة",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 4. Live Build Terminal Console
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "سجل التجميع والتوقيع الحي (Local Build Terminal)",
                    style = MaterialTheme.typography.titleSmall,
                    color = CyberTextPrimary,
                    fontWeight = FontWeight.Bold
                )

                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Surface(
                        color = CyberBackground,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            val logs = buildState.consoleLogs.ifEmpty {
                                listOf(
                                    "[READY] Local Compiler Pipeline initialized (ecj + d8 + smali 2.5.2 + apksig 8.0.0)",
                                    "[READY] Click 'Build & Sign' to assemble modified Java/Smali into signed APK."
                                )
                            }
                            logs.forEach { line ->
                                val lineColor = when {
                                    line.contains("✓") -> EmeraldSuccess
                                    line.contains("خطأ") || line.contains("Error") -> CoralDanger
                                    line.contains("[") -> NeonCyan
                                    else -> CyberTextSecondary
                                }
                                Text(
                                    text = line,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = lineColor
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BuildStepRow(step: BuildPipelineStep) {
    val accentColor = when (step.state) {
        BuildStageState.SUCCESS -> EmeraldSuccess
        BuildStageState.RUNNING -> NeonCyan
        BuildStageState.WARNING -> GoldWarning
        BuildStageState.ERROR -> CoralDanger
        BuildStageState.PENDING -> CyberTextSecondary
    }

    Surface(
        color = CyberBackground,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (step.state == BuildStageState.PENDING) CyberBorder else accentColor.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    when (step.state) {
                        BuildStageState.RUNNING -> {
                            CircularProgressIndicator(
                                color = NeonCyan,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        BuildStageState.SUCCESS -> {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        BuildStageState.ERROR -> {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = CoralDanger,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        else -> {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${step.stepNumber}. ${step.titleAr}",
                        style = MaterialTheme.typography.titleSmall,
                        color = CyberTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = step.subtitleAr,
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Surface(
                color = CyberSurfaceElevated,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
                Text(
                    text = if (step.durationMs > 0) "${step.durationMs}ms" else step.toolBadge,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = accentColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
