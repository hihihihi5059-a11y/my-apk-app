package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.VerticalSplit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CodeChunkResult
import com.example.model.LocalAiTaskType
import com.example.model.LocalGgufModelState
import com.example.model.ProjectFileNode
import com.example.model.ProjectFileType
import com.example.ui.theme.CoralDanger
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan

/**
 * Real-time syntax highlighting VisualTransformation for Java, Smali, and XML code.
 */
class CodeSyntaxHighlighter(private val language: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val annotated = buildAnnotatedString {
            append(raw)

            // 1. Highlight keywords (Neon Cyan #00E5FF)
            val keywordPattern = when (language) {
                "SMALI" -> Regex("(\\.class|\\.super|\\.source|\\.field|\\.method|\\.end method|\\.locals|\\.param|public|private|protected|static|final|invoke-virtual|invoke-direct|invoke-static|const/4|const/16|const-string|return-void|return|if-eqz|if-lt|move-result|iput-boolean|and-int/2addr)")
                "XML" -> Regex("(</?[a-zA-Z0-9_-]+|/>|>|xmlns:android|android:[a-zA-Z0-9_]+)")
                else -> Regex("\\b(package|import|public|private|protected|class|extends|implements|return|if|else|boolean|int|void|String|Object|true|false|null|super|new)\\b")
            }
            keywordPattern.findAll(raw).forEach { match ->
                addStyle(
                    SpanStyle(color = NeonCyan, fontWeight = FontWeight.Bold),
                    match.range.first,
                    match.range.last + 1
                )
            }

            // 2. Highlight Registers & Numbers (Gold Warning #FFD54F)
            val registerOrNumPattern = Regex("\\b(v\\d+|p\\d+|0x[0-9a-fA-F]+|\\d+)\\b")
            registerOrNumPattern.findAll(raw).forEach { match ->
                addStyle(
                    SpanStyle(color = GoldWarning),
                    match.range.first,
                    match.range.last + 1
                )
            }

            // 3. Highlight Strings (Emerald Success #00E676)
            val stringPattern = Regex("\"[^\"\n]*\"")
            stringPattern.findAll(raw).forEach { match ->
                addStyle(
                    SpanStyle(color = EmeraldSuccess),
                    match.range.first,
                    match.range.last + 1
                )
            }

            // 4. Highlight Comments (Muted Silver #9AA5B1)
            val commentPattern = Regex("(//.*|#.*|<!--.*?-->)")
            commentPattern.findAll(raw).forEach { match ->
                addStyle(
                    SpanStyle(color = CyberTextSecondary),
                    match.range.first,
                    match.range.last + 1
                )
            }
        }
        return TransformedText(annotated, OffsetMapping.Identity)
    }
}

/**
 * Screen 3: مساحة العمل والمحرر (Local AI Code Editor)
 * - Syntax highlighting for Java, Smali, XML
 * - Split View showing original Smali code side-by-side with structured Java code
 * - Floating Action Button to run Local On-Device AI on the active code
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocalAiCodeEditorScreen(
    selectedNode: ProjectFileNode?,
    allSmaliNodes: List<ProjectFileNode>,
    isSplitView: Boolean,
    javaText: String,
    smaliText: String,
    ggufModel: LocalGgufModelState,
    isAiAnalyzing: Boolean,
    aiChunkProgressText: String,
    latestAiResult: CodeChunkResult?,
    showAiSheet: Boolean,
    onSelectNode: (ProjectFileNode) -> Unit,
    onToggleSplitView: () -> Unit,
    onJavaChange: (String) -> Unit,
    onSmaliChange: (String) -> Unit,
    onOpenAiMenu: () -> Unit,
    onCloseAiMenu: () -> Unit,
    onRunAiTask: (LocalAiTaskType) -> Unit,
    onApplyAiResult: () -> Unit,
    onNavigateToBuild: () -> Unit
) {
    val javaHighlighter = remember { CodeSyntaxHighlighter("JAVA") }
    val smaliHighlighter = remember { CodeSyntaxHighlighter("SMALI") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("local_ai_code_editor_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Editor Header Bar: File Selector Tabs + Split View Toggle + Build Shortcut
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = selectedNode?.name ?: "LicenseValidator.smali",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = selectedNode?.relativePath ?: "smali/com/cybervault/security/LicenseValidator.smali",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = NeonCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Split View Toggle Button
                        Surface(
                            color = if (isSplitView) NeonCyan.copy(alpha = 0.18f) else CyberBackground,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSplitView) NeonCyan else CyberBorder
                            ),
                            modifier = Modifier
                                .clickable { onToggleSplitView() }
                                .testTag("btn_toggle_split_view")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerticalSplit,
                                    contentDescription = "عرض مقسم",
                                    tint = if (isSplitView) NeonCyan else CyberTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (isSplitView) "Split View: نشط" else "عرض منفرد",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSplitView) NeonCyan else CyberTextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Quick Compile & Sign Action
                        Button(
                            onClick = onNavigateToBuild,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldSuccess,
                                contentColor = Color(0xFF002410)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("btn_editor_to_build")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "تجميع وتوقيع",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Quick File Switcher Tabs
                if (allSmaliNodes.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        allSmaliNodes.take(4).forEach { node ->
                            val isActive = selectedNode?.id == node.id
                            Surface(
                                color = if (isActive) CyberSurfaceElevated else CyberBackground,
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isActive) NeonCyan else CyberBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSelectNode(node) }
                            ) {
                                Text(
                                    text = node.name.removeSuffix(".smali"),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = if (isActive) NeonCyan else CyberTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Split View Code Editor Panes (LTR layout direction inside code panes for accurate Java/Smali alignment)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            if (isSplitView && selectedNode?.fileType == ProjectFileType.SMALI) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("split_view_editor_container"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Left Pane: Original / Synced Smali Bytecode
                    CodePaneCard(
                        title = "SMALI BYTECODE (baksmali)",
                        badgeColor = GoldWarning,
                        codeText = smaliText,
                        visualTransformation = smaliHighlighter,
                        onCodeChange = onSmaliChange,
                        testTag = "editor_pane_smali",
                        modifier = Modifier.weight(1f)
                    )

                    // Right Pane: Decompiled Editable Java Code (jadx-core + ecj/d8 sync)
                    CodePaneCard(
                        title = "JAVA SOURCE (jadx-core)",
                        badgeColor = NeonCyan,
                        codeText = javaText,
                        visualTransformation = javaHighlighter,
                        onCodeChange = onJavaChange,
                        testTag = "editor_pane_java",
                        modifier = Modifier.weight(1f)
                    )
                }
            } else {
                // Single Full-Width Pane
                CodePaneCard(
                    title = if (selectedNode?.fileType == ProjectFileType.SMALI) {
                        "JAVA DECOMPILED SOURCE (Synced with Smali)"
                    } else {
                        "XML RESOURCE EDITOR (${selectedNode?.name ?: "AndroidManifest.xml"})"
                    },
                    badgeColor = NeonCyan,
                    codeText = javaText,
                    visualTransformation = javaHighlighter,
                    onCodeChange = onJavaChange,
                    testTag = "editor_pane_single",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Quick Local AI Action Bar + Floating Action Button Trigger
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.45f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مساعد الذكاء الاصطناعي المحلي (${ggufModel.modelName.substringBefore("-Q4")})",
                            style = MaterialTheme.typography.titleSmall,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "إعادة تسمية المتغيرات الغامضة • شرح الدوال • اقتراح تعديل برمجي نظيف",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }

                    ExtendedFloatingActionButton(
                        onClick = onOpenAiMenu,
                        containerColor = NeonCyan,
                        contentColor = Color(0xFF002026),
                        icon = {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "تشغيل الذكاء الاصطناعي المحلي"
                            )
                        },
                        text = {
                            Text(
                                text = "تحليل بالذكاء المحلي",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        modifier = Modifier.testTag("fab_run_local_ai")
                    )
                }

                // Direct One-Tap AI Task Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LocalAiTaskType.entries.forEach { task ->
                        OutlinedButton(
                            onClick = { onRunAiTask(task) },
                            enabled = !isAiAnalyzing,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_ai_task_${task.name}")
                        ) {
                            Text(
                                text = task.titleAr,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet for Local On-Device AI Assistant Results & Chunking Progress
    if (showAiSheet) {
        ModalBottomSheet(
            onDismissRequest = onCloseAiMenu,
            containerColor = CyberSurface,
            contentColor = CyberTextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = NeonCyan
                    )
                    Column {
                        Text(
                            text = "محرك الاستدلال البرمجي المحلي (On-Device GGUF LLM)",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = aiChunkProgressText.ifBlank { "اختر مهمة لتحليل الكود المحدد بدون إنترنت" },
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCyan
                        )
                    }
                }

                if (isAiAnalyzing) {
                    LinearProgressIndicator(
                        color = NeonCyan,
                        trackColor = CyberBackground,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50))
                    )
                }

                // Task Selector Cards inside Sheet
                LocalAiTaskType.entries.forEach { task ->
                    Surface(
                        color = CyberBackground,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isAiAnalyzing) { onRunAiTask(task) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.titleAr,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = NeonCyan,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = task.descriptionAr,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            }
                        }
                    }
                }

                // Display AI Analysis Result if available
                if (latestAiResult != null) {
                    Surface(
                        color = CyberBackground,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "نتيجة التحليل المحلي (${latestAiResult.totalChunks} Chunk)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = latestAiResult.explanationAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextPrimary
                            )
                            Button(
                                onClick = onApplyAiResult,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldSuccess,
                                    contentColor = Color(0xFF002410)
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "تأكيد وتطبيق الكود المحسّن في المحرر",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun CodePaneCard(
    title: String,
    badgeColor: Color,
    codeText: String,
    visualTransformation: VisualTransformation,
    onCodeChange: (String) -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CyberSurface,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Pane Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSurfaceElevated)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = badgeColor,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${codeText.lines().size} lines",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = CyberTextSecondary
                )
            }

            OutlinedTextField(
                value = codeText,
                onValueChange = onCodeChange,
                visualTransformation = visualTransformation,
                textStyle = TextStyle(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 11.5.sp,
                    lineHeight = 17.sp,
                    color = CyberTextPrimary
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = CyberBackground,
                    unfocusedContainerColor = CyberBackground,
                    cursorColor = NeonCyan
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .testTag(testTag)
            )
        }
    }
}
