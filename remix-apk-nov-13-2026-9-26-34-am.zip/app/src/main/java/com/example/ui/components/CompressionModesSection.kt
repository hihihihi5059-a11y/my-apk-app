package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BuildCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.engine.ApkMergeEngine
import com.example.model.AbiFilterMode
import com.example.model.MergeConfig
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.ColorLib
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CompressionModesAndConfigSection(
    config: MergeConfig,
    detectedAbis: List<String>,
    bloatFilesCount: Int,
    bloatFilesBytes: Long,
    enabled: Boolean,
    onTogglePatchManifest: (Boolean) -> Unit,
    onToggleEnforce4k: (Boolean) -> Unit,
    onToggleStripSignatures: (Boolean) -> Unit,
    onToggleMergeObb: (Boolean) -> Unit,
    onSelectAbiFilterMode: (AbiFilterMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Tune,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = stringResource(R.string.section_compression_modes),
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ObsidianBorder, RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = ObsidianCardElevated)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. Binary Manifest Patching Toggle (android:isSplitRequired="false" & Strip Split <meta-data>)
                MergeFeatureToggleRow(
                    title = stringResource(R.string.patch_manifest_toggle),
                    subtitle = stringResource(R.string.patch_manifest_sub),
                    badge = "AXML 0x01010591",
                    icon = Icons.Default.BuildCircle,
                    accentColor = EmeraldPrimary,
                    checked = config.patchBinaryManifest,
                    enabled = enabled,
                    onCheckedChange = onTogglePatchManifest,
                    testTag = "patch_manifest_switch"
                )

                // 2. Enforce ZipEntry.STORED + 4K Memory Alignment (4096-byte alignment) for .so, .pak, .obb, .assets
                MergeFeatureToggleRow(
                    title = stringResource(R.string.enforce_4k_toggle),
                    subtitle = stringResource(R.string.enforce_4k_sub),
                    badge = "STORED • 4096B",
                    icon = Icons.Default.Memory,
                    accentColor = CyanSecondary,
                    checked = config.enforce4kAlignmentForSoAndGameAssets,
                    enabled = enabled,
                    onCheckedChange = onToggleEnforce4k,
                    testTag = "enforce_4k_switch"
                )

                // 3. Delete META-INF directory to wipe old split signatures
                MergeFeatureToggleRow(
                    title = stringResource(R.string.strip_signatures_toggle),
                    subtitle = stringResource(R.string.strip_signatures_sub),
                    badge = if (bloatFilesCount > 0) {
                        "$bloatFilesCount ملف (${ApkMergeEngine.formatBytesShort(bloatFilesBytes)})"
                    } else {
                        "V1/V2 Ready"
                    },
                    icon = Icons.Default.DeleteSweep,
                    accentColor = AmberTertiary,
                    checked = config.stripMetaInfSignatures,
                    enabled = enabled,
                    onCheckedChange = onToggleStripSignatures,
                    testTag = "strip_signatures_switch"
                )

                // 4. Merge OBB expansion containers into assets/obb/
                MergeFeatureToggleRow(
                    title = stringResource(R.string.merge_obb_toggle),
                    subtitle = stringResource(R.string.merge_obb_sub),
                    badge = "XAPK -> assets/obb",
                    icon = Icons.Default.SportsEsports,
                    accentColor = ColorLib,
                    checked = config.mergeObbIntoAssets,
                    enabled = enabled,
                    onCheckedChange = onToggleMergeObb,
                    testTag = "merge_obb_switch"
                )

                // 5. Target ABI Architecture Filter
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianSurface)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeveloperBoard,
                            contentDescription = null,
                            tint = ColorLib,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = stringResource(R.string.section_abi_filter),
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White
                        )
                    }
                    Text(
                        text = if (detectedAbis.isNotEmpty()) {
                            "المعماريات المكتشفة في الحزم الفرعية: ${detectedAbis.joinToString(", ")}"
                        } else {
                            "حدد معماريات المعالج المراد دمجها في مجلد lib/ داخل Universal_Game.apk:"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AbiFilterMode.entries.forEach { abiOption ->
                            val isSelected = config.abiFilterMode == abiOption
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectAbiFilterMode(abiOption) },
                                enabled = enabled,
                                label = {
                                    Text(
                                        text = abiOption.titleAr,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                leadingIcon = if (isSelected) {
                                    {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ColorLib.copy(alpha = 0.25f),
                                    selectedLabelColor = Color.White,
                                    selectedLeadingIconColor = ColorLib
                                )
                            )
                        }
                    }
                }

                // Memory Safe 512KB Streaming Guarantee Banner
                Surface(
                    color = EmeraldPrimary.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GppGood,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = "ضمان التدفق الآمن للذاكرة (512KB Buffer Streaming • Zero OOM)",
                                style = MaterialTheme.typography.titleSmall,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "يتم دمج ملفات الألعاب الضخمة (4GB+) باستخدام BufferedInputStream و BufferedOutputStream بحجم نافذة 512KB (524,288 بايت) دون تحميل الملفات في ذاكرة RAM.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MergeFeatureToggleRow(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    accentColor: Color,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (checked) accentColor.copy(alpha = 0.1f) else ObsidianSurface)
            .border(
                1.dp,
                if (checked) accentColor.copy(alpha = 0.4f) else Color.Transparent,
                RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled) {
                onCheckedChange(!checked)
            }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    color = accentColor.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = badge,
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF042F2E),
                checkedTrackColor = accentColor
            )
        )
    }
}
