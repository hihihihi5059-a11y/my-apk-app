package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.LocalDecompiledProject
import com.example.model.ProjectFileNode
import com.example.model.ProjectFileType
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan

/**
 * Screen 2: مستكشف المشروع (Local Project Tree)
 * Structured view of smali/, res/, and AndroidManifest.xml with instant search inside local files.
 */
@Composable
fun LocalProjectTreeScreen(
    project: LocalDecompiledProject?,
    searchQuery: String,
    selectedFolderFilter: String,
    onSearchQueryChange: (String) -> Unit,
    onSelectFolderFilter: (String) -> Unit,
    onOpenFileNode: (ProjectFileNode) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("local_project_tree_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (project == null) {
            Surface(
                color = CyberSurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        text = "لا يوجد مشروع محلي مفتوح حالياً",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyberTextPrimary
                    )
                }
            }
            return
        }

        // Project Header & Instant Search Bar
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "مستكشف ملفات المشروع: ${project.appName}",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = project.workspaceDirPath,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = CyberTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Instant Search Field (searches file names, paths, Smali, and Java code)
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = {
                        Text(
                            text = "بحث فوري في أسماء الملفات أو داخل كود Smali / Java / XML...",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = NeonCyan
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "مسح البحث",
                                    tint = CyberTextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = CyberBorder,
                        focusedContainerColor = CyberBackground,
                        unfocusedContainerColor = CyberBackground,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_tree_search_input")
                )

                // Folder Filter Chips: ALL, smali/, res/, AndroidManifest
                val filters = listOf(
                    "ALL" to "الكل (${project.files.size})",
                    "smali" to "مجلد smali/ (${project.smaliClassesCount})",
                    "res" to "مجلد res/ (${project.xmlResourcesCount})",
                    "root" to "AndroidManifest"
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filters.forEach { (key, label) ->
                        val selected = selectedFolderFilter == key
                        Surface(
                            color = if (selected) NeonCyan.copy(alpha = 0.18f) else CyberBackground,
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (selected) NeonCyan else CyberBorder
                            ),
                            modifier = Modifier
                                .clickable { onSelectFolderFilter(key) }
                                .testTag("filter_folder_$key")
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) NeonCyan else CyberTextSecondary,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Filtered Project Tree Nodes
        val filteredFiles = project.files.filter { node ->
            val matchesFolder = selectedFolderFilter == "ALL" ||
                node.fileType.folderCategory == selectedFolderFilter
            val q = searchQuery.trim()
            val matchesQuery = q.isEmpty() ||
                node.name.contains(q, ignoreCase = true) ||
                node.relativePath.contains(q, ignoreCase = true) ||
                node.smaliContent.contains(q, ignoreCase = true) ||
                node.javaContent.contains(q, ignoreCase = true)
            matchesFolder && matchesQuery
        }

        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "الملفات المطابقة (${filteredFiles.size})",
                    style = MaterialTheme.typography.labelLarge,
                    color = CyberTextPrimary
                )

                filteredFiles.forEach { node ->
                    val badgeColor = when (node.fileType) {
                        ProjectFileType.SMALI -> NeonCyan
                        ProjectFileType.JAVA -> EmeraldSuccess
                        ProjectFileType.XML -> GoldWarning
                        ProjectFileType.MANIFEST -> EmeraldSuccess
                    }

                    Surface(
                        color = CyberBackground,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (node.isModified) EmeraldSuccess.copy(alpha = 0.6f) else CyberBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenFileNode(node) }
                            .testTag("tree_node_${node.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(badgeColor.copy(alpha = 0.14f))
                                        .border(1.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (node.fileType == ProjectFileType.SMALI) Icons.Default.Code else Icons.Default.Description,
                                        contentDescription = null,
                                        tint = badgeColor,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = node.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = CyberTextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (node.isModified) {
                                            Text(
                                                text = "مُعدّل",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = EmeraldSuccess
                                            )
                                        }
                                    }
                                    Text(
                                        text = node.relativePath,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFontFamily,
                                        color = CyberTextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Surface(
                                color = badgeColor.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (node.fileType == ProjectFileType.SMALI) "SMALI + JAVA" else node.fileType.badgeLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = badgeColor,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
