package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.engine.ApkMergeEngine
import com.example.model.ApkAnalysisReport
import com.example.model.SplitModuleType
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.ColorArsc
import com.example.ui.theme.ColorAssets
import com.example.ui.theme.ColorDex
import com.example.ui.theme.ColorLib
import com.example.ui.theme.ColorOther
import com.example.ui.theme.ColorRes
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun HeroFileSelectionBanner(
    isAnalyzing: Boolean,
    onPickExternalArchive: () -> Unit,
    onGenerateSampleApks: () -> Unit,
    onGenerateSampleXapk: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, ObsidianBorder, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_compressor_1794099867774),
                contentDescription = stringResource(R.string.app_name),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(225.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(225.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0x88090D16),
                                Color(0xD9090D16),
                                Color(0xFF111827)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = EmeraldPrimary.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MergeType,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "ANTI-SPLIT • AXML PATCH • 4K STORED • 512KB STREAM",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = stringResource(R.string.merger_hero_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )

                Text(
                    text = stringResource(R.string.merger_hero_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onPickExternalArchive,
                    enabled = !isAnalyzing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("select_apk_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = Color(0xFF042F2E)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.select_apk_button),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onGenerateSampleApks,
                        enabled = !isAnalyzing,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("generate_sample_apk_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanSecondary.copy(alpha = 0.6f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = null,
                            tint = CyanSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.generate_sample_apks_button),
                            style = MaterialTheme.typography.bodySmall,
                            color = CyanSecondary,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    OutlinedButton(
                        onClick = onGenerateSampleXapk,
                        enabled = !isAnalyzing,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("generate_sample_game_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.6f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.generate_sample_game_button),
                            style = MaterialTheme.typography.bodySmall,
                            color = EmeraldPrimary,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ApkInspectorCard(
    isAnalyzing: Boolean,
    report: ApkAnalysisReport?,
    onOpenEntryExplorer: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, ObsidianBorder, RoundedCornerShape(20.dp))
            .testTag("apk_inspector_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianCardElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyanSecondary.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = null,
                            tint = CyanSecondary
                        )
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.section_apk_inspector),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = report?.sourceLabelAr ?: "جاري الفحص...",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                if (report != null) {
                    Surface(
                        color = ObsidianSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder),
                        modifier = Modifier
                            .clickable(onClick = onOpenEntryExplorer)
                            .testTag("open_entry_explorer_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "تصفح الملفات (${report.totalEntryCount})",
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            if (isAnalyzing) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        color = EmeraldPrimary,
                        modifier = Modifier.size(28.dp),
                        strokeWidth = 3.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "جاري فحص حزم base.apk و split_*.apk وتحليل AndroidManifest.xml...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            } else if (report != null) {
                // Archive Summary Card
                Surface(
                    color = ObsidianSurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ObsidianBorder.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Inventory2,
                                    contentDescription = null,
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = report.fileName,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Surface(
                                    color = EmeraldPrimary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "${report.discoveredSplits.size} Splits",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EmeraldPrimary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = ApkMergeEngine.formatBytesShort(report.originalFileSize),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily
                                ),
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        HorizontalDivider(color = ObsidianBorder.copy(alpha = 0.5f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            InspectorStatPill(
                                label = "الحزم الفرعية المكتشفة",
                                value = "${report.innerApkCount} APKs"
                            )
                            InspectorStatPill(
                                label = "إجمالي البيانات",
                                value = ApkMergeEngine.formatBytesShort(report.uncompressedTotalSize)
                            )
                            InspectorStatPill(
                                label = "حالة isSplitRequired",
                                value = if (report.manifestInspection.hasIsSplitRequiredTrue) {
                                    "true (سيتم تعطيلها)"
                                } else {
                                    "جاهز للدمج"
                                },
                                valueColor = if (report.manifestInspection.hasIsSplitRequiredTrue) {
                                    AmberTertiary
                                } else {
                                    EmeraldPrimary
                                }
                            )
                        }
                    }
                }

                // Discovered Split APKs List (base.apk + split_config.*.apk)
                if (report.discoveredSplits.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "الحزم المكتشفة داخل الأرشيف (${report.discoveredSplits.size}):",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        report.discoveredSplits.forEach { split ->
                            val badgeColor = when (split.moduleType) {
                                SplitModuleType.BASE -> EmeraldPrimary
                                SplitModuleType.ABI -> ColorLib
                                SplitModuleType.ASSET_PACK -> ColorAssets
                                SplitModuleType.DENSITY -> ColorRes
                                SplitModuleType.LANGUAGE -> CyanSecondary
                                SplitModuleType.FEATURE -> AmberTertiary
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(ObsidianSurface.copy(alpha = 0.8f))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        color = badgeColor.copy(alpha = 0.18f),
                                        shape = RoundedCornerShape(6.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor.copy(alpha = 0.5f))
                                    ) {
                                        Text(
                                            text = split.moduleType.shortTag,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = badgeColor,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = split.fileName,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${split.moduleType.labelAr} • ${split.entryCount} مدخل",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                                Text(
                                    text = ApkMergeEngine.formatBytesShort(split.compressedSize),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily
                                    ),
                                    color = badgeColor,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Binary Manifest Split Detection Banner
                if (report.manifestInspection.hasIsSplitRequiredTrue || report.manifestInspection.splitMetaDataNames.isNotEmpty()) {
                    Surface(
                        color = AmberTertiary.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberTertiary.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = AmberTertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "تم رصد قيود التقسيم داخل AndroidManifest.xml الثنائي (AXML):",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AmberTertiary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "السمة android:isSplitRequired=\"true\" نشطة، بالإضافة إلى وسوم (${
                                    report.manifestInspection.splitMetaDataNames.joinToString(", ").ifEmpty { "vending.splits" }
                                }). سيقوم المحرك بتحويلها إلى false وحذف وسوم التقسيم تلقائياً أثناء الدمج.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                        }
                    }
                }

                // Multi-segment proportion bar
                val bd = report.breakdown
                val totalComp = bd.totalCompressedBytes.toFloat()
                val segments = listOf(
                    Triple(bd.dexBytes, ColorDex, "DEX"),
                    Triple(bd.arscBytes, ColorArsc, "ARSC"),
                    Triple(bd.libBytes, ColorLib, "LIB"),
                    Triple(bd.resBytes, ColorRes, "RES"),
                    Triple(bd.assetsBytes, ColorAssets, "ASSETS"),
                    Triple(bd.otherBytes, ColorOther, "OTHER")
                ).filter { it.first > 0L }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "التوزيع الهيكلي للملفات المدمجة:",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White
                    )

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(14.dp)
                            .clip(RoundedCornerShape(50))
                            .background(ObsidianSurface)
                    ) {
                        var currentX = 0f
                        segments.forEach { (bytes, color, _) ->
                            val segWidth = (bytes.toFloat() / totalComp) * size.width
                            if (segWidth > 0f) {
                                drawRect(
                                    color = color,
                                    topLeft = Offset(currentX, 0f),
                                    size = Size(segWidth, size.height)
                                )
                                currentX += segWidth
                            }
                        }
                    }
                }

                // Category breakdown rows
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BreakdownCategoryRow(
                        title = stringResource(R.string.category_lib),
                        count = bd.libCount,
                        bytes = bd.libBytes,
                        totalBytes = bd.totalCompressedBytes,
                        dotColor = ColorLib
                    )
                    BreakdownCategoryRow(
                        title = stringResource(R.string.category_assets),
                        count = bd.assetsCount,
                        bytes = bd.assetsBytes,
                        totalBytes = bd.totalCompressedBytes,
                        dotColor = ColorAssets
                    )
                    BreakdownCategoryRow(
                        title = stringResource(R.string.category_res),
                        count = bd.resCount,
                        bytes = bd.resBytes,
                        totalBytes = bd.totalCompressedBytes,
                        dotColor = ColorRes
                    )
                    BreakdownCategoryRow(
                        title = stringResource(R.string.category_dex),
                        count = bd.dexCount,
                        bytes = bd.dexBytes,
                        totalBytes = bd.totalCompressedBytes,
                        dotColor = ColorDex
                    )
                    BreakdownCategoryRow(
                        title = stringResource(R.string.category_arsc),
                        count = bd.arscCount,
                        bytes = bd.arscBytes,
                        totalBytes = bd.totalCompressedBytes,
                        dotColor = ColorArsc
                    )
                }

                // Detected ABIs & Old Split Signatures footer
                AnimatedVisibility(visible = report.detectedAbis.isNotEmpty() || report.bloatAndSignatureFilesCount > 0) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        report.detectedAbis.forEach { abi ->
                            Surface(
                                color = ColorLib.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, ColorLib.copy(alpha = 0.45f))
                            ) {
                                Text(
                                    text = "ABI: $abi",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFDDD6FE),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (report.bloatAndSignatureFilesCount > 0) {
                            Surface(
                                color = AmberTertiary.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, AmberTertiary.copy(alpha = 0.45f))
                            ) {
                                Text(
                                    text = "تواقيع META-INF للحزم الفرعية: ${report.bloatAndSignatureFilesCount} (${ApkMergeEngine.formatBytesShort(report.bloatAndSignatureBytes)})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberTertiary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InspectorStatPill(
    label: String,
    value: String,
    valueColor: Color = Color.White
) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = valueColor,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun BreakdownCategoryRow(
    title: String,
    count: Int,
    bytes: Long,
    totalBytes: Long,
    dotColor: Color
) {
    val pct = if (totalBytes > 0) (bytes.toFloat() / totalBytes.toFloat() * 100f) else 0f
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ObsidianSurface.copy(alpha = 0.7f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "($count)",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = String.format(Locale.US, "%.1f%%", pct),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Text(
                text = ApkMergeEngine.formatBytesShort(bytes),
                style = MaterialTheme.typography.labelMedium,
                color = dotColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
