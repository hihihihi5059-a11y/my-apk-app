package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================================
// Modern Dark/Light Palette: Deep Navy & Glowing Cyan Accent
// ============================================================================

// Dark Mode - Deep Navy & Midnight Aesthetics
val DeepNavyBackground = Color(0xFF060B18)       // خلفية ليلية فائقة النقاء بلون الكحلي العميق
val DeepNavySurface = Color(0xFF0E1833)          // لون بطاقات الواجهة (Navy Surface)
val DeepNavySurfaceElevated = Color(0xFF16244A)  // بطاقات مرتفعة وألواح منبثقة
val DeepNavyBorder = Color(0xFF223666)           // إطارات هندسية دقيقة
val DeepNavyBorderGlow = Color(0xFF00E5FF)       // إطار مضيء مشع

// Cyan Accent - سماوي مضيء
val CyanAccent = Color(0xFF00E5FF)               // لون التمييز الأساسي المضيء
val CyanAccentGlow = Color(0xFF80F4FF)           // إشعاع سماوي شفاف
val CyanAccentContainer = Color(0xFF00333D)      // حاوية اللون السماوي
val OnCyanAccent = Color(0xFF001F26)             // نص داكن فوق اللون السماوي
val OnCyanAccentContainer = Color(0xFFB8F8FF)    // نص مشرق فوق حاوية السيان

// Light Mode - Clean Navy & Crisp White
val LightNavyBackground = Color(0xFFF4F7FD)      // خلفية فاتحة نظيفة مع مسحة كحلية
val LightNavySurface = Color(0xFFFFFFFF)         // سطح البطاقات ناصع البياض
val LightNavySurfaceElevated = Color(0xFFE9F0FA) // بطاقات بارزة خفيفة
val LightNavyBorder = Color(0xFFD4E0F2)          // إطارات ناعمة
val LightNavyPrimary = Color(0xFF0B214D)         // كحلي كلاسيكي عميق للنصوص والأزرار
val LightCyanAccent = Color(0xFF00A2B8)          // سيان متباين للشاشات الفاتحة
val LightOnCyanAccent = Color(0xFFFFFFFF)

// Status & Feedback Colors
val EmeraldSuccess = Color(0xFF00E676)           // أخضر زمردي للنجاح
val EmeraldSuccessContainer = Color(0xFF003818)  // حاوية النجاح الداكنة
val EmeraldSuccessLightContainer = Color(0xFFD7FBE6)
val OnEmeraldSuccess = Color(0xFF00240D)

val GoldWarning = Color(0xFFFFD54F)              // أصفر ذهبي للتحذيرات
val GoldWarningContainer = Color(0xFF3F2F00)
val GoldWarningLightContainer = Color(0xFFFFF7D6)

val CoralDanger = Color(0xFFFF5252)              // أحمر مرجاني للأخطاء
val CoralDangerContainer = Color(0xFF420E0E)
val CoralDangerLightContainer = Color(0xFFFFE5E5)
val OnCoralDanger = Color(0xFFFFFFFF)

// Typography & Contrast Tokens
val DarkTextPrimary = Color(0xFFF5F8FC)          // نصوص رئيسية ناصعة
val DarkTextSecondary = Color(0xFF9FB0CE)        // نصوص ثانوية متباينة
val DarkTextMuted = Color(0xFF65789A)            // نصوص باهتة وملاحظات

val LightTextPrimary = Color(0xFF0A162C)         // نصوص رئيسية داكنة للوضع الفاتح
val LightTextSecondary = Color(0xFF4A5D7E)       // نصوص ثانوية
val LightTextMuted = Color(0xFF8293B0)           // نصوص خفيفة

// ============================================================================
// Full Backwards Compatibility Aliases for Legacy Screens
// ============================================================================
val ObsidianBackground = DeepNavyBackground
val ObsidianSurface = DeepNavySurface
val ObsidianSurfaceVariant = DeepNavySurfaceElevated
val ObsidianCardElevated = DeepNavySurfaceElevated
val ObsidianBorder = DeepNavyBorder

val EmeraldPrimary = EmeraldSuccess
val EmeraldContainer = EmeraldSuccessContainer
val OnEmeraldContainer = Color(0xFFA7F3D0)

val CyanSecondary = CyanAccent
val CyanContainer = CyanAccentContainer
val OnCyanContainer = OnCyanAccentContainer

val AmberTertiary = GoldWarning
val AmberContainer = GoldWarningContainer
val OnAmberContainer = Color(0xFFFDE68A)

val CoralError = CoralDanger
val CoralErrorContainer = CoralDangerContainer

val ColorDex = EmeraldSuccess
val ColorArsc = CyanAccent
val ColorLib = Color(0xFF8B5CF6)
val ColorRes = GoldWarning
val ColorAssets = Color(0xFFEC4899)
val ColorOther = DarkTextSecondary

val CyberBackground = DeepNavyBackground
val CyberSurface = DeepNavySurface
val CyberSurfaceElevated = DeepNavySurfaceElevated
val CyberBorder = DeepNavyBorder
val NeonCyan = CyanAccent
val NeonCyanContainer = CyanAccentContainer
val OnNeonCyanContainer = OnCyanAccentContainer
val CyberTextPrimary = DarkTextPrimary
val CyberTextSecondary = DarkTextSecondary
val CyberTextMuted = DarkTextMuted
val TextPrimary = DarkTextPrimary
val TextSecondary = DarkTextSecondary
val TextMuted = DarkTextMuted
