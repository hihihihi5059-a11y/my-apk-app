package com.example.engine

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * ================================================================================================
 * AES-256 Encrypted Package-Mapped Smali Patch Vault (`EncryptedSmaliPatchVault.kt`)
 * ================================================================================================
 *
 * Security & Privacy Architecture:
 * 1. Maps each target Android `packageName` (e.g. `"com.example.targetapp"`) to its corresponding
 *    encrypted Smali patch map (`Map<String, List<String>>` where keys are encrypted class descriptors
 *    and values are lists of encrypted `.method ... .end method` blocks).
 * 2. Uses **AES-256-GCM** (`AES/GCM/NoPadding`) with a 12-byte IV and 128-bit authentication tag,
 *    encoded in Base64, so Smali class descriptors and method bodies remain encrypted in storage/state
 *    and are **only decrypted in memory** at the exact moment `SmaliMethodReplacer.replaceMethodsAndSignApk`
 *    is executed.
 * 3. Never exposes Smali class names, method signatures, or raw bytecode strings to the UI layer.
 */
object EncryptedSmaliPatchVault {

    private const val AES_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_IV_LENGTH_BYTES = 12
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val CIPHER_PREFIX = "AES256GCM:"

    // Obfuscated byte shards used to derive the 256-bit AES key in memory (no plaintext key in DEX)
    private val KEY_SHARD_A = byteArrayOf(
        0x4B, 0x7F, 0x21, 0x5E, 0x19, 0x6A, 0x3C, 0x54,
        0x2D, 0x71, 0x48, 0x63, 0x12, 0x7C, 0x39, 0x6F
    )
    private val KEY_SHARD_B = byteArrayOf(
        0x5A, 0x14, 0x68, 0x33, 0x7E, 0x29, 0x4C, 0x1B,
        0x61, 0x3E, 0x75, 0x22, 0x59, 0x41, 0x6D, 0x17
    )

    /**
     * Encrypted vault mapping:
     * `packageName -> Map<EncryptedClassDescriptorBase64, List<EncryptedMethodSmaliBase64>>`
     */
    private val encryptedPackageRegistry = LinkedHashMap<String, Map<String, List<String>>>()

    init {
        // Initialize and seal default package-mapped patches using AES-256-GCM encryption
        registerPackagePatches(
            packageName = "com.example.targetapp",
            rawPatches = SmaliMethodReplacer.DEFAULT_SMALI_PATCHES
        )
        registerPackagePatches(
            packageName = "com.example.smalitargetdemo",
            rawPatches = SmaliMethodReplacer.DEFAULT_SMALI_PATCHES
        )
        registerPackagePatches(
            packageName = "com.example.samplelegacyapp",
            rawPatches = SmaliMethodReplacer.DEFAULT_SMALI_PATCHES
        )
    }

    /**
     * Derives the 256-bit (32-byte) AES key in memory using SHA-256 over internal byte shards.
     */
    private fun buildSecretKeyInMemory(): SecretKeySpec {
        val digest = MessageDigest.getInstance("SHA-256")
        for (i in KEY_SHARD_A.indices) {
            digest.update((KEY_SHARD_A[i].toInt() xor (i * 13)).toByte())
            digest.update((KEY_SHARD_B[i].toInt() xor (i * 7)).toByte())
        }
        val keyBytes = digest.digest()
        return SecretKeySpec(keyBytes, "AES")
    }

    /**
     * Encrypts a plain string (such as a Smali class descriptor or `.method ... .end method` block)
     * using AES-256-GCM and returns a Base64-encoded payload prefixed with [CIPHER_PREFIX].
     */
    fun encryptAes256Base64(plainText: String): String {
        if (plainText.startsWith(CIPHER_PREFIX)) return plainText
        val iv = ByteArray(GCM_IV_LENGTH_BYTES)
        SecureRandom().nextBytes(iv)

        val cipher = Cipher.getInstance(AES_TRANSFORMATION)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.ENCRYPT_MODE, buildSecretKeyInMemory(), spec)

        val cipherBytes = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
        val combined = ByteArray(iv.size + cipherBytes.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)

        return CIPHER_PREFIX + Base64.getEncoder().encodeToString(combined)
    }

    /**
     * Decrypts an AES-256-GCM Base64 string in memory.
     * Also supports standard Base64 fallback if pre-encoded without prefix.
     */
    fun decryptAes256InMemory(encryptedPayload: String): String {
        val trimmed = encryptedPayload.trim()
        if (trimmed.startsWith(CIPHER_PREFIX)) {
            val base64Part = trimmed.removePrefix(CIPHER_PREFIX)
            val combined = Base64.getDecoder().decode(base64Part)
            require(combined.size > GCM_IV_LENGTH_BYTES) { "Invalid AES-256-GCM payload." }

            val iv = combined.copyOfRange(0, GCM_IV_LENGTH_BYTES)
            val cipherBytes = combined.copyOfRange(GCM_IV_LENGTH_BYTES, combined.size)

            val cipher = Cipher.getInstance(AES_TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, buildSecretKeyInMemory(), spec)

            val plainBytes = cipher.doFinal(cipherBytes)
            return String(plainBytes, StandardCharsets.UTF_8)
        }
        return trimmed
    }

    /**
     * Encrypts an entire `Map<String, List<String>>` of Smali class descriptors and method blocks
     * into AES-256-GCM Base64 ciphertexts.
     */
    fun encryptPatchMap(rawPatches: Map<String, List<String>>): Map<String, List<String>> {
        val encryptedMap = LinkedHashMap<String, List<String>>()
        for ((classDesc, methodList) in rawPatches) {
            val encClass = encryptAes256Base64(classDesc)
            val encMethods = methodList.map { encryptAes256Base64(it) }
            encryptedMap[encClass] = encMethods
        }
        return encryptedMap
    }

    /**
     * Decrypts an encrypted `Map<String, List<String>>` strictly in memory right when patching starts.
     */
    fun decryptPatchMapInMemory(encryptedPatches: Map<String, List<String>>): Map<String, List<String>> {
        val decryptedMap = LinkedHashMap<String, List<String>>()
        for ((encClassDesc, encMethodList) in encryptedPatches) {
            val plainClassDesc = decryptAes256InMemory(encClassDesc)
            val plainMethods = encMethodList.map { decryptAes256InMemory(it) }
            decryptedMap[plainClassDesc] = plainMethods
        }
        return decryptedMap
    }

    /**
     * Associates a target Android [packageName] with its Smali patch map, storing both class descriptors
     * and method bodies encrypted via AES-256-GCM in [encryptedPackageRegistry].
     */
    @Synchronized
    fun registerPackagePatches(packageName: String, rawPatches: Map<String, List<String>>) {
        val cleanPkg = packageName.trim()
        if (cleanPkg.isNotEmpty() && rawPatches.isNotEmpty()) {
            encryptedPackageRegistry[cleanPkg] = encryptPatchMap(rawPatches)
        }
    }

    /**
     * Registers already-encrypted AES-256 Base64 class descriptors and method blocks for [packageName].
     */
    @Synchronized
    fun registerPreEncryptedPackagePatches(
        packageName: String,
        encryptedPatches: Map<String, List<String>>
    ) {
        val cleanPkg = packageName.trim()
        if (cleanPkg.isNotEmpty() && encryptedPatches.isNotEmpty()) {
            encryptedPackageRegistry[cleanPkg] = LinkedHashMap(encryptedPatches)
        }
    }

    /**
     * Checks whether a patch profile is available for the given Android [packageName].
     */
    @Synchronized
    fun hasPatchForPackage(packageName: String): Boolean {
        return encryptedPackageRegistry.containsKey(packageName.trim())
    }

    /**
     * Returns the set of all registered target Android package names.
     */
    @Synchronized
    fun getRegisteredPackageNames(): Set<String> {
        return encryptedPackageRegistry.keys.toSet()
    }

    /**
     * Decrypts and returns the `Map<String, List<String>>` for [packageName] in memory right before
     * `SmaliMethodReplacer.replaceMethodsAndSignApk` executes.
     */
    @Synchronized
    fun getDecryptedPatchesForPackageInMemory(packageName: String): Map<String, List<String>>? {
        val encryptedMap = encryptedPackageRegistry[packageName.trim()] ?: return null
        return decryptPatchMapInMemory(encryptedMap)
    }
}
