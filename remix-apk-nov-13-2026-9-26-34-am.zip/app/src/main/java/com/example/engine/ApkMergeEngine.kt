package com.example.engine

import com.example.model.AbiFilterMode
import com.example.model.ApkAnalysisReport
import com.example.model.ApkEntryCategory
import com.example.model.ApkEntryInfo
import com.example.model.CategoryBreakdown
import com.example.model.DiscoveredSplitApk
import com.example.model.EntryComparisonItem
import com.example.model.ManifestPatchSummary
import com.example.model.ManifestSplitInspection
import com.example.model.MergeConfig
import com.example.model.MergePhase
import com.example.model.MergeResult
import com.example.model.ProcessingProgress
import com.example.model.SplitModuleType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Smart Game Merger Engine (Anti-Split & Universal APK Merger).
 *
 * Converts split game archives (.apks / .xapk) containing `base.apk` + multiple `split_*.apk`
 * modules (CPU architectures, screen densities, language packs, and asset packs) into a single
 * directly installable `Universal_Game.apk`:
 *
 * 1. **Archive Parsing**: Extracts `base.apk` and all `split_*.apk` files into a temporary Cache workspace
 *    using 512KB streaming buffers.
 * 2. **Smart Deep Merging**:
 *    - Merges `lib/<abi>/` `.so` native libraries from architecture splits into the base `lib/` tree.
 *    - Merges `assets/` files from asset packs (and `.obb` expansion files) into the base `assets/` tree.
 *    - Merges `res/` resources (images, layouts, drawables, strings) from density/language splits.
 * 3. **Binary Manifest Patching (AXML)**:
 *    - Parses binary `AndroidManifest.xml` (`0x00080003` AXML format).
 *    - Locates `android:isSplitRequired="true"` (`0x01010591`) and patches it to `false` (`0`), or strips
 *      `requiredSplitTypes` / `splitTypes`.
 *    - Removes `<meta-data>` elements referencing splits (`com.android.vending.splits`,
 *      `com.android.vending.splits.required`, `com.android.dynamic.apk.fused.modules`, etc.).
 * 4. **Universal Repackaging (`Universal_Game.apk`)**:
 *    - Strictly enforces `ZipEntry.STORED` + **4096-byte (4K) alignment** for `.so` native libraries,
 *      game engine files (`.pak`, `.obb`, `.assets`, `.resS`, `.ucas`, `.utoc`, `.bundle`, `.fsb`, `.bank`),
 *      and `resources.arsc`.
 *    - Completely strips the `META-INF/` signature directory to wipe old split signatures.
 * 5. **Memory-Safe 512KB Streaming**:
 *    - Uses `BufferedInputStream` and `BufferedOutputStream` with a 512KB (`131072 * 4 = 524,288` bytes)
 *      buffer so multi-gigabyte games never trigger `OutOfMemoryError`.
 */
object ApkMergeEngine {

    /**
     * Mandatory 512KB streaming buffer size (131072 * 4 = 524,288 bytes) to prevent OutOfMemoryError on 4GB+ games.
     */
    const val STREAM_BUFFER_SIZE = 131_072 * 4 // 524,288 bytes (512 KB)
    const val ALIGNMENT_4K = 4096L
    private const val MAX_REPORTED_ENTRIES = 60

    // Binary AndroidManifest.xml (AXML) Chunk Types & Resource IDs
    private const val RES_XML_TYPE = 0x0003
    private const val RES_STRING_POOL_TYPE = 0x0001
    private const val RES_XML_RESOURCE_MAP_TYPE = 0x0180
    private const val RES_XML_START_ELEMENT_TYPE = 0x0102
    private const val RES_XML_END_ELEMENT_TYPE = 0x0103

    private const val ATTR_ANDROID_NAME = 0x01010003
    private const val ATTR_ANDROID_VALUE = 0x01010024
    private const val ATTR_ANDROID_RESOURCE = 0x01010025
    private const val ATTR_ANDROID_EXTRACT_NATIVE_LIBS = 0x010104EA
    private const val ATTR_ANDROID_IS_SPLIT_REQUIRED = 0x01010591
    private const val ATTR_ANDROID_REQUIRED_SPLIT_TYPES = 0x0101064E
    private const val ATTR_ANDROID_SPLIT_TYPES = 0x0101064F

    private const val TYPE_INT_BOOLEAN = 0x12
    private const val UTF8_FLAG = 0x00000100

    private val GAME_ENGINE_STORED_EXTENSIONS = setOf(
        "pak", "obb", "assets", "ress", "resource",
        "ucas", "utoc", "bundle", "fsb", "bank", "wem", "pck"
    )

    private val KNOWN_ABIS = setOf(
        "arm64-v8a", "armeabi-v7a", "armeabi", "x86_64", "x86"
    )

    private val DENSITY_TOKENS = setOf(
        "ldpi", "mdpi", "tvdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"
    )

    enum class PackageArchiveType {
        APK,
        APKS,
        XAPK
    }

    /**
     * Tracks the exact byte offset written to the underlying OutputStream so we can compute
     * exact 4096-byte (4K) alignment padding for `ZipEntry.STORED` entries.
     */
    private class CountingOutputStream(out: OutputStream) : FilterOutputStream(out) {
        var bytesWritten: Long = 0L
            private set

        override fun write(b: Int) {
            out.write(b)
            bytesWritten += 1L
        }

        override fun write(b: ByteArray) {
            out.write(b)
            bytesWritten += b.size.toLong()
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            out.write(b, off, len)
            bytesWritten += len.toLong()
        }
    }

    fun detectArchiveType(file: File): PackageArchiveType {
        val ext = file.extension.lowercase(Locale.US)
        if (ext == "xapk") return PackageArchiveType.XAPK
        if (ext == "apks") return PackageArchiveType.APKS

        return try {
            ZipFile(file).use { zip ->
                var hasInnerApk = false
                var hasObbOrManifestJson = false
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val name = entries.nextElement().name.lowercase(Locale.US)
                    if (name.endsWith(".apk")) hasInnerApk = true
                    if (name.endsWith(".obb") || name == "manifest.json") hasObbOrManifestJson = true
                }
                when {
                    hasInnerApk && hasObbOrManifestJson -> PackageArchiveType.XAPK
                    hasInnerApk -> PackageArchiveType.APKS
                    else -> PackageArchiveType.APK
                }
            }
        } catch (_: Exception) {
            PackageArchiveType.APK
        }
    }

    /**
     * Classifies a split APK filename (e.g., `base.apk`, `split_config.arm64_v8a.apk`,
     * `split_config.xhdpi.apk`, `split_config.ar.apk`, `install_time_assets.apk`) into its [SplitModuleType].
     */
    fun classifySplitApkName(fileName: String): Pair<SplitModuleType, String?> {
        val clean = fileName.substringAfterLast('/').lowercase(Locale.US).removeSuffix(".apk")
        if (clean == "base" || clean == "base-master" || clean.endsWith("_base")) {
            return Pair(SplitModuleType.BASE, null)
        }
        if (clean.contains("arm64_v8a") || clean.contains("arm64-v8a")) {
            return Pair(SplitModuleType.ABI, "arm64-v8a")
        }
        if (clean.contains("armeabi_v7a") || clean.contains("armeabi-v7a")) {
            return Pair(SplitModuleType.ABI, "armeabi-v7a")
        }
        if (clean.contains("x86_64")) {
            return Pair(SplitModuleType.ABI, "x86_64")
        }
        if (clean.endsWith(".x86") || clean.contains("_x86")) {
            return Pair(SplitModuleType.ABI, "x86")
        }
        for (dpi in DENSITY_TOKENS) {
            if (clean.contains(".$dpi") || clean.contains("_$dpi")) {
                return Pair(SplitModuleType.DENSITY, null)
            }
        }
        if (clean.contains("asset") || clean.contains("pack") || clean.contains("main") || clean.contains("obb")) {
            return Pair(SplitModuleType.ASSET_PACK, null)
        }
        val afterConfig = clean.substringAfter("config.", "")
        if (afterConfig.length in 2..5 && afterConfig.all { it.isLetter() || it == '_' }) {
            return Pair(SplitModuleType.LANGUAGE, null)
        }
        return Pair(SplitModuleType.FEATURE, null)
    }

    /**
     * Returns true if the entry is a game engine container or native library that MUST be packed
     * as `ZipEntry.STORED` with 4096-byte (4K) alignment so the game engine can `mmap` it directly.
     */
    fun requiresStored4kAlignment(entryName: String, enforce4kConfig: Boolean = true): Boolean {
        if (!enforce4kConfig) return false
        val normalized = entryName.trimStart('/')
        val lower = normalized.lowercase(Locale.US)
        if (lower == "resources.arsc") return true
        if (lower.startsWith("lib/") && lower.endsWith(".so")) return true
        if (isGameEngineAsset(normalized)) return true
        return false
    }

    /**
     * Detects game engine files (.pak, .obb, .assets, .resS, .ucas, .utoc, .bundle, .fsb, .bank, Unity level0..N).
     */
    fun isGameEngineAsset(entryName: String): Boolean {
        val normalized = entryName.trimStart('/')
        val lower = normalized.lowercase(Locale.US)
        val ext = lower.substringAfterLast('.', "")
        if (ext in GAME_ENGINE_STORED_EXTENSIONS) return true
        if (lower.contains(".assets.split") || lower.contains(".ress.split") || lower.contains(".resource.split")) {
            return true
        }
        if (lower.startsWith("assets/bin/data/")) {
            val fileName = lower.substringAfterLast('/')
            if (fileName.startsWith("level") ||
                fileName.startsWith("sharedassets") ||
                fileName.startsWith("globalgamemanagers") ||
                fileName.startsWith("resources") ||
                fileName == "maindata"
            ) {
                return true
            }
        }
        return false
    }

    /**
     * Returns true if the entry belongs to the old split signature directory (`META-INF/`) that must be
     * wiped before Universal APK signing.
     */
    fun isMetaInfSignatureOrBloatEntry(entryName: String): Boolean {
        val normalized = entryName.trimStart('/')
        val lower = normalized.lowercase(Locale.US)
        if (lower.startsWith("meta-inf/")) {
            // Wipe all old split signatures, MANIFEST.MF, .SF, .RSA, .DSA, .EC, and stamp metadata
            if (lower == "meta-inf/" || !lower.startsWith("meta-inf/services/")) {
                return true
            }
        }
        if (lower.endsWith(".ds_store") || lower.endsWith("thumbs.db")) return true
        return false
    }

    fun categorizeEntry(entryName: String): ApkEntryCategory {
        val normalized = entryName.trimStart('/')
        val lower = normalized.lowercase(Locale.US)
        return when {
            lower.endsWith(".dex") && !lower.contains("/") -> ApkEntryCategory.DEX
            lower == "resources.arsc" -> ApkEntryCategory.ARSC
            lower.startsWith("lib/") && lower.endsWith(".so") -> ApkEntryCategory.LIB
            lower.startsWith("res/") -> ApkEntryCategory.RES
            lower.startsWith("assets/") || lower.endsWith(".obb") || lower.endsWith(".pak") -> ApkEntryCategory.ASSETS
            else -> ApkEntryCategory.OTHER
        }
    }

    fun extractAbiFromName(entryName: String): String? {
        val normalized = entryName.trimStart('/')
        if (!normalized.startsWith("lib/")) return null
        val parts = normalized.split('/')
        return if (parts.size >= 3) parts[1] else null
    }

    /**
     * Analyzes a `.apks`, `.xapk`, or `.apk` file to discover all inner split APKs (`base.apk` + `split_*.apk`),
     * architectures, entry categories, and Binary `AndroidManifest.xml` split attributes.
     */
    suspend fun analyzeArchive(
        archiveFile: File,
        displayFileName: String,
        sourceLabelAr: String
    ): ApkAnalysisReport = withContext(Dispatchers.IO) {
        val archiveType = detectArchiveType(archiveFile)
        if (archiveType == PackageArchiveType.APKS || archiveType == PackageArchiveType.XAPK) {
            analyzeSplitBundleArchive(archiveFile, displayFileName, sourceLabelAr)
        } else {
            analyzeSingleApkFile(archiveFile, displayFileName, sourceLabelAr)
        }
    }

    private suspend fun analyzeSplitBundleArchive(
        archiveFile: File,
        displayFileName: String,
        sourceLabelAr: String
    ): ApkAnalysisReport = withContext(Dispatchers.IO) {
        val tempDir = File(archiveFile.parentFile, "merge_inspect_${System.nanoTime()}").apply { mkdirs() }
        val buffer = ByteArray(STREAM_BUFFER_SIZE)
        try {
            var dexBytes = 0L
            var arscBytes = 0L
            var libBytes = 0L
            var resBytes = 0L
            var assetsBytes = 0L
            var otherBytes = 0L

            var dexCount = 0
            var arscCount = 0
            var libCount = 0
            var resCount = 0
            var assetsCount = 0
            var otherCount = 0

            val detectedAbis = linkedSetOf<String>()
            var metaInfCount = 0
            var metaInfBytes = 0L
            var aligned4kStoredCount = 0
            var totalStoredCount = 0
            var uncompressedTotalSize = 0L
            var totalEntriesCount = 0
            var innerApkCount = 0
            val discoveredSplits = ArrayList<DiscoveredSplitApk>()
            val entryList = ArrayList<ApkEntryInfo>(256)
            var manifestInspection = ManifestSplitInspection()

            ZipFile(archiveFile).use { bundleZip ->
                val entries = bundleZip.entries()
                while (entries.hasMoreElements()) {
                    currentCoroutineContext().ensureActive()
                    val outerEntry = entries.nextElement()
                    if (outerEntry.isDirectory) continue

                    val outerName = outerEntry.name.trimStart('/')
                    val lowerOuter = outerName.lowercase(Locale.US)

                    if (lowerOuter.endsWith(".apk")) {
                        innerApkCount++
                        val shortApkName = outerName.substringAfterLast('/')
                        val tempInnerApk = File(tempDir, "inspect_${innerApkCount}_$shortApkName")
                        try {
                            BufferedInputStream(bundleZip.getInputStream(outerEntry), STREAM_BUFFER_SIZE).use { input ->
                                BufferedOutputStream(FileOutputStream(tempInnerApk), STREAM_BUFFER_SIZE).use { output ->
                                    var r: Int
                                    while (input.read(buffer).also { r = it } != -1) {
                                        currentCoroutineContext().ensureActive()
                                        output.write(buffer, 0, r)
                                    }
                                }
                            }

                            val (splitType, splitAbiHint) = classifySplitApkName(shortApkName)
                            if (splitAbiHint != null) {
                                detectedAbis.add(splitAbiHint)
                            }

                            var splitUncompressed = 0L
                            var splitEntries = 0
                            var splitDetectedAbi: String? = splitAbiHint

                            val subReport = analyzeSingleApkFile(tempInnerApk, shortApkName, shortApkName)
                            if (splitType == SplitModuleType.BASE || shortApkName.equals("base.apk", ignoreCase = true)) {
                                manifestInspection = subReport.manifestInspection
                            }

                            dexBytes += subReport.breakdown.dexBytes
                            arscBytes += subReport.breakdown.arscBytes
                            libBytes += subReport.breakdown.libBytes
                            resBytes += subReport.breakdown.resBytes
                            assetsBytes += subReport.breakdown.assetsBytes
                            otherBytes += subReport.breakdown.otherBytes

                            dexCount += subReport.breakdown.dexCount
                            arscCount += subReport.breakdown.arscCount
                            libCount += subReport.breakdown.libCount
                            resCount += subReport.breakdown.resCount
                            assetsCount += subReport.breakdown.assetsCount
                            otherCount += subReport.breakdown.otherCount

                            detectedAbis.addAll(subReport.detectedAbis)
                            if (splitDetectedAbi == null && subReport.detectedAbis.isNotEmpty()) {
                                splitDetectedAbi = subReport.detectedAbis.first()
                            }

                            metaInfCount += subReport.bloatAndSignatureFilesCount
                            metaInfBytes += subReport.bloatAndSignatureBytes
                            aligned4kStoredCount += subReport.aligned4kStoredCount
                            totalStoredCount += subReport.totalStoredCount
                            uncompressedTotalSize += subReport.uncompressedTotalSize
                            totalEntriesCount += subReport.totalEntryCount
                            splitUncompressed = subReport.uncompressedTotalSize
                            splitEntries = subReport.totalEntryCount

                            val resolvedModuleType = when {
                                splitType != SplitModuleType.FEATURE -> splitType
                                subReport.breakdown.libCount > 0 && subReport.breakdown.dexCount == 0 -> SplitModuleType.ABI
                                subReport.breakdown.assetsCount > 0 && subReport.breakdown.dexCount == 0 -> SplitModuleType.ASSET_PACK
                                subReport.breakdown.resCount > 0 && subReport.breakdown.dexCount == 0 -> SplitModuleType.DENSITY
                                else -> splitType
                            }

                            discoveredSplits.add(
                                DiscoveredSplitApk(
                                    fileName = shortApkName,
                                    moduleType = resolvedModuleType,
                                    compressedSize = tempInnerApk.length(),
                                    uncompressedSize = splitUncompressed,
                                    entryCount = splitEntries,
                                    detectedAbi = splitDetectedAbi
                                )
                            )

                            for (subEntry in subReport.entries) {
                                if (entryList.size < 250) {
                                    entryList.add(subEntry.copy(sourceApkName = shortApkName))
                                }
                            }
                        } finally {
                            tempInnerApk.delete()
                        }
                    } else if (lowerOuter.endsWith(".obb") || isGameEngineAsset(outerName)) {
                        val compSize = if (outerEntry.compressedSize >= 0) outerEntry.compressedSize else outerEntry.size.coerceAtLeast(0L)
                        val uncompSize = if (outerEntry.size >= 0) outerEntry.size else compSize
                        assetsBytes += compSize
                        assetsCount++
                        uncompressedTotalSize += uncompSize
                        totalEntriesCount++

                        discoveredSplits.add(
                            DiscoveredSplitApk(
                                fileName = outerName.substringAfterLast('/'),
                                moduleType = SplitModuleType.ASSET_PACK,
                                compressedSize = compSize,
                                uncompressedSize = uncompSize,
                                entryCount = 1,
                                detectedAbi = null
                            )
                        )

                        if (entryList.size < 250) {
                            entryList.add(
                                ApkEntryInfo(
                                    name = outerName,
                                    sourceApkName = "OBB / Expansion",
                                    compressedSize = compSize,
                                    uncompressedSize = uncompSize,
                                    method = outerEntry.method,
                                    crc = outerEntry.crc,
                                    dataOffset = 0L,
                                    is4kAligned = outerEntry.method == ZipEntry.STORED,
                                    category = ApkEntryCategory.ASSETS
                                )
                            )
                        }
                    }
                }
            }

            discoveredSplits.sortBy { split ->
                when (split.moduleType) {
                    SplitModuleType.BASE -> 0
                    SplitModuleType.ABI -> 1
                    SplitModuleType.ASSET_PACK -> 2
                    SplitModuleType.DENSITY -> 3
                    SplitModuleType.LANGUAGE -> 4
                    SplitModuleType.FEATURE -> 5
                }
            }

            entryList.sortByDescending { it.uncompressedSize }

            ApkAnalysisReport(
                fileName = displayFileName,
                sourceLabelAr = sourceLabelAr,
                sourceFilePath = archiveFile.absolutePath,
                originalFileSize = archiveFile.length(),
                totalEntryCount = totalEntriesCount,
                uncompressedTotalSize = uncompressedTotalSize,
                breakdown = CategoryBreakdown(
                    dexBytes = dexBytes,
                    arscBytes = arscBytes,
                    libBytes = libBytes,
                    resBytes = resBytes,
                    assetsBytes = assetsBytes,
                    otherBytes = otherBytes,
                    dexCount = dexCount,
                    arscCount = arscCount,
                    libCount = libCount,
                    resCount = resCount,
                    assetsCount = assetsCount,
                    otherCount = otherCount
                ),
                detectedAbis = detectedAbis.toList(),
                bloatAndSignatureFilesCount = metaInfCount,
                bloatAndSignatureBytes = metaInfBytes,
                aligned4kStoredCount = aligned4kStoredCount,
                totalStoredCount = totalStoredCount,
                entries = entryList,
                isSplitArchive = true,
                innerApkCount = innerApkCount,
                discoveredSplits = discoveredSplits,
                manifestInspection = manifestInspection
            )
        } finally {
            tempDir.deleteRecursively()
        }
    }

    private suspend fun analyzeSingleApkFile(
        apkFile: File,
        displayFileName: String,
        sourceLabelAr: String
    ): ApkAnalysisReport = withContext(Dispatchers.IO) {
        val localOffsets = parseLocalHeaderDataOffsets(apkFile)

        var dexBytes = 0L
        var arscBytes = 0L
        var libBytes = 0L
        var resBytes = 0L
        var assetsBytes = 0L
        var otherBytes = 0L

        var dexCount = 0
        var arscCount = 0
        var libCount = 0
        var resCount = 0
        var assetsCount = 0
        var otherCount = 0

        val detectedAbis = linkedSetOf<String>()
        var metaInfCount = 0
        var metaInfBytes = 0L
        var aligned4kStoredCount = 0
        var totalStoredCount = 0
        var uncompressedTotalSize = 0L
        var totalEntriesCount = 0
        var manifestInspection = ManifestSplitInspection()

        val entryList = ArrayList<ApkEntryInfo>(256)

        ZipFile(apkFile).use { zip ->
            val manifestEntry = zip.getEntry("AndroidManifest.xml")
            if (manifestEntry != null && manifestEntry.size in 1..(2 * 1024 * 1024)) {
                val manifestBytes = zip.getInputStream(manifestEntry).readBytes()
                manifestInspection = inspectBinaryAndroidManifest(manifestBytes)
            }

            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                currentCoroutineContext().ensureActive()
                val entry = entries.nextElement()
                if (entry.isDirectory) continue

                totalEntriesCount++
                val name = entry.name
                val compSize = if (entry.compressedSize >= 0) entry.compressedSize else entry.size.coerceAtLeast(0L)
                val uncompSize = if (entry.size >= 0) entry.size else compSize
                uncompressedTotalSize += uncompSize

                val category = categorizeEntry(name)
                val abi = extractAbiFromName(name)
                if (abi != null && abi in KNOWN_ABIS) {
                    detectedAbis.add(abi)
                }

                if (isMetaInfSignatureOrBloatEntry(name)) {
                    metaInfCount++
                    metaInfBytes += compSize
                }

                val dataOffset = localOffsets[name] ?: -1L
                val isStored = entry.method == ZipEntry.STORED
                val is4k = isStored && dataOffset > 0L && (dataOffset % ALIGNMENT_4K == 0L)
                if (isStored) {
                    totalStoredCount++
                    if (is4k) aligned4kStoredCount++
                }

                when (category) {
                    ApkEntryCategory.DEX -> {
                        dexBytes += compSize
                        dexCount++
                    }
                    ApkEntryCategory.ARSC -> {
                        arscBytes += compSize
                        arscCount++
                    }
                    ApkEntryCategory.LIB -> {
                        libBytes += compSize
                        libCount++
                    }
                    ApkEntryCategory.RES -> {
                        resBytes += compSize
                        resCount++
                    }
                    ApkEntryCategory.ASSETS -> {
                        assetsBytes += compSize
                        assetsCount++
                    }
                    ApkEntryCategory.OTHER -> {
                        otherBytes += compSize
                        otherCount++
                    }
                }

                if (entryList.size < 250) {
                    entryList.add(
                        ApkEntryInfo(
                            name = name,
                            sourceApkName = displayFileName,
                            compressedSize = compSize,
                            uncompressedSize = uncompSize,
                            method = entry.method,
                            crc = entry.crc,
                            dataOffset = dataOffset,
                            is4kAligned = is4k,
                            category = category,
                            abi = abi
                        )
                    )
                }
            }
        }

        entryList.sortByDescending { it.uncompressedSize }

        ApkAnalysisReport(
            fileName = displayFileName,
            sourceLabelAr = sourceLabelAr,
            sourceFilePath = apkFile.absolutePath,
            originalFileSize = apkFile.length(),
            totalEntryCount = totalEntriesCount,
            uncompressedTotalSize = uncompressedTotalSize,
            breakdown = CategoryBreakdown(
                dexBytes = dexBytes,
                arscBytes = arscBytes,
                libBytes = libBytes,
                resBytes = resBytes,
                assetsBytes = assetsBytes,
                otherBytes = otherBytes,
                dexCount = dexCount,
                arscCount = arscCount,
                libCount = libCount,
                resCount = resCount,
                assetsCount = assetsCount,
                otherCount = otherCount
            ),
            detectedAbis = detectedAbis.toList(),
            bloatAndSignatureFilesCount = metaInfCount,
            bloatAndSignatureBytes = metaInfBytes,
            aligned4kStoredCount = aligned4kStoredCount,
            totalStoredCount = totalStoredCount,
            entries = entryList,
            isSplitArchive = false,
            innerApkCount = 1,
            discoveredSplits = listOf(
                DiscoveredSplitApk(
                    fileName = displayFileName,
                    moduleType = SplitModuleType.BASE,
                    compressedSize = apkFile.length(),
                    uncompressedSize = uncompressedTotalSize,
                    entryCount = totalEntriesCount,
                    detectedAbi = detectedAbis.firstOrNull()
                )
            ),
            manifestInspection = manifestInspection
        )
    }

    // ============================================================================================
    // CORE SMART GAME MERGER PIPELINE (Coroutines on Dispatchers.IO + 512KB Streaming)
    // ============================================================================================

    /**
     * Merges a split game archive (`.apks` or `.xapk` containing `base.apk` + `split_*.apk` + `.obb`)
     * or a standalone split-configured `.apk` into a single, directly installable `Universal_Game.apk`.
     *
     * Uses `BufferedInputStream` and `BufferedOutputStream` with a 512KB (`131072 * 4 = 524,288` bytes)
     * buffer on `Dispatchers.IO` so multi-gigabyte games never load into RAM.
     */
    suspend fun mergeSplitGameToUniversalApk(
        sourceArchiveFile: File,
        outputUniversalApkFile: File,
        config: MergeConfig = MergeConfig(),
        onProgress: (ProcessingProgress) -> Unit
    ): MergeResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val workspaceDir = File(
            outputUniversalApkFile.parentFile ?: sourceArchiveFile.parentFile,
            "universal_merge_cache_${System.nanoTime()}"
        ).apply { mkdirs() }

        val liveLogs = ArrayDeque<String>(64)
        fun appendLog(msg: String) {
            if (liveLogs.size >= 50) liveLogs.removeFirst()
            liveLogs.addLast(msg)
        }

        // Single reusable 512KB (524,288 bytes) streaming buffer
        val streamBuffer = ByteArray(STREAM_BUFFER_SIZE)

        try {
            // ------------------------------------------------------------------------------------
            // PHASE 1: ARCHIVE PARSING & EXTRACTION TO CACHE DIRECTORY
            // ------------------------------------------------------------------------------------
            appendLog("📦 [Phase 1] Extracting split archive (${sourceArchiveFile.name}) using 512KB streaming buffer...")
            onProgress(
                ProcessingProgress(
                    isRunning = true,
                    currentPhase = MergePhase.EXTRACTING_ARCHIVE,
                    currentPhaseTitle = MergePhase.EXTRACTING_ARCHIVE.titleEn,
                    currentEntryName = sourceArchiveFile.name,
                    currentActionTag = "EXTRACT 512KB",
                    liveLogs = liveLogs.toList()
                )
            )

            val extractedApks = ArrayList<Pair<String, File>>()
            val extractedObbFiles = ArrayList<Pair<String, File>>()
            val archiveType = detectArchiveType(sourceArchiveFile)

            if (archiveType == PackageArchiveType.APKS || archiveType == PackageArchiveType.XAPK) {
                ZipFile(sourceArchiveFile).use { bundleZip ->
                    val entries = bundleZip.entries()
                    var index = 0
                    while (entries.hasMoreElements()) {
                        currentCoroutineContext().ensureActive()
                        val entry = entries.nextElement()
                        if (entry.isDirectory) continue

                        val cleanName = entry.name.trimStart('/')
                        val lower = cleanName.lowercase(Locale.US)
                        val shortName = cleanName.substringAfterLast('/')

                        if (lower.endsWith(".apk")) {
                            val (_, splitAbi) = classifySplitApkName(shortName)
                            if (config.abiFilterMode.targetAbi != null &&
                                splitAbi != null &&
                                splitAbi != config.abiFilterMode.targetAbi
                            ) {
                                appendLog("⏭️ Skipping ABI Split APK ($shortName) due to filter: ${config.abiFilterMode.targetAbi}")
                                continue
                            }

                            index++
                            val extractedApkFile = File(workspaceDir, "split_${index}_$shortName")
                            BufferedInputStream(bundleZip.getInputStream(entry), STREAM_BUFFER_SIZE).use { input ->
                                BufferedOutputStream(FileOutputStream(extractedApkFile), STREAM_BUFFER_SIZE).use { output ->
                                    var r: Int
                                    while (input.read(streamBuffer).also { r = it } != -1) {
                                        currentCoroutineContext().ensureActive()
                                        output.write(streamBuffer, 0, r)
                                    }
                                }
                            }
                            extractedApks.add(Pair(shortName, extractedApkFile))
                            appendLog("✓ Extracted split module: $shortName (${formatBytesShort(extractedApkFile.length())})")
                        } else if (config.mergeObbIntoAssets && (lower.endsWith(".obb") || isGameEngineAsset(cleanName))) {
                            index++
                            val extractedObb = File(workspaceDir, "obb_${index}_$shortName")
                            BufferedInputStream(bundleZip.getInputStream(entry), STREAM_BUFFER_SIZE).use { input ->
                                BufferedOutputStream(FileOutputStream(extractedObb), STREAM_BUFFER_SIZE).use { output ->
                                    var r: Int
                                    while (input.read(streamBuffer).also { r = it } != -1) {
                                        currentCoroutineContext().ensureActive()
                                        output.write(streamBuffer, 0, r)
                                    }
                                }
                            }
                            val targetAssetPath = if (lower.startsWith("assets/")) {
                                cleanName
                            } else if (lower.endsWith(".obb")) {
                                "assets/obb/$shortName"
                            } else {
                                "assets/$shortName"
                            }
                            extractedObbFiles.add(Pair(targetAssetPath, extractedObb))
                            appendLog("🎮 Extracted game expansion container: $shortName -> $targetAssetPath")
                        }
                    }
                }
            } else {
                // Standalone APK passed directly
                extractedApks.add(Pair(sourceArchiveFile.name, sourceArchiveFile))
                appendLog("✓ Loaded standalone APK for Universal Anti-Split normalization: ${sourceArchiveFile.name}")
            }

            if (extractedApks.isEmpty()) {
                throw IllegalStateException("No valid base.apk or split_*.apk files found inside ${sourceArchiveFile.name}")
            }

            // Identify base.apk vs split_*.apk modules
            // Sort so base.apk is first, followed by ABI splits, Asset Packs, Density splits, Language splits, Feature splits
            extractedApks.sortBy { (name, file) ->
                val (type, _) = classifySplitApkName(name)
                when {
                    name.equals("base.apk", ignoreCase = true) || name.equals("base-master.apk", ignoreCase = true) -> 0
                    type == SplitModuleType.BASE -> 1
                    type == SplitModuleType.ABI -> 2
                    type == SplitModuleType.ASSET_PACK -> 3
                    type == SplitModuleType.DENSITY -> 4
                    type == SplitModuleType.LANGUAGE -> 5
                    else -> 6
                }
            }

            // If no file was explicitly named base.apk, pick the one containing AndroidManifest.xml + classes.dex + resources.arsc
            val baseIndex = extractedApks.indexOfFirst { (name, file) ->
                name.equals("base.apk", ignoreCase = true) || hasClassesDexAndManifest(file)
            }.coerceAtLeast(0)
            if (baseIndex > 0) {
                val basePair = extractedApks.removeAt(baseIndex)
                extractedApks.add(0, basePair)
            }

            val baseApkPair = extractedApks.first()
            val splitApkPairs = extractedApks.drop(1)
            appendLog("🎯 Identified Base APK: ${baseApkPair.first} + ${splitApkPairs.size} Split APKs")

            // Pre-scan total entries & uncompressed bytes across base + splits + OBBs for accurate progress bar
            var totalEntriesToProcess = extractedObbFiles.size
            var totalBytesToProcess = extractedObbFiles.sumOf { it.second.length() }
            for ((_, apkFile) in extractedApks) {
                ZipFile(apkFile).use { zip ->
                    val e = zip.entries()
                    while (e.hasMoreElements()) {
                        val ze = e.nextElement()
                        if (!ze.isDirectory) {
                            totalEntriesToProcess++
                            totalBytesToProcess += ze.size.coerceAtLeast(0L)
                        }
                    }
                }
            }

            // ------------------------------------------------------------------------------------
            // PHASE 2: BINARY MANIFEST PATCHING (base.apk AndroidManifest.xml)
            // ------------------------------------------------------------------------------------
            onProgress(
                ProcessingProgress(
                    isRunning = true,
                    currentPhase = MergePhase.PATCHING_MANIFEST,
                    currentPhaseTitle = MergePhase.PATCHING_MANIFEST.titleEn,
                    currentInnerApkName = baseApkPair.first,
                    currentEntryName = "AndroidManifest.xml",
                    currentActionTag = "AXML PATCH",
                    totalEntries = totalEntriesToProcess,
                    totalBytes = totalBytesToProcess,
                    liveLogs = liveLogs.toList()
                )
            )

            var patchedManifestBytes: ByteArray? = null
            var manifestPatchSummary = ManifestPatchSummary()

            ZipFile(baseApkPair.second).use { baseZip ->
                val manifestEntry = baseZip.getEntry("AndroidManifest.xml")
                if (manifestEntry != null) {
                    val rawManifest = baseZip.getInputStream(manifestEntry).readBytes()
                    if (config.patchBinaryManifest) {
                        val (patched, summary) = patchBinaryAndroidManifest(
                            manifestBytes = rawManifest,
                            setExtractNativeLibsFalse = config.enforce4kAlignmentForSoAndGameAssets
                        )
                        patchedManifestBytes = patched
                        manifestPatchSummary = summary
                        appendLog(
                            "🛡️ Patched Binary AndroidManifest.xml: isSplitRequired=false (${summary.isSplitRequiredSetToFalse}), " +
                                "Removed ${summary.removedSplitMetaDataTags.size} split <meta-data> tags"
                        )
                    } else {
                        patchedManifestBytes = rawManifest
                        manifestPatchSummary = ManifestPatchSummary(
                            wasManifestPatched = false,
                            originalManifestBytes = rawManifest.size,
                            patchedManifestBytes = rawManifest.size
                        )
                    }
                }
            }

            // ------------------------------------------------------------------------------------
            // PHASE 3..6: UNIVERSAL APK REPACKAGING & SMART DEEP MERGING (512KB STREAMING)
            // ------------------------------------------------------------------------------------
            if (outputUniversalApkFile.exists()) {
                outputUniversalApkFile.delete()
            }

            val writtenEntryNames = HashSet<String>(totalEntriesToProcess * 2)
            var nextDexIndex = 1
            var processedEntries = 0
            var processedBytes = 0L

            var mergedNativeLibsCount = 0
            var mergedAssetsCount = 0
            var mergedResourcesCount = 0
            var mergedDexCount = 0
            var stored4kAlignedCount = 0
            var deflatedEntryCount = 0
            var strippedMetaInfCount = 0
            val comparisons = ArrayList<EntryComparisonItem>(MAX_REPORTED_ENTRIES * 2)

            FileOutputStream(outputUniversalApkFile).use { fos ->
                val bufferedOut = BufferedOutputStream(fos, STREAM_BUFFER_SIZE)
                val countingOut = CountingOutputStream(bufferedOut)
                ZipOutputStream(countingOut).use { zos ->
                    zos.setLevel(Deflater.DEFAULT_COMPRESSION)

                    // Helper to emit live progress updates
                    fun reportProgress(
                        phase: MergePhase,
                        innerApkName: String,
                        entryName: String,
                        actionTag: String
                    ) {
                        onProgress(
                            ProcessingProgress(
                                isRunning = true,
                                currentPhase = phase,
                                currentPhaseTitle = phase.titleEn,
                                currentInnerApkName = innerApkName,
                                currentEntryName = entryName,
                                currentActionTag = actionTag,
                                processedEntries = processedEntries,
                                totalEntries = totalEntriesToProcess.coerceAtLeast(processedEntries),
                                processedBytes = processedBytes,
                                totalBytes = totalBytesToProcess.coerceAtLeast(processedBytes),
                                alignedEntriesSoFar = stored4kAlignedCount,
                                mergedLibsSoFar = mergedNativeLibsCount,
                                mergedAssetsSoFar = mergedAssetsCount,
                                mergedResSoFar = mergedResourcesCount,
                                strippedMetaInfSoFar = strippedMetaInfCount,
                                bufferSizeKb = STREAM_BUFFER_SIZE / 1024,
                                liveLogs = liveLogs.toList()
                            )
                        )
                    }

                    // 1. Write patched binary AndroidManifest.xml first
                    if (patchedManifestBytes != null) {
                        val manifestData = patchedManifestBytes!!
                        val outEntry = ZipEntry("AndroidManifest.xml").apply {
                            method = ZipEntry.DEFLATED
                            extra = null
                            comment = null
                        }
                        val beforeOffset = countingOut.bytesWritten
                        zos.putNextEntry(outEntry)
                        zos.flush()
                        val dataStartOffset = countingOut.bytesWritten
                        zos.write(manifestData)
                        zos.closeEntry()
                        zos.flush()

                        writtenEntryNames.add("AndroidManifest.xml")
                        deflatedEntryCount++
                        processedEntries++
                        processedBytes += manifestData.size.toLong()

                        comparisons.add(
                            EntryComparisonItem(
                                name = "AndroidManifest.xml",
                                sourceSplitName = baseApkPair.first,
                                category = ApkEntryCategory.OTHER,
                                uncompressedSize = manifestData.size.toLong(),
                                newMethod = ZipEntry.DEFLATED,
                                dataOffset = dataStartOffset,
                                is4kAligned = false,
                                mergeBadge = if (manifestPatchSummary.wasManifestPatched) {
                                    "Patched (isSplitRequired=false)"
                                } else {
                                    "Base Manifest"
                                }
                            )
                        )
                    }

                    // Helper to stream a single ZipEntry from a source ZipFile intoUniversal_Game.apk
                    suspend fun streamZipEntryIntoUniversal(
                        sourceZip: ZipFile,
                        sourceApkLabel: String,
                        sourceEntry: ZipEntry,
                        targetEntryName: String,
                        phase: MergePhase,
                        badge: String?
                    ) {
                        currentCoroutineContext().ensureActive()
                        val category = categorizeEntry(targetEntryName)
                        val enforceStored4k = requiresStored4kAlignment(
                            entryName = targetEntryName,
                            enforce4kConfig = config.enforce4kAlignmentForSoAndGameAssets
                        )

                        var rawSize = sourceEntry.size
                        var entryCrc = sourceEntry.crc

                        // For STORED + 4K alignment, ZipOutputStream requires size and crc upfront.
                        // If missing on the source entry, compute them by streaming once with the 512KB buffer (0 MB heap).
                        if (enforceStored4k && (rawSize < 0L || entryCrc < 0L)) {
                            val crcCalc = CRC32()
                            var counted = 0L
                            BufferedInputStream(sourceZip.getInputStream(sourceEntry), STREAM_BUFFER_SIZE).use { input ->
                                var r: Int
                                while (input.read(streamBuffer).also { r = it } != -1) {
                                    currentCoroutineContext().ensureActive()
                                    crcCalc.update(streamBuffer, 0, r)
                                    counted += r.toLong()
                                }
                            }
                            rawSize = counted
                            entryCrc = crcCalc.value
                        }

                        val outEntry = ZipEntry(targetEntryName)
                        outEntry.comment = null
                        val actualDataStartOffset: Long
                        val isEntry4kAligned: Boolean

                        if (enforceStored4k) {
                            outEntry.method = ZipEntry.STORED
                            outEntry.size = rawSize
                            outEntry.compressedSize = rawSize
                            outEntry.crc = entryCrc

                            zos.flush()
                            val currentOffset = countingOut.bytesWritten
                            val nameBytesLen = targetEntryName.toByteArray(Charsets.UTF_8).size
                            val baseHeaderEnd = currentOffset + 30L + nameBytesLen.toLong()
                            val padBytes = ((ALIGNMENT_4K - (baseHeaderEnd % ALIGNMENT_4K)) % ALIGNMENT_4K).toInt()
                            outEntry.extra = if (padBytes > 0) ByteArray(padBytes) else null

                            zos.putNextEntry(outEntry)
                            zos.flush()
                            actualDataStartOffset = countingOut.bytesWritten

                            BufferedInputStream(sourceZip.getInputStream(sourceEntry), STREAM_BUFFER_SIZE).use { input ->
                                var r: Int
                                while (input.read(streamBuffer).also { r = it } != -1) {
                                    currentCoroutineContext().ensureActive()
                                    zos.write(streamBuffer, 0, r)
                                }
                            }
                            zos.closeEntry()
                            zos.flush()

                            isEntry4kAligned = (actualDataStartOffset % ALIGNMENT_4K == 0L)
                            if (isEntry4kAligned) {
                                stored4kAlignedCount++
                            }
                        } else {
                            outEntry.method = ZipEntry.DEFLATED
                            outEntry.extra = null

                            zos.flush()
                            zos.putNextEntry(outEntry)
                            zos.flush()
                            actualDataStartOffset = countingOut.bytesWritten

                            var streamedBytes = 0L
                            BufferedInputStream(sourceZip.getInputStream(sourceEntry), STREAM_BUFFER_SIZE).use { input ->
                                var r: Int
                                while (input.read(streamBuffer).also { r = it } != -1) {
                                    currentCoroutineContext().ensureActive()
                                    zos.write(streamBuffer, 0, r)
                                    streamedBytes += r.toLong()
                                }
                            }
                            zos.closeEntry()
                            zos.flush()
                            if (rawSize < 0L) rawSize = streamedBytes
                            isEntry4kAligned = false
                            deflatedEntryCount++
                        }

                        writtenEntryNames.add(targetEntryName)
                        processedEntries++
                        processedBytes += rawSize.coerceAtLeast(0L)

                        when (category) {
                            ApkEntryCategory.LIB -> mergedNativeLibsCount++
                            ApkEntryCategory.ASSETS -> mergedAssetsCount++
                            ApkEntryCategory.RES -> mergedResourcesCount++
                            ApkEntryCategory.DEX -> mergedDexCount++
                            else -> {}
                        }

                        if (comparisons.size < MAX_REPORTED_ENTRIES * 2) {
                            comparisons.add(
                                EntryComparisonItem(
                                    name = targetEntryName,
                                    sourceSplitName = sourceApkLabel,
                                    category = category,
                                    uncompressedSize = rawSize.coerceAtLeast(0L),
                                    newMethod = outEntry.method,
                                    dataOffset = actualDataStartOffset,
                                    is4kAligned = isEntry4kAligned,
                                    mergeBadge = badge
                                )
                            )
                        }

                        if (processedEntries % 3 == 0 ||
                            processedEntries == totalEntriesToProcess ||
                            rawSize >= 256 * 1024L ||
                            category == ApkEntryCategory.LIB
                        ) {
                            val actionTag = if (enforceStored4k) "STORED 4K" else "MERGED"
                            reportProgress(phase, sourceApkLabel, targetEntryName, actionTag)
                        }
                    }

                    // 2. Process Base APK + all Split APKs in structured order:
                    //    - Base APK core files (classes*.dex, resources.arsc, res/, assets/, lib/)
                    //    - All Split APKs (merging lib/<abi>/*.so, assets/**, res/**, and feature classes*.dex)
                    for ((apkIndex, pair) in extractedApks.withIndex()) {
                        val (apkName, apkFile) = pair
                        val (moduleType, _) = classifySplitApkName(apkName)
                        val isBaseApk = (apkIndex == 0)

                        appendLog(
                            if (isBaseApk) {
                                "🔹 [Base APK] Streaming core files from $apkName..."
                            } else {
                                "🔗 [Split Merge] Merging ${moduleType.shortTag} module: $apkName..."
                            }
                        )

                        ZipFile(apkFile).use { zip ->
                            val entries = zip.entries().asSequence().filter { !it.isDirectory }.toList()

                            for (entry in entries) {
                                currentCoroutineContext().ensureActive()
                                val rawEntryName = entry.name.trimStart('/')

                                // Always skip AndroidManifest.xml from splits (and from base since we already wrote the patched one)
                                if (rawEntryName.equals("AndroidManifest.xml", ignoreCase = true)) {
                                    if (!isBaseApk) {
                                        processedEntries++
                                    }
                                    continue
                                }

                                // Completely delete META-INF directory to wipe out old split signatures
                                if (config.stripMetaInfSignatures && isMetaInfSignatureOrBloatEntry(rawEntryName)) {
                                    strippedMetaInfCount++
                                    processedEntries++
                                    processedBytes += entry.size.coerceAtLeast(0L)
                                    continue
                                }

                                // Check ABI filter for lib/<abi>/*.so
                                val entryAbi = extractAbiFromName(rawEntryName)
                                if (entryAbi != null &&
                                    config.abiFilterMode.targetAbi != null &&
                                    entryAbi != config.abiFilterMode.targetAbi
                                ) {
                                    strippedMetaInfCount++
                                    processedEntries++
                                    processedBytes += entry.size.coerceAtLeast(0L)
                                    continue
                                }

                                // Handle classes*.dex merging:
                                // Base APK keeps classes.dex, classes2.dex, etc.
                                // If a feature split APK also contains classes.dex, renumber it to classes<N>.dex!
                                val lowerName = rawEntryName.lowercase(Locale.US)
                                val targetEntryName: String
                                if (lowerName.endsWith(".dex") && !lowerName.contains("/")) {
                                    if (rawEntryName !in writtenEntryNames) {
                                        targetEntryName = rawEntryName
                                        nextDexIndex = maxOf(nextDexIndex, parseDexIndex(rawEntryName) + 1)
                                    } else {
                                        while (true) {
                                            val candidate = if (nextDexIndex == 1) "classes.dex" else "classes$nextDexIndex.dex"
                                            nextDexIndex++
                                            if (candidate !in writtenEntryNames) {
                                                targetEntryName = candidate
                                                break
                                            }
                                        }
                                    }
                                } else {
                                    targetEntryName = rawEntryName
                                }

                                // Skip duplicate entries already merged from base or earlier priority splits
                                // (e.g., duplicate resources.arsc in config splits when base already provided the master table)
                                if (targetEntryName in writtenEntryNames) {
                                    processedEntries++
                                    processedBytes += entry.size.coerceAtLeast(0L)
                                    continue
                                }

                                val category = categorizeEntry(targetEntryName)
                                val phase = when {
                                    category == ApkEntryCategory.LIB -> MergePhase.MERGING_LIBS
                                    category == ApkEntryCategory.ASSETS -> MergePhase.MERGING_ASSETS
                                    category == ApkEntryCategory.RES -> MergePhase.MERGING_RESOURCES
                                    else -> MergePhase.MERGING_BASE
                                }

                                val badge = when {
                                    category == ApkEntryCategory.LIB -> {
                                        val abiLabel = entryAbi ?: "native"
                                        "Merged $abiLabel .so • 4K Aligned"
                                    }
                                    isGameEngineAsset(targetEntryName) -> "Game Engine Asset • 4K STORED"
                                    targetEntryName == "resources.arsc" -> "Resource Table • 4K STORED"
                                    !isBaseApk && category == ApkEntryCategory.ASSETS -> "Merged from $apkName"
                                    !isBaseApk && category == ApkEntryCategory.RES -> "Merged DPI/Lang Resource"
                                    else -> null
                                }

                                if (category == ApkEntryCategory.LIB) {
                                    appendLog("🧬 Merging ${entryAbi ?: "native"} library: $targetEntryName (from $apkName)")
                                } else if (isGameEngineAsset(targetEntryName)) {
                                    appendLog("🎮 Packing 4K STORED game asset: $targetEntryName (${formatBytesShort(entry.size)})")
                                }

                                streamZipEntryIntoUniversal(
                                    sourceZip = zip,
                                    sourceApkLabel = apkName,
                                    sourceEntry = entry,
                                    targetEntryName = targetEntryName,
                                    phase = phase,
                                    badge = badge
                                )
                            }
                        }
                    }

                    // 3. Merge any extracted XAPK .obb / root game engine files into assets/ with 4K STORED alignment
                    for ((targetAssetPath, obbFile) in extractedObbFiles) {
                        currentCoroutineContext().ensureActive()
                        if (targetAssetPath in writtenEntryNames || !obbFile.exists()) continue

                        val fileLen = obbFile.length()
                        val crcCalc = CRC32()
                        BufferedInputStream(FileInputStream(obbFile), STREAM_BUFFER_SIZE).use { input ->
                            var r: Int
                            while (input.read(streamBuffer).also { r = it } != -1) {
                                currentCoroutineContext().ensureActive()
                                crcCalc.update(streamBuffer, 0, r)
                            }
                        }

                        val outEntry = ZipEntry(targetAssetPath).apply {
                            method = ZipEntry.STORED
                            size = fileLen
                            compressedSize = fileLen
                            crc = crcCalc.value
                            comment = null
                        }

                        zos.flush()
                        val currentOffset = countingOut.bytesWritten
                        val nameBytesLen = targetAssetPath.toByteArray(Charsets.UTF_8).size
                        val baseHeaderEnd = currentOffset + 30L + nameBytesLen.toLong()
                        val padBytes = ((ALIGNMENT_4K - (baseHeaderEnd % ALIGNMENT_4K)) % ALIGNMENT_4K).toInt()
                        outEntry.extra = if (padBytes > 0) ByteArray(padBytes) else null

                        zos.putNextEntry(outEntry)
                        zos.flush()
                        val actualDataStartOffset = countingOut.bytesWritten

                        BufferedInputStream(FileInputStream(obbFile), STREAM_BUFFER_SIZE).use { input ->
                            var r: Int
                            while (input.read(streamBuffer).also { r = it } != -1) {
                                currentCoroutineContext().ensureActive()
                                zos.write(streamBuffer, 0, r)
                            }
                        }
                        zos.closeEntry()
                        zos.flush()

                        val is4k = (actualDataStartOffset % ALIGNMENT_4K == 0L)
                        if (is4k) stored4kAlignedCount++
                        mergedAssetsCount++
                        writtenEntryNames.add(targetAssetPath)
                        processedEntries++
                        processedBytes += fileLen

                        appendLog("🎮 Merged OBB expansion container (4K STORED): $targetAssetPath (${formatBytesShort(fileLen)})")
                        comparisons.add(
                            EntryComparisonItem(
                                name = targetAssetPath,
                                sourceSplitName = obbFile.name,
                                category = ApkEntryCategory.ASSETS,
                                uncompressedSize = fileLen,
                                newMethod = ZipEntry.STORED,
                                dataOffset = actualDataStartOffset,
                                is4kAligned = is4k,
                                mergeBadge = "OBB Expansion • 4K STORED"
                            )
                        )
                        reportProgress(MergePhase.MERGING_ASSETS, "XAPK OBB", targetAssetPath, "STORED 4K")
                    }

                    // 4. Finalize Universal_Game.apk
                    reportProgress(
                        MergePhase.FINALIZING_UNIVERSAL,
                        "Universal_Game.apk",
                        "Closing Central Directory & Verifying 4K Offsets...",
                        "FINALIZE"
                    )
                    zos.finish()
                    zos.flush()
                }
            }

            val elapsedMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
            val universalSize = outputUniversalApkFile.length()
            val throughputMbPerSec = (processedBytes.toFloat() / (1024f * 1024f)) / (elapsedMs.toFloat() / 1000f)

            appendLog(
                "✅ Universal_Game.apk built successfully! Size: ${formatBytesShort(universalSize)} • " +
                    "$stored4kAlignedCount 4K STORED entries • $strippedMetaInfCount META-INF signatures wiped."
            )

            comparisons.sortWith(
                compareBy<EntryComparisonItem> {
                    when {
                        it.name == "AndroidManifest.xml" -> 0
                        it.category == ApkEntryCategory.LIB -> 1
                        it.category == ApkEntryCategory.ASSETS -> 2
                        it.category == ApkEntryCategory.ARSC -> 3
                        else -> 4
                    }
                }.thenByDescending { it.uncompressedSize }
            )

            MergeResult(
                outputFile = outputUniversalApkFile,
                outputFileName = outputUniversalApkFile.name,
                originalArchiveSize = sourceArchiveFile.length(),
                universalApkSize = universalSize,
                mergedSplitApksCount = extractedApks.size,
                totalEntriesMerged = writtenEntryNames.size,
                mergedNativeLibsCount = mergedNativeLibsCount,
                mergedAssetsCount = mergedAssetsCount,
                mergedResourcesCount = mergedResourcesCount,
                mergedDexCount = mergedDexCount,
                stored4kAlignedCount = stored4kAlignedCount,
                deflatedEntryCount = deflatedEntryCount,
                strippedMetaInfCount = strippedMetaInfCount,
                manifestPatchSummary = manifestPatchSummary,
                elapsedTimeMs = elapsedMs,
                throughputMbPerSec = throughputMbPerSec,
                entryComparisons = comparisons.take(MAX_REPORTED_ENTRIES),
                finalLogs = liveLogs.toList(),
                requiresResign = true
            )
        } finally {
            workspaceDir.deleteRecursively()
        }
    }

    // ============================================================================================
    // BINARY ANDROIDMANIFEST.XML (AXML) PARSER & ANTI-SPLIT PATCHER
    // ============================================================================================

    private val SPLIT_ATTRIBUTE_NAMES = setOf(
        "isSplitRequired",
        "requiredSplitTypes",
        "splitTypes",
        "com.android.vending.splits.required"
    )

    private val SPLIT_METADATA_KEYS = setOf(
        "com.android.vending.splits",
        "com.android.vending.splits.required",
        "com.android.dynamic.apk.fused.modules",
        "com.android.stamp.source",
        "com.android.stamp.type",
        "com.android.vending.derived.apk.id"
    )

    /**
     * Inspects a Binary `AndroidManifest.xml` (AXML) byte array to detect whether
     * `android:isSplitRequired="true"` and split `<meta-data>` tags are present.
     */
    fun inspectBinaryAndroidManifest(manifestBytes: ByteArray): ManifestSplitInspection {
        if (manifestBytes.size < 16) {
            return ManifestSplitInspection(isBinaryAxml = false)
        }
        val magic = readLeInt(manifestBytes, 0)
        if ((magic and 0xFFFF) != RES_XML_TYPE) {
            val text = String(manifestBytes, Charsets.UTF_8)
            val hasSplitReq = text.contains("isSplitRequired=\"true\"")
            val splitMeta = SPLIT_METADATA_KEYS.filter { text.contains(it) }
            return ManifestSplitInspection(
                isBinaryAxml = false,
                hasIsSplitRequiredTrue = hasSplitReq,
                splitMetaDataNames = splitMeta
            )
        }

        val (_, summary) = patchBinaryAndroidManifest(manifestBytes, setExtractNativeLibsFalse = false)
        return ManifestSplitInspection(
            isBinaryAxml = true,
            hasIsSplitRequiredTrue = summary.isSplitRequiredSetToFalse || summary.splitAttributesClearedCount > 0,
            hasExtractNativeLibsTrue = false,
            splitMetaDataNames = summary.removedSplitMetaDataTags
        )
    }

    /**
     * Parses and patches Android's Binary XML (`AXML`, header `0x00080003`) `AndroidManifest.xml`:
     *
     * 1. Finds `android:isSplitRequired="true"` (`0x01010591` or string `"isSplitRequired"`) on
     *    `<manifest>` or `<application>` and changes its boolean value to `false` (`0`).
     * 2. Neutralizes `android:requiredSplitTypes` (`0x0101064E`) and `android:splitTypes` (`0x0101064F`)
     *    attributes by removing them from `<manifest>` start elements.
     * 3. Optionally sets `android:extractNativeLibs="false"` (`0x010104EA`) when 4K alignment is active.
     * 4. Removes any `<meta-data>` element (both its `START_ELEMENT` `0x0102` and `END_ELEMENT` `0x0103` chunks)
     *    whose `android:name` references splits (`com.android.vending.splits`, `com.android.vending.splits.required`,
     *    `com.android.dynamic.apk.fused.modules`, `com.android.stamp.*`, or contains `"split"`).
     * 5. Recalculates the root AXML 32-bit `fileSize` header at offset `4..7`.
     */
    fun patchBinaryAndroidManifest(
        manifestBytes: ByteArray,
        setExtractNativeLibsFalse: Boolean = true
    ): Pair<ByteArray, ManifestPatchSummary> {
        if (manifestBytes.size < 16) {
            return Pair(manifestBytes, ManifestPatchSummary(originalManifestBytes = manifestBytes.size, patchedManifestBytes = manifestBytes.size))
        }

        val chunkType = readLeUInt16(manifestBytes, 0)
        val headerSize = readLeUInt16(manifestBytes, 2)
        if (chunkType != RES_XML_TYPE || headerSize != 8) {
            // Fallback for plain-text or synthetic XML manifests
            return patchTextOrHybridManifest(manifestBytes)
        }

        return try {
            var stringPool: List<String> = emptyList()
            var resourceIds: IntArray = IntArray(0)

            var isSplitRequiredPatched = false
            var splitAttributesCleared = 0
            val removedMetaDataNames = ArrayList<String>()

            // First pass: locate StringPool and ResourceMap so we can resolve attribute names & resource IDs
            var scanOffset = 8
            val limit = manifestBytes.size
            while (scanOffset + 8 <= limit) {
                val cType = readLeUInt16(manifestBytes, scanOffset)
                val cHeaderSize = readLeUInt16(manifestBytes, scanOffset + 2)
                val cSize = readLeInt(manifestBytes, scanOffset + 4)
                if (cSize < 8 || scanOffset + cSize > limit) break

                if (cType == RES_STRING_POOL_TYPE) {
                    stringPool = parseAxmlStringPool(manifestBytes, scanOffset, cHeaderSize, cSize)
                } else if (cType == RES_XML_RESOURCE_MAP_TYPE) {
                    val count = (cSize - cHeaderSize) / 4
                    if (count in 1..16384) {
                        resourceIds = IntArray(count) { idx ->
                            readLeInt(manifestBytes, scanOffset + cHeaderSize + idx * 4)
                        }
                    }
                }
                scanOffset += cSize
            }

            fun getStringOrNull(idx: Int): String? =
                if (idx in stringPool.indices) stringPool[idx] else null

            fun getAttrResId(nameStringIdx: Int): Int =
                if (nameStringIdx in resourceIds.indices) resourceIds[nameStringIdx] else 0

            // Second pass: walk all chunks, patch <manifest>/<application> attributes, and drop split <meta-data> chunks
            val outChunks = ByteArrayOutputStream(manifestBytes.size)
            // Reserve 8-byte AXML file header (we will write updated total size at the end)
            outChunks.write(manifestBytes, 0, 8)

            var pos = 8
            var skipNextMetaDataEndElement = false

            while (pos + 8 <= limit) {
                val cType = readLeUInt16(manifestBytes, pos)
                val cHeaderSize = readLeUInt16(manifestBytes, pos + 2)
                val cSize = readLeInt(manifestBytes, pos + 4)
                if (cSize < 8 || pos + cSize > limit) {
                    // Copy remaining bytes safely
                    outChunks.write(manifestBytes, pos, limit - pos)
                    break
                }

                if (cType == RES_XML_START_ELEMENT_TYPE && cSize >= 36) {
                    val elemNameIdx = readLeInt(manifestBytes, pos + 20)
                    val elemName = getStringOrNull(elemNameIdx) ?: ""
                    val attrStart = readLeUInt16(manifestBytes, pos + 24)
                    val attrSize = readLeUInt16(manifestBytes, pos + 26)
                    val attrCount = readLeUInt16(manifestBytes, pos + 28)
                    val attrsBaseOffset = pos + 16 + attrStart

                    if (attrSize >= 20 && attrsBaseOffset + attrCount * attrSize <= pos + cSize) {
                        // 1. Check if this is a <meta-data> tag referencing splits
                        if (elemName == "meta-data") {
                            var metaNameValue = ""
                            for (a in 0 until attrCount) {
                                val attrOff = attrsBaseOffset + a * attrSize
                                val attrNameIdx = readLeInt(manifestBytes, attrOff + 4)
                                val attrName = getStringOrNull(attrNameIdx) ?: ""
                                val attrResId = getAttrResId(attrNameIdx)
                                val rawValIdx = readLeInt(manifestBytes, attrOff + 8)
                                val typedData = readLeInt(manifestBytes, attrOff + 16)
                                val valStr = getStringOrNull(rawValIdx) ?: getStringOrNull(typedData) ?: ""

                                if (attrName == "name" || attrResId == ATTR_ANDROID_NAME) {
                                    metaNameValue = valStr
                                }
                            }

                            val isSplitMetaData = metaNameValue in SPLIT_METADATA_KEYS ||
                                metaNameValue.contains("vending.splits", ignoreCase = true) ||
                                metaNameValue.contains("fused.modules", ignoreCase = true) ||
                                metaNameValue.startsWith("com.android.stamp.", ignoreCase = true) ||
                                metaNameValue.contains(".splits", ignoreCase = true)

                            if (isSplitMetaData) {
                                removedMetaDataNames.add(metaNameValue.ifEmpty { "meta-data[splits]" })
                                skipNextMetaDataEndElement = true
                                pos += cSize
                                continue
                            }
                        }

                        // 2. Patch <manifest> or <application> attributes (isSplitRequired, requiredSplitTypes, splitTypes, extractNativeLibs)
                        val chunkCopy = manifestBytes.copyOfRange(pos, pos + cSize)
                        val keptAttrBytes = ByteArrayOutputStream(attrCount * attrSize)
                        var keptAttrCount = 0

                        for (a in 0 until attrCount) {
                            val relOff = 16 + attrStart + a * attrSize
                            val attrNameIdx = readLeInt(chunkCopy, relOff + 4)
                            val attrName = getStringOrNull(attrNameIdx) ?: ""
                            val attrResId = getAttrResId(attrNameIdx)

                            // Remove requiredSplitTypes / splitTypes completely so PackageManager doesn't expect split modules
                            if (attrName == "requiredSplitTypes" ||
                                attrName == "splitTypes" ||
                                attrResId == ATTR_ANDROID_REQUIRED_SPLIT_TYPES ||
                                attrResId == ATTR_ANDROID_SPLIT_TYPES
                            ) {
                                splitAttributesCleared++
                                continue
                            }

                            // Patch android:isSplitRequired="true" -> false (0)
                            if (attrName == "isSplitRequired" ||
                                attrName == "com.android.vending.splits.required" ||
                                attrResId == ATTR_ANDROID_IS_SPLIT_REQUIRED
                            ) {
                                val currentData = readLeInt(chunkCopy, relOff + 16)
                                if (currentData != 0) {
                                    isSplitRequiredPatched = true
                                    splitAttributesCleared++
                                }
                                writeLeInt(chunkCopy, relOff + 8, -1) // rawValue = -1 (none)
                                chunkCopy[relOff + 12] = 8
                                chunkCopy[relOff + 13] = 0
                                chunkCopy[relOff + 14] = 0
                                chunkCopy[relOff + 15] = TYPE_INT_BOOLEAN.toByte()
                                writeLeInt(chunkCopy, relOff + 16, 0) // false = 0x00000000
                            }

                            // Patch android:extractNativeLibs="true" -> false (0) when 4K alignment is enforced
                            if (setExtractNativeLibsFalse &&
                                (attrName == "extractNativeLibs" || attrResId == ATTR_ANDROID_EXTRACT_NATIVE_LIBS)
                            ) {
                                writeLeInt(chunkCopy, relOff + 8, -1)
                                chunkCopy[relOff + 12] = 8
                                chunkCopy[relOff + 13] = 0
                                chunkCopy[relOff + 14] = 0
                                chunkCopy[relOff + 15] = TYPE_INT_BOOLEAN.toByte()
                                writeLeInt(chunkCopy, relOff + 16, 0) // false = 0
                            }

                            keptAttrBytes.write(chunkCopy, relOff, attrSize)
                            keptAttrCount++
                        }

                        if (keptAttrCount != attrCount) {
                            // Rebuild START_ELEMENT chunk with filtered attributes
                            val newChunkSize = 16 + attrStart + keptAttrCount * attrSize
                            val rebuiltChunk = ByteArray(newChunkSize)
                            System.arraycopy(chunkCopy, 0, rebuiltChunk, 0, 16 + attrStart)
                            writeLeInt(rebuiltChunk, 4, newChunkSize)
                            writeLeUInt16(rebuiltChunk, 28, keptAttrCount)
                            val attrArray = keptAttrBytes.toByteArray()
                            System.arraycopy(attrArray, 0, rebuiltChunk, 16 + attrStart, attrArray.size)
                            outChunks.write(rebuiltChunk)
                        } else {
                            outChunks.write(chunkCopy)
                        }
                        pos += cSize
                        continue
                    }
                } else if (cType == RES_XML_END_ELEMENT_TYPE && skipNextMetaDataEndElement) {
                    val elemNameIdx = if (cSize >= 24) readLeInt(manifestBytes, pos + 20) else -1
                    val elemName = getStringOrNull(elemNameIdx) ?: ""
                    if (elemName == "meta-data" || elemName.isEmpty()) {
                        skipNextMetaDataEndElement = false
                        pos += cSize
                        continue
                    }
                }

                outChunks.write(manifestBytes, pos, cSize)
                pos += cSize
            }

            val patchedBytes = outChunks.toByteArray()
            // Update root AXML total file size at offset 4..7
            writeLeInt(patchedBytes, 4, patchedBytes.size)

            val summary = ManifestPatchSummary(
                wasManifestPatched = isSplitRequiredPatched || splitAttributesCleared > 0 || removedMetaDataNames.isNotEmpty(),
                isSplitRequiredSetToFalse = isSplitRequiredPatched,
                splitAttributesClearedCount = splitAttributesCleared,
                removedSplitMetaDataTags = removedMetaDataNames,
                originalManifestBytes = manifestBytes.size,
                patchedManifestBytes = patchedBytes.size
            )
            Pair(patchedBytes, summary)
        } catch (_: Throwable) {
            patchTextOrHybridManifest(manifestBytes)
        }
    }

    /**
     * Parses the `RES_STRING_POOL_TYPE` (`0x0001`) chunk in a binary AXML file.
     * Supports both UTF-16LE (default AXML) and UTF-8 (`UTF8_FLAG = 0x100`) string pools.
     */
    private fun parseAxmlStringPool(
        buf: ByteArray,
        chunkOffset: Int,
        headerSize: Int,
        chunkSize: Int
    ): List<String> {
        if (chunkSize < 28) return emptyList()
        val stringCount = readLeInt(buf, chunkOffset + 8)
        val flags = readLeInt(buf, chunkOffset + 16)
        val stringsStart = readLeInt(buf, chunkOffset + 20)
        if (stringCount <= 0 || stringCount > 65536) return emptyList()

        val isUtf8 = (flags and UTF8_FLAG) != 0
        val offsetsBase = chunkOffset + headerSize
        val poolDataBase = chunkOffset + stringsStart
        val chunkEnd = chunkOffset + chunkSize

        val result = ArrayList<String>(stringCount)
        for (i in 0 until stringCount) {
            val offsetPos = offsetsBase + i * 4
            if (offsetPos + 4 > chunkEnd) break
            val strRelOffset = readLeInt(buf, offsetPos)
            val strPos = poolDataBase + strRelOffset
            if (strPos < poolDataBase || strPos >= chunkEnd) {
                result.add("")
                continue
            }

            if (isUtf8) {
                var p = strPos
                // Skip UTF-16 char length varint (1 or 2 bytes)
                val charLenByte1 = buf[p].toInt() and 0xFF
                p += if ((charLenByte1 and 0x80) != 0) 2 else 1
                // Read UTF-8 byte length varint (1 or 2 bytes)
                if (p >= chunkEnd) {
                    result.add("")
                    continue
                }
                val b1 = buf[p].toInt() and 0xFF
                val utf8ByteLen: Int
                if ((b1 and 0x80) != 0 && p + 1 < chunkEnd) {
                    val b2 = buf[p + 1].toInt() and 0xFF
                    utf8ByteLen = ((b1 and 0x7F) shl 8) or b2
                    p += 2
                } else {
                    utf8ByteLen = b1
                    p += 1
                }
                val safeLen = utf8ByteLen.coerceIn(0, chunkEnd - p)
                result.add(String(buf, p, safeLen, Charsets.UTF_8))
            } else {
                // UTF-16LE string: 2-byte (or 4-byte) char count followed by 2*charCount bytes
                var p = strPos
                if (p + 2 > chunkEnd) {
                    result.add("")
                    continue
                }
                val u1 = readLeUInt16(buf, p)
                val charCount: Int
                if ((u1 and 0x8000) != 0 && p + 4 <= chunkEnd) {
                    val u2 = readLeUInt16(buf, p + 2)
                    charCount = ((u1 and 0x7FFF) shl 16) or u2
                    p += 4
                } else {
                    charCount = u1
                    p += 2
                }
                val byteLen = (charCount * 2).coerceIn(0, chunkEnd - p)
                result.add(String(buf, p, byteLen, Charsets.UTF_16LE))
            }
        }
        return result
    }

    /**
     * Fallback manifest patcher for non-AXML or hybrid test manifests.
     */
    private fun patchTextOrHybridManifest(manifestBytes: ByteArray): Pair<ByteArray, ManifestPatchSummary> {
        val text = String(manifestBytes, Charsets.UTF_8)
        var patchedText = text
        var splitReqChanged = false
        val removedMeta = ArrayList<String>()

        if (patchedText.contains("android:isSplitRequired=\"true\"")) {
            patchedText = patchedText.replace("android:isSplitRequired=\"true\"", "android:isSplitRequired=\"false\"")
            splitReqChanged = true
        }
        if (patchedText.contains("isSplitRequired=\"true\"")) {
            patchedText = patchedText.replace("isSplitRequired=\"true\"", "isSplitRequired=\"false\"")
            splitReqChanged = true
        }

        val metaRegex = Regex("""<meta-data[^>]*splits[^>]*/>""", RegexOption.IGNORE_CASE)
        metaRegex.findAll(patchedText).forEach { match ->
            removedMeta.add(match.value)
        }
        if (removedMeta.isNotEmpty()) {
            patchedText = metaRegex.replace(patchedText, "")
        }

        val outBytes = patchedText.toByteArray(Charsets.UTF_8)
        return Pair(
            outBytes,
            ManifestPatchSummary(
                wasManifestPatched = splitReqChanged || removedMeta.isNotEmpty(),
                isSplitRequiredSetToFalse = splitReqChanged,
                splitAttributesClearedCount = if (splitReqChanged) 1 else 0,
                removedSplitMetaDataTags = removedMeta,
                originalManifestBytes = manifestBytes.size,
                patchedManifestBytes = outBytes.size
            )
        )
    }

    private fun hasClassesDexAndManifest(apkFile: File): Boolean {
        return try {
            ZipFile(apkFile).use { zip ->
                zip.getEntry("AndroidManifest.xml") != null && zip.getEntry("classes.dex") != null
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun parseDexIndex(dexName: String): Int {
        val numStr = dexName.lowercase(Locale.US)
            .removePrefix("classes")
            .removeSuffix(".dex")
        return numStr.toIntOrNull() ?: 1
    }

    /**
     * Parses local file headers in an APK to compute the exact byte offset where each entry's data starts.
     * Supports both `STORED` entries and `DEFLATED` entries with ZIP Data Descriptors (`flag 0x0008`).
     */
    fun parseLocalHeaderDataOffsets(apkFile: File): Map<String, Long> {
        val offsets = HashMap<String, Long>()
        if (!apkFile.exists() || apkFile.length() < 30L) return offsets
        try {
            ZipFile(apkFile).use { zip ->
                RandomAccessFile(apkFile, "r").use { raf ->
                    val fileLen = raf.length()
                    val headerBuf = ByteArray(30)
                    val ddSigBuf = ByteArray(4)
                    var pos = 0L
                    while (pos + 30L <= fileLen) {
                        raf.seek(pos)
                        raf.readFully(headerBuf)
                        val sig = readLeInt(headerBuf, 0)
                        if (sig != 0x04034B50) break // Reached Central Directory

                        val flags = readLeUInt16(headerBuf, 6)
                        val headerCompSize = readLeUInt32(headerBuf, 18)
                        val nameLen = readLeUInt16(headerBuf, 26)
                        val extraLen = readLeUInt16(headerBuf, 28)

                        val nameBytes = ByteArray(nameLen)
                        raf.readFully(nameBytes)
                        val entryName = String(nameBytes, Charsets.UTF_8)
                        val dataStart = pos + 30L + nameLen.toLong() + extraLen.toLong()
                        offsets[entryName] = dataStart

                        val hasDataDescriptor = (flags and 0x0008) != 0
                        val actualCompSize = if (hasDataDescriptor && headerCompSize == 0L) {
                            val ze = zip.getEntry(entryName) ?: break
                            if (ze.compressedSize < 0L) break
                            ze.compressedSize
                        } else {
                            headerCompSize
                        }

                        var nextPos = dataStart + actualCompSize
                        if (hasDataDescriptor) {
                            if (nextPos + 4L <= fileLen) {
                                raf.seek(nextPos)
                                raf.readFully(ddSigBuf)
                                val ddSig = readLeInt(ddSigBuf, 0)
                                nextPos += if (ddSig == 0x08074B50) 16L else 12L
                            } else {
                                break
                            }
                        }
                        pos = nextPos
                    }
                }
            }
        } catch (_: Exception) {
        }
        return offsets
    }

    fun formatBytesShort(bytes: Long): String {
        val absBytes = kotlin.math.abs(bytes)
        val sign = if (bytes < 0) "-" else ""
        return when {
            absBytes >= 1024L * 1024L * 1024L ->
                String.format(Locale.US, "%s%.2f GB", sign, absBytes.toDouble() / (1024.0 * 1024.0 * 1024.0))
            absBytes >= 1024L * 1024L ->
                String.format(Locale.US, "%s%.2f MB", sign, absBytes.toDouble() / (1024.0 * 1024.0))
            absBytes >= 1024L ->
                String.format(Locale.US, "%s%.1f KB", sign, absBytes.toDouble() / 1024.0)
            else -> "$sign$absBytes B"
        }
    }

    private fun readLeUInt16(buf: ByteArray, offset: Int): Int {
        return (buf[offset].toInt() and 0xFF) or
            ((buf[offset + 1].toInt() and 0xFF) shl 8)
    }

    private fun writeLeUInt16(buf: ByteArray, offset: Int, value: Int) {
        buf[offset] = (value and 0xFF).toByte()
        buf[offset + 1] = ((value ushr 8) and 0xFF).toByte()
    }

    private fun readLeInt(buf: ByteArray, offset: Int): Int {
        return (buf[offset].toInt() and 0xFF) or
            ((buf[offset + 1].toInt() and 0xFF) shl 8) or
            ((buf[offset + 2].toInt() and 0xFF) shl 16) or
            ((buf[offset + 3].toInt() and 0xFF) shl 24)
    }

    private fun readLeUInt32(buf: ByteArray, offset: Int): Long {
        return readLeInt(buf, offset).toLong() and 0xFFFFFFFFL
    }

    private fun writeLeInt(buf: ByteArray, offset: Int, value: Int) {
        buf[offset] = (value and 0xFF).toByte()
        buf[offset + 1] = ((value ushr 8) and 0xFF).toByte()
        buf[offset + 2] = ((value ushr 16) and 0xFF).toByte()
        buf[offset + 3] = ((value ushr 24) and 0xFF).toByte()
    }
}
