package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.FileProvider
import com.android.apksig.ApkSigner
import com.android.apksig.util.DataSinks
import com.android.apksig.util.DataSources
import com.example.model.ApkFileInfo
import com.example.model.FixProgressStage
import com.example.model.FixResult
import com.example.model.TargetAndroidVersion
import com.reandroid.apk.ApkModule
import com.reandroid.arsc.chunk.xml.AndroidManifestBlock
import com.reandroid.arsc.chunk.xml.ResXmlElement
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Production-grade APK Modification, Zipalign & Signing Engine (Android 11–16 Compatible):
 *
 * 1. **Step 1 — Real Binary AXML Patching via `REAndroid/ARSCLib` (`AndroidManifestBlock` & `ApkModule`)**:
 *    - Parses binary `AndroidManifest.xml` cleanly using `AndroidManifestBlock` without corrupting string pools or resource IDs.
 *    - Updates `android:minSdkVersion` (and `android:targetSdkVersion` if requested) inside `<uses-sdk>`.
 *    - Automatically inspects all `<activity>`, `<activity-alias>`, `<service>`, and `<receiver>` components
 *      containing an `<intent-filter>` and sets `android:exported="true"` (`0x01010010`) if missing (mandatory for Android 12+).
 *    - Keeps the original `package` name and all other resources 100% untouched, writing to a temporary intermediate `.apk`.
 *
 * 2. **Step 2 — Proper ZIP Packaging & Uncompressed Resources**:
 *    - Ensures `resources.arsc` and all `.so` native libraries are stored uncompressed (`ZipEntry.STORED`
 *      with exact pre-calculated `size`, `compressedSize`, and `crc` checksums).
 *    - Strips all old signature files from `META-INF/` (`MANIFEST.MF`, `.SF`, `.RSA`, `.DSA`, `.EC`, `SIG-*`).
 *
 * 3. **Step 3 — 4-Byte / 4096-Byte Zipalign**:
 *    - Aligns all uncompressed `ZipEntry.STORED` entries (including `resources.arsc`) to an exact **4-byte** boundary,
 *      and aligns all `.so` native shared libraries to an exact **4096-byte (4K)** page boundary (strictly required by Android 11+).
 *
 * 4. **Step 4 — Official Google V1 + V2 + V3 Signing (`com.android.apksig.ApkSigner`)**:
 *    - Persists a valid RSA 2048-bit self-signed key (`testkey.pk8` & `testkey.x509.der`) in app storage if not already present.
 *    - Signs the aligned APK using `ApkSigner` with `v1SigningEnabled = true`, `v2SigningEnabled = true`, and `v3SigningEnabled = true`.
 */
object ApkFixerEngine {

    private const val BUFFER_SIZE = 64 * 1024 // 64 KB streaming buffer
    private const val FIXED_ZIP_TIME = 315561600000L // 1980-01-01 00:00:00 UTC

    // Android framework resource ID for android:exported
    private const val ATTR_EXPORTED = 0x01010010

    private val COMPONENT_TAGS = setOf("activity", "activity-alias", "service", "receiver")

    // Standard 2048-bit RSA PKCS#8 PrivateKey & self-signed X.509 Certificate (CN=Android Debug, O=Android, C=US)
    private const val EMBEDDED_RSA_PKCS8_BASE64 =
        "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDFU4UsYTF4NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X2mSj" +
            "OBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZTIx6W" +
            "sriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rqXVoe" +
            "mmMwqguqznCVbggN4fUFAgMBAAECggEAAU3nVM8Sb5xmhqDyMc2Na5+KsW2V5e1qEsfqJuJqn1w5ejmxhEUHg0qQdRYlXuXYhumZCnlgxxWG7yeayVhTB5RUHX1T" +
            "kx0IJ5YDSICnbw5/hRPpUP19xN2Qs+Ym55LyIl/ZuY8526Hhx09vA3oQYv7BnNbzXfR9rCRcpej3/kG78rew+mn/L0e51/rr481R4WFyL4T23zMUCg2+WvZZ0RQ+" +
            "jBNn3QaYWX1FYVzSaZ2JShSakAvtHLQwBUMg1jaqV9IIyqx9VR/dMhOG8LpIpFSMwRfQPKWniV2e6ljCVjYAKuSLoqISaWjO1FQBiwbfl6lM7CIyENHc+Dq2ZF1Z" +
            "iQKBgQDXKCFipjK7cHC51D7JR+oARRjvodnu+sMLCAZLWAtl1TJ1zLCjU/+STbLkMUWyPthE197NMB9RzINxQ8Ode124tiINF6Q7GlCU4INWzKrrLuQ41ouiwZa/" +
            "OxXnI+UgFL3FnvL8CWNfqkyKtRwc2dBtu9+Z77w7zmcMVwkxnMGE/QKBgQDqyOOe5EDEls2a3MZtDNrmw+2D/ioPSgoizIEpZdjfcPH+uSRgCQjgdHPQj27rAutJ" +
            "UNWGf3+B2cTgzKMCngi/U+LoonVkIKe1G357HZwZp5L9EskcSG/tY5MqNu3EbCdbQLNVqWPZNDHINiFvllZJp466BrL1n73HkY/sHTLyqQKBgFQ6aZds6L9oLTkS" +
            "VeIGPR0N780f12ku0dwnsA8e0Jd09uQW1a+a2pozwKyEfXxiDdglihtZk2k6XtqgZJvqB66f3oSxlKFuk800dzYruV2IZd+6Xb/BeXozb0elTbVZaVFMAGOaaUSy" +
            "LnS+odrJikbrHYXtzAq9qqmyCO9bJochAoGAbXOpaXFPIFaNExzJBB1yDxJXr6jVQrtpbj+YFwx7xe6JYg49fue3U6v2McwsETMTLOKaKFFXx9kVhxbfB2FVApzA" +
            "s2LJBxySEkP2+r4a/3q3c3NGfgDm7Ov2tz9UKLWiw0+uSsjk22URsBxMChEzuLJ8PwzQcOE/P8IELjaOgcECgYEAjnI+aSRfhE1xdbFQplbapzpj1/kfTCPudJbI" +
            "zOOmET088NtS1G4sJjrGALe4agQtFqvVsU3s8sv9Z8bMdzlx2yAsxOQtBgKW35RQ4HwNyPxlP3l+UGdgicWCGlDegMTprYthSrhjBNdeY0M4Fhi66ZV6h+EqxXzz" +
            "89Vo1vrX4Ic="

    private const val EMBEDDED_X509_CERT_BASE64 =
        "MIIC+DCCAeCgAwIBAgIQP11r3V28MrQX7vLoc9+ZtTANBgkqhkiG9w0BAQsFADA3MQswCQYDVQQGEwJVUzEQMA4GA1UEChMHQW5kcm9pZDEWMBQGA1UEAxMNQW5k" +
            "cm9pZCBEZWJ1ZzAgFw0yNjExMDcwMjE5NTFaGA8yMDU0MDMyNjAyMTk1MVowNzELMAkGA1UEBhMCVVMxEDAOBgNVBAoTB0FuZHJvaWQxFjAUBgNVBAMTDUFuZHJv" +
            "aWQgRGVidWcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFU4UsYTF4NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X" +
            "2mSjOBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZT" +
            "Ix6WsriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rq" +
            "XVoemmMwqguqznCVbggN4fUFAgMBAAEwDQYJKoZIhvcNAQELBQADggEBACVMg0rOu03ptqGLuaZ//q8o3sC9XjjT/p+qh9zcMQFCnO1v2OXW6ClhkaFAgLhNa10H" +
            "tm5zjNME4d/FFBxtR8wfyvUbkaCQVugVRLUVAZBM7+xbsrzvyh0/JZKLDYjEj+LGZADwKr7Ut9WEzd62h85NmBEspDTG6AwybJJ0CFPdF4mh+8+GZfX98c7K01MW" +
            "rtAncV154+rmEKnm/X1rUXFHrJBiLEx611nWTAi0y7uJ3iAOdj0G6KP2bK1/JCcct8O9gOO7+yFSDdPbNwIu05kOLUzyLDLbwdcZmGJZRfBR5Z0delQAhKy7GlPt" +
            "AWCArU0VE7O2QzKZlMCcNeegxME="

    /**
     * Tracks exact byte position written by ZipOutputStream so we can compute exact 4-byte
     * and 4096-byte alignment padding in `ZipEntry.extra` for `ZipEntry.STORED` entries.
     */
    private class CountingOutputStream(out: OutputStream) : FilterOutputStream(out) {
        var bytesWritten: Long = 0L
            private set

        override fun write(b: Int) {
            out.write(b)
            bytesWritten += 1L
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            out.write(b, off, len)
            bytesWritten += len.toLong()
        }
    }

    /**
     * Copies a user-selected APK Uri from Storage Access Framework into a local cache file.
     */
    suspend fun importApkFromUri(context: Context, uri: Uri): ApkFileInfo = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        var displayName = "Selected_App.apk"
        var sizeBytes = 0L

        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) {
                    cursor.getString(nameIndex)?.let { displayName = it }
                }
                if (sizeIndex != -1) {
                    sizeBytes = cursor.getLong(sizeIndex)
                }
            }
        }

        if (!displayName.endsWith(".apk", ignoreCase = true)) {
            displayName = "$displayName.apk"
        }

        val cacheDir = File(context.cacheDir, "imported_apks").apply { mkdirs() }
        val targetFile = File(cacheDir, displayName)

        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(targetFile).use { output ->
                input.copyTo(output, bufferSize = BUFFER_SIZE)
                safeFlushAndSync(output)
            }
        } ?: throw IllegalStateException("تعذر فتح دفق القراءة للملف المختار")

        if (sizeBytes <= 0L) {
            sizeBytes = targetFile.length()
        }

        inspectApkFile(targetFile, uri, displayName)
    }

    /**
     * Inspects an APK using `REAndroid/ARSCLib` (`ApkModule` & `AndroidManifestBlock`)
     * to read its original packageName, minSdkVersion, and targetSdkVersion.
     */
    suspend fun inspectApkFile(
        file: File,
        uri: Uri? = null,
        fileName: String = file.name,
        isSample: Boolean = false
    ): ApkFileInfo = withContext(Dispatchers.IO) {
        var pkgName = "com.app.apk"
        var minSdk: Int? = null
        var targetSdk: Int? = null

        try {
            ApkModule.loadApkFile(file).use { apkModule ->
                if (apkModule.hasAndroidManifest()) {
                    val manifest = apkModule.androidManifest
                    val parsedPkg = manifest.packageName
                    if (!parsedPkg.isNullOrBlank()) {
                        pkgName = parsedPkg
                    }
                    minSdk = manifest.minSdkVersion
                    targetSdk = manifest.targetSdkVersion
                }
            }
        } catch (_: Throwable) {
            // Fallback to direct AndroidManifest.xml stream inspection
            try {
                ZipFile(file).use { zip ->
                    val manifestEntry = zip.getEntry("AndroidManifest.xml")
                    if (manifestEntry != null) {
                        val bytes = zip.getInputStream(manifestEntry).readBytes()
                        val info = inspectBinaryManifest(bytes)
                        if (info.packageName.isNotBlank()) pkgName = info.packageName
                        minSdk = info.minSdkVersion
                        targetSdk = info.targetSdkVersion
                    }
                }
            } catch (_: Throwable) {
                // Keep defaults
            }
        }

        ApkFileInfo(
            fileName = fileName,
            fileSizeBytes = file.length(),
            fileUri = uri,
            localFile = file,
            packageName = pkgName,
            detectedMinSdk = minSdk,
            detectedTargetSdk = targetSdk,
            isSample = isSample
        )
    }

    data class ManifestInspectionResult(
        val packageName: String,
        val minSdkVersion: Int?,
        val targetSdkVersion: Int?,
        val exportedComponentsWithIntentFilterCount: Int = 0
    )

    /**
     * Reads package name, minSdkVersion, targetSdkVersion, and exported component count from a
     * Binary XML (`AXML`) `AndroidManifest.xml` using `REAndroid/ARSCLib` (`AndroidManifestBlock`).
     */
    fun inspectBinaryManifest(buf: ByteArray): ManifestInspectionResult {
        if (buf.size < 8) return ManifestInspectionResult("", null, null, 0)
        return try {
            val manifestBlock = AndroidManifestBlock.load(ByteArrayInputStream(buf))
            val pkg = manifestBlock.packageName.orEmpty()
            val minSdk = manifestBlock.minSdkVersion
            val targetSdk = manifestBlock.targetSdkVersion
            val exportedCount = countExportedComponentsWithIntentFilter(manifestBlock)
            ManifestInspectionResult(
                packageName = pkg,
                minSdkVersion = minSdk,
                targetSdkVersion = targetSdk,
                exportedComponentsWithIntentFilterCount = exportedCount
            )
        } catch (_: Throwable) {
            ManifestInspectionResult("", null, null, 0)
        }
    }

    private fun countExportedComponentsWithIntentFilter(manifestBlock: AndroidManifestBlock): Int {
        val appElement = manifestBlock.applicationElement ?: return 0
        var count = 0
        val children = appElement.listElements()
        for (child in children) {
            if (child.name in COMPONENT_TAGS && hasIntentFilter(child)) {
                val exportedAttr = child.searchAttributeByResourceId(ATTR_EXPORTED)
                    ?: child.searchAttributeByName("exported")
                if (exportedAttr != null && exportedAttr.valueAsBoolean) {
                    count++
                }
            }
        }
        return count
    }

    private fun hasIntentFilter(componentElement: ResXmlElement): Boolean {
        for (sub in componentElement.listElements()) {
            if (sub.name == "intent-filter") {
                return true
            }
        }
        return false
    }

    data class ManifestPatchOutput(
        val patchedBytes: ByteArray,
        val packageName: String,
        val minSdkVersion: Int,
        val targetSdkVersion: Int,
        val exportedComponentsPatchedCount: Int
    )

    /**
     * Uses `REAndroid/ARSCLib` (`AndroidManifestBlock`) to cleanly edit binary `AndroidManifest.xml`:
     * - Updates `minSdkVersion` (and `targetSdkVersion` if `newTargetSdk != null`) inside `<uses-sdk>`.
     * - Automatically inspects all `<activity>`, `<activity-alias>`, `<service>`, and `<receiver>`
     *   elements containing an `<intent-filter>` and ensures `android:exported="true"` (`0x01010010`) is set if missing.
     * - Preserves the original `package` name and all other attributes/elements untouched.
     */
    fun patchBinaryManifestWithArscLib(
        origBytes: ByteArray,
        newMinSdk: Int,
        newTargetSdk: Int? = null
    ): ManifestPatchOutput {
        val manifestBlock = AndroidManifestBlock.load(ByteArrayInputStream(origBytes))
        val origPackageName = manifestBlock.packageName.orEmpty()
        val origTargetSdk = manifestBlock.targetSdkVersion

        // 1. Update minSdkVersion and optional targetSdkVersion via AndroidManifestBlock
        manifestBlock.setMinSdkVersion(newMinSdk)
        val effectiveTargetSdk = newTargetSdk ?: origTargetSdk ?: newMinSdk
        if (newTargetSdk != null || origTargetSdk == null) {
            manifestBlock.setTargetSdkVersion(effectiveTargetSdk)
        }

        // 2. Ensure all <activity>, <activity-alias>, <service>, and <receiver> with <intent-filter>
        //    have android:exported="true" (mandatory for Android 12+ installation)
        var exportedPatchedCount = 0
        val appElement = manifestBlock.applicationElement
        if (appElement != null) {
            for (component in appElement.listElements()) {
                if (component.name in COMPONENT_TAGS && hasIntentFilter(component)) {
                    val existingExported = component.searchAttributeByResourceId(ATTR_EXPORTED)
                        ?: component.searchAttributeByName("exported")
                    if (existingExported == null) {
                        val exportedAttr = component.getOrCreateAndroidAttribute("exported", ATTR_EXPORTED)
                        exportedAttr.setValueAsBoolean(true)
                        exportedPatchedCount++
                    }
                }
            }
        }

        // 3. Ensure original package name is strictly preserved
        if (origPackageName.isNotBlank() && manifestBlock.packageName != origPackageName) {
            manifestBlock.packageName = origPackageName
        }

        manifestBlock.refresh()
        val outBytes = manifestBlock.bytes

        return ManifestPatchOutput(
            patchedBytes = outBytes,
            packageName = manifestBlock.packageName.orEmpty().ifBlank { origPackageName },
            minSdkVersion = manifestBlock.minSdkVersion ?: newMinSdk,
            targetSdkVersion = manifestBlock.targetSdkVersion ?: effectiveTargetSdk,
            exportedComponentsPatchedCount = exportedPatchedCount
        )
    }

    /**
     * Backward-compatible helper that returns the patched binary `AndroidManifest.xml` bytes via `ARSCLib`.
     */
    fun patchBinaryManifestSdkVersions(
        origBytes: ByteArray,
        newMinSdk: Int,
        newTargetSdk: Int? = null
    ): ByteArray {
        return patchBinaryManifestWithArscLib(
            origBytes = origBytes,
            newMinSdk = newMinSdk,
            newTargetSdk = newTargetSdk
        ).patchedBytes
    }

    /**
     * Executes the strict 4-Step APK Modification, Packaging, Zipalign & Signing Pipeline on `Dispatchers.IO`:
     * - **Step 1 (Patch Manifest):** Applies Binary AXML edits to `AndroidManifest.xml` via `ARSCLib` (`AndroidManifestBlock`)
     *   and writes the modified entries to a temporary intermediate `.apk` file.
     * - **Step 2 (Proper ZIP Packaging & Uncompressed Resources):** Ensures `resources.arsc` and all `.so` native libraries
     *   are stored uncompressed (`ZipEntry.STORED` with exact `size`, `compressedSize`, and `crc` checksums) and strips
     *   all old signature files from `META-INF/` (`*.SF`, `*.RSA`, `*.DSA`, `*.EC`, `MANIFEST.MF`).
     * - **Step 3 (4-Byte / 4096-Byte Zipalign):** Aligns all uncompressed entries in the APK to a 4-byte boundary
     *   (and 4096-byte boundary for `.so` files), strictly required by Android 11+.
     * - **Step 4 (Official Google V1 + V2 + V3 Signing):** Generates/persists a valid RSA 2048-bit self-signed certificate
     *   in app storage and signs the aligned APK using `com.android.apksig.ApkSigner` with `v1SigningEnabled = true`,
     *   `v2SigningEnabled = true`, and `v3SigningEnabled = true`.
     */
    suspend fun fixAndRebuildApk(
        context: Context,
        sourceApk: ApkFileInfo,
        targetVersion: TargetAndroidVersion,
        alsoUpdateTargetSdk: Boolean = false,
        onProgress: suspend (FixProgressStage, Float, String) -> Unit
    ): FixResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val logs = mutableListOf<String>()

        fun log(msg: String) {
            logs.add(msg)
        }

        val sourceFile = sourceApk.localFile
        require(sourceFile.exists() && sourceFile.length() > 0L) {
            "ملف APK المصدر غير موجود أو فارغ"
        }

        val desiredMinSdk = targetVersion.minSdk
        val shouldUpdateTargetSdk = alsoUpdateTargetSdk || (targetVersion == TargetAndroidVersion.UNIVERSAL && alsoUpdateTargetSdk)
        val desiredTargetSdk = if (shouldUpdateTargetSdk) {
            targetVersion.apiLevel
        } else {
            sourceApk.detectedTargetSdk ?: targetVersion.apiLevel
        }

        log("🚀 بدء معالجة الحزمة: ${sourceApk.fileName} (${sourceApk.formattedSize})")
        log("📦 اسم الحزمة الأصلي (محفوظ بالكامل): ${sourceApk.packageName}")
        log("🎯 الإعدادات: minSdkVersion = $desiredMinSdk" +
            if (shouldUpdateTargetSdk) " | targetSdkVersion = $desiredTargetSdk" else " (مع الحفاظ على targetSdkVersion الأصلي)")

        val workspaceDir = File(context.cacheDir, "apk_pipeline_${System.currentTimeMillis()}").apply { mkdirs() }
        val step1IntermediateApk = File(workspaceDir, "step1_patched_intermediate.apk")
        val step3AlignedUnsignedApk = File(workspaceDir, "step3_aligned_unsigned.apk")
        val step4SignedTempApk = File(workspaceDir, "step4_signed_temp.apk")

        val cleanAppName = sourceApk.fileName
            .substringBeforeLast(".apk")
            .replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .ifBlank { "App" }
        val finalApkName = "Fixed_$cleanAppName.apk"

        val outputApkDir = File(context.cacheDir, "fixed_apks").apply { mkdirs() }
        val finalSignedApk = File(outputApkDir, finalApkName)

        try {
            // =========================================================================
            // STEP 1: BINARY AXML MANIFEST PATCHING VIA REAndroid/ARSCLib
            // =========================================================================
            onProgress(
                FixProgressStage.EXTRACTING,
                0.15f,
                "الخطوة 1/4: جاري فحص وتعديل AndroidManifest.xml ثنائياً عبر ARSCLib..."
            )

            val originalManifestBytes: ByteArray
            ZipFile(sourceFile).use { zip ->
                val manifestEntry = zip.getEntry("AndroidManifest.xml")
                    ?: throw IllegalStateException("الملف المختار لا يحتوي على AndroidManifest.xml صالح")
                originalManifestBytes = zip.getInputStream(manifestEntry).readBytes()
            }

            val beforeInspection = inspectBinaryManifest(originalManifestBytes)
            log("🔍 القيم الأصلية في <uses-sdk>: minSdkVersion=${beforeInspection.minSdkVersion ?: "غير محدد"}, targetSdkVersion=${beforeInspection.targetSdkVersion ?: "غير محدد"}")

            onProgress(
                FixProgressStage.MODIFYING_MANIFEST,
                0.35f,
                "الخطوة 1/4: جاري تطبيق تعديلات <uses-sdk> و android:exported=\"true\" عبر ARSCLib..."
            )

            val patchOutput = patchBinaryManifestWithArscLib(
                origBytes = originalManifestBytes,
                newMinSdk = desiredMinSdk,
                newTargetSdk = if (shouldUpdateTargetSdk) desiredTargetSdk else null
            )

            // Write Step 1 intermediate APK containing the ARSCLib-patched AndroidManifest.xml
            val strippedCount = writeStep1IntermediateApk(
                sourceApkFile = sourceFile,
                patchedManifestBytes = patchOutput.patchedBytes,
                intermediateApkFile = step1IntermediateApk
            )

            log("✅ الخطوة 1 (ARSCLib): تم تحديث minSdkVersion=${patchOutput.minSdkVersion}, targetSdkVersion=${patchOutput.targetSdkVersion}")
            if (patchOutput.exportedComponentsPatchedCount > 0) {
                log("🛡️ الخطوة 1 (توافق Android 12+): تمت إضافة android:exported=\"true\" تلقائياً لـ ${patchOutput.exportedComponentsPatchedCount} مكونات تحتوي على <intent-filter>.")
            } else {
                log("🛡️ الخطوة 1 (توافق Android 12+): جميع المكونات التي تحتوي على <intent-filter> مضبوطة مسبقاً بشكل سليم.")
            }
            log("🧹 الخطوة 2 (تنظيف التواقيع): تم حذف $strippedCount ملفات توقيع قديمة من META-INF/ لمنع تعارض التواقيع.")

            // =========================================================================
            // STEP 2 & STEP 3: UNCOMPRESSED PACKAGING + 4-BYTE / 4096-BYTE ZIPALIGN
            // =========================================================================
            onProgress(
                FixProgressStage.REBUILDING_APK,
                0.65f,
                "الخطوة 2 و 3: جاري حفظ resources.arsc و .so بوضع STORED غير مضغوط ومحاذاة Zipalign (4B / 4096B)..."
            )

            val alignedStats = zipalignIntermediateApk(
                intermediateApkFile = step1IntermediateApk,
                alignedOutputApkFile = step3AlignedUnsignedApk
            )

            log("📐 الخطوة 3 (Zipalign): تمت محاذاة ${alignedStats.storedAlignedCount} ملفات غير مضغوطة (resources.arsc على 4-Byte ومكتبات .so على 4096-Byte).")

            // =========================================================================
            // STEP 4: OFFICIAL GOOGLE V1 + V2 + V3 SIGNING (RSA 2048-BIT)
            // =========================================================================
            onProgress(
                FixProgressStage.SIGNING_APK,
                0.88f,
                "الخطوة 4/4: جاري التوقيع الرقمي الرسمي عبر Google ApkSigner (V1 + V2 + V3)..."
            )

            signApkWithApksigV1V2V3(
                context = context,
                alignedUnsignedApk = step3AlignedUnsignedApk,
                outputSignedApk = step4SignedTempApk,
                minSdkVersion = patchOutput.minSdkVersion
            )

            // Safely copy, flush, and close the final signed APK to cacheDir/fixed_apks for FileProvider
            FileOutputStream(finalSignedApk).use { fos ->
                step4SignedTempApk.inputStream().use { input ->
                    input.copyTo(fos, bufferSize = BUFFER_SIZE)
                }
                safeFlushAndSync(fos)
            }

            if (!finalSignedApk.exists() || finalSignedApk.length() <= 0L) {
                throw IllegalStateException("فشل إنشاء ملف APK الموقع النهائي")
            }

            // Best-effort copy to public Downloads directory
            val savedToDownloads = trySaveCopyToPublicDownloads(context, finalSignedApk, finalApkName)
            if (savedToDownloads) {
                log("💾 تم حفظ نسخة تلقائياً في مجلد التنزيلات (Downloads/$finalApkName).")
            }
            log("✍️ الخطوة 4 (ApkSigner): تم التوقيع بنجاح بصيغ V1 (JAR) + V2 + V3 بمفتاح RSA 2048-bit.")

            onProgress(
                FixProgressStage.COMPLETED,
                1.0f,
                "تم إصلاح ومحاذاة وتوقيع التطبيق بنجاح! جاهز للتثبيت."
            )

            val durationMs = System.currentTimeMillis() - startTime
            log("🎉 اكتملت المراحل الأربع بنجاح في ${durationMs}ms.")

            FixResult(
                outputApkFile = finalSignedApk,
                outputFileName = finalApkName,
                packageName = patchOutput.packageName.ifEmpty { sourceApk.packageName },
                originalSizeBytes = sourceApk.fileSizeBytes,
                finalSizeBytes = finalSignedApk.length(),
                originalMinSdk = beforeInspection.minSdkVersion,
                originalTargetSdk = beforeInspection.targetSdkVersion,
                patchedMinSdk = patchOutput.minSdkVersion,
                patchedTargetSdk = patchOutput.targetSdkVersion,
                storedAlignedEntriesCount = alignedStats.storedAlignedCount,
                strippedMetaInfSignaturesCount = strippedCount,
                signedSchemesSummary = "V1 (JAR) + V2 + V3 (RSA-2048)",
                exportedComponentsCount = patchOutput.exportedComponentsPatchedCount,
                executionDurationMs = durationMs,
                logs = logs
            )
        } finally {
            workspaceDir.deleteRecursively()
        }
    }

    /**
     * Step 1 & Step 2 helper: Writes the `ARSCLib`-patched `AndroidManifest.xml` and all non-signature
     * entries from `sourceApkFile` into `intermediateApkFile`, stripping old `META-INF/` signatures
     * and preserving `resources.arsc` and `.so` libraries as `ZipEntry.STORED`.
     */
    private fun writeStep1IntermediateApk(
        sourceApkFile: File,
        patchedManifestBytes: ByteArray,
        intermediateApkFile: File
    ): Int {
        var strippedSignaturesCount = 0
        val writtenNames = HashSet<String>()
        val copyBuffer = ByteArray(BUFFER_SIZE)

        FileOutputStream(intermediateApkFile).use { fos ->
            BufferedOutputStream(fos, BUFFER_SIZE).use { bos ->
                ZipOutputStream(bos).use { zos ->
                    zos.setLevel(Deflater.DEFAULT_COMPRESSION)

                    // Write ARSCLib-patched AndroidManifest.xml
                    val manifestEntry = ZipEntry("AndroidManifest.xml").apply {
                        method = ZipEntry.DEFLATED
                        time = FIXED_ZIP_TIME
                    }
                    zos.putNextEntry(manifestEntry)
                    zos.write(patchedManifestBytes)
                    zos.closeEntry()
                    writtenNames.add("AndroidManifest.xml")

                    ZipFile(sourceApkFile).use { zipFile ->
                        val entries = zipFile.entries()
                        while (entries.hasMoreElements()) {
                            val origEntry = entries.nextElement()
                            val name = origEntry.name

                            if (origEntry.isDirectory || name in writtenNames) {
                                continue
                            }

                            if (isSignatureFileInMetaInf(name)) {
                                strippedSignaturesCount++
                                continue
                            }

                            writtenNames.add(name)

                            val isResourcesArsc = (name == "resources.arsc")
                            val isNativeSo = name.endsWith(".so", ignoreCase = true)
                            val mustStoreUncompressed = isResourcesArsc || isNativeSo || (origEntry.method == ZipEntry.STORED)

                            if (mustStoreUncompressed) {
                                var exactSize = 0L
                                val crc = CRC32()
                                zipFile.getInputStream(origEntry).use { input ->
                                    var read = input.read(copyBuffer)
                                    while (read != -1) {
                                        crc.update(copyBuffer, 0, read)
                                        exactSize += read
                                        read = input.read(copyBuffer)
                                    }
                                }

                                val storedEntry = ZipEntry(name).apply {
                                    method = ZipEntry.STORED
                                    size = exactSize
                                    compressedSize = exactSize
                                    this.crc = crc.value
                                    time = FIXED_ZIP_TIME
                                }
                                zos.putNextEntry(storedEntry)
                                zipFile.getInputStream(origEntry).use { input ->
                                    var read = input.read(copyBuffer)
                                    while (read != -1) {
                                        zos.write(copyBuffer, 0, read)
                                        read = input.read(copyBuffer)
                                    }
                                }
                                zos.closeEntry()
                            } else {
                                val deflatedEntry = ZipEntry(name).apply {
                                    method = ZipEntry.DEFLATED
                                    time = FIXED_ZIP_TIME
                                }
                                zos.putNextEntry(deflatedEntry)
                                zipFile.getInputStream(origEntry).use { input ->
                                    var read = input.read(copyBuffer)
                                    while (read != -1) {
                                        zos.write(copyBuffer, 0, read)
                                        read = input.read(copyBuffer)
                                    }
                                }
                                zos.closeEntry()
                            }
                        }
                    }

                    zos.finish()
                    zos.flush()
                }
                bos.flush()
            }
            safeFlushAndSync(fos)
        }

        return strippedSignaturesCount
    }

    data class ZipalignStats(
        val storedAlignedCount: Int
    )

    /**
     * Step 3: Reads `intermediateApkFile` and writes `alignedOutputApkFile` with strict Zipalign:
     * - `resources.arsc` and all other uncompressed `ZipEntry.STORED` entries are aligned to a **4-byte** boundary.
     * - All `.so` native shared libraries are stored uncompressed (`ZipEntry.STORED`) and aligned to a **4096-byte (4K)** boundary.
     */
    private fun zipalignIntermediateApk(
        intermediateApkFile: File,
        alignedOutputApkFile: File
    ): ZipalignStats {
        var storedAlignedCount = 0
        val copyBuffer = ByteArray(BUFFER_SIZE)

        FileOutputStream(alignedOutputApkFile).use { fos ->
            val bufferedOut = BufferedOutputStream(fos, BUFFER_SIZE)
            val countingOut = CountingOutputStream(bufferedOut)
            ZipOutputStream(countingOut).use { zos ->
                zos.setLevel(Deflater.DEFAULT_COMPRESSION)

                ZipFile(intermediateApkFile).use { zipFile ->
                    val entries = zipFile.entries()
                    while (entries.hasMoreElements()) {
                        val origEntry = entries.nextElement()
                        val name = origEntry.name
                        if (origEntry.isDirectory) continue

                        val isResourcesArsc = (name == "resources.arsc")
                        val isNativeSo = name.endsWith(".so", ignoreCase = true)
                        val mustStoreUncompressed = isResourcesArsc || isNativeSo || (origEntry.method == ZipEntry.STORED)

                        if (mustStoreUncompressed) {
                            val alignment = if (isNativeSo) 4096L else 4L

                            var exactSize = 0L
                            val crc = CRC32()
                            zipFile.getInputStream(origEntry).use { input ->
                                var read = input.read(copyBuffer)
                                while (read != -1) {
                                    crc.update(copyBuffer, 0, read)
                                    exactSize += read
                                    read = input.read(copyBuffer)
                                }
                            }

                            zos.flush()
                            val currentOffset = countingOut.bytesWritten
                            val nameBytesLen = name.toByteArray(Charsets.UTF_8).size
                            val lfhBaseSize = 30L + nameBytesLen
                            val unalignedPayloadOffset = currentOffset + lfhBaseSize
                            val remainder = (unalignedPayloadOffset % alignment).toInt()
                            val padBytes = if (remainder == 0) 0 else (alignment.toInt() - remainder)

                            val storedEntry = ZipEntry(name).apply {
                                method = ZipEntry.STORED
                                size = exactSize
                                compressedSize = exactSize
                                this.crc = crc.value
                                time = FIXED_ZIP_TIME
                                extra = if (padBytes > 0) ByteArray(padBytes) else null
                            }

                            zos.putNextEntry(storedEntry)
                            zipFile.getInputStream(origEntry).use { input ->
                                var read = input.read(copyBuffer)
                                while (read != -1) {
                                    zos.write(copyBuffer, 0, read)
                                    read = input.read(copyBuffer)
                                }
                            }
                            zos.closeEntry()
                            zos.flush()
                            storedAlignedCount++
                        } else {
                            val deflatedEntry = ZipEntry(name).apply {
                                method = ZipEntry.DEFLATED
                                time = FIXED_ZIP_TIME
                            }
                            zos.putNextEntry(deflatedEntry)
                            zipFile.getInputStream(origEntry).use { input ->
                                var read = input.read(copyBuffer)
                                while (read != -1) {
                                    zos.write(copyBuffer, 0, read)
                                    read = input.read(copyBuffer)
                                }
                            }
                            zos.closeEntry()
                        }
                    }
                }

                zos.finish()
                zos.flush()
            }
            countingOut.flush()
            bufferedOut.flush()
            safeFlushAndSync(fos)
        }

        return ZipalignStats(storedAlignedCount = storedAlignedCount)
    }

    /**
     * Checks if an entry in `META-INF/` is a JAR/APK signature file that must be removed
     * before re-signing (`MANIFEST.MF`, `.SF`, `.RSA`, `.DSA`, `.EC`, `SIG-*`, `STAMP-CERT*`).
     */
    private fun isSignatureFileInMetaInf(entryName: String): Boolean {
        val norm = entryName.replace('\\', '/')
        if (!norm.startsWith("META-INF/", ignoreCase = true)) return false
        val sub = norm.substringAfter("META-INF/").uppercase(Locale.US)
        if (sub == "MANIFEST.MF") return true
        if (sub.endsWith(".SF") ||
            sub.endsWith(".RSA") ||
            sub.endsWith(".DSA") ||
            sub.endsWith(".EC") ||
            sub.startsWith("SIG-") ||
            sub.contains("STAMP-CERT")
        ) {
            return true
        }
        return false
    }

    /**
     * Step 4: Signs `alignedUnsignedApk` into `outputSignedApk` using Google's official `com.android.apksig.ApkSigner`
     * with v1, v2, and v3 signing schemes enabled and an RSA 2048-bit key persisted in app storage.
     */
    private fun signApkWithApksigV1V2V3(
        context: Context,
        alignedUnsignedApk: File,
        outputSignedApk: File,
        minSdkVersion: Int
    ) {
        val signerConfig = loadOrCreatePersistedRsaSignerConfig(context)
        RandomAccessFile(alignedUnsignedApk, "r").use { inputRaf ->
            RandomAccessFile(outputSignedApk, "rw").use { outputRaf ->
                outputRaf.setLength(0L)
                val apkSigner = ApkSigner.Builder(listOf(signerConfig))
                    .setMinSdkVersion(minOf(minSdkVersion, 21).coerceAtLeast(18))
                    .setV1SigningEnabled(true)
                    .setV2SigningEnabled(true)
                    .setV3SigningEnabled(true)
                    .setInputApk(DataSources.asDataSource(inputRaf))
                    .setOutputApk(DataSinks.asDataSink(outputRaf), DataSources.asDataSource(outputRaf))
                    .build()
                apkSigner.sign()
                try {
                    outputRaf.fd.sync()
                } catch (_: Throwable) {
                    // Ignore SyncFailedException on virtualized tmpfs/overlayfs
                }
            }
        }
    }

    private fun safeFlushAndSync(fos: FileOutputStream) {
        fos.flush()
        try {
            fos.fd.sync()
        } catch (_: Throwable) {
            // Ignore SyncFailedException on virtualized filesystems
        }
    }

    /**
     * Persists the 2048-bit RSA PKCS#8 private key (`testkey.pk8`) and self-signed X.509 certificate
     * (`testkey.x509.der`) in `context.filesDir/signer_credentials` if not already present, ensuring
     * consistent signatures across app updates/rebuilds on the same device.
     */
    private fun loadOrCreatePersistedRsaSignerConfig(context: Context): ApkSigner.SignerConfig {
        val keyDir = File(context.filesDir, "signer_credentials").apply { mkdirs() }
        val pk8File = File(keyDir, "testkey.pk8")
        val certFile = File(keyDir, "testkey.x509.der")

        if (!pk8File.exists() || pk8File.length() == 0L || !certFile.exists() || certFile.length() == 0L) {
            val rawKeyBytes = decodeBase64Compat(EMBEDDED_RSA_PKCS8_BASE64)
            val rawCertBytes = decodeBase64Compat(EMBEDDED_X509_CERT_BASE64)
            FileOutputStream(pk8File).use { fos ->
                fos.write(rawKeyBytes)
                safeFlushAndSync(fos)
            }
            FileOutputStream(certFile).use { fos ->
                fos.write(rawCertBytes)
                safeFlushAndSync(fos)
            }
        }

        val keyBytes = pk8File.readBytes()
        val certBytes = certFile.readBytes()

        val keySpec = PKCS8EncodedKeySpec(keyBytes)
        val privateKey: PrivateKey = KeyFactory.getInstance("RSA").generatePrivate(keySpec)

        val certFactory = CertificateFactory.getInstance("X.509")
        val certificate = certFactory.generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate

        return ApkSigner.SignerConfig.Builder("CERT", privateKey, listOf(certificate)).build()
    }

    private fun decodeBase64Compat(base64String: String): ByteArray {
        return try {
            java.util.Base64.getDecoder().decode(base64String)
        } catch (_: Throwable) {
            android.util.Base64.decode(base64String, android.util.Base64.DEFAULT)
        }
    }

    /**
     * Saves a copy of the signed APK into the device's public `Downloads` folder using `MediaStore.Downloads`
     * on Android 10+ (API 29+) or standard Downloads directory on older versions.
     */
    private fun trySaveCopyToPublicDownloads(context: Context, signedApkFile: File, displayFileName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, displayFileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues) ?: return false
                resolver.openOutputStream(uri)?.use { out ->
                    signedApkFile.inputStream().use { input ->
                        input.copyTo(out, bufferSize = BUFFER_SIZE)
                    }
                    out.flush()
                }
                contentValues.clear()
                contentValues.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
                true
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (downloadsDir != null && (downloadsDir.exists() || downloadsDir.mkdirs())) {
                    val outFile = File(downloadsDir, displayFileName)
                    FileOutputStream(outFile).use { fos ->
                        signedApkFile.inputStream().use { input ->
                            input.copyTo(fos, bufferSize = BUFFER_SIZE)
                        }
                        safeFlushAndSync(fos)
                    }
                    true
                } else {
                    false
                }
            }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Triggers the Android system package installer via `FileProvider` after verifying the file exists and is non-empty.
     */
    fun installApkDirectly(context: Context, apkFile: File) {
        require(apkFile.exists() && apkFile.length() > 0L) {
            "ملف APK المعدل غير موجود أو فارغ"
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canInstall = try {
                context.packageManager.canRequestPackageInstalls()
            } catch (_: Throwable) {
                true
            }
            if (!canInstall) {
                val settingsIntent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(settingsIntent)
                return
            }
        }

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(installIntent)
    }

    /**
     * Shares the signed APK via `FileProvider`.
     */
    fun shareFixedApk(context: Context, apkFile: File) {
        require(apkFile.exists() && apkFile.length() > 0L) {
            "ملف APK المعدل غير موجود أو فارغ"
        }
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(shareIntent, "مشاركة ملف APK المعدل").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
