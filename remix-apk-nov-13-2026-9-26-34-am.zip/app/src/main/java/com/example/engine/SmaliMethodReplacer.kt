package com.example.engine

import android.content.Context
import com.android.apksig.ApkSigner
import com.example.model.ApkFileInfo
import com.example.model.ReplacedSmaliMethodInfo
import com.example.model.SmaliPatchResult
import com.example.model.SmaliReplacerStage
import com.reandroid.arsc.chunk.PackageBlock
import com.reandroid.arsc.chunk.TableBlock
import com.reandroid.arsc.chunk.TypeBlock
import com.reandroid.arsc.container.SpecTypePair
import com.reandroid.arsc.value.Entry
import com.reandroid.arsc.value.ResConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jf.dexlib2.DexFileFactory
import org.jf.dexlib2.Opcodes
import org.jf.dexlib2.iface.ClassDef
import org.jf.dexlib2.iface.DexFile
import org.jf.dexlib2.iface.Method
import org.jf.dexlib2.immutable.ImmutableClassDef
import org.jf.dexlib2.immutable.ImmutableMethod
import org.jf.dexlib2.writer.io.FileDataStore
import org.jf.dexlib2.writer.pool.DexPool
import org.jf.smali.Smali
import org.jf.smali.SmaliOptions
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Base64
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * ================================================================================================
 * Multi-Class Flexible Smali Method Replacer Engine (`SmaliMethodReplacer.kt`) — Tab 3 ("تعديل Smali")
 * ================================================================================================
 *
 * How to customize in code:
 * Define any number of target classes and their replacement `.method ... .end method` blocks inside
 * [DEFAULT_SMALI_PATCHES] (`Map<String, List<String>>`), where:
 * - **Key (`String`)**: The Smali class descriptor (e.g., `"Lcom/example/TargetClass;"`).
 * - **Value (`List<String>`)**: Any number of raw `.method ... .end method` blocks for that class.
 *
 * Pipeline:
 * 1. Scans all `classes.dex`, `classes2.dex`, `classes3.dex`, etc. inside the selected APK.
 * 2. Iterates through every `classDef` in `dexFile.classes` and checks `val targetMethodsSmali = patches[classDef.type]`.
 * 3. When matched, wraps each raw `.method ... .end method` block in a temporary valid `.class` header
 *    with `classDef.type` and `classDef.superclass`, assembles it into `dexlib2` [Method] objects using
 *    `org.jf.smali.Smali`, and replaces matching methods inside that [ClassDef] via [replaceMethodsInClassDef].
 * 4. Writes all modified `classes*.dex` files back into the APK, preserves `resources.arsc` as uncompressed
 *    (`ZipEntry.STORED`) with 4-byte alignment, and signs the final APK with `com.android.apksig.ApkSigner`
 *    (V1 + V2 + V3).
 */
object SmaliMethodReplacer {

    // ============================================================================================
    // 1. MULTI-CLASS SMALI PATCHES MAP (`DEFAULT_SMALI_PATCHES: Map<String, List<String>>`)
    //    Each key is a Smali class descriptor (e.g. "Lcom/example/TargetClass;").
    //    Each value is a List<String> of raw `.method ... .end method` blocks for that class.
    //    You can add 1 class, 2 classes, or any number of classes across classes.dex, classes2.dex, etc.
    // ============================================================================================
    val DEFAULT_SMALI_PATCHES: Map<String, List<String>> = mapOf(
        // ── Class #1: Paste target class descriptor & its raw .method ... .end method blocks ──
        "Lcom/example/TargetClass;" to listOf(
            """
            .method public isFeatureEnabled()Z
                .locals 1

                const/4 v0, 0x1
                return v0
            .end method
            """.trimIndent(),
            """
            .method public getStatusMessage()Ljava/lang/String;
                .locals 1

                const-string v0, "Smali Method Patched Successfully"
                return-object v0
            .end method
            """.trimIndent()
        ),

        // ── Class #2: You can patch additional classes in the same run (or remove/add entries) ──
        "Lcom/example/SecondTargetClass;" to listOf(
            """
            .method public getSecurityLevel()I
                .locals 1

                const/16 v0, 0x64
                return v0
            .end method
            """.trimIndent()
        )
    )

    // Backwards-compatible single-class references pointing to the first entry of DEFAULT_SMALI_PATCHES
    const val TARGET_CLASS_DESCRIPTOR: String = "Lcom/example/TargetClass;"
    val REPLACEMENT_METHODS_SMALI: List<String> =
        DEFAULT_SMALI_PATCHES[TARGET_CLASS_DESCRIPTOR] ?: emptyList()

    // ============================================================================================
    // Internal Constants & Embedded V1/V2/V3 Signing Credentials
    // ============================================================================================
    private const val BUFFER_SIZE = 64 * 1024
    private const val FIXED_ZIP_TIME = 315561600000L // 1980-01-01 00:00:00 UTC

    private const val EMBEDDED_RSA_PKCS8_BASE64 =
        "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDFU4UsYTF4NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X2mSj" +
            "OBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZTIx6W" +
            "sriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rqXVoe" +
            "mmMwqguqznCVbggN4fUFAgMBAAECggEAAU3nVM8Sb5xmhqDyMc2Na5+KsW2V5e1qEsfqJuJqn1w5ejmxhEUHg0qQdRYlXuXYhumZCnlgxxWG7yeayVhTB5RUHX1T" +
            "kx0IJ5YDSICnbw5/hRPpUP19xN2Qs+Ym55LyIl/ZuY8526Hhx09vA3oQYv7BnNbzXfR9rCRcpej3/kG78rew+mn/L0e51/rr481R4WFyL4T23zMUCg2+WvZZ0RQ+" +
            "jBNn3QaYWX1FYVzSaZ2JShSakAvtHLQwBUMg1jaqV9IIyqx9VR/dMhOG8LpIpFSMwRfQPKWniV2e6ljCVjYAKuSLoqISaWjO1FQBiwbfl6lM7CIyENHc+Dq2ZF1Z" +
            "iQKBgQDXKCFipjK7cHC51D7JR+oARRjvodnu+sMLCAZLWAtl1TJ1zLCjU/+STbLkMUWyPthE197NMB9RzINxQ8Ode124tiINF6Q7GlCU4INWzKrrLuQ41ouiwZa/" +
            "OxXnI+UgFL3FnvL8CWNfqkyKtRwc2dBtu9+Z77w7zmcMVwkxnMGE/QKBgQDqyOOe5EDEls2a3MZtDNrmw+2D/ioPSgoizIEpZdjfcPH+uSRgCQjgdHPQj27rAutJ" +
            "UNWGf3+B2cTgzKMCngi/U+LoonVkIKe1G357HZwZp5L9EskcSG/tY5MqNu3EbCdbQLNVqWPZNDHINiFvllZJp466BrL1n73HkY/sHTLyqQKBgFQ6aZds6L9oLTkS" +
            "VeIGPR0N780f12ku0dwnsA8e0Jd09uQW1a+a2pozwKyEfXxiDdglihtZk2k6XtqgZJvqB66f3oSxlKFuk800dzYruV2IZd+6Xb/BeXozb0elTbVZaVFMAGOaaUSy" +
            "LnS+odrJikbrHYXtzAq9qqmyCO9bJochAoGAbXOpaXFPIFaNExzJBB1yDxJXr6jVQrtpbj+YFwx7xe6JYg49fue3U6v2McwsETMTLOKaKFFXx9kVhxbfB2FVApzA" +
            "s2LJBxySEkP2+r4a/3q3c3NGfgDm7Ov2tz9UKLWiw0+uSsjk22URsBxMChEzuLJ8PwzQcOE/P8IELjaOgcECgYEAjnI+aSRfhE1xdbFQplbapzpj1/kfTCPudJbI" +
            "zOOmET088NtS1G4sJjrGALe4agQtFqvVsU3s8sv9Z8bMdzlx2yAsxOQtBgKW35RQ4HwNyPxlP3l+UGdgicWCGlDegMTprYthSrhjBNdeY0M4Fhi66ZV6h+EqxXzz" +
            "89Vo1vrX4Ic="

    private const val EMBEDDED_X509_CERT_BASE64 =
        "MIIC+DCCAeCgAwIBAgIQP11r3V28MrQX7vLoc9+ZtTANBgkqhkiG9w0BAQsFADA3MQswCQYDVQQGEwJVUzEQMA4GA1UEChMHQW5kcm9pZDEWMBQGA1UEAxMNQW5k" +
            "cm9pZCBEZWJ1ZzAgFw0yNjExMDcwMjE5NTFaGA8yMDU0MDMyNjAyMTk1MVowNzELMAkGA1UEBhMCVVMxEDAOBgNVBAoTB0FuZHJvaWQxFjAUBgNVBAMTDUFuZHJv" +
            "aWQgRGVidWcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFU4UsYTF4NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X" +
            "2mSjOBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZT" +
            "Ix6WsriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rq" +
            "XVoemmMwqguqznCVbggN4fUFAgMBAAEwDQYJKoZIhvcNAQELBQADggEBACVMg0rOu03ptqGLuaZ//q8o3sC9XjjT/p+qh9zcMQFCnO1v2OXW6ClhkaFAgLhNa10H" +
            "tm5zjNME4d/FFBxtR8wfyvUbkaCQVugVRLUVAZBM7+xbsrzvyh0/JZKLDYjEj+LGZADwKr7Ut9WEzd62h85NmBEspDTG6AwybJJ0CFPdF4mh+8+GZfX98c7K01MW" +
            "rtAncV154+rmEKnm/X1rUXFHrJBiLEx611nWTAi0y7uJ3iAOdj0G6KP2bK1/JCcct8O9gOO7+yFSDdPbNwIu05kOLUzyLDLbwdcZmGJZRfBR5Z0delQAhKy7GlPt" +
            "AWCArU0VE7O2QzKZlMCcNeegxME="

    /**
     * Normalizes either `"com.example.TargetClass"` or `"Lcom/example/TargetClass;"`
     * into standard Smali type descriptor format `"Lcom/example/TargetClass;"`.
     */
    fun normalizeClassDescriptor(rawDescriptor: String): String {
        val trimmed = rawDescriptor.trim()
        require(trimmed.isNotEmpty()) { "Target class descriptor cannot be empty." }
        if (trimmed.startsWith("L") && trimmed.endsWith(";")) {
            return trimmed.replace('.', '/')
        }
        val slashName = trimmed.removePrefix("L").removeSuffix(";").replace('.', '/')
        return "L$slashName;"
    }

    /**
     * Lists all `classes*.dex` entry names inside [apkFile] sorted in natural DEX order:
     * `classes.dex`, `classes2.dex`, `classes3.dex`, ...
     */
    fun listDexEntriesInApk(apkFile: File): List<String> {
        val dexRegex = Regex("""^classes(\d*)\.dex$""")
        val entries = mutableListOf<String>()
        ZipFile(apkFile).use { zip ->
            val enumEntries = zip.entries()
            while (enumEntries.hasMoreElements()) {
                val entry = enumEntries.nextElement()
                if (!entry.isDirectory && dexRegex.matches(entry.name)) {
                    entries.add(entry.name)
                }
            }
        }
        return entries.sortedWith(
            compareBy { name ->
                val numStr = dexRegex.find(name)?.groupValues?.getOrNull(1).orEmpty()
                if (numStr.isEmpty()) 1 else numStr.toIntOrNull() ?: Int.MAX_VALUE
            }
        )
    }

    /**
     * Step 1: Assembles every raw `.method ... .end method` string in [rawMethodsSmali]
     * into `dexlib2` [Method] instances using `org.jf.smali.Smali`.
     *
     * Each block is temporarily wrapped in a valid `.class` header with [targetClassDescriptor]
     * and [superclassDescriptor] so `Smali` parses all instructions, registers, labels, try/catch
     * blocks, and field/method references cleanly without any hardcoded assumptions.
     */
    fun assembleSmaliMethods(
        targetClassDescriptor: String,
        superclassDescriptor: String = "Ljava/lang/Object;",
        rawMethodsSmali: List<String>,
        apiLevel: Int = 26,
        workDir: File
    ): List<Method> {
        val normalizedClass = normalizeClassDescriptor(targetClassDescriptor)
        val nonEmptyBlocks = rawMethodsSmali.map { it.trim() }.filter { it.isNotEmpty() }
        require(nonEmptyBlocks.isNotEmpty()) {
            "قائمة دوال Smali للكلاس ($normalizedClass) فارغة. يرجى لصق دالة .method ... .end method واحدة على الأقل."
        }

        val smaliTempDir = File(workDir, "smali_assemble_${System.nanoTime()}").apply { mkdirs() }
        try {
            val assembledMethods = mutableListOf<Method>()

            nonEmptyBlocks.forEachIndexed { index, rawBlock ->
                val fullSmaliSource = if (rawBlock.lineSequence().any { it.trim().startsWith(".class ") }) {
                    rawBlock
                } else {
                    require(rawBlock.contains(".method ") && rawBlock.contains(".end method")) {
                        "الكتلة رقم #${index + 1} في الكلاس ($normalizedClass) لا تحتوي على ترويسة .method ... .end method صالحة."
                    }
                    buildString {
                        appendLine(".class public $normalizedClass")
                        appendLine(".super $superclassDescriptor")
                        appendLine()
                        appendLine(rawBlock)
                    }
                }

                val smaliFile = File(smaliTempDir, "MethodBlock_${index + 1}.smali")
                smaliFile.writeText(fullSmaliSource, Charsets.UTF_8)

                val outDexFile = File(smaliTempDir, "MethodBlock_${index + 1}.dex")
                val smaliOptions = SmaliOptions().apply {
                    outputDexFile = outDexFile.absolutePath
                    this.apiLevel = apiLevel.coerceAtLeast(15)
                }

                val success = Smali.assemble(smaliOptions, listOf(smaliFile.absolutePath))
                if (!success || !outDexFile.exists() || outDexFile.length() == 0L) {
                    throw IllegalArgumentException(
                        "فشل تجميع كود Smali في الكتلة رقم #${index + 1} للكلاس ($normalizedClass) عبر org.smali:smali. تحقق من صحة صياغة التعليمات."
                    )
                }

                val dexFile = DexFileFactory.loadDexFile(outDexFile, Opcodes.forApi(smaliOptions.apiLevel))
                val assembledClass = dexFile.classes.firstOrNull { it.type == normalizedClass }
                    ?: dexFile.classes.firstOrNull()
                    ?: throw IllegalStateException("لم يتم العثور على الكلاس المجمّع داخل ملف DEX المؤقت.")

                for (method in assembledClass.methods) {
                    assembledMethods.add(ImmutableMethod.of(method))
                }
            }

            return assembledMethods
        } finally {
            smaliTempDir.deleteRecursively()
        }
    }

    /**
     * Helper to build a canonical method signature key: `name(param1Type,param2Type,...)returnType`.
     * Matches strictly by `method.name`, `method.parameterTypes`, and `method.returnType`.
     */
    fun methodSignatureKey(method: Method): String {
        val params = method.parameterTypes.joinToString(separator = "") { it.toString() }
        return "${method.name}($params)${method.returnType}"
    }

    /**
     * Replaces matching methods inside [targetClassDef] using the assembled [replacementMethods]
     * matched by (`method.name`, `method.parameterTypes`, `method.returnType`), while preserving
     * all other untouched methods, fields, annotations, and class metadata.
     */
    fun replaceMethodsInClassDef(
        targetClassDef: ClassDef,
        replacementMethods: List<Method>,
        dexFileName: String
    ): Pair<ClassDef, List<ReplacedSmaliMethodInfo>> {
        val replacementByKey = LinkedHashMap<String, Method>()
        for (m in replacementMethods) {
            replacementByKey[methodSignatureKey(m)] = m
        }

        val replacedInfos = mutableListOf<ReplacedSmaliMethodInfo>()

        val updatedDirectMethods = targetClassDef.directMethods.map { origMethod ->
            val key = methodSignatureKey(origMethod)
            val replacement = replacementByKey[key]
            if (replacement != null) {
                replacedInfos.add(
                    ReplacedSmaliMethodInfo(
                        classDescriptor = targetClassDef.type,
                        methodName = replacement.name,
                        parameterTypes = replacement.parameterTypes.map { it.toString() },
                        returnType = replacement.returnType,
                        isDirectMethod = true,
                        dexFileName = dexFileName
                    )
                )
                ImmutableMethod.of(replacement)
            } else {
                origMethod
            }
        }

        val updatedVirtualMethods = targetClassDef.virtualMethods.map { origMethod ->
            val key = methodSignatureKey(origMethod)
            val replacement = replacementByKey[key]
            if (replacement != null) {
                replacedInfos.add(
                    ReplacedSmaliMethodInfo(
                        classDescriptor = targetClassDef.type,
                        methodName = replacement.name,
                        parameterTypes = replacement.parameterTypes.map { it.toString() },
                        returnType = replacement.returnType,
                        isDirectMethod = false,
                        dexFileName = dexFileName
                    )
                )
                ImmutableMethod.of(replacement)
            } else {
                origMethod
            }
        }

        val updatedClassDef = ImmutableClassDef(
            targetClassDef.type,
            targetClassDef.accessFlags,
            targetClassDef.superclass,
            targetClassDef.interfaces,
            targetClassDef.sourceFile,
            targetClassDef.annotations,
            targetClassDef.staticFields,
            targetClassDef.instanceFields,
            updatedDirectMethods,
            updatedVirtualMethods
        )

        return Pair(updatedClassDef, replacedInfos)
    }

    /**
     * Multi-class end-to-end Smali Method Replacement + Repackaging + 4-Byte `resources.arsc` Alignment +
     * `com.android.apksig.ApkSigner` (V1 + V2 + V3) signing pipeline.
     *
     * Accepts [patches] (`Map<String, List<String>>`) mapping each target Smali class descriptor
     * to its list of raw `.method ... .end method` blocks. Scans all `classes*.dex` files in one pass
     * so classes spread across `classes.dex`, `classes2.dex`, `classes3.dex`, etc. are all patched.
     */
    suspend fun replaceMethodsAndSignApk(
        context: Context,
        sourceApk: ApkFileInfo,
        patches: Map<String, List<String>> = DEFAULT_SMALI_PATCHES,
        onLog: (String) -> Unit = {},
        onProgress: (stage: SmaliReplacerStage, percent: Int, statusText: String) -> Unit = { _, _, _ -> }
    ): SmaliPatchResult = withContext(Dispatchers.IO) {
        val inputFile = sourceApk.localFile
        require(inputFile.exists() && inputFile.length() > 0L) {
            "ملف APK المختار غير موجود أو فارغ."
        }

        // Normalize all keys in patches map to standard "Lcom/pkg/ClassName;" format
        val normalizedPatches = LinkedHashMap<String, List<String>>()
        for ((rawClassDesc, methodsList) in patches) {
            val cleanMethods = methodsList.map { it.trim() }.filter { it.isNotEmpty() }
            if (rawClassDesc.isNotBlank() && cleanMethods.isNotEmpty()) {
                val normKey = normalizeClassDescriptor(rawClassDesc)
                val existing = normalizedPatches[normKey]
                normalizedPatches[normKey] = if (existing != null) existing + cleanMethods else cleanMethods
            }
        }
        require(normalizedPatches.isNotEmpty()) {
            "خريطة تعديلات Smali (patches) فارغة. يرجى إدخال كلاس مستهدف واحد ودالة واحدة على الأقل."
        }

        val workDir = File(context.cacheDir, "smali_replacer_work_${System.currentTimeMillis()}").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        val outputDir = File(context.filesDir, "smali_patched_apks").apply { mkdirs() }
        val sanitizedBaseName = sourceApk.fileName
            .removeSuffix(".apk")
            .replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val finalSignedApk = File(outputDir, "${sanitizedBaseName}_SmaliPatched_Signed.apk")
        if (finalSignedApk.exists()) finalSignedApk.delete()

        val unsignedAlignedApk = File(workDir, "unsigned_aligned.apk")

        try {
            // ── STAGE 1: Preliminary Assembly Validation of All Classes in `patches` ──
            onProgress(
                SmaliReplacerStage.ASSEMBLING_SMALI,
                12,
                "جاري التحقق من دوال Smali لـ ${normalizedPatches.size} كلاس عبر org.smali:smali..."
            )
            onLog("▶ عدد الكلاسات المستهدفة في الخريطة (patches): ${normalizedPatches.size}")

            for ((classDesc, rawMethodsList) in normalizedPatches) {
                onLog("• الكلاس المستهدف: $classDesc (${rawMethodsList.size} كتلة Smali)")
                val previewMethods = assembleSmaliMethods(
                    targetClassDescriptor = classDesc,
                    superclassDescriptor = "Ljava/lang/Object;",
                    rawMethodsSmali = rawMethodsList,
                    apiLevel = 26,
                    workDir = workDir
                )
                for (m in previewMethods) {
                    onLog("  ✓ تم التحقق من صياغة الدالة: $classDesc->${methodSignatureKey(m)}")
                }
            }

            // ── STAGE 2: Scan ALL classes.dex, classes2.dex, classes3.dex... in one pass ──
            onProgress(
                SmaliReplacerStage.SCANNING_DEX,
                30,
                "جاري فحص جميع ملفات classes*.dex داخل الـ APK..."
            )

            val dexEntryNames = listDexEntriesInApk(inputFile)
            require(dexEntryNames.isNotEmpty()) {
                "لم يتم العثور على أي ملف classes*.dex داخل ملف الـ APK المختار."
            }
            onLog("▶ ملفات DEX المكتشفة (${dexEntryNames.size}): ${dexEntryNames.joinToString(", ")}")

            val patchedDexByEntryName = LinkedHashMap<String, ByteArray>()
            val patchedClassDescriptors = mutableListOf<String>()
            val allReplacedMethods = mutableListOf<ReplacedSmaliMethodInfo>()
            val allUnmatchedSignatures = mutableListOf<String>()
            var totalMethodsInPatchedClasses = 0

            ZipFile(inputFile).use { zip ->
                for ((dexIdx, dexName) in dexEntryNames.withIndex()) {
                    val scanProgress = 30 + ((dexIdx + 1) * 35 / dexEntryNames.size)
                    onProgress(
                        SmaliReplacerStage.PATCHING_DEX,
                        scanProgress,
                        "جاري فحص وتعديل الكلاسات المطابقة داخل $dexName..."
                    )
                    onLog("• جاري فحص $dexName...")

                    val entry = zip.getEntry(dexName) ?: continue
                    val tempInDex = File(workDir, "scan_$dexName")
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(tempInDex).use { output ->
                            input.copyTo(output, BUFFER_SIZE)
                        }
                    }

                    val loadedDex = DexFileFactory.loadDexFile(tempInDex, Opcodes.getDefault())
                    val dexApi = loadedDex.opcodes.api.coerceAtLeast(15)
                    var isCurrentDexModified = false
                    val updatedClasses = ArrayList<ClassDef>(loadedDex.classes.size)

                    for (classDef in loadedDex.classes) {
                        val targetMethodsSmali = normalizedPatches[classDef.type]
                        if (targetMethodsSmali != null) {
                            val classMethodCount = classDef.methods.count()
                            totalMethodsInPatchedClasses += classMethodCount
                            val superclass = classDef.superclass ?: "Ljava/lang/Object;"

                            onLog("★ [$dexName] تم العثور على الكلاس المستهدف: ${classDef.type} (Superclass: $superclass، إجمالي الدوال: $classMethodCount)")

                            val assembledForClass = assembleSmaliMethods(
                                targetClassDescriptor = classDef.type,
                                superclassDescriptor = superclass,
                                rawMethodsSmali = targetMethodsSmali,
                                apiLevel = dexApi,
                                workDir = workDir
                            )

                            val (updatedClassDef, replacedInfos) = replaceMethodsInClassDef(
                                targetClassDef = classDef,
                                replacementMethods = assembledForClass,
                                dexFileName = dexName
                            )

                            val replacedKeySet = replacedInfos.map { it.fullSignature }.toSet()
                            val unmatchedForClass = assembledForClass
                                .map { methodSignatureKey(it) }
                                .filter { it !in replacedKeySet }
                                .map { "${classDef.type}->$it" }
                            allUnmatchedSignatures.addAll(unmatchedForClass)

                            for (info in replacedInfos) {
                                val kindLabel = if (info.isDirectMethod) "Direct/Static/Constructor" else "Virtual"
                                onLog("  ✓ [$dexName] تم استبدال: ${classDef.type}->${info.fullSignature} ($kindLabel)")
                            }

                            for (unmatched in unmatchedForClass) {
                                onLog("  ⚠ تنبيه: الدالة $unmatched غير موجودة بهذا التوقيع في الكلاس.")
                            }

                            if (replacedInfos.isNotEmpty()) {
                                isCurrentDexModified = true
                                if (classDef.type !in patchedClassDescriptors) {
                                    patchedClassDescriptors.add(classDef.type)
                                }
                                allReplacedMethods.addAll(replacedInfos)
                                updatedClasses.add(updatedClassDef)
                            } else {
                                updatedClasses.add(classDef)
                            }
                        } else {
                            updatedClasses.add(classDef)
                        }
                    }

                    if (isCurrentDexModified) {
                        val updatedDexFile = object : DexFile {
                            override fun getClasses(): Set<ClassDef> = LinkedHashSet(updatedClasses)
                            override fun getOpcodes(): Opcodes = loadedDex.opcodes
                        }

                        val tempOutDex = File(workDir, "patched_$dexName")
                        val dexPool = DexPool(loadedDex.opcodes)
                        for (cls in updatedDexFile.classes) {
                            dexPool.internClass(cls)
                        }
                        dexPool.writeTo(FileDataStore(tempOutDex))
                        val bytes = tempOutDex.readBytes()
                        patchedDexByEntryName[dexName] = bytes
                        onLog("✓ تم إعادة بناء $dexName بنجاح (${bytes.size / 1024} KB).")
                        tempOutDex.delete()
                    }

                    tempInDex.delete()
                }
            }

            if (patchedDexByEntryName.isEmpty() || allReplacedMethods.isEmpty()) {
                val requestedClasses = normalizedPatches.keys.joinToString(", ")
                throw IllegalArgumentException(
                    "لم يتم العثور على أي كلاس/دالة مطابقة من ($requestedClasses) داخل ملفات (${dexEntryNames.joinToString(", ")})."
                )
            }

            val missingClasses = normalizedPatches.keys.filter { it !in patchedClassDescriptors }
            for (missingClass in missingClasses) {
                onLog("⚠ ملاحظة: الكلاس $missingClass لم يتم العثور عليه في ملفات DEX لهذا الـ APK.")
            }

            // ── STAGE 4: Repackage APK with 4-byte aligned STORED resources.arsc ──
            onProgress(
                SmaliReplacerStage.REBUILDING_APK,
                75,
                "جاري إعادة حزم الـ APK ومحاذاة resources.arsc (4-Byte STORED)..."
            )
            onLog("▶ جاري إعادة حزم ملفات الـ APK (${patchedDexByEntryName.keys.joinToString(", ")}) مع محاذاة resources.arsc على 4 بايت...")

            repackageApkWithPatchedDex(
                sourceApkFile = inputFile,
                patchedDexByEntryName = patchedDexByEntryName,
                unsignedAlignedOutputApk = unsignedAlignedApk
            )

            // ── STAGE 5: Sign APK with V1 + V2 + V3 via Google's official ApkSigner ──
            onProgress(
                SmaliReplacerStage.SIGNING_APK,
                90,
                "جاري توقيع الـ APK بالتوقيع الرقمي الشامل (V1 + V2 + V3)..."
            )
            onLog("▶ جاري التوقيع الرقمي عبر com.android.apksig.ApkSigner (V1 + V2 + V3)...")

            val credentials = loadOrCreateSigningCredentials(context)
            val signerConfig = ApkSigner.SignerConfig.Builder(
                "CERT",
                credentials.privateKey,
                listOf(credentials.certificate)
            ).build()

            val apkSigner = ApkSigner.Builder(listOf(signerConfig))
                .setInputApk(unsignedAlignedApk)
                .setOutputApk(finalSignedApk)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .setOtherSignersSignaturesPreserved(false)
                .build()

            apkSigner.sign()

            require(finalSignedApk.exists() && finalSignedApk.length() > 0L) {
                "فشل حفظ ملف APK الموقّع النهائي."
            }

            val modifiedDexNamesList = patchedDexByEntryName.keys.toList()
            onLog("✓ اكتملت العملية بنجاح! تم تعديل ${patchedClassDescriptors.size} كلاس (${allReplacedMethods.size} دالة) في [${modifiedDexNamesList.joinToString(", ")}].")
            onProgress(
                SmaliReplacerStage.COMPLETED,
                100,
                "تم تعديل ${patchedClassDescriptors.size} كلاس (${allReplacedMethods.size} دالة) وتوقيع الـ APK بنجاح!"
            )

            SmaliPatchResult(
                outputApkFile = finalSignedApk,
                outputFileName = finalSignedApk.name,
                packageName = sourceApk.packageName,
                patchedClassDescriptors = patchedClassDescriptors,
                modifiedDexFileNames = modifiedDexNamesList,
                scannedDexFiles = dexEntryNames,
                replacedMethods = allReplacedMethods,
                unmatchedMethodSignatures = allUnmatchedSignatures,
                totalMethodsInPatchedClasses = totalMethodsInPatchedClasses,
                outputSizeBytes = finalSignedApk.length(),
                isSignedV1V2V3 = true
            )
        } finally {
            workDir.deleteRecursively()
        }
    }

    /**
     * Repackages [sourceApkFile] into [unsignedAlignedOutputApk]:
     * - Strips old `META-INF/` signature files.
     * - Replaces every modified DEX entry in [patchedDexByEntryName] with its patched bytes.
     * - Keeps `resources.arsc` uncompressed (`ZipEntry.STORED`) with strict 4-byte alignment.
     * - Writes all other entries using the smaller representation (never inflating entries).
     */
    private fun repackageApkWithPatchedDex(
        sourceApkFile: File,
        patchedDexByEntryName: Map<String, ByteArray>,
        unsignedAlignedOutputApk: File
    ) {
        ZipFile(sourceApkFile).use { zip ->
            val rawEntries = mutableListOf<ZipEntry>()
            val enumeration = zip.entries()
            while (enumeration.hasMoreElements()) {
                val entry = enumeration.nextElement()
                if (!entry.isDirectory && !isSignatureEntry(entry.name)) {
                    rawEntries.add(entry)
                }
            }

            // Place resources.arsc first for clean 4-byte alignment
            val sortedEntries = rawEntries.sortedWith(
                compareBy<ZipEntry> { entry ->
                    when {
                        entry.name == "resources.arsc" -> 0
                        entry.name == "AndroidManifest.xml" -> 1
                        entry.name in patchedDexByEntryName -> 2
                        else -> 3
                    }
                }.thenBy { it.name }
            )

            FileOutputStream(unsignedAlignedOutputApk).use { fos ->
                val countingOut = CountingOutputStream(BufferedOutputStream(fos, BUFFER_SIZE))
                ZipOutputStream(countingOut).use { zos ->
                    zos.setLevel(Deflater.BEST_COMPRESSION)

                    for (origEntry in sortedEntries) {
                        val name = origEntry.name
                        val patchedDexBytes = patchedDexByEntryName[name]

                        if (name == "resources.arsc") {
                            val arscBytes = zip.getInputStream(origEntry).use { it.readBytes() }
                            writeStoredAlignedEntry(
                                zos = zos,
                                countingOut = countingOut,
                                entryName = name,
                                rawBytes = arscBytes,
                                alignmentBytes = 4L
                            )
                        } else if (patchedDexBytes != null) {
                            writeSmallestCompressedEntry(zos, name, patchedDexBytes)
                        } else {
                            val rawBytes = zip.getInputStream(origEntry).use { it.readBytes() }
                            if (origEntry.method == ZipEntry.STORED && !name.endsWith(".so")) {
                                writeStoredAlignedEntry(
                                    zos = zos,
                                    countingOut = countingOut,
                                    entryName = name,
                                    rawBytes = rawBytes,
                                    alignmentBytes = 4L
                                )
                            } else {
                                writeSmallestCompressedEntry(zos, name, rawBytes)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun writeStoredAlignedEntry(
        zos: ZipOutputStream,
        countingOut: CountingOutputStream,
        entryName: String,
        rawBytes: ByteArray,
        alignmentBytes: Long
    ) {
        zos.flush()
        val lfhStartOffset = countingOut.bytesWritten
        val nameBytesLen = entryName.toByteArray(Charsets.UTF_8).size
        val baseDataOffset = lfhStartOffset + 30L + nameBytesLen

        val remainder = baseDataOffset % alignmentBytes
        val padLen = if (remainder == 0L) 0 else (alignmentBytes - remainder).toInt()

        val crc = CRC32()
        crc.update(rawBytes)

        val newEntry = ZipEntry(entryName).apply {
            method = ZipEntry.STORED
            size = rawBytes.size.toLong()
            compressedSize = rawBytes.size.toLong()
            this.crc = crc.value
            time = FIXED_ZIP_TIME
            if (padLen > 0) {
                extra = ByteArray(padLen)
            }
        }

        zos.putNextEntry(newEntry)
        zos.write(rawBytes)
        zos.closeEntry()
        zos.flush()
    }

    private fun writeSmallestCompressedEntry(
        zos: ZipOutputStream,
        entryName: String,
        rawBytes: ByteArray
    ) {
        val deflatedProbe = deflateBytesLevel9(rawBytes)
        if (deflatedProbe.size < rawBytes.size) {
            val newEntry = ZipEntry(entryName).apply {
                method = ZipEntry.DEFLATED
                time = FIXED_ZIP_TIME
            }
            zos.putNextEntry(newEntry)
            zos.write(rawBytes)
            zos.closeEntry()
        } else {
            val crc = CRC32()
            crc.update(rawBytes)
            val storedEntry = ZipEntry(entryName).apply {
                method = ZipEntry.STORED
                size = rawBytes.size.toLong()
                compressedSize = rawBytes.size.toLong()
                this.crc = crc.value
                time = FIXED_ZIP_TIME
            }
            zos.putNextEntry(storedEntry)
            zos.write(rawBytes)
            zos.closeEntry()
        }
    }

    private fun deflateBytesLevel9(rawBytes: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream(rawBytes.size / 2 + 64)
        val deflater = Deflater(Deflater.BEST_COMPRESSION, true)
        try {
            DeflaterOutputStream(baos, deflater, 16 * 1024).use { dos ->
                dos.write(rawBytes)
            }
        } finally {
            deflater.end()
        }
        return baos.toByteArray()
    }

    private fun isSignatureEntry(entryName: String): Boolean {
        if (!entryName.startsWith("META-INF/")) return false
        val upper = entryName.uppercase()
        return upper == "META-INF/MANIFEST.MF" ||
            upper.endsWith(".SF") ||
            upper.endsWith(".RSA") ||
            upper.endsWith(".DSA") ||
            upper.endsWith(".EC") ||
            upper.startsWith("META-INF/SIG-")
    }

    private data class SigningCredentials(
        val privateKey: PrivateKey,
        val certificate: X509Certificate
    )

    private fun loadOrCreateSigningCredentials(context: Context): SigningCredentials {
        val keyDir = File(context.filesDir, "signer_credentials").apply { mkdirs() }
        val pk8File = File(keyDir, "testkey.pk8")
        val certFile = File(keyDir, "testkey.x509.der")

        val pk8Bytes = if (pk8File.exists() && pk8File.length() > 0L) {
            pk8File.readBytes()
        } else {
            Base64.getDecoder().decode(EMBEDDED_RSA_PKCS8_BASE64).also { pk8File.writeBytes(it) }
        }

        val certBytes = if (certFile.exists() && certFile.length() > 0L) {
            certFile.readBytes()
        } else {
            Base64.getDecoder().decode(EMBEDDED_X509_CERT_BASE64).also { certFile.writeBytes(it) }
        }

        val keyFactory = KeyFactory.getInstance("RSA")
        val privateKey = keyFactory.generatePrivate(PKCS8EncodedKeySpec(pk8Bytes))
        val certFactory = CertificateFactory.getInstance("X.509")
        val certificate = certFactory.generateCertificate(
            BufferedInputStream(certBytes.inputStream())
        ) as X509Certificate

        return SigningCredentials(privateKey, certificate)
    }

    /**
     * Generates a valid, multi-DEX sample APK containing:
     * - `Lcom/example/SecondTargetClass;` in `classes.dex`
     * - `Lcom/example/TargetClass;` in `classes2.dex`
     * so multi-class Smali patching in [DEFAULT_SMALI_PATCHES] can be tested immediately in a single run.
     */
    fun createSampleApkWithTargetClass(targetFile: File) {
        val workDir = File(targetFile.parentFile, "sample_smali_apk_${System.nanoTime()}").apply { mkdirs() }
        try {
            // 1. Binary AndroidManifest.xml
            val manifestBytes = SampleApkBuilder.buildBinaryManifestPayload()

            // 2. Binary resources.arsc via ARSCLib
            val tableBlock = TableBlock()
            val pkg: PackageBlock = tableBlock.newPackage(0x7F, "com.example.smalitargetdemo")
            val specTypePair: SpecTypePair = pkg.getOrCreateSpecTypePair(1, "string")
            val defaultType: TypeBlock = specTypePair.getOrCreateTypeBlock(ResConfig())
            val entry: Entry = defaultType.getOrCreateEntry(0.toShort())
            entry.setName("app_name", true)
            entry.setValueAsString("Smali Multi-Class Demo")
            tableBlock.refresh()
            val arscBytes = tableBlock.bytes

            // 3. Assemble classes.dex with Lcom/example/SecondTargetClass; + untouched MainLauncher
            val smaliSecondTarget = """
                .class public Lcom/example/SecondTargetClass;
                .super Ljava/lang/Object;

                .method public constructor <init>()V
                    .locals 0
                    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
                    return-void
                .end method

                .method public getSecurityLevel()I
                    .locals 1
                    const/4 v0, 0x1
                    return v0
                .end method

                .method public getUntouchedLabel()Ljava/lang/String;
                    .locals 1
                    const-string v0, "KeepIntact"
                    return-object v0
                .end method
            """.trimIndent()

            // 4. Assemble classes2.dex with Lcom/example/TargetClass;
            val smaliTargetClass = """
                .class public Lcom/example/TargetClass;
                .super Ljava/lang/Object;

                .field private featureFlag:Z

                .method public constructor <init>()V
                    .locals 1
                    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
                    const/4 v0, 0x0
                    iput-boolean v0, p0, Lcom/example/TargetClass;->featureFlag:Z
                    return-void
                .end method

                .method public isFeatureEnabled()Z
                    .locals 1
                    const/4 v0, 0x0
                    return v0
                .end method

                .method public getStatusMessage()Ljava/lang/String;
                    .locals 1
                    const-string v0, "Original Unpatched Status"
                    return-object v0
                .end method

                .method public getUntouchedVersionCode()I
                    .locals 1
                    const/16 v0, 0x2a
                    return v0
                .end method
            """.trimIndent()

            val smaliFile1 = File(workDir, "SecondTargetClass.smali").apply { writeText(smaliSecondTarget) }
            val dexFile1 = File(workDir, "classes.dex")
            Smali.assemble(
                SmaliOptions().apply {
                    outputDexFile = dexFile1.absolutePath
                    apiLevel = 26
                },
                listOf(smaliFile1.absolutePath)
            )

            val smaliFile2 = File(workDir, "TargetClass.smali").apply { writeText(smaliTargetClass) }
            val dexFile2 = File(workDir, "classes2.dex")
            Smali.assemble(
                SmaliOptions().apply {
                    outputDexFile = dexFile2.absolutePath
                    apiLevel = 26
                },
                listOf(smaliFile2.absolutePath)
            )

            FileOutputStream(targetFile).use { fos ->
                val countingOut = CountingOutputStream(BufferedOutputStream(fos, BUFFER_SIZE))
                ZipOutputStream(countingOut).use { zos ->
                    zos.setLevel(Deflater.BEST_COMPRESSION)
                    writeStoredAlignedEntry(zos, countingOut, "resources.arsc", arscBytes, 4L)
                    writeSmallestCompressedEntry(zos, "AndroidManifest.xml", manifestBytes)
                    writeSmallestCompressedEntry(zos, "classes.dex", dexFile1.readBytes())
                    writeSmallestCompressedEntry(zos, "classes2.dex", dexFile2.readBytes())
                }
            }
        } finally {
            workDir.deleteRecursively()
        }
    }

    private class CountingOutputStream(
        private val delegate: java.io.OutputStream
    ) : java.io.OutputStream() {
        var bytesWritten: Long = 0L
            private set

        override fun write(b: Int) {
            delegate.write(b)
            bytesWritten += 1L
        }

        override fun write(b: ByteArray) {
            delegate.write(b)
            bytesWritten += b.size
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            delegate.write(b, off, len)
            bytesWritten += len
        }

        override fun flush() {
            delegate.flush()
        }

        override fun close() {
            delegate.close()
        }
    }
}
