package com.example

import com.example.engine.ApkMergeEngine
import com.example.engine.SampleApkBuilder
import com.example.model.AbiFilterMode
import com.example.model.MergeConfig
import com.example.model.SplitModuleType
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

class ExampleUnitTest {

    @Test
    fun streamBufferConstant_isStrictly512KB() {
        assertEquals(
            "Memory-safe streaming buffer must be strictly 512KB (131072 * 4 = 524288 bytes)",
            131_072 * 4,
            ApkMergeEngine.STREAM_BUFFER_SIZE
        )
    }

    @Test
    fun binaryManifestPatching_patchesIsSplitRequiredToFalseAndRemovesSplitMetaDataChunks() {
        val rawManifestBytes = SampleApkBuilder.buildBinaryManifestPayload()

        // 1. Inspect unpatched binary AndroidManifest.xml
        val beforeInspection = ApkMergeEngine.inspectBinaryAndroidManifest(rawManifestBytes)
        assertTrue("Manifest must be valid Binary AXML (0x00080003)", beforeInspection.isBinaryAxml)
        assertTrue("Unpatched manifest must have android:isSplitRequired=true", beforeInspection.hasIsSplitRequiredTrue)
        assertEquals(
            "Unpatched manifest must contain 3 split <meta-data> tags",
            3,
            beforeInspection.splitMetaDataNames.size
        )
        assertTrue(beforeInspection.splitMetaDataNames.contains("com.android.vending.splits"))
        assertTrue(beforeInspection.splitMetaDataNames.contains("com.android.vending.splits.required"))
        assertTrue(beforeInspection.splitMetaDataNames.contains("com.android.dynamic.apk.fused.modules"))

        // 2. Patch binary AndroidManifest.xml
        val (patchedBytes, patchSummary) = ApkMergeEngine.patchBinaryAndroidManifest(rawManifestBytes)

        assertTrue("Patch summary must confirm manifest was patched", patchSummary.wasManifestPatched)
        assertTrue("Patch summary must confirm isSplitRequired was patched to false", patchSummary.isSplitRequiredSetToFalse)
        assertTrue("Patch summary must confirm split attributes were cleared", patchSummary.splitAttributesClearedCount >= 1)
        assertEquals(
            "Patch summary must confirm 3 split <meta-data> tags were removed",
            3,
            patchSummary.removedSplitMetaDataTags.size
        )
        assertTrue(
            "Patched manifest must be smaller after stripping split attributes and <meta-data> chunks",
            patchedBytes.size < rawManifestBytes.size
        )

        // Verify AXML file size header at bytes 4..7 matches patched array length
        val headerTotalSize = ByteBuffer.wrap(patchedBytes, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
        assertEquals("AXML header total size must equal patchedBytes.size", patchedBytes.size, headerTotalSize)

        // 3. Re-inspect patched binary AndroidManifest.xml
        val afterInspection = ApkMergeEngine.inspectBinaryAndroidManifest(patchedBytes)
        assertTrue("Patched manifest must remain valid Binary AXML", afterInspection.isBinaryAxml)
        assertFalse(
            "Patched manifest must have android:isSplitRequired=false (not true)",
            afterInspection.hasIsSplitRequiredTrue
        )
        assertTrue(
            "Patched manifest must have 0 split <meta-data> tags remaining",
            afterInspection.splitMetaDataNames.isEmpty()
        )
    }

    @Test
    fun splitGameArchiveApks_parsesAndMergesAllSplitsIntoUniversalApkWith4kAlignment() = runBlocking {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "apks_merge_test_${System.currentTimeMillis()}").apply {
            mkdirs()
        }
        try {
            val inputApks = File(tempDir, "unreal_split_bundle.apks")
            val outputUniversalApk = File(tempDir, "Universal_Game.apk")

            SampleApkBuilder.createSampleSplitGameArchive(inputApks, isXapk = false)
            assertTrue("Sample .apks archive must exist", inputApks.exists())

            // 1. Verify Archive Parsing & Analysis
            val analysis = ApkMergeEngine.analyzeArchive(inputApks, inputApks.name, "Test APKS")
            assertTrue("Should detect split archive", analysis.isSplitArchive)
            assertEquals("Should discover 6 split APKs (base + 2 ABIs + xhdpi + ar + asset_pack)", 6, analysis.innerApkCount)
            assertTrue(analysis.discoveredSplits.any { it.moduleType == SplitModuleType.BASE })
            assertTrue(analysis.discoveredSplits.any { it.moduleType == SplitModuleType.ABI })
            assertTrue(analysis.discoveredSplits.any { it.moduleType == SplitModuleType.DENSITY })
            assertTrue(analysis.discoveredSplits.any { it.moduleType == SplitModuleType.LANGUAGE })
            assertTrue(analysis.discoveredSplits.any { it.moduleType == SplitModuleType.ASSET_PACK })
            assertTrue("Manifest inspection must detect split flags in base.apk", analysis.manifestInspection.hasIsSplitRequiredTrue)

            // 2. Run Smart Deep Merging into Universal_Game.apk (KEEP_ALL ABIs to verify multi-ABI lib/ merging)
            val config = MergeConfig(
                patchBinaryManifest = true,
                enforce4kAlignmentForSoAndGameAssets = true,
                stripMetaInfSignatures = true,
                mergeObbIntoAssets = true,
                abiFilterMode = AbiFilterMode.KEEP_ALL
            )

            val result = ApkMergeEngine.mergeSplitGameToUniversalApk(
                sourceArchiveFile = inputApks,
                outputUniversalApkFile = outputUniversalApk,
                config = config,
                onProgress = {}
            )

            assertTrue("Output Universal_Game.apk must exist", outputUniversalApk.exists())
            assertEquals("Universal_Game.apk", result.outputFileName)
            assertEquals(6, result.mergedSplitApksCount)
            assertTrue("Should merge native .so libraries from ABI splits", result.mergedNativeLibsCount >= 3)
            assertTrue("Should merge game engine assets (.pak, .assets, .resS)", result.mergedAssetsCount >= 3)
            assertTrue("Should merge split resources (drawable-xhdpi, values-ar)", result.mergedResourcesCount >= 2)
            assertTrue("Should strip META-INF signatures from all splits", result.strippedMetaInfCount >= 6)
            assertTrue("Should patch Binary AndroidManifest.xml", result.manifestPatchSummary.isSplitRequiredSetToFalse)

            // 3. Inspect output Universal_Game.apk entries and 4K alignment
            val outputReport = ApkMergeEngine.analyzeArchive(outputUniversalApk, outputUniversalApk.name, "Universal APK")
            assertFalse("Output Universal_Game.apk must be a single standalone APK, not a split archive", outputReport.isSplitArchive)
            assertFalse(
                "Output Universal_Game.apk manifest must have isSplitRequired=false",
                outputReport.manifestInspection.hasIsSplitRequiredTrue
            )
            assertTrue(
                "Output Universal_Game.apk manifest must have no split <meta-data> tags",
                outputReport.manifestInspection.splitMetaDataNames.isEmpty()
            )

            ZipFile(outputUniversalApk).use { zip ->
                // Verify Smart Deep Merging of lib/ directories
                assertNotNull("arm64-v8a libunreal_game.so must be merged", zip.getEntry("lib/arm64-v8a/libunreal_game.so"))
                assertNotNull("arm64-v8a libil2cpp.so must be merged", zip.getEntry("lib/arm64-v8a/libil2cpp.so"))
                assertNotNull("armeabi-v7a libunreal_game.so must be merged", zip.getEntry("lib/armeabi-v7a/libunreal_game.so"))

                // Verify Smart Deep Merging of assets/ directories from asset_packs
                assertNotNull("Unreal .pak asset must be merged into assets/", zip.getEntry("assets/level1_world.pak"))
                assertNotNull("Unity .assets must be merged into assets/", zip.getEntry("assets/bin/Data/sharedassets0.assets"))
                assertNotNull("Unity .resS must be merged into assets/", zip.getEntry("assets/bin/Data/sharedassets0.assets.resS"))

                // Verify Smart Deep Merging of res/ directories from density & language splits
                assertNotNull("xhdpi radar texture must be merged into res/", zip.getEntry("res/drawable-xhdpi-v4/hud_radar.png"))
                assertNotNull("Arabic strings.xml must be merged into res/", zip.getEntry("res/values-ar/strings.xml"))

                // Verify complete deletion of META-INF signature files
                assertNull("META-INF/MANIFEST.MF must be deleted", zip.getEntry("META-INF/MANIFEST.MF"))
                assertNull("META-INF/CERT.SF must be deleted", zip.getEntry("META-INF/CERT.SF"))
                assertNull("META-INF/CERT.RSA must be deleted", zip.getEntry("META-INF/CERT.RSA"))
            }

            // 4. Verify ZipEntry.STORED and 4096-byte (4K) alignment on all .so, .pak, .assets, .resS, and resources.arsc
            val mustBe4kStored = listOf(
                "resources.arsc",
                "lib/arm64-v8a/libunreal_game.so",
                "lib/arm64-v8a/libil2cpp.so",
                "lib/armeabi-v7a/libunreal_game.so",
                "assets/level1_world.pak",
                "assets/bin/Data/sharedassets0.assets",
                "assets/bin/Data/sharedassets0.assets.resS"
            )
            for (targetPath in mustBe4kStored) {
                val stat = outputReport.entries.firstOrNull { it.name == targetPath }
                assertNotNull("Entry $targetPath must exist in Universal_Game.apk", stat)
                assertEquals(
                    "Entry $targetPath must use ZipEntry.STORED (0)",
                    ZipEntry.STORED,
                    stat!!.method
                )
                assertEquals(
                    "Entry $targetPath dataOffset (${stat.dataOffset}) must be 4096-byte (4K) aligned",
                    0L,
                    stat.dataOffset % 4096L
                )
                assertTrue("Entry $targetPath must be flagged as 4K aligned", stat.is4kAligned)
            }
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun xapkArchiveWithObbAndArm64Filter_mergesObbAndStrips32BitSplit() = runBlocking {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "xapk_merge_test_${System.currentTimeMillis()}").apply {
            mkdirs()
        }
        try {
            val inputXapk = File(tempDir, "game_bundle.xapk")
            val outputUniversalApk = File(tempDir, "Universal_Game.apk")

            SampleApkBuilder.createSampleSplitGameArchive(inputXapk, isXapk = true)

            val config = MergeConfig(
                patchBinaryManifest = true,
                enforce4kAlignmentForSoAndGameAssets = true,
                stripMetaInfSignatures = true,
                mergeObbIntoAssets = true,
                abiFilterMode = AbiFilterMode.ARM64_ONLY
            )

            val result = ApkMergeEngine.mergeSplitGameToUniversalApk(
                sourceArchiveFile = inputXapk,
                outputUniversalApkFile = outputUniversalApk,
                config = config,
                onProgress = {}
            )

            assertEquals("Expected 5 splits merged (armeabi-v7a split skipped by ARM64_ONLY)", 5, result.mergedSplitApksCount)

            val outputReport = ApkMergeEngine.analyzeArchive(outputUniversalApk, outputUniversalApk.name, "Universal XAPK")
            val obbEntry = outputReport.entries.firstOrNull { it.name == "assets/obb/main.100.com.example.universalgame.obb" }
            assertNotNull("OBB file from XAPK must be merged into assets/obb/ with 4K STORED alignment", obbEntry)
            assertEquals(ZipEntry.STORED, obbEntry!!.method)
            assertEquals("Merged OBB file must be 4096-byte aligned", 0L, obbEntry.dataOffset % 4096L)

            val armeabiEntry = outputReport.entries.firstOrNull { it.name.startsWith("lib/armeabi-v7a/") }
            assertNull("32-bit armeabi-v7a libraries must be excluded when ARM64_ONLY is enabled", armeabiEntry)
        } finally {
            tempDir.deleteRecursively()
        }
    }
}
