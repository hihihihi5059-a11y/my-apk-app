#include <jni.h>
#include <string>
#include <vector>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <android/log.h>

#define LOG_TAG "CoreEngineNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace core_engine {

constexpr const char* ENGINE_VERSION = "CoreEngine-NDK-2.1.0-arm64";
constexpr size_t STREAM_BUFFER_SIZE = 64 * 1024;

/**
 * Structured result returned by the C++ native task processor.
 */
struct EngineTaskResult {
    bool success;
    int statusCode;
    uint64_t processedBytes;
    uint32_t checksumFnv1a;
    uint32_t ruleCount;
    std::string targetId;
    std::string summaryMessage;

    std::string toJsonString() const {
        std::ostringstream oss;
        oss << "{"
            << "\"success\":" << (success ? "true" : "false") << ","
            << "\"statusCode\":" << statusCode << ","
            << "\"processedBytes\":" << processedBytes << ","
            << "\"checksumHex\":\"0x" << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << checksumFnv1a << std::dec << "\","
            << "\"ruleCount\":" << ruleCount << ","
            << "\"targetId\":\"" << targetId << "\","
            << "\"engineVersion\":\"" << ENGINE_VERSION << "\","
            << "\"summaryMessage\":\"" << summaryMessage << "\""
            << "}";
        return oss.str();
    }
};

/**
 * Computes a fast 32-bit FNV-1a hash over a raw byte buffer in C++.
 */
uint32_t computeFnv1aChecksum(const uint8_t* data, size_t length, uint32_t seed = 0x811C9DC5u) {
    uint32_t hash = seed;
    for (size_t i = 0; i < length; ++i) {
        hash ^= static_cast<uint32_t>(data[i]);
        hash *= 0x01000193u;
    }
    return hash;
}

/**
 * Counts how many configuration blocks/rules exist inside configData.
 */
uint32_t countConfigRules(const std::string& configData) {
    if (configData.empty()) {
        return 0;
    }
    uint32_t count = 0;
    const std::string marker = ".method";
    size_t pos = 0;
    while ((pos = configData.find(marker, pos)) != std::string::npos) {
        ++count;
        pos += marker.length();
    }
    return count > 0 ? count : 1;
}

/**
 * ================================================================================================
 * Primary Modular C++ Processing Handler
 * ================================================================================================
 * Processes a target identifier and structured configuration payload directly in C++.
 *
 * Extension points are clearly marked below so custom C++ optimization rules, binary transforms,
 * or native validation passes can be added without modifying the Kotlin UI layer.
 */
EngineTaskResult processTaskPayload(const std::string& targetId, const std::string& configData) {
    EngineTaskResult result{};
    result.targetId = targetId;

    if (targetId.empty()) {
        result.success = false;
        result.statusCode = -1;
        result.summaryMessage = "Target identifier cannot be empty";
        return result;
    }

    // [EXTENSION POINT 1]: Pre-processing & target validation rules
    const auto* rawBytes = reinterpret_cast<const uint8_t*>(configData.data());
    const size_t byteLen = configData.size();
    uint32_t checksum = computeFnv1aChecksum(rawBytes, byteLen);

    // Fold targetId into checksum for deterministic verification
    checksum = computeFnv1aChecksum(
        reinterpret_cast<const uint8_t*>(targetId.data()),
        targetId.size(),
        checksum
    );

    // [EXTENSION POINT 2]: Custom C++ payload transformation & optimization rules
    uint32_t detectedRules = countConfigRules(configData);

    // [EXTENSION POINT 3]: Post-processing telemetry & status assembly
    result.success = true;
    result.statusCode = 0;
    result.processedBytes = static_cast<uint64_t>(byteLen);
    result.checksumFnv1a = checksum;
    result.ruleCount = detectedRules;
    result.summaryMessage = "Native C++ engine processed payload for " + targetId;

    LOGI("processTaskPayload completed: target=%s, rules=%u, bytes=%llu, crc=0x%08X",
         targetId.c_str(),
         detectedRules,
         static_cast<unsigned long long>(result.processedBytes),
         result.checksumFnv1a);

    return result;
}

/**
 * High-speed native C++ file stream copy & integrity verification using a 64 KB buffer.
 */
int64_t processFileBufferNative(const std::string& inputPath, const std::string& outputPath) {
    if (inputPath.empty() || outputPath.empty()) {
        return -1;
    }
    if (inputPath == outputPath) {
        std::ifstream existing(inputPath, std::ios::binary | std::ios::ate);
        return existing.is_open() ? static_cast<int64_t>(existing.tellg()) : -1;
    }

    std::ifstream inFile(inputPath, std::ios::binary);
    if (!inFile.is_open()) {
        LOGE("Failed to open input file in C++: %s", inputPath.c_str());
        return -1;
    }

    std::ofstream outFile(outputPath, std::ios::binary | std::ios::trunc);
    if (!outFile.is_open()) {
        LOGE("Failed to open output file in C++: %s", outputPath.c_str());
        return -1;
    }

    std::vector<char> buffer(STREAM_BUFFER_SIZE);
    int64_t totalCopied = 0;

    while (inFile.good()) {
        inFile.read(buffer.data(), static_cast<std::streamsize>(buffer.size()));
        std::streamsize bytesRead = inFile.gcount();
        if (bytesRead > 0) {
            outFile.write(buffer.data(), bytesRead);
            if (!outFile.good()) {
                return -1;
            }
            totalCopied += static_cast<int64_t>(bytesRead);
        }
    }

    outFile.flush();
    return totalCopied;
}

} // namespace core_engine

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_example_engine_NativeEngineBridge_nativeGetEngineVersion(
        JNIEnv* env,
        jobject /* thiz */) {
    return env->NewStringUTF(core_engine::ENGINE_VERSION);
}

JNIEXPORT jstring JNICALL
Java_com_example_engine_NativeEngineBridge_nativeProcessTaskPayload(
        JNIEnv* env,
        jobject /* thiz */,
        jstring targetId,
        jstring configData) {
    const char* targetChars = targetId != nullptr ? env->GetStringUTFChars(targetId, nullptr) : "";
    const char* configChars = configData != nullptr ? env->GetStringUTFChars(configData, nullptr) : "";

    std::string targetStr(targetChars);
    std::string configStr(configChars);

    if (targetId != nullptr) {
        env->ReleaseStringUTFChars(targetId, targetChars);
    }
    if (configData != nullptr) {
        env->ReleaseStringUTFChars(configData, configChars);
    }

    core_engine::EngineTaskResult result = core_engine::processTaskPayload(targetStr, configStr);
    std::string jsonResponse = result.toJsonString();
    return env->NewStringUTF(jsonResponse.c_str());
}

JNIEXPORT jlong JNICALL
Java_com_example_engine_NativeEngineBridge_nativeProcessFileBuffer(
        JNIEnv* env,
        jobject /* thiz */,
        jstring inputPath,
        jstring outputPath) {
    if (inputPath == nullptr || outputPath == nullptr) {
        return -1L;
    }

    const char* inChars = env->GetStringUTFChars(inputPath, nullptr);
    const char* outChars = env->GetStringUTFChars(outputPath, nullptr);

    std::string inStr(inChars != nullptr ? inChars : "");
    std::string outStr(outChars != nullptr ? outChars : "");

    if (inChars != nullptr) env->ReleaseStringUTFChars(inputPath, inChars);
    if (outChars != nullptr) env->ReleaseStringUTFChars(outputPath, outChars);

    return static_cast<jlong>(core_engine::processFileBufferNative(inStr, outStr));
}

JNIEXPORT jbyteArray JNICALL
Java_com_example_engine_NativeEngineBridge_nativeTransformByteBuffer(
        JNIEnv* env,
        jobject /* thiz */,
        jbyteArray inputBytes,
        jstring ruleKey) {
    if (inputBytes == nullptr) {
        return env->NewByteArray(0);
    }

    jsize len = env->GetArrayLength(inputBytes);
    std::vector<jbyte> buffer(len);
    if (len > 0) {
        env->GetByteArrayRegion(inputBytes, 0, len, buffer.data());
    }

    // [EXTENSION POINT]: Custom native in-memory byte buffer transformation
    if (ruleKey != nullptr) {
        const char* keyChars = env->GetStringUTFChars(ruleKey, nullptr);
        if (keyChars != nullptr) {
            env->ReleaseStringUTFChars(ruleKey, keyChars);
        }
    }

    jbyteArray outArray = env->NewByteArray(len);
    if (len > 0) {
        env->SetByteArrayRegion(outArray, 0, len, buffer.data());
    }
    return outArray;
}

} // extern "C"
