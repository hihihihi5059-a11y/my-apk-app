package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.android.apksig.ApkVerifier
import com.example.engine.ApkFixerEngine
import com.example.engine.SampleApkBuilder
import com.example.model.FixProgressStage
import com.example.model.TargetAndroidVersion
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches APK Package Fixer`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("APK Package Fixer", appName)
    }

    @Test
    fun `apk fixer patches minSdkVersion in binary manifest, aligns resources_arsc 4B and so 4K, and signs v1 v2 v3`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "test_apk_fixer_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            val sampleApk = File(tempDir, "Test_Legacy_App.apk")
            SampleApkBuilder.createUnoptimizedSampleApk(sampleApk)
            assertTrue("Expected sample APK to exist", sampleApk.exists())

            val apkInfo = ApkFixerEngine.inspectApkFile(sampleApk)
            assertNotNull("Expected valid apk info", apkInfo)
            assertEquals("com.example.samplelegacyapp", apkInfo.packageName)
            assertEquals(34, apkInfo.detectedMinSdk)
            assertEquals(35, apkInfo.detectedTargetSdk)

            val observedStages = mutableSetOf<FixProgressStage>()
            val result = ApkFixerEngine.fixAndRebuildApk(
                context = context,
                sourceApk = apkInfo,
                targetVersion = TargetAndroidVersion.ANDROID_11,
                alsoUpdateTargetSdk = false,
                onProgress = { stage, _, _ ->
                    observedStages.add(stage)
                }
            )

            assertTrue("Expected EXTRACTING stage", observedStages.contains(FixProgressStage.EXTRACTING))
            assertTrue("Expected MODIFYING_MANIFEST stage", observedStages.contains(FixProgressStage.MODIFYING_MANIFEST))
            assertTrue("Expected REBUILDING_APK stage", observedStages.contains(FixProgressStage.REBUILDING_APK))
            assertTrue("Expected SIGNING_APK stage", observedStages.contains(FixProgressStage.SIGNING_APK))
            assertTrue("Expected COMPLETED stage", observedStages.contains(FixProgressStage.COMPLETED))

            val outputApk = result.outputApkFile
            assertTrue("Expected output file to exist", outputApk.exists() && outputApk.length() > 0L)
            assertEquals("Package name must remain untouched", "com.example.samplelegacyapp", result.packageName)
            assertEquals("minSdkVersion must be patched to 30 (Android 11)", 30, result.patchedMinSdk)
            assertEquals("targetSdkVersion must remain untouched at 35 when alsoUpdateTargetSdk=false", 35, result.patchedTargetSdk)
            assertEquals(
                "ARSCLib must automatically set android:exported=true on MainActivity with <intent-filter>",
                1,
                result.exportedComponentsCount
            )

            // Verify persisted RSA 2048-bit key and X.509 certificate in app storage
            val keyDir = File(context.filesDir, "signer_credentials")
            assertTrue("Persisted testkey.pk8 must exist in filesDir", File(keyDir, "testkey.pk8").exists())
            assertTrue("Persisted testkey.x509.der must exist in filesDir", File(keyDir, "testkey.x509.der").exists())

            // 1. Verify patched binary AndroidManifest.xml inside output APK via ARSCLib
            ZipFile(outputApk).use { zip ->
                val manifestEntry = zip.getEntry("AndroidManifest.xml")
                assertNotNull("AndroidManifest.xml must exist in output APK", manifestEntry)
                val manifestBytes = zip.getInputStream(manifestEntry).readBytes()
                val inspected = ApkFixerEngine.inspectBinaryManifest(manifestBytes)
                assertEquals("com.example.samplelegacyapp", inspected.packageName)
                assertEquals(30, inspected.minSdkVersion)
                assertEquals(35, inspected.targetSdkVersion)
                assertEquals(
                    "Patched manifest must have android:exported=true on component with <intent-filter>",
                    1,
                    inspected.exportedComponentsWithIntentFilterCount
                )

                val arscEntry = zip.getEntry("resources.arsc")
                assertNotNull("resources.arsc must exist", arscEntry)
                assertEquals("resources.arsc must be STORED uncompressed", ZipEntry.STORED, arscEntry.method)
            }

            // 2. Verify 4-byte alignment of resources.arsc and 4096-byte alignment of .so files in raw ZIP LFH
            val payloadOffsets = readZipLocalEntryPayloadOffsets(outputApk)
            val arscOffset = payloadOffsets["resources.arsc"]
            assertNotNull("Expected resources.arsc in LFH scan", arscOffset)
            assertEquals("resources.arsc payload offset must be 4-byte aligned", 0L, arscOffset!! % 4L)

            val soEntries = payloadOffsets.filterKeys { it.endsWith(".so") }
            assertTrue("Expected native .so libraries in APK", soEntries.isNotEmpty())
            for ((soName, offset) in soEntries) {
                assertEquals("$soName payload offset must be 4096-byte aligned", 0L, offset % 4096L)
            }

            // 3. Verify cryptographic APK signature (v1 + v2 + v3) using Google's official ApkVerifier
            val verifier = ApkVerifier.Builder(outputApk)
                .setMinCheckedPlatformVersion(21)
                .build()
            val verificationResult = verifier.verify()
            assertTrue(
                "APK must pass official Google ApkVerifier: ${verificationResult.errors}",
                verificationResult.isVerified
            )
            assertTrue("Expected v1 signature scheme verified", verificationResult.isVerifiedUsingV1Scheme)
            assertTrue("Expected v2 signature scheme verified", verificationResult.isVerifiedUsingV2Scheme)
            assertTrue("Expected v3 signature scheme verified", verificationResult.isVerifiedUsingV3Scheme)
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun `tab 2 apk compressor optimizes dex via dexlib2, prunes foreign locales via ARSCLib, filters arm64, aligns 4B_4K, and signs v1_v2_v3`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "test_apk_compressor_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            val sampleApk = File(tempDir, "Bloated_MultiArch_Sample.apk")
            com.example.engine.ApkCompressorEngine.createRichSampleApkForCompression(sampleApk)
            assertTrue("Expected rich sample APK to exist", sampleApk.exists() && sampleApk.length() > 0L)

            val apkInfo = ApkFixerEngine.inspectApkFile(sampleApk)
            val result = com.example.engine.ApkCompressorEngine.compressAndOptimizeApk(
                context = context,
                sourceApk = apkInfo,
                options = com.example.model.CompressorOptions(
                    stripDexDebugAndBloat = true,
                    keepOnlyArEnLanguages = true,
                    convertImagesToWebp = true,
                    keepOnlyArm64NativeLibs = true,
                    useLevel9BestCompression = true
                ),
                onProgress = { _, _, _ -> }
            )

            val outputApk = result.outputApkFile
            assertTrue("Expected compressed output APK to exist", outputApk.exists() && outputApk.length() > 0L)
            assertTrue(
                "Compressed APK (${result.totalBreakdown.afterBytes}) must be smaller than original (${result.totalBreakdown.beforeBytes})",
                result.totalBreakdown.afterBytes < result.totalBreakdown.beforeBytes
            )
            assertEquals("Expected 2 DEX files optimized via dexlib2", 2, result.dexFilesOptimizedCount)
            assertTrue("Expected non-runtime bloat entries stripped", result.strippedBloatEntriesCount >= 4)
            assertTrue("Expected foreign locales pruned via ARSCLib", result.prunedLocalesCount >= 6)
            assertEquals("Expected 3 non-arm64 native libraries stripped", 3, result.strippedNativeLibsCount)

            // Verify contents of compressed APK
            ZipFile(outputApk).use { zip ->
                assertNotNull("classes.dex must exist", zip.getEntry("classes.dex"))
                assertNotNull("classes2.dex must exist", zip.getEntry("classes2.dex"))
                val arm64Entry = zip.getEntry("lib/arm64-v8a/libcore_engine.so")
                assertNotNull("arm64-v8a .so must be kept", arm64Entry)
                assertEquals(
                    "Native .so library must be compressed with DEFLATED (Level 9) in Tab 2",
                    ZipEntry.DEFLATED,
                    arm64Entry!!.method
                )
                assertTrue(
                    "Compressed .so size (${arm64Entry.compressedSize}) must be strictly smaller than uncompressed size (${arm64Entry.size})",
                    arm64Entry.compressedSize < arm64Entry.size
                )
                org.junit.Assert.assertNull("armeabi-v7a .so must be stripped", zip.getEntry("lib/armeabi-v7a/libcore_engine.so"))
                org.junit.Assert.assertNull("x86_64 .so must be stripped", zip.getEntry("lib/x86_64/libcore_engine.so"))
                org.junit.Assert.assertNull("x86 .so must be stripped", zip.getEntry("lib/x86/libcore_engine.so"))

                // Verify AndroidManifest.xml has android:extractNativeLibs="true" (0x010104EA) on <application>
                val manifestEntry = zip.getEntry("AndroidManifest.xml")
                assertNotNull("AndroidManifest.xml must exist", manifestEntry)
                val manifestBlock = java.io.ByteArrayInputStream(zip.getInputStream(manifestEntry).readBytes()).use {
                    com.reandroid.arsc.chunk.xml.AndroidManifestBlock.load(it)
                }
                val appElem = manifestBlock.applicationElement
                assertNotNull("<application> must exist in AndroidManifest.xml", appElem)
                val extractNativeAttr = appElem!!.searchAttributeByResourceId(0x010104EA)
                assertNotNull("android:extractNativeLibs must be set on <application>", extractNativeAttr)
                assertTrue("android:extractNativeLibs must be true", extractNativeAttr!!.valueAsBoolean)

                // .9.png and ic_launcher must be preserved
                assertNotNull(".9.png nine-patch must be preserved", zip.getEntry("res/drawable-xxhdpi-v4/button_bg.9.png"))
                assertNotNull("ic_launcher must be preserved", zip.getEntry("res/mipmap-xxxhdpi-v4/ic_launcher.png"))

                // Bloat files must be stripped
                org.junit.Assert.assertNull("kotlin_module must be stripped", zip.getEntry("META-INF/app_release.kotlin_module"))
                org.junit.Assert.assertNull("DebugProbesKt.bin must be stripped", zip.getEntry("DebugProbesKt.bin"))
                org.junit.Assert.assertNull("kotlin-tooling-metadata.json must be stripped", zip.getEntry("kotlin-tooling-metadata.json"))
                org.junit.Assert.assertNull("junit class must be stripped", zip.getEntry("junit/framework/ComparisonFailure.class"))
            }

            // Verify 4-byte alignment of resources.arsc (the ONLY entry stored uncompressed)
            val payloadOffsets = readZipLocalEntryPayloadOffsets(outputApk)
            val arscOffset = payloadOffsets["resources.arsc"]
            assertNotNull("Expected resources.arsc in LFH scan", arscOffset)
            assertEquals("resources.arsc payload offset must be 4-byte aligned", 0L, arscOffset!! % 4L)

            // Verify v1 + v2 + v3 signature using Google's official ApkVerifier
            val verifier = ApkVerifier.Builder(outputApk)
                .setMinCheckedPlatformVersion(21)
                .build()
            val verificationResult = verifier.verify()
            assertTrue(
                "Compressed APK must pass official Google ApkVerifier: ${verificationResult.errors}",
                verificationResult.isVerified
            )
            assertTrue("Expected v1 signature scheme verified", verificationResult.isVerifiedUsingV1Scheme)
            assertTrue("Expected v2 signature scheme verified", verificationResult.isVerifiedUsingV2Scheme)
            assertTrue("Expected v3 signature scheme verified", verificationResult.isVerifiedUsingV3Scheme)
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun `tab 3 smali method replacer patches multiple classes across classes_dex and classes2_dex via Map, aligns 4B arsc, and signs v1_v2_v3`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "test_smali_replacer_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            val sampleApk = File(tempDir, "Smali_Target_MultiDex.apk")
            com.example.engine.SmaliMethodReplacer.createSampleApkWithTargetClass(sampleApk)
            assertTrue("Expected sample APK to exist", sampleApk.exists() && sampleApk.length() > 0L)

            val apkInfo = ApkFixerEngine.inspectApkFile(sampleApk)
            val logs = mutableListOf<String>()

            assertTrue(
                "Expected app.ninjavpn.android to be registered in EncryptedSmaliPatchVault",
                com.example.engine.EncryptedSmaliPatchVault.hasPatchForPackage("app.ninjavpn.android")
            )
            val decryptedPatches = com.example.engine.EncryptedSmaliPatchVault.getDecryptedPatchesForPackageInMemory("app.ninjavpn.android")
            assertNotNull("Expected in-memory AES-256 decrypted patches", decryptedPatches)

            // Verify NativeEngineBridge task payload processing and file buffer copy
            val nativeReport = com.example.engine.NativeEngineBridge.executeTaskPayload(
                targetId = "app.ninjavpn.android",
                patchesConfig = decryptedPatches!!
            )
            assertTrue("Expected NativeEngineBridge report to succeed", nativeReport.success)
            assertEquals("app.ninjavpn.android", nativeReport.targetId)
            assertEquals("Expected 3 method rules detected by NativeEngineBridge", 3, nativeReport.ruleCount)
            assertTrue("Expected non-zero FNV-1a checksum hex", nativeReport.checksumHex.startsWith("0x"))

            val nativeCopyFile = File(tempDir, "NativeCopied_MultiDex.apk")
            val copiedBytes = com.example.engine.NativeEngineBridge.copyAndVerifyFileBuffer(sampleApk, nativeCopyFile)
            assertEquals("Expected NativeEngineBridge file copy size to match source", sampleApk.length(), copiedBytes)

            val patchResult = com.example.engine.SmaliMethodReplacer.replaceMethodsAndSignApk(
                context = context,
                sourceApk = apkInfo,
                patches = decryptedPatches,
                onLog = { logs.add(it) }
            )

            val outputApk = patchResult.outputApkFile
            assertTrue("Expected patched APK to exist", outputApk.exists() && outputApk.length() > 0L)
            assertEquals(
                "Expected both classes.dex and classes2.dex to be modified in a single pass",
                listOf("classes.dex", "classes2.dex"),
                patchResult.modifiedDexFileNames
            )
            assertEquals("Expected 2 classes patched", 2, patchResult.patchedClassDescriptors.size)
            assertEquals("Expected 3 total methods replaced across both classes", 3, patchResult.replacedMethods.size)
            assertTrue(
                "Expected getSecurityLevel()I replaced in SecondTargetClass",
                patchResult.replacedMethods.any {
                    it.classDescriptor == "Lcom/example/SecondTargetClass;" && it.fullSignature == "getSecurityLevel()I"
                }
            )
            assertTrue(
                "Expected isFeatureEnabled()Z replaced in TargetClass",
                patchResult.replacedMethods.any {
                    it.classDescriptor == "Lcom/example/TargetClass;" && it.fullSignature == "isFeatureEnabled()Z"
                }
            )
            assertTrue(
                "Expected getStatusMessage()Ljava/lang/String; replaced in TargetClass",
                patchResult.replacedMethods.any {
                    it.classDescriptor == "Lcom/example/TargetClass;" && it.fullSignature == "getStatusMessage()Ljava/lang/String;"
                }
            )

            // Verify resources.arsc 4-byte alignment
            val payloadOffsets = readZipLocalEntryPayloadOffsets(outputApk)
            val arscOffset = payloadOffsets["resources.arsc"]
            assertNotNull("Expected resources.arsc in LFH scan", arscOffset)
            assertEquals("resources.arsc payload offset must be 4-byte aligned", 0L, arscOffset!! % 4L)

            // Verify v1 + v2 + v3 signature using Google's official ApkVerifier
            val verifier = ApkVerifier.Builder(outputApk)
                .setMinCheckedPlatformVersion(21)
                .build()
            val verificationResult = verifier.verify()
            assertTrue(
                "Smali-patched APK must pass official Google ApkVerifier: ${verificationResult.errors}",
                verificationResult.isVerified
            )
            assertTrue("Expected v1 signature scheme verified", verificationResult.isVerifiedUsingV1Scheme)
            assertTrue("Expected v2 signature scheme verified", verificationResult.isVerifiedUsingV2Scheme)
            assertTrue("Expected v3 signature scheme verified", verificationResult.isVerifiedUsingV3Scheme)
        } finally {
            tempDir.deleteRecursively()
        }
    }

    /**
     * Parses the ZIP Central Directory and Local File Headers of `apkFile` to return a map of
     * `entryName -> exactPayloadStartByteOffset` for every `STORED` entry.
     */
    private fun readZipLocalEntryPayloadOffsets(apkFile: File): Map<String, Long> {
        val result = LinkedHashMap<String, Long>()
        RandomAccessFile(apkFile, "r").use { raf ->
            val fileLen = raf.length()
            val searchSize = minOf(fileLen, 65557L).toInt()
            val tail = ByteArray(searchSize)
            raf.seek(fileLen - searchSize)
            raf.readFully(tail)

            var eocdPos = -1
            for (i in searchSize - 22 downTo 0) {
                if (tail[i].toInt() == 0x50 &&
                    tail[i + 1].toInt() == 0x4B &&
                    tail[i + 2].toInt() == 0x05 &&
                    tail[i + 3].toInt() == 0x06
                ) {
                    eocdPos = i
                    break
                }
            }
            require(eocdPos != -1) { "EOCD not found in APK" }

            val bb = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN)
            val cdEntries = bb.getShort(eocdPos + 10).toInt() and 0xFFFF
            val cdOffset = bb.getInt(eocdPos + 16).toLong() and 0xFFFFFFFFL

            var pos = cdOffset
            val headerBuf = ByteArray(46)
            val lfhBuf = ByteArray(30)

            for (idx in 0 until cdEntries) {
                raf.seek(pos)
                raf.readFully(headerBuf)
                val cdBb = ByteBuffer.wrap(headerBuf).order(ByteOrder.LITTLE_ENDIAN)
                val sig = cdBb.getInt(0)
                if (sig != 0x02014B50) break

                val method = cdBb.getShort(10).toInt() and 0xFFFF
                val nameLen = cdBb.getShort(28).toInt() and 0xFFFF
                val extraLen = cdBb.getShort(30).toInt() and 0xFFFF
                val commentLen = cdBb.getShort(32).toInt() and 0xFFFF
                val lfhOffset = cdBb.getInt(42).toLong() and 0xFFFFFFFFL

                val nameBytes = ByteArray(nameLen)
                raf.readFully(nameBytes)
                val name = String(nameBytes, Charsets.UTF_8)

                if (method == ZipEntry.STORED) {
                    raf.seek(lfhOffset)
                    raf.readFully(lfhBuf)
                    val lfhBb = ByteBuffer.wrap(lfhBuf).order(ByteOrder.LITTLE_ENDIAN)
                    val lfhNameLen = lfhBb.getShort(26).toInt() and 0xFFFF
                    val lfhExtraLen = lfhBb.getShort(28).toInt() and 0xFFFF
                    val payloadOffset = lfhOffset + 30L + lfhNameLen + lfhExtraLen
                    result[name] = payloadOffset
                }

                pos += 46L + nameLen + extraLen + commentLen
            }
        }
        return result
    }
}
