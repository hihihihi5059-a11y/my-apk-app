package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.ApkFixerEngine
import com.example.engine.SampleApkBuilder
import com.example.model.FixProgressStage
import com.example.model.TargetAndroidVersion
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches APK Package Fixer`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("APK Package Fixer", appName)
    }

    @Test
    fun `apk fixer engine patches manifest minSdkVersion, targetSdk and signs output apk`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "test_apk_fixer_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            val sampleApk = File(tempDir, "Test_Legacy_App.apk")
            SampleApkBuilder.createUnoptimizedSampleApk(sampleApk)
            assertTrue("Expected sample APK to exist", sampleApk.exists())

            val apkInfo = ApkFixerEngine.inspectApkFile(sampleApk)
            assertNotNull("Expected valid apk info", apkInfo)

            val observedStages = mutableSetOf<FixProgressStage>()
            val result = ApkFixerEngine.fixAndRebuildApk(
                context = context,
                sourceApk = apkInfo,
                targetVersion = TargetAndroidVersion.ANDROID_14,
                onProgress = { stage, _, _ ->
                    observedStages.add(stage)
                }
            )

            assertTrue("Expected EXTRACTING stage", observedStages.contains(FixProgressStage.EXTRACTING))
            assertTrue("Expected MODIFYING_MANIFEST stage", observedStages.contains(FixProgressStage.MODIFYING_MANIFEST))
            assertTrue("Expected REBUILDING_APK stage", observedStages.contains(FixProgressStage.REBUILDING_APK))
            assertTrue("Expected SIGNING_APK stage", observedStages.contains(FixProgressStage.SIGNING_APK))
            assertTrue("Expected COMPLETED stage", observedStages.contains(FixProgressStage.COMPLETED))

            assertTrue("Expected output file to exist", result.outputApkFile.exists())
            assertEquals(24, result.patchedMinSdk)
            assertEquals(34, result.patchedTargetSdk)
            assertTrue("Expected output file size > 0", result.finalSizeBytes > 0)
        } finally {
            tempDir.deleteRecursively()
        }
    }
}
