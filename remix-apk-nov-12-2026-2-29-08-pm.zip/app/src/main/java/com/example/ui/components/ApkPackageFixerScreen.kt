package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ApkFileInfo
import com.example.model.FixProgressStage
import com.example.model.FixResult
import com.example.model.FixUiState
import com.example.model.TargetAndroidVersion
import com.example.ui.theme.CoralDanger
import com.example.ui.theme.CoralDangerContainer
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanAccentContainer
import com.example.ui.theme.CyanAccentGlow
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.DeepNavyBorder
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceElevated
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.EmeraldSuccessContainer
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.OnCyanAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkPackageFixerScreen(
    uiState: FixUiState,
    onSelectApkClick: () -> Unit,
    onGenerateSampleClick: () -> Unit,
    onTargetVersionSelected: (TargetAndroidVersion) -> Unit,
    onFixAndRebuildClick: () -> Unit,
    onInstallDirectlyClick: () -> Unit,
    onSaveFixedClick: () -> Unit,
    onShareFixedClick: () -> Unit,
    onDismissDialog: () -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavyBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .verticalScroll(scrollState)
                .padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Error banner notification if any
            AnimatedVisibility(visible = uiState.errorMessage != null) {
                Surface(
                    color = CoralDangerContainer,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CoralDanger),
                    modifier = Modifier.fillMaxWidth().testTag("error_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = CoralDanger,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = uiState.errorMessage.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextPrimary
                            )
                        }
                        IconButton(
                            onClick = onDismissError,
                            modifier = Modifier.size(28.dp).minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = DarkTextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // ====================================================================================
            // 2. Large Interactive Card for uploading/selecting the APK file
            // ====================================================================================
            ApkUploadCard(
                selectedApk = uiState.selectedApk,
                isProcessing = uiState.isProcessing,
                onSelectApkClick = onSelectApkClick,
                onGenerateSampleClick = onGenerateSampleClick
            )

            // ====================================================================================
            // 3. Elegant Dropdown Menu for Target Android Version Selection
            // ====================================================================================
            TargetAndroidDropdown(
                selectedVersion = uiState.selectedTargetVersion,
                isEnabled = !uiState.isProcessing,
                onVersionSelected = onTargetVersionSelected
            )

            // ====================================================================================
            // 4. Prominent Primary Action Button: "Fix & Rebuild APK"
            // ====================================================================================
            FixAndRebuildButton(
                isEnabled = uiState.selectedApk != null && !uiState.isProcessing,
                isProcessing = uiState.isProcessing,
                onClick = onFixAndRebuildClick
            )

            // ====================================================================================
            // 5. Circular Progress Indicator with Live Status Text
            // ====================================================================================
            AnimatedVisibility(
                visible = uiState.isProcessing || uiState.currentStage != FixProgressStage.IDLE,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                FixProgressCard(
                    stage = uiState.currentStage,
                    progress = uiState.progressFloat,
                    statusMessage = uiState.statusMessage
                )
            }

            // Quick live telemetry and logs card
            if (uiState.logs.isNotEmpty()) {
                ExecutionLogsCard(logs = uiState.logs)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // ========================================================================================
    // 6. Completion Dialog: Save Fixed APK / Install Directly
    // ========================================================================================
    if (uiState.showCompletionDialog && uiState.fixResult != null) {
        CompletionResultDialog(
            result = uiState.fixResult,
            onInstallDirectly = onInstallDirectlyClick,
            onSaveFixed = onSaveFixedClick,
            onShare = onShareFixedClick,
            onDismiss = onDismissDialog
        )
    }
}

/**
 * 2. Large Interactive Card for APK Selection & Uploading
 */
@Composable
private fun ApkUploadCard(
    selectedApk: ApkFileInfo?,
    isProcessing: Boolean,
    onSelectApkClick: () -> Unit,
    onGenerateSampleClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = DeepNavySurface
        ),
        border = BorderStroke(
            width = if (selectedApk != null) 1.5.dp else 1.dp,
            color = if (selectedApk != null) CyanAccent.copy(alpha = 0.8f) else DeepNavyBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("apk_upload_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Upload / Package Icon with glowing backdrop
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(CyanAccent.copy(alpha = 0.25f), DeepNavySurfaceElevated)
                        )
                    )
                    .border(1.5.dp, CyanAccent.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (selectedApk != null) Icons.Default.Verified else Icons.Default.CloudUpload,
                    contentDescription = "أيقونة رفع الملف",
                    tint = if (selectedApk != null) EmeraldSuccess else CyanAccent,
                    modifier = Modifier.size(34.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = stringResource(R.string.card_upload_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Text(
                    text = stringResource(R.string.card_upload_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }

            // Primary "Select APK File" button
            Button(
                onClick = onSelectApkClick,
                enabled = !isProcessing,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanAccentContainer,
                    contentColor = CyanAccent
                ),
                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("select_apk_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FileOpen,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = stringResource(R.string.select_apk_button),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Display file name and size clearly inside the Card when selected
            if (selectedApk != null) {
                Surface(
                    color = DeepNavySurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    modifier = Modifier.fillMaxWidth().testTag("selected_file_info_box")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Android,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = selectedApk.fileName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Surface(
                                color = EmeraldSuccess.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = selectedApk.formattedSize,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "الحزمة: ${selectedApk.packageName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (selectedApk.detectedTargetSdk != null) {
                                Text(
                                    text = "Target SDK: ${selectedApk.detectedTargetSdk}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GoldWarning
                                )
                            }
                        }
                    }
                }
            } else {
                // Secondary quick option to generate a sample APK for immediate on-device testing
                TextButton(
                    onClick = onGenerateSampleClick,
                    enabled = !isProcessing,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("generate_sample_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CyanAccentGlow,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = stringResource(R.string.generate_sample_button),
                            style = MaterialTheme.typography.bodySmall,
                            color = CyanAccentGlow,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

/**
 * 3. Dropdown Menu for Target Android Version Selection
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TargetAndroidDropdown(
    selectedVersion: TargetAndroidVersion,
    isEnabled: Boolean,
    onVersionSelected: (TargetAndroidVersion) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier.fillMaxWidth().testTag("target_version_card")
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Speed,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.select_target_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
            }

            Box(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DeepNavySurfaceElevated,
                    border = BorderStroke(1.dp, if (expanded) CyanAccent else DeepNavyBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = isEnabled) { expanded = !expanded }
                        .testTag("target_version_dropdown_box")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = selectedVersion.titleAr,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkTextPrimary
                            )
                            Text(
                                text = selectedVersion.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                        }
                        Icon(
                            imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "قائمة الخيارات",
                            tint = CyanAccent
                        )
                    }
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    modifier = Modifier
                        .background(DeepNavySurfaceElevated)
                        .border(1.dp, DeepNavyBorder, RoundedCornerShape(12.dp))
                        .testTag("target_version_dropdown_menu")
                ) {
                    TargetAndroidVersion.entries.forEach { version ->
                        val isSelected = version == selectedVersion
                        DropdownMenuItem(
                            text = {
                                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                    Text(
                                        text = version.titleAr,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) CyanAccent else DarkTextPrimary
                                    )
                                    Text(
                                        text = version.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = DarkTextSecondary
                                    )
                                }
                            },
                            trailingIcon = {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = CyanAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            onClick = {
                                onVersionSelected(version)
                                expanded = false
                            },
                            modifier = Modifier.testTag("option_${version.name.lowercase()}")
                        )
                    }
                }
            }
        }
    }
}

/**
 * 4. Primary Action Button: "Fix & Rebuild APK"
 */
@Composable
private fun FixAndRebuildButton(
    isEnabled: Boolean,
    isProcessing: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = isEnabled,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = CyanAccent,
            contentColor = OnCyanAccent,
            disabledContainerColor = CyanAccentContainer.copy(alpha = 0.35f),
            disabledContentColor = DarkTextMuted
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 6.dp,
            pressedElevation = 10.dp
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("fix_rebuild_button")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isProcessing) {
                CircularProgressIndicator(
                    color = OnCyanAccent,
                    strokeWidth = 2.5.dp,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = null,
                    tint = if (isEnabled) OnCyanAccent else DarkTextMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
            Text(
                text = stringResource(R.string.fix_rebuild_button),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * 5. Circular Progress Indicator with Step Text
 */
@Composable
private fun FixProgressCard(
    stage: FixProgressStage,
    progress: Float,
    statusMessage: String
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().testTag("progress_card")
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { progress },
                    color = CyanAccent,
                    trackColor = DeepNavySurfaceElevated,
                    strokeWidth = 3.5.dp,
                    modifier = Modifier.size(46.dp).testTag("fix_circular_progress")
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stage.labelAr,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Text(
                    text = statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary
                )
            }
        }
    }
}

/**
 * 6. Completion Dialog: Save Fixed APK / Install Directly
 */
@Composable
private fun CompletionResultDialog(
    result: FixResult,
    onInstallDirectly: () -> Unit,
    onSaveFixed: () -> Unit,
    onShare: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepNavySurface,
        titleContentColor = DarkTextPrimary,
        textContentColor = DarkTextSecondary,
        shape = RoundedCornerShape(24.dp),
        icon = {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(EmeraldSuccessContainer)
                    .border(1.5.dp, EmeraldSuccess, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = EmeraldSuccess,
                    modifier = Modifier.size(30.dp)
                )
            }
        },
        title = {
            Text(
                text = stringResource(R.string.dialog_success_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = stringResource(R.string.dialog_success_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary
                )

                Surface(
                    color = DeepNavySurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DetailRow(label = "الملف المخرج:", value = result.outputFileName)
                        DetailRow(label = "الحجم النهائي:", value = result.formattedFinalSize)
                        DetailRow(label = "minSdkVersion:", value = "${result.patchedMinSdk} (Android 7.0)")
                        DetailRow(label = "targetSdkVersion:", value = "${result.patchedTargetSdk}")
                        DetailRow(label = "مكونات تم تفعيل exported لها:", value = "${result.exportedComponentsCount}")
                        DetailRow(label = "شهادة التوقيع:", value = "V1 + V2 Debug Keystore")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onInstallDirectly,
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = OnCyanAccent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("install_directly_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Android, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text(text = stringResource(R.string.install_directly_button), fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = onShare,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    modifier = Modifier.testTag("share_fixed_button")
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "مشاركة", color = CyanAccent)
                }
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_dialog_button")
                ) {
                    Text(text = stringResource(R.string.close_dialog_button), color = DarkTextSecondary)
                }
            }
        },
        modifier = Modifier.testTag("completion_dialog")
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
        Text(text = value, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = DarkTextPrimary)
    }
}

/**
 * Terminal / Execution logs card
 */
@Composable
private fun ExecutionLogsCard(logs: List<String>) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier.fillMaxWidth().testTag("execution_logs_card")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = stringResource(R.string.log_console_title),
                    style = MaterialTheme.typography.labelLarge,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            Surface(
                color = DeepNavyBackground,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, DeepNavyBorder.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    logs.takeLast(6).forEach { logLine ->
                        Text(
                            text = logLine,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (logLine.startsWith("✅") || logLine.startsWith("✨")) EmeraldSuccess
                            else if (logLine.startsWith("⚠️")) GoldWarning
                            else DarkTextSecondary,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
