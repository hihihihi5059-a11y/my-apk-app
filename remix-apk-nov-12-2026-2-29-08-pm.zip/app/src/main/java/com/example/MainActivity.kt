package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.ApkPackageFixerScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.DeepNavyBorder
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ApkFixerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                ApkPackageFixerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkPackageFixerApp(
    viewModel: ApkFixerViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // SAF File Picker Launcher to select an APK file from storage
    val openApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.onApkFileSelected(context, uri)
        }
    }

    // SAF CreateDocument Launcher to save the fixed APK into Downloads/Documents
    val saveApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { destinationUri ->
        if (destinationUri != null) {
            val sourceFile = uiState.fixResult?.outputApkFile
            if (sourceFile != null && sourceFile.exists()) {
                context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(output)
                    }
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("main_scaffold"),
        containerColor = DeepNavyBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            // 1. Top App Bar carrying the name "APK Package Fixer"
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyanAccent.copy(alpha = 0.16f))
                                .border(1.dp, CyanAccent.copy(alpha = 0.7f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = stringResource(R.string.app_name), // "APK Package Fixer"
                                style = MaterialTheme.typography.titleLarge,
                                color = DarkTextPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("app_title")
                            )
                            Text(
                                text = stringResource(R.string.app_subtitle),
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary,
                                maxLines = 1
                            )
                        }
                    }
                },
                actions = {
                    Surface(
                        color = CyanAccent.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "V1/V2 SIGNER",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepNavySurface
                ),
                modifier = Modifier
                    .border(BorderStroke(1.dp, DeepNavyBorder))
                    .testTag("main_top_app_bar")
            )
        }
    ) { innerPadding ->
        ApkPackageFixerScreen(
            uiState = uiState,
            onSelectApkClick = {
                openApkLauncher.launch(
                    arrayOf(
                        "application/vnd.android.package-archive",
                        "application/octet-stream",
                        "*/*"
                    )
                )
            },
            onGenerateSampleClick = {
                viewModel.generateSampleApk(context)
            },
            onTargetVersionSelected = { version ->
                viewModel.selectTargetVersion(version)
            },
            onFixAndRebuildClick = {
                viewModel.startFixAndRebuild(context)
            },
            onInstallDirectlyClick = {
                viewModel.installFixedApk(context)
            },
            onSaveFixedClick = {
                val fileName = uiState.fixResult?.outputFileName ?: "Fixed_App.apk"
                saveApkLauncher.launch(fileName)
            },
            onShareFixedClick = {
                viewModel.shareFixedApk(context)
            },
            onDismissDialog = {
                viewModel.dismissCompletionDialog()
            },
            onDismissError = {
                viewModel.dismissError()
            },
            modifier = Modifier.padding(innerPadding)
        )
    }
}
