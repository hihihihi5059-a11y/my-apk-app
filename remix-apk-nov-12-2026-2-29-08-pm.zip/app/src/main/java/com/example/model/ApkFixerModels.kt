package com.example.model

import android.net.Uri
import java.io.File

/**
 * Android versions supported for target SDK specification and compatibility fixing.
 */
enum class TargetAndroidVersion(
    val titleAr: String,
    val titleEn: String,
    val apiLevel: Int,
    val minSdk: Int = 24,
    val description: String
) {
    ANDROID_10(
        titleAr = "Android 10 (API 29)",
        titleEn = "Android 10 (API 29)",
        apiLevel = 29,
        minSdk = 24,
        description = "نظام Android 10 (Q) - توافق ممتاز مع الأجهزة السابقة"
    ),
    ANDROID_11(
        titleAr = "Android 11 (API 30)",
        titleEn = "Android 11 (API 30)",
        apiLevel = 30,
        minSdk = 24,
        description = "نظام Android 11 (R) - صلاحيات الوصول المحدودة وتخزين Scoped Storage"
    ),
    ANDROID_12(
        titleAr = "Android 12 (API 31 - Exported إلزامية)",
        titleEn = "Android 12 (API 31 - Exported Required)",
        apiLevel = 31,
        minSdk = 24,
        description = "نظام Android 12 (S) - فرض سمة exported الصريحة على مكونات intent-filter"
    ),
    ANDROID_13(
        titleAr = "Android 13 (API 33)",
        titleEn = "Android 13 (API 33)",
        apiLevel = 33,
        minSdk = 24,
        description = "نظام Android 13 (Tiramisu) - صلاحيات الإشعارات المستقلة"
    ),
    ANDROID_14(
        titleAr = "Android 14 (API 34)",
        titleEn = "Android 14 (API 34)",
        apiLevel = 34,
        minSdk = 24,
        description = "نظام Android 14 (Upside Down Cake) - حظر تثبيت التطبيقات التي تستهدف SDK أقل من 23"
    ),
    ANDROID_15(
        titleAr = "Android 15 (API 35)",
        titleEn = "Android 15 (API 35)",
        apiLevel = 35,
        minSdk = 24,
        description = "نظام Android 15 (Vanilla Ice Cream) - أحدث إصدار للأندرويد مع قيود أمان متقدمة"
    ),
    UNIVERSAL(
        titleAr = "توافق شامل (من أندرويد 8 إلى 15)",
        titleEn = "Universal Compatibility (Android 8 to 15)",
        apiLevel = 34,
        minSdk = 24,
        description = "توصية: minSdkVersion=24 مع targetSdkVersion=34 وتفعيل exported لجميع المكونات"
    )
}

data class ApkFileInfo(
    val fileName: String,
    val fileSizeBytes: Long,
    val fileUri: Uri? = null,
    val localFile: File,
    val packageName: String = "com.app.fixed",
    val detectedMinSdk: Int? = null,
    val detectedTargetSdk: Int? = null,
    val isSample: Boolean = false
) {
    val formattedSize: String
        get() {
            if (fileSizeBytes < 1024) return "$fileSizeBytes B"
            val kb = fileSizeBytes / 1024.0
            if (kb < 1024) return String.format("%.1f KB", kb)
            val mb = kb / 1024.0
            return String.format("%.2f MB", mb)
        }
}

enum class FixProgressStage(val stepIndex: Int, val labelAr: String) {
    IDLE(0, "جاهز للبدء"),
    EXTRACTING(1, "جاري فك الضغط وقراءة ملف APK..."),
    MODIFYING_MANIFEST(2, "جاري تعديل Manifest (minSdk, targetSdk, exported)..."),
    REBUILDING_APK(3, "جاري إعادة ضغط الحزمة وحزم الملفات..."),
    SIGNING_APK(4, "جاري التوقيع الرقمي بحزمة V1/V2 Keystore..."),
    COMPLETED(5, "تم اكتمال العملية بنجاح!"),
    FAILED(-1, "فشلت العملية")
}

data class FixResult(
    val outputApkFile: File,
    val outputFileName: String,
    val originalSizeBytes: Long,
    val finalSizeBytes: Long,
    val patchedMinSdk: Int,
    val patchedTargetSdk: Int,
    val exportedComponentsCount: Int,
    val executionDurationMs: Long,
    val logs: List<String>
) {
    val formattedFinalSize: String
        get() {
            val mb = finalSizeBytes / (1024.0 * 1024.0)
            return String.format("%.2f MB", mb)
        }
}

data class FixUiState(
    val selectedApk: ApkFileInfo? = null,
    val selectedTargetVersion: TargetAndroidVersion = TargetAndroidVersion.UNIVERSAL,
    val isProcessing: Boolean = false,
    val currentStage: FixProgressStage = FixProgressStage.IDLE,
    val progressFloat: Float = 0f,
    val statusMessage: String = "",
    val logs: List<String> = emptyList(),
    val showCompletionDialog: Boolean = false,
    val fixResult: FixResult? = null,
    val errorMessage: String? = null
)
