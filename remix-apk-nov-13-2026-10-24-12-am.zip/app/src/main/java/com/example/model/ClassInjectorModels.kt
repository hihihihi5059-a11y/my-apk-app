package com.example.model

import java.io.File

/**
 * Where optional hook instructions should be injected inside a target existing method.
 */
enum class HookInjectionPosition(val titleAr: String, val titleEn: String) {
    AT_ENTRY(
        titleAr = "بداية الدالة (Index 0)",
        titleEn = "Method Entry (Index 0)"
    ),
    BEFORE_RETURN(
        titleAr = "قبل Return",
        titleEn = "Before Return"
    )
}

/**
 * Policy for handling duplicate class descriptors when injecting new `.class` definitions.
 */
enum class DuplicateClassPolicy(val titleAr: String, val titleEn: String) {
    SKIP_IF_EXISTS(
        titleAr = "تخطي إذا كان موجوداً (آمن)",
        titleEn = "Skip if exists (Safe)"
    ),
    FAIL_ON_DUPLICATE(
        titleAr = "إيقاف العملية عند التكرار",
        titleEn = "Fail on duplicate"
    ),
    REPLACE_EXISTING(
        titleAr = "استبدال الكلاس الموجود",
        titleEn = "Replace existing class"
    )
}

/**
 * Optional method hook specification allowing existing app methods to invoke methods
 * inside newly injected extension classes without rewriting entire existing classes.
 */
data class MethodHookSpec(
    val id: String = "hook_1",
    val targetClassDescriptor: String,
    val targetMethodSignature: String,
    val hookSmaliInstructions: String,
    val position: HookInjectionPosition = HookInjectionPosition.AT_ENTRY
)

/**
 * Ready-to-use Smali class + optional hook presets for the 4th tab ("حقن كلاسات").
 */
data class ClassInjectorPreset(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val smaliClassesCode: String,
    val enableHookByDefault: Boolean = false,
    val defaultHookClass: String = "",
    val defaultHookMethodSignature: String = "",
    val defaultHookInstructions: String = "",
    val defaultHookPosition: HookInjectionPosition = HookInjectionPosition.AT_ENTRY
)

enum class ClassInjectorStage(val stepIndex: Int, val labelAr: String) {
    IDLE(0, "جاهز لحقن الكلاسات الجديدة داخل ملفات DEX"),
    ASSEMBLING_CLASSES(1, "جاري تجميع تعريفات الكلاسات الجديدة عبر org.smali:smali..."),
    CHECKING_DUPLICATES(2, "جاري فحص التكرار في جميع ملفات classes*.dex..."),
    INJECTING_CLASSES(3, "جاري حقن ImmutableClassDef في ملف DEX المستهدف..."),
    INJECTING_HOOKS(4, "جاري حقن استدعاءات الربط (Method Hooks) الاختيارية..."),
    REBUILDING_APK(5, "جاري إعادة حزم APK ومحاذاة resources.arsc (4-Byte STORED)..."),
    SIGNING_APK(6, "جاري التوقيع الرقمي الشامل (V1 + V2 + V3)..."),
    COMPLETED(7, "تم حقن الكلاسات وتوقيع APK بنجاح!"),
    FAILED(-1, "فشلت عملية الحقن")
}

data class InjectedClassSummary(
    val classDescriptor: String,
    val targetDexName: String,
    val methodsCount: Int,
    val fieldsCount: Int,
    val statusLabel: String
)

data class InjectedHookSummary(
    val targetClassDescriptor: String,
    val targetMethodSignature: String,
    val dexFileName: String,
    val position: HookInjectionPosition,
    val instructionsAddedCount: Int
)

data class ClassInjectorResult(
    val outputApkFile: File,
    val outputFileName: String,
    val packageName: String,
    val targetDexName: String,
    val injectedClasses: List<InjectedClassSummary>,
    val skippedDuplicateClasses: List<String>,
    val appliedHooks: List<InjectedHookSummary>,
    val scannedDexFiles: List<String>,
    val modifiedDexFiles: List<String>,
    val outputSizeBytes: Long,
    val isSignedV1V2V3: Boolean,
    val executionDurationMs: Long,
    val logs: List<String>
) {
    val formattedOutputSize: String
        get() {
            if (outputSizeBytes < 1024L) return "$outputSizeBytes B"
            val kb = outputSizeBytes / 1024.0
            if (kb < 1024.0) return String.format("%.1f KB", kb)
            return String.format("%.2f MB", kb / 1024.0)
        }
}

data class ClassInjectorUiState(
    val selectedApk: ApkFileInfo? = null,
    val smaliClassesInput: String = "",
    val targetDexChoice: String = "classes.dex",
    val duplicatePolicy: DuplicateClassPolicy = DuplicateClassPolicy.SKIP_IF_EXISTS,
    val hooksEnabled: Boolean = false,
    val hookTargetClass: String = "Lcom/example/HostEntry;",
    val hookTargetMethodSignature: String = "onCreateHook()V",
    val hookInstructionsInput: String = "invoke-static {}, Lapp/ext/ExtensionBridge;->onAppInit()V",
    val hookPosition: HookInjectionPosition = HookInjectionPosition.AT_ENTRY,
    val selectedPresetId: String = "extension_bridge",
    val isProcessing: Boolean = false,
    val currentStage: ClassInjectorStage = ClassInjectorStage.IDLE,
    val progressPercent: Int = 0,
    val statusMessage: String = "",
    val logs: List<String> = emptyList(),
    val result: ClassInjectorResult? = null,
    val errorMessage: String? = null
)
