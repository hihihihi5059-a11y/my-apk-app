package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.ApkFixerEngine
import com.example.engine.EncryptedSmaliPatchVault
import com.example.engine.SmaliMethodReplacer
import com.example.model.InstalledUserAppInfo
import com.example.model.SmaliReplacerStage
import com.example.model.SmaliReplacerUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class SmaliReplacerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(SmaliReplacerUiState())
    val uiState: StateFlow<SmaliReplacerUiState> = _uiState.asStateFlow()

    /**
     * Scans installed user applications via Android's `PackageManager`, filtering out system apps
     * (`ApplicationInfo.FLAG_SYSTEM`), checking `EncryptedSmaliPatchVault.hasPatchForPackage`, and
     * sorting supported apps ("تم العثور على تعديل") to the very top of the list.
     */
    fun loadInstalledUserApps(context: Context) {
        if (_uiState.value.isLoadingApps) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingApps = true, errorMessage = null) }

            try {
                val sortedApps = withContext(Dispatchers.IO) {
                    val pm = context.packageManager
                    val installedPackages: List<PackageInfo> = try {
                        pm.getInstalledPackages(0)
                    } catch (_: Exception) {
                        emptyList()
                    }

                    val discoveredByPkg = LinkedHashMap<String, InstalledUserAppInfo>()

                    for (pkgInfo in installedPackages) {
                        val appInfo = pkgInfo.applicationInfo ?: continue
                        val pkgName = pkgInfo.packageName ?: continue
                        if (pkgName == context.packageName) continue

                        val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                        val isUpdatedSystemApp = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                        val hasPatch = EncryptedSmaliPatchVault.hasPatchForPackage(pkgName)

                        // Include non-system user apps (or any app explicitly in our patch registry)
                        if (!isSystemApp || isUpdatedSystemApp || hasPatch) {
                            val sourceDir = appInfo.sourceDir ?: continue
                            val sourceFile = File(sourceDir)
                            if (!sourceFile.exists()) continue

                            val label = try {
                                pm.getApplicationLabel(appInfo).toString().ifBlank { pkgName }
                            } catch (_: Exception) {
                                pkgName
                            }
                            val verName = pkgInfo.versionName ?: "1.0.0"
                            val iconBmp = try {
                                drawableToBitmap(pm.getApplicationIcon(appInfo))
                            } catch (_: Exception) {
                                null
                            }

                            discoveredByPkg[pkgName] = InstalledUserAppInfo(
                                appName = label,
                                packageName = pkgName,
                                versionName = verName,
                                sourceApkPath = sourceDir,
                                iconBitmap = iconBmp,
                                hasAvailablePatch = hasPatch
                            )
                        }
                    }

                    // Explicitly verify registered target packages (e.g. app.ninjavpn.android) via PackageManager
                    for (registeredPkg in EncryptedSmaliPatchVault.getRegisteredPackageNames()) {
                        if (!discoveredByPkg.containsKey(registeredPkg)) {
                            try {
                                val pkgInfo = pm.getPackageInfo(registeredPkg, 0)
                                val appInfo = pkgInfo.applicationInfo
                                val sourceDir = appInfo?.sourceDir
                                if (appInfo != null && sourceDir != null && File(sourceDir).exists()) {
                                    val label = try {
                                        pm.getApplicationLabel(appInfo).toString().ifBlank { registeredPkg }
                                    } catch (_: Exception) {
                                        registeredPkg
                                    }
                                    val verName = pkgInfo.versionName ?: "1.0.0"
                                    val iconBmp = try {
                                        drawableToBitmap(pm.getApplicationIcon(appInfo))
                                    } catch (_: Exception) {
                                        null
                                    }
                                    discoveredByPkg[registeredPkg] = InstalledUserAppInfo(
                                        appName = label,
                                        packageName = registeredPkg,
                                        versionName = verName,
                                        sourceApkPath = sourceDir,
                                        iconBitmap = iconBmp,
                                        hasAvailablePatch = true
                                    )
                                }
                            } catch (_: Exception) {
                                // Package is not installed on this device; do not add fake placeholders
                            }
                        }
                    }

                    // Sort so apps with available patches ("تم العثور على تعديل") appear at the very top
                    discoveredByPkg.values.sortedWith(
                        compareByDescending<InstalledUserAppInfo> { it.hasAvailablePatch }
                            .thenBy { it.appName.lowercase() }
                    )
                }

                _uiState.update {
                    it.copy(
                        isLoadingApps = false,
                        installedApps = sortedApps
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoadingApps = false,
                        errorMessage = "تعذر جلب قائمة التطبيقات المثبتة: ${e.localizedMessage ?: ""}"
                    )
                }
            }
        }
    }

    /**
     * Called when the user taps any installed app card (supported or unsupported).
     * Opens the clean execution bottom sheet/card.
     */
    fun onSupportedAppClicked(app: InstalledUserAppInfo) {
        if (_uiState.value.isProcessing) return
        _uiState.update {
            it.copy(
                selectedAppForSheet = app,
                stage = SmaliReplacerStage.IDLE,
                currentStepNumber = 0,
                progressPercent = 0,
                statusText = "",
                result = null,
                errorMessage = null
            )
        }
    }

    fun dismissExecutionSheet() {
        if (_uiState.value.isProcessing) return
        _uiState.update {
            it.copy(
                selectedAppForSheet = null,
                stage = SmaliReplacerStage.IDLE,
                currentStepNumber = 0,
                progressPercent = 0,
                statusText = "",
                errorMessage = null
            )
        }
    }

    /**
     * Executes the complete extraction, in-memory AES-256 patch decryption, DEX patching,
     * 4-byte zipalign, and V1/V2/V3 signing flow with 4 clean, non-technical Arabic status steps:
     * 1. "جاري سحب نسخة التطبيق..."
     * 2. "جاري تطبيق التعديلات الذكية..."
     * 3. "جاري إعادة البناء والتوقيع..."
     * 4. "تم التعديل بنجاح! اضغط للتثبيت."
     */
    fun applySmaliPatchForSelectedApp(context: Context) {
        val targetApp = _uiState.value.selectedAppForSheet ?: return
        if (_uiState.value.isProcessing) return

        viewModelScope.launch {
            // Step 1: "جاري سحب نسخة التطبيق..."
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    stage = SmaliReplacerStage.SCANNING_DEX,
                    currentStepNumber = 1,
                    progressPercent = 18,
                    statusText = "جاري سحب نسخة التطبيق...",
                    result = null,
                    errorMessage = null
                )
            }

            try {
                val patchResult = withContext(Dispatchers.IO) {
                    val baseApkFile = File(targetApp.sourceApkPath)
                    require(baseApkFile.exists() && baseApkFile.length() > 0L) {
                        "تعذر الوصول إلى ملف التطبيق الأساسي."
                    }

                    // Pull a clean working copy of the installed app's base APK
                    val pullDir = File(context.cacheDir, "pulled_installed_apks").apply { mkdirs() }
                    val pulledApkFile = File(
                        pullDir,
                        "${targetApp.packageName.replace('.', '_')}_base.apk"
                    )
                    if (baseApkFile.absolutePath != pulledApkFile.absolutePath) {
                        if (pulledApkFile.exists()) {
                            pulledApkFile.delete()
                        }
                        baseApkFile.inputStream().use { input ->
                            FileOutputStream(pulledApkFile).use { output ->
                                input.copyTo(output, bufferSize = 64 * 1024)
                            }
                        }
                    }

                    val apkInfo = ApkFixerEngine.inspectApkFile(pulledApkFile).copy(
                        fileName = "${targetApp.appName}.apk",
                        packageName = targetApp.packageName
                    )

                    // Step 2: Decrypt the package's Smali patches strictly in memory right when patching starts
                    _uiState.update {
                        it.copy(
                            stage = SmaliReplacerStage.PATCHING_DEX,
                            currentStepNumber = 2,
                            progressPercent = 50,
                            statusText = "جاري تطبيق التعديلات الذكية..."
                        )
                    }

                    val decryptedPatchesInMemory =
                        EncryptedSmaliPatchVault.getDecryptedPatchesForPackageInMemory(targetApp.packageName)
                            ?: SmaliMethodReplacer.DEFAULT_SMALI_PATCHES

                    SmaliMethodReplacer.replaceMethodsAndSignApk(
                        context = context,
                        sourceApk = apkInfo,
                        patches = decryptedPatchesInMemory,
                        onLog = { /* Technical logs suppressed from UI */ },
                        onProgress = { stage, _, _ ->
                            when (stage) {
                                SmaliReplacerStage.ASSEMBLING_SMALI,
                                SmaliReplacerStage.SCANNING_DEX -> {
                                    _uiState.update {
                                        it.copy(
                                            stage = stage,
                                            currentStepNumber = 1,
                                            progressPercent = 25,
                                            statusText = "جاري سحب نسخة التطبيق..."
                                        )
                                    }
                                }
                                SmaliReplacerStage.PATCHING_DEX -> {
                                    _uiState.update {
                                        it.copy(
                                            stage = stage,
                                            currentStepNumber = 2,
                                            progressPercent = 58,
                                            statusText = "جاري تطبيق التعديلات الذكية..."
                                        )
                                    }
                                }
                                SmaliReplacerStage.REBUILDING_APK,
                                SmaliReplacerStage.SIGNING_APK -> {
                                    _uiState.update {
                                        it.copy(
                                            stage = stage,
                                            currentStepNumber = 3,
                                            progressPercent = 86,
                                            statusText = "جاري إعادة البناء والتوقيع..."
                                        )
                                    }
                                }
                                SmaliReplacerStage.COMPLETED -> {
                                    _uiState.update {
                                        it.copy(
                                            stage = stage,
                                            currentStepNumber = 4,
                                            progressPercent = 100,
                                            statusText = "تم التعديل بنجاح! اضغط للتثبيت."
                                        )
                                    }
                                }
                                else -> Unit
                            }
                        }
                    )
                }

                // Step 4: "تم التعديل بنجاح! اضغط للتثبيت."
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        stage = SmaliReplacerStage.COMPLETED,
                        currentStepNumber = 4,
                        progressPercent = 100,
                        statusText = "تم التعديل بنجاح! اضغط للتثبيت.",
                        result = patchResult,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        stage = SmaliReplacerStage.FAILED,
                        currentStepNumber = 0,
                        progressPercent = 0,
                        statusText = "تعذر إكمال التعديل",
                        errorMessage = "تعذر إكمال تعديل التطبيق. يرجى المحاولة مرة أخرى."
                    )
                }
            }
        }
    }

    // Legacy compatibility methods kept intact if invoked externally
    fun onApkFileSelected(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val appItem = withContext(Dispatchers.IO) {
                    val displayName = resolveDisplayName(context, uri) ?: "Selected_App.apk"
                    val importDir = File(context.cacheDir, "imported_smali_apks").apply { mkdirs() }
                    val localFile = File(importDir, displayName.replace(Regex("[^a-zA-Z0-9._-]"), "_"))
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(localFile).use { output ->
                            input.copyTo(output, bufferSize = 64 * 1024)
                        }
                    } ?: throw IllegalStateException("تعذر فتح الملف.")

                    val info = ApkFixerEngine.inspectApkFile(localFile, uri).copy(fileName = displayName)
                    EncryptedSmaliPatchVault.registerPackagePatches(
                        info.packageName,
                        SmaliMethodReplacer.DEFAULT_SMALI_PATCHES
                    )
                    InstalledUserAppInfo(
                        appName = displayName.removeSuffix(".apk"),
                        packageName = info.packageName,
                        versionName = "1.0",
                        sourceApkPath = localFile.absolutePath,
                        iconBitmap = null,
                        hasAvailablePatch = true
                    )
                }
                onSupportedAppClicked(appItem)
            } catch (_: Exception) {
            }
        }
    }

    fun installPatchedApk(context: Context) {
        val outputFile = _uiState.value.result?.outputApkFile ?: return
        if (!outputFile.exists()) {
            _uiState.update { it.copy(errorMessage = "ملف التطبيق المعدّل غير موجود.") }
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!context.packageManager.canRequestPackageInstalls()) {
                    val settingsIntent = Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${context.packageName}")
                    ).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(settingsIntent)
                    return
                }
            }

            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outputFile
            )

            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر تشغيل مثبّت الحزم: ${e.localizedMessage}")
            }
        }
    }

    fun sharePatchedApk(context: Context) {
        val outputFile = _uiState.value.result?.outputApkFile ?: return
        if (!outputFile.exists()) return

        try {
            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outputFile
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, apkUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(
                Intent.createChooser(shareIntent, "مشاركة التطبيق المعدّل").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } catch (_: Exception) {
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val width = drawable.intrinsicWidth.coerceIn(48, 192)
        val height = drawable.intrinsicHeight.coerceIn(48, 192)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    private fun resolveDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) {
                    cursor.getString(nameIndex)
                } else {
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }
}
