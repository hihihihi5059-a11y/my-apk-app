package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.ApkFixerEngine
import com.example.engine.SmaliClassInjector
import com.example.model.ClassInjectorPreset
import com.example.model.ClassInjectorStage
import com.example.model.ClassInjectorUiState
import com.example.model.DuplicateClassPolicy
import com.example.model.HookInjectionPosition
import com.example.model.MethodHookSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Standalone ViewModel exclusively for Tab 4 ("حقن كلاسات" / Smali Class Injection & Extension Patching).
 */
class ClassInjectorViewModel : ViewModel() {

    private val initialPreset = SmaliClassInjector.PRESETS.first()

    private val _uiState = MutableStateFlow(
        ClassInjectorUiState(
            smaliClassesInput = initialPreset.smaliClassesCode,
            selectedPresetId = initialPreset.id,
            hooksEnabled = false,
            hookTargetClass = initialPreset.defaultHookClass,
            hookTargetMethodSignature = initialPreset.defaultHookMethodSignature,
            hookInstructionsInput = initialPreset.defaultHookInstructions,
            hookPosition = initialPreset.defaultHookPosition
        )
    )
    val uiState: StateFlow<ClassInjectorUiState> = _uiState.asStateFlow()

    fun applyPreset(preset: ClassInjectorPreset) {
        if (_uiState.value.isProcessing) return
        _uiState.update {
            it.copy(
                selectedPresetId = preset.id,
                smaliClassesInput = preset.smaliClassesCode,
                hooksEnabled = preset.enableHookByDefault,
                hookTargetClass = preset.defaultHookClass.ifBlank { it.hookTargetClass },
                hookTargetMethodSignature = preset.defaultHookMethodSignature.ifBlank { it.hookTargetMethodSignature },
                hookInstructionsInput = preset.defaultHookInstructions.ifBlank { it.hookInstructionsInput },
                hookPosition = preset.defaultHookPosition,
                errorMessage = null
            )
        }
    }

    fun updateSmaliClassesInput(value: String) {
        _uiState.update { it.copy(smaliClassesInput = value, errorMessage = null) }
    }

    fun updateTargetDexChoice(dexName: String) {
        _uiState.update { it.copy(targetDexChoice = dexName) }
    }

    fun updateDuplicatePolicy(policy: DuplicateClassPolicy) {
        _uiState.update { it.copy(duplicatePolicy = policy) }
    }

    fun setHooksEnabled(enabled: Boolean) {
        _uiState.update { it.copy(hooksEnabled = enabled) }
    }

    fun updateHookTargetClass(value: String) {
        _uiState.update { it.copy(hookTargetClass = value) }
    }

    fun updateHookTargetMethodSignature(value: String) {
        _uiState.update { it.copy(hookTargetMethodSignature = value) }
    }

    fun updateHookInstructionsInput(value: String) {
        _uiState.update { it.copy(hookInstructionsInput = value) }
    }

    fun updateHookPosition(position: HookInjectionPosition) {
        _uiState.update { it.copy(hookPosition = position) }
    }

    fun onApkFileSelected(context: Context, uri: Uri) {
        if (_uiState.value.isProcessing) return
        viewModelScope.launch {
            _uiState.update { it.copy(errorMessage = null, result = null) }
            try {
                val apkInfo = withContext(Dispatchers.IO) {
                    val displayName = resolveDisplayName(context, uri) ?: "Target_App.apk"
                    val importDir = File(context.cacheDir, "injector_imported_apks").apply { mkdirs() }
                    val safeName = displayName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                    val localFile = File(importDir, safeName)
                    if (localFile.exists()) localFile.delete()

                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(localFile).use { output ->
                            input.copyTo(output, bufferSize = 64 * 1024)
                        }
                    } ?: throw IllegalStateException("تعذر قراءة ملف الـ APK المختار.")

                    ApkFixerEngine.inspectApkFile(localFile, uri).copy(
                        fileName = displayName,
                        isSample = false
                    )
                }

                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        currentStage = ClassInjectorStage.IDLE,
                        progressPercent = 0,
                        statusMessage = "تم تحميل الملف: ${apkInfo.fileName}",
                        logs = listOf("▶ تم فحص الحزمة: ${apkInfo.packageName} (${apkInfo.formattedSize})")
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "فشل قراءة ملف APK: ${e.localizedMessage ?: "خطأ غير معروف"}")
                }
            }
        }
    }

    fun generateSampleHostApk(context: Context) {
        if (_uiState.value.isProcessing) return
        viewModelScope.launch {
            _uiState.update { it.copy(errorMessage = null, result = null) }
            try {
                val apkInfo = withContext(Dispatchers.IO) {
                    val sampleDir = File(context.cacheDir, "injector_sample_apks").apply { mkdirs() }
                    val sampleFile = File(sampleDir, "Injector_Host_Sample.apk")
                    SmaliClassInjector.createSampleHostApk(sampleFile)
                    ApkFixerEngine.inspectApkFile(sampleFile).copy(
                        fileName = "Injector_Host_Sample.apk",
                        isSample = true
                    )
                }
                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        currentStage = ClassInjectorStage.IDLE,
                        progressPercent = 0,
                        statusMessage = "تم إنشاء APK تجريبي جاهز لحقن الكلاسات والـ Hooks",
                        logs = listOf(
                            "▶ تم إنشاء APK تجريبي: Injector_Host_Sample.apk",
                            "• يحتوي على الكلاس Lcom/example/HostEntry; والدالة onCreateHook()V"
                        )
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(errorMessage = "تعذر إنشاء الملف التجريبي: ${e.localizedMessage}")
                }
            }
        }
    }

    fun startClassInjection(context: Context) {
        val current = _uiState.value
        val sourceApk = current.selectedApk ?: return
        if (current.isProcessing) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    currentStage = ClassInjectorStage.ASSEMBLING_CLASSES,
                    progressPercent = 5,
                    statusMessage = ClassInjectorStage.ASSEMBLING_CLASSES.labelAr,
                    logs = listOf("▶ بدء عملية حقن الكلاسات في ${sourceApk.fileName}..."),
                    result = null,
                    errorMessage = null
                )
            }

            try {
                val hooksList = if (current.hooksEnabled) {
                    listOf(
                        MethodHookSpec(
                            targetClassDescriptor = current.hookTargetClass,
                            targetMethodSignature = current.hookTargetMethodSignature,
                            hookSmaliInstructions = current.hookInstructionsInput,
                            position = current.hookPosition
                        )
                    )
                } else {
                    emptyList()
                }

                val injectionResult = SmaliClassInjector.injectClassesAndSignApk(
                    context = context,
                    sourceApk = sourceApk,
                    smaliClassesRaw = current.smaliClassesInput,
                    targetDexName = current.targetDexChoice,
                    duplicatePolicy = current.duplicatePolicy,
                    hooks = hooksList,
                    onLog = { line ->
                        _uiState.update { state ->
                            state.copy(logs = state.logs + line)
                        }
                    },
                    onProgress = { stage, percent, msg ->
                        _uiState.update { state ->
                            state.copy(
                                currentStage = stage,
                                progressPercent = percent,
                                statusMessage = msg
                            )
                        }
                    }
                )

                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        currentStage = ClassInjectorStage.COMPLETED,
                        progressPercent = 100,
                        statusMessage = ClassInjectorStage.COMPLETED.labelAr,
                        result = injectionResult
                    )
                }
            } catch (e: Exception) {
                val msg = e.localizedMessage ?: "حدث خطأ غير متوقع أثناء حقن الكلاسات."
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        currentStage = ClassInjectorStage.FAILED,
                        progressPercent = 0,
                        statusMessage = ClassInjectorStage.FAILED.labelAr,
                        logs = it.logs + "✖ خطأ: $msg",
                        errorMessage = msg
                    )
                }
            }
        }
    }

    fun installInjectedApk(context: Context) {
        val outputFile = _uiState.value.result?.outputApkFile ?: return
        if (!outputFile.exists()) {
            _uiState.update { it.copy(errorMessage = "ملف الـ APK الناتج غير موجود.") }
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()
            ) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(intent)
                return
            }

            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outputFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر تشغيل مثبّت الحزم: ${e.localizedMessage}")
            }
        }
    }

    fun shareInjectedApk(context: Context) {
        val outputFile = _uiState.value.result?.outputApkFile ?: return
        if (!outputFile.exists()) return
        try {
            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outputFile
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, apkUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(
                Intent.createChooser(shareIntent, "مشاركة APK المحقون بالكلاسات").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر مشاركة الملف: ${e.localizedMessage}")
            }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun resolveDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) cursor.getString(nameIndex) else null
            }
        } catch (_: Exception) {
            null
        }
    }
}
