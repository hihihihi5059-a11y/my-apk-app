package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.SmaliClassInjector
import com.example.model.ApkFileInfo
import com.example.model.ClassInjectorPreset
import com.example.model.ClassInjectorResult
import com.example.model.ClassInjectorStage
import com.example.model.ClassInjectorUiState
import com.example.model.DuplicateClassPolicy
import com.example.model.HookInjectionPosition
import com.example.ui.theme.CoralError
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanAccentGlow
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.DeepNavyBorder
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceElevated
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldWarning
import com.example.ui.theme.OnCyanAccent

@Composable
fun ClassInjectorScreen(
    uiState: ClassInjectorUiState,
    onSelectApkClick: () -> Unit,
    onGenerateSampleApkClick: () -> Unit,
    onSelectPreset: (ClassInjectorPreset) -> Unit,
    onSmaliClassesInputChange: (String) -> Unit,
    onTargetDexChoiceChange: (String) -> Unit,
    onDuplicatePolicyChange: (DuplicateClassPolicy) -> Unit,
    onHooksEnabledChange: (Boolean) -> Unit,
    onHookTargetClassChange: (String) -> Unit,
    onHookTargetMethodSignatureChange: (String) -> Unit,
    onHookInstructionsInputChange: (String) -> Unit,
    onHookPositionChange: (HookInjectionPosition) -> Unit,
    onInjectAndSignClick: () -> Unit,
    onInstallClick: () -> Unit,
    onSaveClick: () -> Unit,
    onShareClick: () -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val targetDexOptions = listOf("classes.dex", "classes2.dex", "classes3.dex")

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            DeepNavyBackground,
                            Color(0xFF0A1426),
                            DeepNavyBackground
                        )
                    )
                )
                .testTag("class_injector_screen"),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Header Banner
                InjectorHeaderCard()

                // 2. Error Banner
                AnimatedVisibility(visible = uiState.errorMessage != null) {
                    uiState.errorMessage?.let { err ->
                        InjectorErrorCard(errorText = err, onDismiss = onDismissError)
                    }
                }

                // 3. Source APK Selector + APK Info Display
                SourceApkSelectorCard(
                    selectedApk = uiState.selectedApk,
                    isProcessing = uiState.isProcessing,
                    onSelectApkClick = onSelectApkClick,
                    onGenerateSampleApkClick = onGenerateSampleApkClick
                )

                // 4. Preset Selector + Smali .class Input Area
                SmaliClassesEditorCard(
                    smaliClassesInput = uiState.smaliClassesInput,
                    selectedPresetId = uiState.selectedPresetId,
                    targetDexChoice = uiState.targetDexChoice,
                    targetDexOptions = targetDexOptions,
                    duplicatePolicy = uiState.duplicatePolicy,
                    isProcessing = uiState.isProcessing,
                    onSelectPreset = onSelectPreset,
                    onSmaliClassesInputChange = onSmaliClassesInputChange,
                    onTargetDexChoiceChange = onTargetDexChoiceChange,
                    onDuplicatePolicyChange = onDuplicatePolicyChange
                )

                // 5. Optional Method Hook Injection Card
                OptionalMethodHookCard(
                    hooksEnabled = uiState.hooksEnabled,
                    hookTargetClass = uiState.hookTargetClass,
                    hookTargetMethodSignature = uiState.hookTargetMethodSignature,
                    hookInstructionsInput = uiState.hookInstructionsInput,
                    hookPosition = uiState.hookPosition,
                    isProcessing = uiState.isProcessing,
                    onHooksEnabledChange = onHooksEnabledChange,
                    onHookTargetClassChange = onHookTargetClassChange,
                    onHookTargetMethodSignatureChange = onHookTargetMethodSignatureChange,
                    onHookInstructionsInputChange = onHookInstructionsInputChange,
                    onHookPositionChange = onHookPositionChange
                )

                // 6. Primary Action Button + Progress Indicator
                Button(
                    onClick = onInjectAndSignClick,
                    enabled = uiState.selectedApk != null &&
                        uiState.smaliClassesInput.isNotBlank() &&
                        !uiState.isProcessing,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = OnCyanAccent,
                        disabledContainerColor = DeepNavySurfaceElevated,
                        disabledContentColor = DarkTextMuted
                    ),
                    contentPadding = PaddingValues(vertical = 16.dp, horizontal = 20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("inject_classes_sign_button")
                ) {
                    if (uiState.isProcessing) {
                        CircularProgressIndicator(
                            color = OnCyanAccent,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = uiState.statusMessage.ifEmpty { "جاري حقن الكلاسات..." },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.LibraryAdd,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "حقن الكلاسات وتوقيع APK",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                // Progress Status Card
                AnimatedVisibility(
                    visible = uiState.isProcessing || uiState.currentStage == ClassInjectorStage.COMPLETED
                ) {
                    InjectorProgressCard(
                        stage = uiState.currentStage,
                        progressPercent = uiState.progressPercent,
                        statusMessage = uiState.statusMessage
                    )
                }

                // 7. Live Execution Console Log
                if (uiState.logs.isNotEmpty()) {
                    LiveExecutionConsoleCard(logs = uiState.logs)
                }

                // 8. Result Summary Card (Injected Classes + Install / Save / Share)
                AnimatedVisibility(visible = uiState.result != null) {
                    uiState.result?.let { res ->
                        ClassInjectionResultCard(
                            result = res,
                            onInstallClick = onInstallClick,
                            onSaveClick = onSaveClick,
                            onShareClick = onShareClick
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }
        }
    }
}

@Composable
private fun InjectorHeaderCard() {
    Surface(
        color = DeepNavySurface,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CyanAccent.copy(alpha = 0.14f))
                    .border(1.dp, CyanAccent.copy(alpha = 0.55f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LibraryAdd,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = "حقن كلاسات Smali والامتدادات (Class Injector)",
                    style = MaterialTheme.typography.titleSmall,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "تجميع وحقن تعريفات .class جديدة في DEX مع ربط Hooks اختيارية وتوقيع V1/V2/V3",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary
                )
            }
        }
    }
}

@Composable
private fun SourceApkSelectorCard(
    selectedApk: ApkFileInfo?,
    isProcessing: Boolean,
    onSelectApkClick: () -> Unit,
    onGenerateSampleApkClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Android,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "1. ملف APK المستهدف (Source APK)",
                    style = MaterialTheme.typography.titleSmall,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            if (selectedApk != null) {
                Surface(
                    color = DeepNavySurfaceElevated,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("injector_selected_apk_info")
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = selectedApk.fileName,
                            style = MaterialTheme.typography.titleSmall,
                            color = DarkTextPrimary,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            InfoBadgeChip("الحزمة: ${selectedApk.packageName}")
                            InfoBadgeChip(selectedApk.formattedSize)
                        }
                        if (selectedApk.detectedMinSdk != null || selectedApk.detectedTargetSdk != null) {
                            Text(
                                text = "minSdk: ${selectedApk.detectedMinSdk ?: "?"}  •  targetSdk: ${selectedApk.detectedTargetSdk ?: "?"}",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyanAccentGlow
                            )
                        }
                    }
                }
            } else {
                Surface(
                    color = DeepNavyBackground.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "لم يتم اختيار ملف APK بعد. اختر ملفاً من جهازك أو أنشئ APK تجريبياً للاختبار.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextMuted,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onSelectApkClick,
                    enabled = !isProcessing,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent.copy(alpha = 0.18f),
                        contentColor = CyanAccent
                    ),
                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("injector_pick_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "اختيار APK",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onGenerateSampleApkClick,
                    enabled = !isProcessing,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkTextSecondary),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("injector_generate_sample_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Science,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "APK تجريبي",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SmaliClassesEditorCard(
    smaliClassesInput: String,
    selectedPresetId: String,
    targetDexChoice: String,
    targetDexOptions: List<String>,
    duplicatePolicy: DuplicateClassPolicy,
    isProcessing: Boolean,
    onSelectPreset: (ClassInjectorPreset) -> Unit,
    onSmaliClassesInputChange: (String) -> Unit,
    onTargetDexChoiceChange: (String) -> Unit,
    onDuplicatePolicyChange: (DuplicateClassPolicy) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Code,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "2. تعريفات كلاسات Smali (.class ...)",
                    style = MaterialTheme.typography.titleSmall,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            // Preset Selector
            Text(
                text = "قوالب جاهزة (Presets):",
                style = MaterialTheme.typography.labelMedium,
                color = DarkTextSecondary
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SmaliClassInjector.PRESETS.forEach { preset ->
                    val isSelected = preset.id == selectedPresetId
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectPreset(preset) },
                        enabled = !isProcessing,
                        label = {
                            Text(
                                text = preset.titleAr,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                            selectedLabelColor = CyanAccent,
                            containerColor = DeepNavySurfaceElevated,
                            labelColor = DarkTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = !isProcessing,
                            selected = isSelected,
                            borderColor = DeepNavyBorder,
                            selectedBorderColor = CyanAccent
                        )
                    )
                }
            }

            // LTR Monospace Smali Code Editor
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                OutlinedTextField(
                    value = smaliClassesInput,
                    onValueChange = onSmaliClassesInputChange,
                    enabled = !isProcessing,
                    label = {
                        Text(
                            text = "Full .class Smali Definitions (Supports 1 or multiple .class blocks)",
                            style = MaterialTheme.typography.labelSmall
                        )
                    },
                    textStyle = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = DarkTextPrimary
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanAccent,
                        unfocusedBorderColor = DeepNavyBorder,
                        focusedContainerColor = DeepNavyBackground,
                        unfocusedContainerColor = DeepNavyBackground,
                        focusedLabelColor = CyanAccent,
                        unfocusedLabelColor = DarkTextSecondary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    minLines = 7,
                    maxLines = 14,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("smali_class_code_input")
                )
            }

            HorizontalDivider(color = DeepNavyBorder)

            // Target DEX Selector
            Text(
                text = "ملف DEX المستهدف للحقن (Target DEX):",
                style = MaterialTheme.typography.labelMedium,
                color = DarkTextSecondary
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                targetDexOptions.forEach { dexName ->
                    val selected = targetDexChoice == dexName
                    Surface(
                        color = if (selected) CyanAccent.copy(alpha = 0.2f) else DeepNavySurfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            1.dp,
                            if (selected) CyanAccent else DeepNavyBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(enabled = !isProcessing) { onTargetDexChoiceChange(dexName) }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = dexName,
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) CyanAccent else DarkTextSecondary
                            )
                        }
                    }
                }
            }

            // Duplicate Class Policy
            Text(
                text = "سياسة التعامل مع التكرار (Duplicate Check):",
                style = MaterialTheme.typography.labelMedium,
                color = DarkTextSecondary
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                DuplicateClassPolicy.entries.forEach { policy ->
                    val selected = duplicatePolicy == policy
                    Surface(
                        color = if (selected) CyanAccent.copy(alpha = 0.14f) else DeepNavySurfaceElevated,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, if (selected) CyanAccent else DeepNavyBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(enabled = !isProcessing) { onDuplicatePolicyChange(policy) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = policy.titleAr,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) CyanAccentGlow else DarkTextSecondary
                            )
                            Text(
                                text = policy.titleEn,
                                style = MaterialTheme.typography.labelSmall,
                                color = DarkTextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionalMethodHookCard(
    hooksEnabled: Boolean,
    hookTargetClass: String,
    hookTargetMethodSignature: String,
    hookInstructionsInput: String,
    hookPosition: HookInjectionPosition,
    isProcessing: Boolean,
    onHooksEnabledChange: (Boolean) -> Unit,
    onHookTargetClassChange: (String) -> Unit,
    onHookTargetMethodSignatureChange: (String) -> Unit,
    onHookInstructionsInputChange: (String) -> Unit,
    onHookPositionChange: (HookInjectionPosition) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        border = BorderStroke(
            1.dp,
            if (hooksEnabled) CyanAccent.copy(alpha = 0.55f) else DeepNavyBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = null,
                        tint = if (hooksEnabled) CyanAccent else DarkTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "3. حقن استدعاء ربط اختياري (Method Hook)",
                            style = MaterialTheme.typography.titleSmall,
                            color = DarkTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "استدعاء الكلاس المحقون من داخل دالة قائمة بدون إعادة كتابة الكلاس بالكامل",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary
                        )
                    }
                }

                Switch(
                    checked = hooksEnabled,
                    onCheckedChange = onHooksEnabledChange,
                    enabled = !isProcessing,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = OnCyanAccent,
                        checkedTrackColor = CyanAccent
                    ),
                    modifier = Modifier.testTag("injector_hook_toggle")
                )
            }

            AnimatedVisibility(visible = hooksEnabled) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    HorizontalDivider(color = DeepNavyBorder)

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        OutlinedTextField(
                            value = hookTargetClass,
                            onValueChange = onHookTargetClassChange,
                            enabled = !isProcessing,
                            singleLine = true,
                            label = { Text("Target Class Descriptor (e.g. Lcom/example/HostEntry;)") },
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = DarkTextPrimary
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = DeepNavyBorder,
                                focusedContainerColor = DeepNavyBackground,
                                unfocusedContainerColor = DeepNavyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = hookTargetMethodSignature,
                            onValueChange = onHookTargetMethodSignatureChange,
                            enabled = !isProcessing,
                            singleLine = true,
                            label = { Text("Target Method Signature (e.g. onCreateHook()V)") },
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = DarkTextPrimary
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = DeepNavyBorder,
                                focusedContainerColor = DeepNavyBackground,
                                unfocusedContainerColor = DeepNavyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = hookInstructionsInput,
                            onValueChange = onHookInstructionsInputChange,
                            enabled = !isProcessing,
                            label = { Text("Smali Hook Instructions") },
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = DarkTextPrimary
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = DeepNavyBorder,
                                focusedContainerColor = DeepNavyBackground,
                                unfocusedContainerColor = DeepNavyBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            minLines = 2,
                            maxLines = 5,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Text(
                        text = "موضع الحقن داخل الدالة:",
                        style = MaterialTheme.typography.labelMedium,
                        color = DarkTextSecondary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HookInjectionPosition.entries.forEach { pos ->
                            val selected = hookPosition == pos
                            Surface(
                                color = if (selected) CyanAccent.copy(alpha = 0.2f) else DeepNavySurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) CyanAccent else DeepNavyBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable(enabled = !isProcessing) { onHookPositionChange(pos) }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = pos.titleAr,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) CyanAccent else DarkTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InjectorProgressCard(
    stage: ClassInjectorStage,
    progressPercent: Int,
    statusMessage: String
) {
    val isDone = stage == ClassInjectorStage.COMPLETED
    Surface(
        color = DeepNavySurfaceElevated,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            1.dp,
            if (isDone) EmeraldSuccess.copy(alpha = 0.65f) else CyanAccent.copy(alpha = 0.45f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = statusMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isDone) EmeraldSuccess else CyanAccentGlow,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "$progressPercent%",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isDone) EmeraldSuccess else CyanAccent,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            LinearProgressIndicator(
                progress = { (progressPercent / 100f).coerceIn(0f, 1f) },
                color = if (isDone) EmeraldSuccess else CyanAccent,
                trackColor = DeepNavyBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp))
            )
        }
    }
}

@Composable
private fun LiveExecutionConsoleCard(logs: List<String>) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF050A14)),
        border = BorderStroke(1.dp, DeepNavyBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("injector_console_log")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "سجل التنفيذ المباشر (Live Console Log)",
                    style = MaterialTheme.typography.labelLarge,
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold
                )
            }

            HorizontalDivider(color = DeepNavyBorder)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 200.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                logs.forEach { line ->
                    val lineColor = when {
                        line.startsWith("✓") || line.startsWith("★") -> EmeraldSuccess
                        line.startsWith("⚠") || line.startsWith("↷") -> GoldWarning
                        line.startsWith("✖") -> CoralError
                        else -> DarkTextSecondary
                    }
                    Text(
                        text = line,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        color = lineColor
                    )
                }
            }
        }
    }
}

@Composable
private fun ClassInjectionResultCard(
    result: ClassInjectorResult,
    onInstallClick: () -> Unit,
    onSaveClick: () -> Unit,
    onShareClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurfaceElevated),
        border = BorderStroke(1.5.dp, EmeraldSuccess.copy(alpha = 0.7f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("injector_result_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = EmeraldSuccess,
                    modifier = Modifier.size(26.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "تم حقن الكلاسات وتوقيع الحزمة بنجاح",
                        style = MaterialTheme.typography.titleSmall,
                        color = EmeraldSuccess,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "${result.outputFileName} (${result.formattedOutputSize}) • ${result.executionDurationMs}ms",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
                Surface(
                    color = EmeraldSuccess.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "V1+V2+V3",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldSuccess,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            HorizontalDivider(color = DeepNavyBorder)

            Text(
                text = "الكلاسات المحقونة (${result.injectedClasses.size}) — DEX المعدّل: ${result.modifiedDexFiles.joinToString(", ")}",
                style = MaterialTheme.typography.labelMedium,
                color = DarkTextPrimary,
                fontWeight = FontWeight.Bold
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                result.injectedClasses.forEach { item ->
                    Surface(
                        color = DeepNavyBackground.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, DeepNavyBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddCircleOutline,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = item.classDescriptor,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp
                                    ),
                                    color = DarkTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = "${item.targetDexName} • ${item.methodsCount}M/${item.fieldsCount}F",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            if (result.appliedHooks.isNotEmpty()) {
                Text(
                    text = "الـ Hooks المطبّقة (${result.appliedHooks.size}):",
                    style = MaterialTheme.typography.labelMedium,
                    color = CyanAccentGlow,
                    fontWeight = FontWeight.Bold
                )
                result.appliedHooks.forEach { hook ->
                    Text(
                        text = "• [${hook.dexFileName}] ${hook.targetClassDescriptor}->${hook.targetMethodSignature} (${hook.position.titleEn})",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                        color = DarkTextSecondary
                    )
                }
            }

            // Direct Action Buttons: Install ("تثبيت"), Save ("حفظ"), Share ("مشاركة")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onInstallClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldSuccess,
                        contentColor = Color(0xFF041F14)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("injector_install_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.InstallMobile,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تثبيت", fontWeight = FontWeight.ExtraBold)
                }

                OutlinedButton(
                    onClick = onSaveClick,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CyanAccent),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("injector_save_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SaveAlt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("حفظ", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onShareClick,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, DeepNavyBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkTextPrimary),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("injector_share_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("مشاركة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InfoBadgeChip(label: String) {
    Surface(
        color = CyanAccent.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.3f))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = CyanAccentGlow,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun InjectorErrorCard(
    errorText: String,
    onDismiss: () -> Unit
) {
    Surface(
        color = CoralError.copy(alpha = 0.14f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CoralError.copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = CoralError,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = errorText,
                style = MaterialTheme.typography.bodySmall,
                color = DarkTextPrimary,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onDismiss) {
                Text("إغلاق", color = CoralError, fontWeight = FontWeight.Bold)
            }
        }
    }
}
