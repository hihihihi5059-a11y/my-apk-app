package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.model.InstalledUserAppInfo
import com.example.model.SmaliReplacerStage
import com.example.model.SmaliReplacerUiState
import com.example.ui.theme.CoralError
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanAccentGlow
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.DeepNavyBorder
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceElevated
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.OnCyanAccent

private val CLEAN_EXECUTION_STEPS = listOf(
    1 to "جاري سحب نسخة التطبيق...",
    2 to "جاري تطبيق التعديلات الذكية...",
    3 to "جاري إعادة البناء والتوقيع...",
    4 to "تم التعديل بنجاح! اضغط للتثبيت."
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmaliReplacerScreen(
    uiState: SmaliReplacerUiState,
    onRefreshInstalledApps: () -> Unit,
    onSupportedAppClick: (InstalledUserAppInfo) -> Unit,
    onApplyPatchNowClick: () -> Unit,
    onInstallPatchedClick: () -> Unit,
    onSavePatchedClick: () -> Unit,
    onDismissSheet: () -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        if (uiState.installedApps.isEmpty() && !uiState.isLoadingApps) {
            onRefreshInstalledApps()
        }
    }

    val supportedCount = uiState.installedApps.count { it.hasAvailablePatch }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            DeepNavyBackground,
                            Color(0xFF0A1426),
                            DeepNavyBackground
                        )
                    )
                )
                .testTag("smali_replacer_screen"),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Clean Top Summary Header
                InstalledAppsHeaderBanner(
                    totalAppsCount = uiState.installedApps.size,
                    supportedAppsCount = supportedCount,
                    isLoading = uiState.isLoadingApps,
                    onRefreshClick = onRefreshInstalledApps
                )

                // 2. Error Banner if any
                AnimatedVisibility(visible = uiState.errorMessage != null) {
                    uiState.errorMessage?.let { msg ->
                        CleanErrorBanner(
                            errorMessage = msg,
                            onDismiss = onDismissError
                        )
                    }
                }

                // 3. Installed User Apps List (Supported apps sorted to the very top)
                if (uiState.isLoadingApps && uiState.installedApps.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                color = CyanAccent,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "جاري فحص التطبيقات المثبتة على جهازك...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = DarkTextSecondary
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .testTag("installed_apps_list"),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(
                            items = uiState.installedApps,
                            key = { it.packageName }
                        ) { appItem ->
                            InstalledUserAppRowCard(
                                app = appItem,
                                onClick = {
                                    onSupportedAppClick(appItem)
                                }
                            )
                        }
                    }
                }
            }

            // 4. Clean Bottom Sheet when a Supported App is Tapped
            val selectedApp = uiState.selectedAppForSheet
            if (selectedApp != null) {
                val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
                ModalBottomSheet(
                    onDismissRequest = {
                        if (!uiState.isProcessing) {
                            onDismissSheet()
                        }
                    },
                    sheetState = sheetState,
                    containerColor = DeepNavySurface,
                    scrimColor = Color.Black.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        SmartPatchExecutionSheetContent(
                            app = selectedApp,
                            uiState = uiState,
                            onApplyPatchNowClick = onApplyPatchNowClick,
                            onInstallPatchedClick = onInstallPatchedClick,
                            onSavePatchedClick = onSavePatchedClick,
                            onDismissError = onDismissError,
                            onCloseClick = onDismissSheet
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InstalledAppsHeaderBanner(
    totalAppsCount: Int,
    supportedAppsCount: Int,
    isLoading: Boolean,
    onRefreshClick: () -> Unit
) {
    Surface(
        color = DeepNavySurface,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(CyanAccent.copy(alpha = 0.14f))
                        .border(1.dp, CyanAccent.copy(alpha = 0.55f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "مركز التعديلات الذكية للتطبيقات المثبتة",
                        style = MaterialTheme.typography.titleSmall,
                        color = DarkTextPrimary,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "تم اكتشاف $supportedAppsCount تطبيق مدعوم جاهز للتعديل من أصل $totalAppsCount تطبيق",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
            }

            IconButton(
                onClick = onRefreshClick,
                enabled = !isLoading,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("refresh_installed_apps_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "تحديث قائمة التطبيقات",
                    tint = CyanAccent
                )
            }
        }
    }
}

@Composable
private fun InstalledUserAppRowCard(
    app: InstalledUserAppInfo,
    onClick: () -> Unit
) {
    val isSupported = app.hasAvailablePatch

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (isSupported) 1f else 0.72f)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("installed_app_card_${app.packageName}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSupported) DeepNavySurfaceElevated else DeepNavySurface
        ),
        border = BorderStroke(
            width = if (isSupported) 1.5.dp else 1.dp,
            color = if (isSupported) EmeraldSuccess.copy(alpha = 0.65f) else DeepNavyBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // App Icon
            AppIconBox(
                app = app,
                sizeDp = 52
            )

            // App Name + Version Name
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = app.appName,
                    style = MaterialTheme.typography.titleSmall,
                    color = DarkTextPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "الإصدار ${app.versionName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary,
                    maxLines = 1
                )
            }

            // Status Badge ("تم العثور على تعديل" in bright green vs "لم يتم العثور على تعديل" in muted gray)
            Surface(
                color = if (isSupported) {
                    EmeraldSuccess.copy(alpha = 0.16f)
                } else {
                    DeepNavyBackground.copy(alpha = 0.6f)
                },
                shape = RoundedCornerShape(50),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isSupported) EmeraldSuccess.copy(alpha = 0.75f) else DeepNavyBorder
                ),
                modifier = Modifier.testTag(
                    if (isSupported) "badge_patch_found" else "badge_patch_not_found"
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isSupported) EmeraldSuccess else DarkTextMuted)
                    )
                    Text(
                        text = app.statusBadgeTextAr,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isSupported) EmeraldSuccess else DarkTextMuted
                    )
                }
            }
        }
    }
}

@Composable
private fun AppIconBox(
    app: InstalledUserAppInfo,
    sizeDp: Int
) {
    val bmp = app.iconBitmap
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (app.hasAvailablePatch) {
                    EmeraldSuccess.copy(alpha = 0.14f)
                } else {
                    DeepNavyBackground
                }
            )
            .border(
                width = 1.dp,
                color = if (app.hasAvailablePatch) {
                    EmeraldSuccess.copy(alpha = 0.5f)
                } else {
                    DeepNavyBorder
                },
                shape = RoundedCornerShape(14.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = app.appName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
        } else {
            Icon(
                imageVector = Icons.Default.Android,
                contentDescription = app.appName,
                tint = if (app.hasAvailablePatch) EmeraldSuccess else DarkTextSecondary,
                modifier = Modifier.size((sizeDp * 0.55f).dp)
            )
        }
    }
}

@Composable
private fun SmartPatchExecutionSheetContent(
    app: InstalledUserAppInfo,
    uiState: SmaliReplacerUiState,
    onApplyPatchNowClick: () -> Unit,
    onInstallPatchedClick: () -> Unit,
    onSavePatchedClick: () -> Unit,
    onDismissError: () -> Unit,
    onCloseClick: () -> Unit
) {
    val isCompleted = uiState.stage == SmaliReplacerStage.COMPLETED && uiState.result != null

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp, vertical = 12.dp)
            .padding(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Selected App Header inside Bottom Sheet
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                AppIconBox(app = app, sizeDp = 56)

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = app.appName,
                        style = MaterialTheme.typography.titleMedium,
                        color = DarkTextPrimary,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "الإصدار ${app.versionName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary
                        )
                        Surface(
                            color = if (app.hasAvailablePatch) {
                                EmeraldSuccess.copy(alpha = 0.16f)
                            } else {
                                DeepNavyBackground.copy(alpha = 0.75f)
                            },
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (app.hasAvailablePatch) EmeraldSuccess.copy(alpha = 0.6f) else DeepNavyBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (app.hasAvailablePatch) {
                                        Icons.Default.Verified
                                    } else {
                                        Icons.Default.AutoFixHigh
                                    },
                                    contentDescription = null,
                                    tint = if (app.hasAvailablePatch) EmeraldSuccess else DarkTextMuted,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = app.statusBadgeTextAr,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (app.hasAvailablePatch) EmeraldSuccess else DarkTextMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            if (!uiState.isProcessing) {
                IconButton(
                    onClick = onCloseClick,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = DarkTextSecondary
                    )
                }
            }
        }

        HorizontalDivider(color = DeepNavyBorder)

        // Clean Progress Bar & 4 Non-Technical Arabic Status Steps
        if (uiState.isProcessing || uiState.currentStepNumber > 0) {
            Surface(
                color = DeepNavySurfaceElevated,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isCompleted) EmeraldSuccess.copy(alpha = 0.7f) else CyanAccent.copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("smali_clean_progress_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = uiState.statusText.ifEmpty { "جاري سحب نسخة التطبيق..." },
                            style = MaterialTheme.typography.titleSmall,
                            color = if (isCompleted) EmeraldSuccess else CyanAccentGlow,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${uiState.progressPercent}%",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isCompleted) EmeraldSuccess else CyanAccent,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    LinearProgressIndicator(
                        progress = { (uiState.progressPercent / 100f).coerceIn(0f, 1f) },
                        color = if (isCompleted) EmeraldSuccess else CyanAccent,
                        trackColor = DeepNavyBackground,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        CLEAN_EXECUTION_STEPS.forEach { (stepNum, stepTitleAr) ->
                            val isStepDone = uiState.currentStepNumber > stepNum ||
                                (stepNum == 4 && isCompleted)
                            val isStepActive = uiState.currentStepNumber == stepNum && !isCompleted

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (isStepDone) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = EmeraldSuccess,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else if (isStepActive) {
                                    CircularProgressIndicator(
                                        color = CyanAccent,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .border(1.dp, DarkTextMuted, CircleShape)
                                    )
                                }

                                Text(
                                    text = stepTitleAr,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (isStepActive || isStepDone) {
                                        FontWeight.Bold
                                    } else {
                                        FontWeight.Normal
                                    },
                                    color = when {
                                        isStepDone -> EmeraldSuccess
                                        isStepActive -> DarkTextPrimary
                                        else -> DarkTextMuted
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (uiState.stage == SmaliReplacerStage.FAILED && uiState.errorMessage != null) {
            CleanErrorBanner(
                errorMessage = uiState.errorMessage,
                onDismiss = onDismissError
            )
        }

        // Primary Action Button: "تطبيق التعديل الآن" OR Direct Install Button when Completed
        if (!isCompleted) {
            Button(
                onClick = onApplyPatchNowClick,
                enabled = !uiState.isProcessing,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanAccent,
                    contentColor = OnCyanAccent,
                    disabledContainerColor = DeepNavySurfaceElevated,
                    disabledContentColor = DarkTextMuted
                ),
                contentPadding = PaddingValues(vertical = 16.dp, horizontal = 24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("apply_smali_patch_button")
            ) {
                if (uiState.isProcessing) {
                    CircularProgressIndicator(
                        color = OnCyanAccent,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = uiState.statusText.ifEmpty { "جاري تطبيق التعديلات الذكية..." },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "تطبيق التعديل الآن",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onInstallPatchedClick,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldSuccess,
                        contentColor = Color(0xFF041F14)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .testTag("install_smali_patched_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.InstallMobile,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "تم التعديل بنجاح! اضغط للتثبيت",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                OutlinedButton(
                    onClick = onSavePatchedClick,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CyanAccent),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_smali_patched_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SaveAlt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "حفظ نسخة التطبيق المعدّل",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun CleanErrorBanner(
    errorMessage: String,
    onDismiss: () -> Unit
) {
    Surface(
        color = CoralError.copy(alpha = 0.14f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, CoralError.copy(alpha = 0.7f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("smali_error_banner")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = CoralError,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = DarkTextPrimary,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onDismiss) {
                Text("إغلاق", color = CoralError, fontWeight = FontWeight.Bold)
            }
        }
    }
}
