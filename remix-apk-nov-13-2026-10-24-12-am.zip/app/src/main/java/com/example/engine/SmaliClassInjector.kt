package com.example.engine

import android.content.Context
import com.android.apksig.ApkSigner
import com.example.model.ApkFileInfo
import com.example.model.ClassInjectorPreset
import com.example.model.ClassInjectorResult
import com.example.model.ClassInjectorStage
import com.example.model.DuplicateClassPolicy
import com.example.model.HookInjectionPosition
import com.example.model.InjectedClassSummary
import com.example.model.InjectedHookSummary
import com.example.model.MethodHookSpec
import com.reandroid.arsc.chunk.PackageBlock
import com.reandroid.arsc.chunk.TableBlock
import com.reandroid.arsc.chunk.TypeBlock
import com.reandroid.arsc.container.SpecTypePair
import com.reandroid.arsc.value.Entry
import com.reandroid.arsc.value.ResConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jf.dexlib2.DexFileFactory
import org.jf.dexlib2.Opcode
import org.jf.dexlib2.Opcodes
import org.jf.dexlib2.builder.BuilderInstruction
import org.jf.dexlib2.builder.MutableMethodImplementation
import org.jf.dexlib2.builder.instruction.BuilderInstruction10x
import org.jf.dexlib2.builder.instruction.BuilderInstruction11n
import org.jf.dexlib2.builder.instruction.BuilderInstruction11x
import org.jf.dexlib2.builder.instruction.BuilderInstruction12x
import org.jf.dexlib2.builder.instruction.BuilderInstruction20bc
import org.jf.dexlib2.builder.instruction.BuilderInstruction21c
import org.jf.dexlib2.builder.instruction.BuilderInstruction21ih
import org.jf.dexlib2.builder.instruction.BuilderInstruction21lh
import org.jf.dexlib2.builder.instruction.BuilderInstruction21s
import org.jf.dexlib2.builder.instruction.BuilderInstruction22b
import org.jf.dexlib2.builder.instruction.BuilderInstruction22c
import org.jf.dexlib2.builder.instruction.BuilderInstruction22s
import org.jf.dexlib2.builder.instruction.BuilderInstruction22x
import org.jf.dexlib2.builder.instruction.BuilderInstruction23x
import org.jf.dexlib2.builder.instruction.BuilderInstruction31c
import org.jf.dexlib2.builder.instruction.BuilderInstruction31i
import org.jf.dexlib2.builder.instruction.BuilderInstruction32x
import org.jf.dexlib2.builder.instruction.BuilderInstruction35c
import org.jf.dexlib2.builder.instruction.BuilderInstruction3rc
import org.jf.dexlib2.builder.instruction.BuilderInstruction45cc
import org.jf.dexlib2.builder.instruction.BuilderInstruction4rcc
import org.jf.dexlib2.builder.instruction.BuilderInstruction51l
import org.jf.dexlib2.iface.ClassDef
import org.jf.dexlib2.iface.DexFile
import org.jf.dexlib2.iface.Method
import org.jf.dexlib2.iface.instruction.FiveRegisterInstruction
import org.jf.dexlib2.iface.instruction.Instruction
import org.jf.dexlib2.iface.instruction.OneRegisterInstruction
import org.jf.dexlib2.iface.instruction.RegisterRangeInstruction
import org.jf.dexlib2.iface.instruction.ThreeRegisterInstruction
import org.jf.dexlib2.iface.instruction.TwoRegisterInstruction
import org.jf.dexlib2.iface.instruction.formats.Instruction10x
import org.jf.dexlib2.iface.instruction.formats.Instruction11n
import org.jf.dexlib2.iface.instruction.formats.Instruction11x
import org.jf.dexlib2.iface.instruction.formats.Instruction12x
import org.jf.dexlib2.iface.instruction.formats.Instruction20bc
import org.jf.dexlib2.iface.instruction.formats.Instruction21c
import org.jf.dexlib2.iface.instruction.formats.Instruction21ih
import org.jf.dexlib2.iface.instruction.formats.Instruction21lh
import org.jf.dexlib2.iface.instruction.formats.Instruction21s
import org.jf.dexlib2.iface.instruction.formats.Instruction22b
import org.jf.dexlib2.iface.instruction.formats.Instruction22c
import org.jf.dexlib2.iface.instruction.formats.Instruction22s
import org.jf.dexlib2.iface.instruction.formats.Instruction22x
import org.jf.dexlib2.iface.instruction.formats.Instruction23x
import org.jf.dexlib2.iface.instruction.formats.Instruction31c
import org.jf.dexlib2.iface.instruction.formats.Instruction31i
import org.jf.dexlib2.iface.instruction.formats.Instruction32x
import org.jf.dexlib2.iface.instruction.formats.Instruction35c
import org.jf.dexlib2.iface.instruction.formats.Instruction3rc
import org.jf.dexlib2.iface.instruction.formats.Instruction45cc
import org.jf.dexlib2.iface.instruction.formats.Instruction4rcc
import org.jf.dexlib2.iface.instruction.formats.Instruction51l
import org.jf.dexlib2.immutable.ImmutableClassDef
import org.jf.dexlib2.immutable.ImmutableMethod
import org.jf.dexlib2.writer.io.FileDataStore
import org.jf.dexlib2.writer.pool.DexPool
import org.jf.smali.Smali
import org.jf.smali.SmaliOptions
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Base64
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * ================================================================================================
 * Standalone Smali Class Injection & Extension Patching Engine (`SmaliClassInjector.kt`) — Tab 4
 * ================================================================================================
 *
 * Completely independent from Tab 1, Tab 2, and Tab 3 (`SmaliMethodReplacer.kt`).
 *
 * Capabilities:
 * 1. Parses and assembles one or multiple full `.class` Smali definitions (with `.super`,
 *    `.implements`, `.field`, `.method`, annotations, and labels) via `org.jf.smali.Smali`.
 * 2. Converts every assembled `ClassDef` into an `ImmutableClassDef`.
 * 3. Scans ALL `classes*.dex` entries in the APK to detect duplicate class descriptors and applies
 *    the chosen [DuplicateClassPolicy] (`SKIP_IF_EXISTS`, `FAIL_ON_DUPLICATE`, or `REPLACE_EXISTING`).
 * 4. Injects the new `ImmutableClassDef`(s) into the chosen DEX (`classes.dex`, `classes2.dex`,
 *    or creates a new `classesN.dex` if requested).
 * 5. Supports optional **Method Hook Injection** ([MethodHookSpec]) to insert Smali hook
 *    instructions at `AT_ENTRY` (index 0) or `BEFORE_RETURN` inside existing app methods using
 *    `MutableMethodImplementation`, safely preserving try/catch blocks and branch offsets.
 * 6. Strips old `META-INF/` signature files, aligns `resources.arsc` & stored entries to 4 bytes,
 *    and signs the final APK with V1 + V2 + V3 via `com.android.apksig.ApkSigner`.
 */
object SmaliClassInjector {

    private const val BUFFER_SIZE = 64 * 1024
    private const val FIXED_ZIP_TIME = 315561600000L

    private const val EMBEDDED_RSA_PKCS8_BASE64 =
        "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDFU4UsYTF4NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X2mSj" +
            "OBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZTIx6W" +
            "sriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rqXVoe" +
            "mmMwqguqznCVbggN4fUFAgMBAAECggEAAU3nVM8Sb5xmhqDyMc2Na5+KsW2V5e1qEsfqJuJqn1w5ejmxhEUHg0qQdRYlXuXYhumZCnlgxxWG7yeayVhTB5RUHX1T" +
            "kx0IJ5YDSICnbw5/hRPpUP19xN2Qs+Ym55LyIl/ZuY8526Hhx09vA3oQYv7BnNbzXfR9rCRcpej3/kG78rew+mn/L0e51/rr481R4WFyL4T23zMUCg2+WvZZ0RQ+" +
            "jBNn3QaYWX1FYVzSaZ2JShSakAvtHLQwBUMg1jaqV9IIyqx9VR/dMhOG8LpIpFSMwRfQPKWniV2e6ljCVjYAKuSLoqISaWjO1FQBiwbfl6lM7CIyENHc+Dq2ZF1Z" +
            "iQKBgQDXKCFipjK7cHC51D7JR+oARRjvodnu+sMLCAZLWAtl1TJ1zLCjU/+STbLkMUWyPthE197NMB9RzINxQ8Ode124tiINF6Q7GlCU4INWzKrrLuQ41ouiwZa/" +
            "OxXnI+UgFL3FnvL8CWNfqkyKtRwc2dBtu9+Z77w7zmcMVwkxnMGE/QKBgQDqyOOe5EDEls2a3MZtDNrmw+2D/ioPSgoizIEpZdjfcPH+uSRgCQjgdHPQj27rAutJ" +
            "UNWGf3+B2cTgzKMCngi/U+LoonVkIKe1G357HZwZp5L9EskcSG/tY5MqNu3EbCdbQLNVqWPZNDHINiFvllZJp466BrL1n73HkY/sHTLyqQKBgFQ6aZds6L9oLTkS" +
            "VeIGPR0N780f12ku0dwnsA8e0Jd09uQW1a+a2pozwKyEfXxiDdglihtZk2k6XtqgZJvqB66f3oSxlKFuk800dzYruV2IZd+6Xb/BeXozb0elTbVZaVFMAGOaaUSy" +
            "LnS+odrJikbrHYXtzAq9qqmyCO9bJochAoGAbXOpaXFPIFaNExzJBB1yDxJXr6jVQrtpbj+YFwx7xe6JYg49fue3U6v2McwsETMTLOKaKFFXx9kVhxbfB2FVApzA" +
            "s2LJBxySEkP2+r4a/3q3c3NGfgDm7Ov2tz9UKLWiw0+uSsjk22URsBxMChEzuLJ8PwzQcOE/P8IELjaOgcECgYEAjnI+aSRfhE1xdbFQplbapzpj1/kfTCPudJbI" +
            "zOOmET088NtS1G4sJjrGALe4agQtFqvVsU3s8sv9Z8bMdzlx2yAsxOQtBgKW35RQ4HwNyPxlP3l+UGdgicWCGlDegMTprYthSrhjBNdeY0M4Fhi66ZV6h+EqxXzz" +
            "89Vo1vrX4Ic="

    private const val EMBEDDED_X509_CERT_BASE64 =
        "MIIC+DCCAeCgAwIBAgIQP11r3V28MrQX7vLoc9+ZtTANBgkqhkiG9w0BAQsFADA3MQswCQYDVQQGEwJVUzEQMA4GA1UEChMHQW5kcm9pZDEWMBQGA1UEAxMNQW5k" +
            "cm9pZCBEZWJ1ZzAgFw0yNjExMDcwMjE5NTFaGA8yMDU0MDMyNjAyMTk1MVowNzELMAkGA1UEBhMCVVMxEDAOBgNVBAoTB0FuZHJvaWQxFjAUBgNVBAMTDUFuZHJv" +
            "aWQgRGVidWcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFU4UsYTF4NnL1baIee1jL/V0Kr98kzsUzOcrLIhlgtj9mYtVICsV4nhjX/aTJ14H7pD4X" +
            "2mSjOBHeeDmv7MkQ6AAnuVHk8ct5bRHJfwjwi6zzEruz2YLUQNDh/RfjBTILDhgLdjmZtXyPRMq2KNwRjPVFjqAPrMhyRbUkTE7L5ACexzPNP1+fpD7ypGHh2mZT" +
            "Ix6WsriuhVJZwq2+Qn8Us70e7Z3snIZPWL7gxQc7M0W0Sb5T90077EN9gRixT42uztapFEppwV8LBxD8hCONi9yt1Pt1MCIu5efagiNfp/EO0oruC7fAAiJHL1rq" +
            "XVoemmMwqguqznCVbggN4fUFAgMBAAEwDQYJKoZIhvcNAQELBQADggEBACVMg0rOu03ptqGLuaZ//q8o3sC9XjjT/p+qh9zcMQFCnO1v2OXW6ClhkaFAgLhNa10H" +
            "tm5zjNME4d/FFBxtR8wfyvUbkaCQVugVRLUVAZBM7+xbsrzvyh0/JZKLDYjEj+LGZADwKr7Ut9WEzd62h85NmBEspDTG6AwybJJ0CFPdF4mh+8+GZfX98c7K01MW" +
            "rtAncV154+rmEKnm/X1rUXFHrJBiLEx611nWTAi0y7uJ3iAOdj0G6KP2bK1/JCcct8O9gOO7+yFSDdPbNwIu05kOLUzyLDLbwdcZmGJZRfBR5Z0delQAhKy7GlPt" +
            "AWCArU0VE7O2QzKZlMCcNeegxME="

    val PRESETS: List<ClassInjectorPreset> = listOf(
        ClassInjectorPreset(
            id = "extension_bridge",
            titleAr = "كلاس امتداد + Hook (Extension Bridge)",
            titleEn = "Extension Bridge + Entry Hook",
            descriptionAr = "حقن كلاس مساعد كامل Lapp/ext/ExtensionBridge; مع ربط اختياري على HostEntry->onCreateHook()V",
            smaliClassesCode = """
                .class public Lapp/ext/ExtensionBridge;
                .super Ljava/lang/Object;

                .field public static initialized:Z
                .field public static final TAG:Ljava/lang/String; = "ExtensionBridge"

                .method static constructor <clinit>()V
                    .locals 1
                    const/4 v0, 0x0
                    sput-boolean v0, Lapp/ext/ExtensionBridge;->initialized:Z
                    return-void
                .end method

                .method public constructor <init>()V
                    .locals 0
                    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
                    return-void
                .end method

                .method public static onAppInit()V
                    .locals 1
                    const/4 v0, 0x1
                    sput-boolean v0, Lapp/ext/ExtensionBridge;->initialized:Z
                    return-void
                .end method

                .method public static isExtensionActive()Z
                    .locals 1
                    sget-boolean v0, Lapp/ext/ExtensionBridge;->initialized:Z
                    if-eqz v0, :cond_disabled
                    const/4 v0, 0x1
                    return v0
                    :cond_disabled
                    const/4 v0, 0x0
                    return v0
                .end method
            """.trimIndent(),
            enableHookByDefault = true,
            defaultHookClass = "Lcom/example/HostEntry;",
            defaultHookMethodSignature = "onCreateHook()V",
            defaultHookInstructions = "invoke-static {}, Lapp/ext/ExtensionBridge;->onAppInit()V",
            defaultHookPosition = HookInjectionPosition.AT_ENTRY
        ),
        ClassInjectorPreset(
            id = "multi_class_bundle",
            titleAr = "حزمة كلاسات متعددة (2 Classes)",
            titleEn = "Multi-Class Extension Bundle",
            descriptionAr = "حقن كلاسين جديدين (ConfigHolder + FeatureGate) في نفس العملية مع استدعاء متبادل بينهما",
            smaliClassesCode = """
                .class public Lapp/ext/ConfigHolder;
                .super Ljava/lang/Object;

                .field public static featureLevel:I

                .method static constructor <clinit>()V
                    .locals 1
                    const/16 v0, 0x64
                    sput v0, Lapp/ext/ConfigHolder;->featureLevel:I
                    return-void
                .end method

                .method public constructor <init>()V
                    .locals 0
                    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
                    return-void
                .end method

                .method public static getFeatureLevel()I
                    .locals 1
                    sget v0, Lapp/ext/ConfigHolder;->featureLevel:I
                    return v0
                .end method

                .class public Lapp/ext/FeatureGate;
                .super Ljava/lang/Object;

                .method public constructor <init>()V
                    .locals 0
                    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
                    return-void
                .end method

                .method public static isUnlocked()Z
                    .locals 2
                    invoke-static {}, Lapp/ext/ConfigHolder;->getFeatureLevel()I
                    move-result v0
                    const/16 v1, 0x32
                    if-lt v0, v1, :cond_locked
                    const/4 v0, 0x1
                    return v0
                    :cond_locked
                    const/4 v0, 0x0
                    return v0
                .end method
            """.trimIndent(),
            enableHookByDefault = false,
            defaultHookClass = "Lcom/example/HostEntry;",
            defaultHookMethodSignature = "onCreateHook()V",
            defaultHookInstructions = "invoke-static {}, Lapp/ext/FeatureGate;->isUnlocked()Z",
            defaultHookPosition = HookInjectionPosition.AT_ENTRY
        )
    )

    /**
     * Normalizes either `"com.example.Foo"` or `"Lcom/example/Foo;"` into `"Lcom/example/Foo;"`.
     */
    fun normalizeClassDescriptor(rawDescriptor: String): String {
        val trimmed = rawDescriptor.trim()
        require(trimmed.isNotEmpty()) { "وصف الكلاس (Class Descriptor) لا يمكن أن يكون فارغاً." }
        if (trimmed.startsWith("L") && trimmed.endsWith(";")) {
            return trimmed.replace('.', '/')
        }
        val slashName = trimmed.removePrefix("L").removeSuffix(";").replace('.', '/')
        return "L$slashName;"
    }

    /**
     * Splits raw Smali input containing one or more `.class ...` definitions into separate class sources.
     */
    fun splitSmaliClassBlocks(rawSmaliInput: String): List<String> {
        val blocks = mutableListOf<StringBuilder>()
        var currentBlock: StringBuilder? = null

        for (line in rawSmaliInput.lines()) {
            val trimmed = line.trimStart()
            if (trimmed.startsWith(".class ")) {
                currentBlock?.let {
                    val text = it.toString().trim()
                    if (text.isNotEmpty()) blocks.add(StringBuilder(text))
                }
                currentBlock = StringBuilder().appendLine(line)
            } else {
                if (currentBlock != null) {
                    currentBlock.appendLine(line)
                } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                    throw IllegalArgumentException(
                        "يجب أن يبدأ كل تعريف كلاس بتعليمة (.class ...) مثل: .class public Lapp/ext/MyHelper;"
                    )
                }
            }
        }
        currentBlock?.let {
            val text = it.toString().trim()
            if (text.isNotEmpty()) blocks.add(StringBuilder(text))
        }

        return blocks.map { it.toString() }.filter { it.isNotEmpty() }
    }

    /**
     * Assembles full Smali `.class` definitions into `ImmutableClassDef` objects using `org.jf.smali.Smali`.
     */
    fun assembleSmaliClasses(
        smaliClassBlocks: List<String>,
        apiLevel: Int = 26,
        workDir: File
    ): List<ImmutableClassDef> {
        require(smaliClassBlocks.isNotEmpty()) {
            "يرجى إدخال تعريف كلاس Smali واحد على الأقل يبدأ بـ .class"
        }

        val assembleDir = File(workDir, "class_assemble_${System.nanoTime()}").apply { mkdirs() }
        try {
            val assembledClasses = mutableListOf<ImmutableClassDef>()
            val effectiveApi = apiLevel.coerceAtLeast(15)

            smaliClassBlocks.forEachIndexed { index, rawBlock ->
                val hasSuper = rawBlock.lineSequence().any { it.trimStart().startsWith(".super ") }
                val finalSource = if (hasSuper) {
                    rawBlock
                } else {
                    val lines = rawBlock.lines().toMutableList()
                    lines.add(1, ".super Ljava/lang/Object;")
                    lines.joinToString("\n")
                }

                val smaliFile = File(assembleDir, "InjectedClass_${index + 1}.smali")
                smaliFile.writeText(finalSource, Charsets.UTF_8)

                val outDexFile = File(assembleDir, "InjectedClass_${index + 1}.dex")
                val options = SmaliOptions().apply {
                    outputDexFile = outDexFile.absolutePath
                    this.apiLevel = effectiveApi
                }

                val ok = Smali.assemble(options, listOf(smaliFile.absolutePath))
                if (!ok || !outDexFile.exists() || outDexFile.length() == 0L) {
                    throw IllegalArgumentException(
                        "فشل تجميع كود Smali للكلاس رقم #${index + 1} عبر org.smali:smali. تأكد من صحة .class و .super وصياغة الدوال."
                    )
                }

                val dexFile = DexFileFactory.loadDexFile(outDexFile, Opcodes.forApi(effectiveApi))
                if (dexFile.classes.isEmpty()) {
                    throw IllegalStateException("لم ينتج أي كلاس صالح عن تجميع الكتلة رقم #${index + 1}.")
                }
                for (cls in dexFile.classes) {
                    assembledClasses.add(ImmutableClassDef.of(cls))
                }
            }

            return assembledClasses
        } finally {
            assembleDir.deleteRecursively()
        }
    }

    /**
     * Assembles raw hook instructions into fresh, unattached [BuilderInstruction]s ready to inject
     * into a target method via [MutableMethodImplementation].
     */
    fun assembleHookInstructions(
        rawHookInstructions: String,
        apiLevel: Int = 26,
        workDir: File
    ): List<BuilderInstruction> {
        val cleanBody = rawHookInstructions.trim()
        require(cleanBody.isNotEmpty()) {
            "تعليمات الـ Hook الاختيارية فارغة."
        }

        val hookDir = File(workDir, "hook_assemble_${System.nanoTime()}").apply { mkdirs() }
        try {
            val effectiveApi = apiLevel.coerceAtLeast(15)
            val wrapperSource = buildString {
                appendLine(".class public Ltmp/HookStubWrapper;")
                appendLine(".super Ljava/lang/Object;")
                appendLine()
                appendLine(".method public static __hookStub()V")
                appendLine("    .locals 16")
                appendLine(cleanBody)
                appendLine("    return-void")
                appendLine(".end method")
            }

            val smaliFile = File(hookDir, "HookStubWrapper.smali")
            smaliFile.writeText(wrapperSource, Charsets.UTF_8)

            val outDexFile = File(hookDir, "HookStubWrapper.dex")
            val options = SmaliOptions().apply {
                outputDexFile = outDexFile.absolutePath
                this.apiLevel = effectiveApi
            }

            val ok = Smali.assemble(options, listOf(smaliFile.absolutePath))
            if (!ok || !outDexFile.exists() || outDexFile.length() == 0L) {
                throw IllegalArgumentException(
                    "فشل تجميع تعليمات الـ Hook عبر org.smali:smali. تحقق من أسماء السجلات واستدعاءات الدوال."
                )
            }

            val dexFile = DexFileFactory.loadDexFile(outDexFile, Opcodes.forApi(effectiveApi))
            val wrapperClass = dexFile.classes.firstOrNull()
                ?: throw IllegalStateException("لم يتم العثور على كلاس الـ Hook المؤقت.")
            val stubMethod = wrapperClass.methods.firstOrNull { it.name == "__hookStub" }
                ?: throw IllegalStateException("لم يتم العثور على دالة الـ Hook المؤقتة.")
            val stubImpl = stubMethod.implementation
                ?: throw IllegalStateException("دالة الـ Hook المؤقتة لا تحتوي على تعليمات.")

            val rawInstructions = stubImpl.instructions.toList()
            val withoutTrailingReturn = if (rawInstructions.isNotEmpty() &&
                rawInstructions.last().opcode == Opcode.RETURN_VOID
            ) {
                rawInstructions.dropLast(1)
            } else {
                rawInstructions
            }

            require(withoutTrailingReturn.isNotEmpty()) {
                "لم يتم العثور على أي تعليمة فعلية داخل تعليمات الـ Hook."
            }

            return withoutTrailingReturn.map { toDetachedBuilderInstruction(it) }
        } finally {
            hookDir.deleteRecursively()
        }
    }

    /**
     * Lists all `classes*.dex` entry names inside [apkFile] sorted in natural DEX order.
     */
    fun listDexEntriesInApk(apkFile: File): List<String> {
        val dexRegex = Regex("""^classes(\d*)\.dex$""")
        val entries = mutableListOf<String>()
        ZipFile(apkFile).use { zip ->
            val enumEntries = zip.entries()
            while (enumEntries.hasMoreElements()) {
                val entry = enumEntries.nextElement()
                if (!entry.isDirectory && dexRegex.matches(entry.name)) {
                    entries.add(entry.name)
                }
            }
        }
        return entries.sortedWith(
            compareBy { name ->
                val numStr = dexRegex.find(name)?.groupValues?.getOrNull(1).orEmpty()
                if (numStr.isEmpty()) 1 else numStr.toIntOrNull() ?: Int.MAX_VALUE
            }
        )
    }

    /**
     * End-to-end Smali Class Injection & Optional Hook Patching Pipeline:
     * 1. Assembles full `.class` Smali blocks into `ImmutableClassDef` instances.
     * 2. Scans all `classes*.dex` files in [sourceApk] for duplicates and hook targets.
     * 3. Injects new classes into [targetDexName] (or creates `classesN.dex` if new).
     * 4. Applies any optional [MethodHookSpec] hooks via `MutableMethodImplementation`.
     * 5. Repackages with 4-byte aligned `resources.arsc` and signs with V1 + V2 + V3 via `ApkSigner`.
     */
    suspend fun injectClassesAndSignApk(
        context: Context,
        sourceApk: ApkFileInfo,
        smaliClassesRaw: String,
        targetDexName: String = "classes.dex",
        duplicatePolicy: DuplicateClassPolicy = DuplicateClassPolicy.SKIP_IF_EXISTS,
        hooks: List<MethodHookSpec> = emptyList(),
        onLog: (String) -> Unit = {},
        onProgress: (stage: ClassInjectorStage, percent: Int, statusText: String) -> Unit = { _, _, _ -> }
    ): ClassInjectorResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val capturedLogs = mutableListOf<String>()
        fun log(msg: String) {
            capturedLogs.add(msg)
            onLog(msg)
        }

        val inputFile = sourceApk.localFile
        require(inputFile.exists() && inputFile.length() > 0L) {
            "ملف APK المختار غير موجود أو فارغ."
        }

        val normalizedTargetDex = targetDexName.trim().ifEmpty { "classes.dex" }
        require(Regex("""^classes(\d*)\.dex$""").matches(normalizedTargetDex)) {
            "اسم ملف DEX المستهدف غير صالح: $normalizedTargetDex (مثال صحيح: classes.dex أو classes2.dex)"
        }

        val workDir = File(context.cacheDir, "class_injector_work_${System.currentTimeMillis()}").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        val outputDir = File(context.filesDir, "injected_apks").apply { mkdirs() }
        val sanitizedBase = sourceApk.fileName
            .removeSuffix(".apk")
            .replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val finalSignedApk = File(outputDir, "${sanitizedBase}_ClassInjected_Signed.apk")
        if (finalSignedApk.exists()) finalSignedApk.delete()

        val unsignedAlignedApk = File(workDir, "unsigned_aligned.apk")

        try {
            // ── STAGE 1: Assemble Smali .class blocks ──
            onProgress(
                ClassInjectorStage.ASSEMBLING_CLASSES,
                15,
                "جاري تجميع تعريفات الكلاسات الجديدة عبر org.smali:smali..."
            )
            val classBlocks = splitSmaliClassBlocks(smaliClassesRaw)
            log("▶ تم رصد ${classBlocks.size} تعريف كلاس Smali للتجميع...")

            val assembledClasses = assembleSmaliClasses(
                smaliClassBlocks = classBlocks,
                apiLevel = sourceApk.detectedMinSdk ?: 26,
                workDir = workDir
            )

            // Deduplicate within user input itself (keep last or reject)
            val uniqueInputClasses = LinkedHashMap<String, ImmutableClassDef>()
            for (cls in assembledClasses) {
                if (uniqueInputClasses.containsKey(cls.type)) {
                    log("⚠ تنبيه: الكلاس ${cls.type} مكرر داخل النص المدخل، سيتم اعتماد التعريف الأحدث.")
                }
                uniqueInputClasses[cls.type] = cls
                log("  ✓ تم تجميع الكلاس بنجاح: ${cls.type} (الدوال: ${cls.methods.count()}، الحقول: ${cls.fields.count()})")
            }

            // ── STAGE 2: Scan all classes*.dex for duplicates and hook targets ──
            onProgress(
                ClassInjectorStage.CHECKING_DUPLICATES,
                32,
                "جاري فحص جميع ملفات DEX للكشف عن التكرار..."
            )
            val existingDexEntries = listDexEntriesInApk(inputFile)
            require(existingDexEntries.isNotEmpty()) {
                "لم يتم العثور على أي ملف classes*.dex داخل الـ APK."
            }
            log("▶ ملفات DEX الموجودة (${existingDexEntries.size}): ${existingDexEntries.joinToString(", ")}")

            val loadedDexFiles = LinkedHashMap<String, DexFile>()
            val existingClassToDexMap = LinkedHashMap<String, String>()

            ZipFile(inputFile).use { zip ->
                for (dexName in existingDexEntries) {
                    val entry = zip.getEntry(dexName) ?: continue
                    val tempDex = File(workDir, "in_$dexName")
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(tempDex).use { output ->
                            input.copyTo(output, BUFFER_SIZE)
                        }
                    }
                    val dexFile = DexFileFactory.loadDexFile(tempDex, Opcodes.getDefault())
                    loadedDexFiles[dexName] = dexFile
                    for (cls in dexFile.classes) {
                        existingClassToDexMap[cls.type] = dexName
                    }
                }
            }

            val classesToInject = mutableListOf<ImmutableClassDef>()
            val classesToReplaceByDex = LinkedHashMap<String, MutableMap<String, ImmutableClassDef>>()
            val skippedDuplicates = mutableListOf<String>()
            val injectedSummaries = mutableListOf<InjectedClassSummary>()

            for ((descriptor, newClassDef) in uniqueInputClasses) {
                val foundInDex = existingClassToDexMap[descriptor]
                if (foundInDex != null) {
                    when (duplicatePolicy) {
                        DuplicateClassPolicy.FAIL_ON_DUPLICATE -> {
                            throw IllegalArgumentException(
                                "الكلاس $descriptor موجود مسبقاً داخل $foundInDex. اختر سياسة التخطي أو الاستبدال لتجنب تلف الحزمة."
                            )
                        }
                        DuplicateClassPolicy.SKIP_IF_EXISTS -> {
                            skippedDuplicates.add(descriptor)
                            log("↷ تم تخطي الكلاس المكرر (موجود في $foundInDex): $descriptor")
                        }
                        DuplicateClassPolicy.REPLACE_EXISTING -> {
                            val dexMap = classesToReplaceByDex.getOrPut(foundInDex) { LinkedHashMap() }
                            dexMap[descriptor] = newClassDef
                            injectedSummaries.add(
                                InjectedClassSummary(
                                    classDescriptor = descriptor,
                                    targetDexName = foundInDex,
                                    methodsCount = newClassDef.methods.count(),
                                    fieldsCount = newClassDef.fields.count(),
                                    statusLabel = "Replaced"
                                )
                            )
                            log("↻ سيتم استبدال الكلاس الموجود $descriptor داخل $foundInDex")
                        }
                    }
                } else {
                    classesToInject.add(newClassDef)
                    injectedSummaries.add(
                        InjectedClassSummary(
                            classDescriptor = descriptor,
                            targetDexName = normalizedTargetDex,
                            methodsCount = newClassDef.methods.count(),
                            fieldsCount = newClassDef.fields.count(),
                            statusLabel = "Injected"
                        )
                    )
                }
            }

            // ── STAGE 3: Prepare mutable class lists per DEX and inject classes ──
            onProgress(
                ClassInjectorStage.INJECTING_CLASSES,
                52,
                "جاري حقن الكلاسات الجديدة في $normalizedTargetDex..."
            )

            val workingClassesByDex = LinkedHashMap<String, MutableList<ClassDef>>()
            val opcodesByDex = LinkedHashMap<String, Opcodes>()
            val modifiedDexSet = LinkedHashSet<String>()

            for ((dexName, dexFile) in loadedDexFiles) {
                opcodesByDex[dexName] = dexFile.opcodes
                val replaceMap = classesToReplaceByDex[dexName]
                val list = ArrayList<ClassDef>(dexFile.classes.size + classesToInject.size)
                for (cls in dexFile.classes) {
                    val replacement = replaceMap?.get(cls.type)
                    if (replacement != null) {
                        list.add(replacement)
                        modifiedDexSet.add(dexName)
                    } else {
                        list.add(cls)
                    }
                }
                workingClassesByDex[dexName] = list
            }

            if (classesToInject.isNotEmpty()) {
                val targetList = workingClassesByDex[normalizedTargetDex]
                if (targetList != null) {
                    for (newCls in classesToInject) {
                        targetList.add(newCls)
                        log("★ تم حقن ${newCls.type} في $normalizedTargetDex")
                    }
                } else {
                    // Create a brand new classesN.dex (e.g., classes2.dex on single-DEX APK)
                    val baseApi = opcodesByDex.values.firstOrNull()?.api ?: 26
                    opcodesByDex[normalizedTargetDex] = Opcodes.forApi(baseApi)
                    workingClassesByDex[normalizedTargetDex] = ArrayList<ClassDef>(classesToInject).also {
                        for (newCls in classesToInject) {
                            log("★ تم إنشاء $normalizedTargetDex وحقن ${newCls.type}")
                        }
                    }
                }
                modifiedDexSet.add(normalizedTargetDex)
            }

            // ── STAGE 4: Apply Optional Method Hooks ──
            val appliedHooks = mutableListOf<InjectedHookSummary>()
            val activeHooks = hooks.filter {
                it.targetClassDescriptor.isNotBlank() &&
                    it.targetMethodSignature.isNotBlank() &&
                    it.hookSmaliInstructions.isNotBlank()
            }

            if (activeHooks.isNotEmpty()) {
                onProgress(
                    ClassInjectorStage.INJECTING_HOOKS,
                    66,
                    "جاري حقن ${activeHooks.size} Hook في الدوال المستهدفة..."
                )
                for (hook in activeHooks) {
                    val normTargetClass = normalizeClassDescriptor(hook.targetClassDescriptor)
                    val normMethodSig = normalizeMethodSignature(hook.targetMethodSignature)
                    val api = (opcodesByDex[normalizedTargetDex]?.api ?: 26).coerceAtLeast(15)
                    val hookInstructions = assembleHookInstructions(
                        rawHookInstructions = hook.hookSmaliInstructions,
                        apiLevel = api,
                        workDir = workDir
                    )

                    var hookApplied = false
                    for ((dexName, classList) in workingClassesByDex) {
                        val idx = classList.indexOfFirst { it.type == normTargetClass }
                        if (idx >= 0) {
                            val hostClass = classList[idx]
                            val (patchedHost, matched) = injectHookIntoClassDef(
                                classDef = hostClass,
                                targetMethodSig = normMethodSig,
                                hookInstructions = hookInstructions,
                                position = hook.position
                            )
                            if (matched) {
                                classList[idx] = patchedHost
                                modifiedDexSet.add(dexName)
                                hookApplied = true
                                appliedHooks.add(
                                    InjectedHookSummary(
                                        targetClassDescriptor = normTargetClass,
                                        targetMethodSignature = normMethodSig,
                                        dexFileName = dexName,
                                        position = hook.position,
                                        instructionsAddedCount = hookInstructions.size
                                    )
                                )
                                log("✓ [$dexName] تم حقن Hook (${hookInstructions.size} تعليمة) في $normTargetClass->$normMethodSig (${hook.position.titleEn})")
                                break
                            }
                        }
                    }
                    if (!hookApplied) {
                        throw IllegalArgumentException(
                            "لم يتم العثور على هدف الـ Hook: $normTargetClass->$normMethodSig داخل ملفات DEX."
                        )
                    }
                }
            }

            if (modifiedDexSet.isEmpty()) {
                throw IllegalArgumentException(
                    "لم يتم إجراء أي تعديل (جميع الكلاسات المدخلة موجودة مسبقاً وتم تخطيها بدون تفعيل Hooks)."
                )
            }

            // Write modified DEX files via DexPool
            val patchedDexByEntryName = LinkedHashMap<String, ByteArray>()
            for (dexName in modifiedDexSet) {
                val classes = workingClassesByDex[dexName] ?: continue
                val opcodes = opcodesByDex[dexName] ?: Opcodes.getDefault()
                val outDex = File(workDir, "out_$dexName")
                val dexPool = DexPool(opcodes)
                for (cls in classes) {
                    dexPool.internClass(cls)
                }
                dexPool.writeTo(FileDataStore(outDex))
                val bytes = outDex.readBytes()
                patchedDexByEntryName[dexName] = bytes
                log("✓ تم إعادة بناء $dexName بنجاح (${bytes.size / 1024} KB، إجمالي الكلاسات: ${classes.size}).")
            }

            // ── STAGE 5: Repackage APK with 4-byte aligned STORED resources.arsc ──
            onProgress(
                ClassInjectorStage.REBUILDING_APK,
                80,
                "جاري إعادة حزم APK ومحاذاة resources.arsc (4-Byte STORED)..."
            )
            log("▶ جاري حذف تواقيع META-INF القديمة وإعادة الحزم بمحاذاة 4-Byte...")
            repackageApkWithDexEntries(
                sourceApkFile = inputFile,
                patchedDexByEntryName = patchedDexByEntryName,
                unsignedAlignedOutputApk = unsignedAlignedApk
            )

            // ── STAGE 6: Sign APK with V1 + V2 + V3 via ApkSigner ──
            onProgress(
                ClassInjectorStage.SIGNING_APK,
                92,
                "جاري التوقيع الرقمي الشامل (V1 + V2 + V3)..."
            )
            log("▶ جاري توقيع الحزمة عبر com.android.apksig.ApkSigner (V1 + V2 + V3)...")

            val credentials = loadOrCreateSigningCredentials(context)
            val signerConfig = ApkSigner.SignerConfig.Builder(
                "CERT",
                credentials.privateKey,
                listOf(credentials.certificate)
            ).build()

            val apkSigner = ApkSigner.Builder(listOf(signerConfig))
                .setInputApk(unsignedAlignedApk)
                .setOutputApk(finalSignedApk)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .setOtherSignersSignaturesPreserved(false)
                .build()
            apkSigner.sign()

            require(finalSignedApk.exists() && finalSignedApk.length() > 0L) {
                "فشل إنشاء ملف APK النهائي الموقّع."
            }

            val elapsed = System.currentTimeMillis() - startTime
            log("✓ تم التوقيع (V1 + V2 + V3) واكتملت العملية في ${elapsed}ms -> ${finalSignedApk.name}")
            onProgress(
                ClassInjectorStage.COMPLETED,
                100,
                "تم حقن ${injectedSummaries.size} كلاس وتوقيع APK بنجاح!"
            )

            ClassInjectorResult(
                outputApkFile = finalSignedApk,
                outputFileName = finalSignedApk.name,
                packageName = sourceApk.packageName,
                targetDexName = normalizedTargetDex,
                injectedClasses = injectedSummaries,
                skippedDuplicateClasses = skippedDuplicates,
                appliedHooks = appliedHooks,
                scannedDexFiles = existingDexEntries,
                modifiedDexFiles = patchedDexByEntryName.keys.toList(),
                outputSizeBytes = finalSignedApk.length(),
                isSignedV1V2V3 = true,
                executionDurationMs = elapsed,
                logs = capturedLogs.toList()
            )
        } finally {
            workDir.deleteRecursively()
        }
    }

    private fun normalizeMethodSignature(rawSig: String): String {
        val trimmed = rawSig.trim()
        val afterArrow = if (trimmed.contains("->")) {
            trimmed.substringAfter("->").trim()
        } else {
            trimmed
        }
        return afterArrow.replace(" ", "")
    }

    private fun methodSignatureKey(method: Method): String {
        val params = method.parameterTypes.joinToString(separator = "") { it.toString() }
        return "${method.name}($params)${method.returnType}"
    }

    private fun injectHookIntoClassDef(
        classDef: ClassDef,
        targetMethodSig: String,
        hookInstructions: List<BuilderInstruction>,
        position: HookInjectionPosition
    ): Pair<ClassDef, Boolean> {
        var matched = false

        fun patchMethod(method: Method): Method {
            if (methodSignatureKey(method) != targetMethodSig) return method
            val origImpl = method.implementation ?: throw IllegalArgumentException(
                "الدالة المستهدفة ${classDef.type}->$targetMethodSig مجردة (abstract/native) ولا تحتوي على جسم برمجي."
            )

            val maxHookReg = maxRegisterIndexUsed(hookInstructions)
            val paramRegCount = countParameterRegisters(method)
            val origLocalCount = (origImpl.registerCount - paramRegCount).coerceAtLeast(0)
            if (maxHookReg >= origLocalCount) {
                throw IllegalArgumentException(
                    "تعليمات الـ Hook تستخدم السجل v$maxHookReg بينما الدالة المستهدفة تحتوي على $origLocalCount سجل محلي فقط. قلل السجلات أو استخدم استدعاءاً ثابتاً."
                )
            }

            val mutableImpl = MutableMethodImplementation(origImpl)
            when (position) {
                HookInjectionPosition.AT_ENTRY -> {
                    for (i in hookInstructions.indices.reversed()) {
                        mutableImpl.addInstruction(0, toDetachedBuilderInstruction(hookInstructions[i]))
                    }
                }
                HookInjectionPosition.BEFORE_RETURN -> {
                    val returnIndices = mutableImpl.instructions.mapIndexedNotNull { index, instr ->
                        val opName = instr.opcode.name
                        if (opName.startsWith("RETURN")) index else null
                    }
                    require(returnIndices.isNotEmpty()) {
                        "لم يتم العثور على أي تعليمة return داخل ${classDef.type}->$targetMethodSig."
                    }
                    for (retIdx in returnIndices.asReversed()) {
                        for (i in hookInstructions.indices.reversed()) {
                            mutableImpl.addInstruction(retIdx, toDetachedBuilderInstruction(hookInstructions[i]))
                        }
                    }
                }
            }

            matched = true
            return ImmutableMethod(
                method.definingClass,
                method.name,
                method.parameters,
                method.returnType,
                method.accessFlags,
                method.annotations,
                method.hiddenApiRestrictions,
                mutableImpl
            )
        }

        val updatedDirect = classDef.directMethods.map { patchMethod(it) }
        val updatedVirtual = classDef.virtualMethods.map { patchMethod(it) }

        if (!matched) return Pair(classDef, false)

        val updatedClassDef = ImmutableClassDef(
            classDef.type,
            classDef.accessFlags,
            classDef.superclass,
            classDef.interfaces,
            classDef.sourceFile,
            classDef.annotations,
            classDef.staticFields,
            classDef.instanceFields,
            updatedDirect,
            updatedVirtual
        )
        return Pair(updatedClassDef, true)
    }

    private fun countParameterRegisters(method: Method): Int {
        val isStatic = (method.accessFlags and 0x0008) != 0
        var count = if (isStatic) 0 else 1
        for (paramType in method.parameterTypes) {
            val t = paramType.toString()
            count += if (t == "J" || t == "D") 2 else 1
        }
        return count
    }

    private fun maxRegisterIndexUsed(instructions: List<Instruction>): Int {
        var maxReg = -1
        for (instr in instructions) {
            if (instr is OneRegisterInstruction) {
                maxReg = maxOf(maxReg, instr.registerA)
            }
            if (instr is TwoRegisterInstruction) {
                maxReg = maxOf(maxReg, instr.registerB)
            }
            if (instr is ThreeRegisterInstruction) {
                maxReg = maxOf(maxReg, instr.registerC)
            }
            if (instr is FiveRegisterInstruction) {
                val rc = instr.registerCount
                if (rc >= 1) maxReg = maxOf(maxReg, instr.registerC)
                if (rc >= 2) maxReg = maxOf(maxReg, instr.registerD)
                if (rc >= 3) maxReg = maxOf(maxReg, instr.registerE)
                if (rc >= 4) maxReg = maxOf(maxReg, instr.registerF)
                if (rc >= 5) maxReg = maxOf(maxReg, instr.registerG)
            }
            if (instr is RegisterRangeInstruction && instr.registerCount > 0) {
                maxReg = maxOf(maxReg, instr.startRegister + instr.registerCount - 1)
            }
        }
        return maxReg
    }

    private fun toDetachedBuilderInstruction(instr: Instruction): BuilderInstruction {
        return when (instr) {
            is Instruction10x -> BuilderInstruction10x(instr.opcode)
            is Instruction11n -> BuilderInstruction11n(instr.opcode, instr.registerA, instr.narrowLiteral)
            is Instruction11x -> BuilderInstruction11x(instr.opcode, instr.registerA)
            is Instruction12x -> BuilderInstruction12x(instr.opcode, instr.registerA, instr.registerB)
            is Instruction20bc -> BuilderInstruction20bc(instr.opcode, instr.verificationError, instr.reference)
            is Instruction21c -> BuilderInstruction21c(instr.opcode, instr.registerA, instr.reference)
            is Instruction21ih -> BuilderInstruction21ih(instr.opcode, instr.registerA, instr.narrowLiteral)
            is Instruction21lh -> BuilderInstruction21lh(instr.opcode, instr.registerA, instr.wideLiteral)
            is Instruction21s -> BuilderInstruction21s(instr.opcode, instr.registerA, instr.narrowLiteral)
            is Instruction22b -> BuilderInstruction22b(instr.opcode, instr.registerA, instr.registerB, instr.narrowLiteral)
            is Instruction22c -> BuilderInstruction22c(instr.opcode, instr.registerA, instr.registerB, instr.reference)
            is Instruction22s -> BuilderInstruction22s(instr.opcode, instr.registerA, instr.registerB, instr.narrowLiteral)
            is Instruction22x -> BuilderInstruction22x(instr.opcode, instr.registerA, instr.registerB)
            is Instruction23x -> BuilderInstruction23x(instr.opcode, instr.registerA, instr.registerB, instr.registerC)
            is Instruction31c -> BuilderInstruction31c(instr.opcode, instr.registerA, instr.reference)
            is Instruction31i -> BuilderInstruction31i(instr.opcode, instr.registerA, instr.narrowLiteral)
            is Instruction32x -> BuilderInstruction32x(instr.opcode, instr.registerA, instr.registerB)
            is Instruction35c -> BuilderInstruction35c(
                instr.opcode,
                instr.registerCount,
                instr.registerC,
                instr.registerD,
                instr.registerE,
                instr.registerF,
                instr.registerG,
                instr.reference
            )
            is Instruction3rc -> BuilderInstruction3rc(
                instr.opcode,
                instr.startRegister,
                instr.registerCount,
                instr.reference
            )
            is Instruction45cc -> BuilderInstruction45cc(
                instr.opcode,
                instr.registerCount,
                instr.registerC,
                instr.registerD,
                instr.registerE,
                instr.registerF,
                instr.registerG,
                instr.reference,
                instr.reference2
            )
            is Instruction4rcc -> BuilderInstruction4rcc(
                instr.opcode,
                instr.startRegister,
                instr.registerCount,
                instr.reference,
                instr.reference2
            )
            is Instruction51l -> BuilderInstruction51l(instr.opcode, instr.registerA, instr.wideLiteral)
            else -> throw IllegalArgumentException(
                "نوع تعليمة الـ Hook (${instr.opcode.name}) غير مدعوم حالياً في الحقن السريع."
            )
        }
    }

    private fun repackageApkWithDexEntries(
        sourceApkFile: File,
        patchedDexByEntryName: Map<String, ByteArray>,
        unsignedAlignedOutputApk: File
    ) {
        ZipFile(sourceApkFile).use { zip ->
            val rawEntries = mutableListOf<ZipEntry>()
            val existingNames = HashSet<String>()
            val enumeration = zip.entries()
            while (enumeration.hasMoreElements()) {
                val entry = enumeration.nextElement()
                if (!entry.isDirectory && !isSignatureEntry(entry.name)) {
                    rawEntries.add(entry)
                    existingNames.add(entry.name)
                }
            }

            // Include any newly created classesN.dex entries that weren't in the source APK
            val newDexNames = patchedDexByEntryName.keys.filter { it !in existingNames }.sorted()

            val sortedEntries = rawEntries.sortedWith(
                compareBy<ZipEntry> { entry ->
                    when {
                        entry.name == "resources.arsc" -> 0
                        entry.name == "AndroidManifest.xml" -> 1
                        entry.name in patchedDexByEntryName -> 2
                        else -> 3
                    }
                }.thenBy { it.name }
            )

            FileOutputStream(unsignedAlignedOutputApk).use { fos ->
                val countingOut = CountingOutputStream(BufferedOutputStream(fos, BUFFER_SIZE))
                ZipOutputStream(countingOut).use { zos ->
                    zos.setLevel(Deflater.BEST_COMPRESSION)

                    for (origEntry in sortedEntries) {
                        val name = origEntry.name
                        val patchedDexBytes = patchedDexByEntryName[name]

                        if (name == "resources.arsc") {
                            val arscBytes = zip.getInputStream(origEntry).use { it.readBytes() }
                            writeStoredAlignedEntry(
                                zos = zos,
                                countingOut = countingOut,
                                entryName = name,
                                rawBytes = arscBytes,
                                alignmentBytes = 4L
                            )
                        } else if (patchedDexBytes != null) {
                            writeSmallestCompressedEntry(zos, name, patchedDexBytes)
                        } else {
                            val rawBytes = zip.getInputStream(origEntry).use { it.readBytes() }
                            if (origEntry.method == ZipEntry.STORED && !name.endsWith(".so")) {
                                writeStoredAlignedEntry(
                                    zos = zos,
                                    countingOut = countingOut,
                                    entryName = name,
                                    rawBytes = rawBytes,
                                    alignmentBytes = 4L
                                )
                            } else {
                                writeSmallestCompressedEntry(zos, name, rawBytes)
                            }
                        }
                    }

                    for (newDexName in newDexNames) {
                        val bytes = patchedDexByEntryName[newDexName] ?: continue
                        writeSmallestCompressedEntry(zos, newDexName, bytes)
                    }
                }
            }
        }
    }

    private fun writeStoredAlignedEntry(
        zos: ZipOutputStream,
        countingOut: CountingOutputStream,
        entryName: String,
        rawBytes: ByteArray,
        alignmentBytes: Long
    ) {
        zos.flush()
        val lfhStartOffset = countingOut.bytesWritten
        val nameBytesLen = entryName.toByteArray(Charsets.UTF_8).size
        val baseDataOffset = lfhStartOffset + 30L + nameBytesLen

        val remainder = baseDataOffset % alignmentBytes
        val padLen = if (remainder == 0L) 0 else (alignmentBytes - remainder).toInt()

        val crc = CRC32()
        crc.update(rawBytes)

        val newEntry = ZipEntry(entryName).apply {
            method = ZipEntry.STORED
            size = rawBytes.size.toLong()
            compressedSize = rawBytes.size.toLong()
            this.crc = crc.value
            time = FIXED_ZIP_TIME
            if (padLen > 0) {
                extra = ByteArray(padLen)
            }
        }

        zos.putNextEntry(newEntry)
        zos.write(rawBytes)
        zos.closeEntry()
        zos.flush()
    }

    private fun writeSmallestCompressedEntry(
        zos: ZipOutputStream,
        entryName: String,
        rawBytes: ByteArray
    ) {
        val deflatedProbe = deflateBytesLevel9(rawBytes)
        if (deflatedProbe.size < rawBytes.size) {
            val newEntry = ZipEntry(entryName).apply {
                method = ZipEntry.DEFLATED
                time = FIXED_ZIP_TIME
            }
            zos.putNextEntry(newEntry)
            zos.write(rawBytes)
            zos.closeEntry()
        } else {
            val crc = CRC32()
            crc.update(rawBytes)
            val storedEntry = ZipEntry(entryName).apply {
                method = ZipEntry.STORED
                size = rawBytes.size.toLong()
                compressedSize = rawBytes.size.toLong()
                this.crc = crc.value
                time = FIXED_ZIP_TIME
            }
            zos.putNextEntry(storedEntry)
            zos.write(rawBytes)
            zos.closeEntry()
        }
    }

    private fun deflateBytesLevel9(rawBytes: ByteArray): ByteArray {
        val baos = ByteArrayOutputStream(rawBytes.size / 2 + 64)
        val deflater = Deflater(Deflater.BEST_COMPRESSION, true)
        try {
            DeflaterOutputStream(baos, deflater, 16 * 1024).use { dos ->
                dos.write(rawBytes)
            }
        } finally {
            deflater.end()
        }
        return baos.toByteArray()
    }

    private fun isSignatureEntry(entryName: String): Boolean {
        if (!entryName.startsWith("META-INF/")) return false
        val upper = entryName.uppercase()
        return upper == "META-INF/MANIFEST.MF" ||
            upper.endsWith(".SF") ||
            upper.endsWith(".RSA") ||
            upper.endsWith(".DSA") ||
            upper.endsWith(".EC") ||
            upper.startsWith("META-INF/SIG-")
    }

    private data class SigningCredentials(
        val privateKey: PrivateKey,
        val certificate: X509Certificate
    )

    private fun loadOrCreateSigningCredentials(context: Context): SigningCredentials {
        val keyDir = File(context.filesDir, "signer_credentials").apply { mkdirs() }
        val pk8File = File(keyDir, "testkey.pk8")
        val certFile = File(keyDir, "testkey.x509.der")

        val pk8Bytes = if (pk8File.exists() && pk8File.length() > 0L) {
            pk8File.readBytes()
        } else {
            Base64.getDecoder().decode(EMBEDDED_RSA_PKCS8_BASE64).also { pk8File.writeBytes(it) }
        }

        val certBytes = if (certFile.exists() && certFile.length() > 0L) {
            certFile.readBytes()
        } else {
            Base64.getDecoder().decode(EMBEDDED_X509_CERT_BASE64).also { certFile.writeBytes(it) }
        }

        val keyFactory = KeyFactory.getInstance("RSA")
        val privateKey = keyFactory.generatePrivate(PKCS8EncodedKeySpec(pk8Bytes))
        val certFactory = CertificateFactory.getInstance("X.509")
        val certificate = certFactory.generateCertificate(
            BufferedInputStream(certBytes.inputStream())
        ) as X509Certificate

        return SigningCredentials(privateKey, certificate)
    }

    /**
     * Generates a clean, valid sample APK containing `Lcom/example/HostEntry;` with
     * `onCreateHook()V` for immediate testing of Tab 4 class & hook injection.
     */
    fun createSampleHostApk(targetFile: File) {
        val workDir = File(targetFile.parentFile, "sample_injector_apk_${System.nanoTime()}").apply { mkdirs() }
        try {
            val manifestBytes = SampleApkBuilder.buildBinaryManifestPayload()

            val tableBlock = TableBlock()
            val pkg: PackageBlock = tableBlock.newPackage(0x7F, "com.example.injectorhost")
            val specTypePair: SpecTypePair = pkg.getOrCreateSpecTypePair(1, "string")
            val defaultType: TypeBlock = specTypePair.getOrCreateTypeBlock(ResConfig())
            val entry: Entry = defaultType.getOrCreateEntry(0.toShort())
            entry.setName("app_name", true)
            entry.setValueAsString("Injector Host Sample")
            tableBlock.refresh()
            val arscBytes = tableBlock.bytes

            val hostSmali = """
                .class public Lcom/example/HostEntry;
                .super Ljava/lang/Object;

                .method public constructor <init>()V
                    .locals 0
                    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
                    return-void
                .end method

                .method public onCreateHook()V
                    .locals 1
                    const/4 v0, 0x0
                    return-void
                .end method
            """.trimIndent()

            val smaliFile = File(workDir, "HostEntry.smali").apply { writeText(hostSmali) }
            val dexFile = File(workDir, "classes.dex")
            val ok = Smali.assemble(
                SmaliOptions().apply {
                    outputDexFile = dexFile.absolutePath
                    apiLevel = 26
                },
                listOf(smaliFile.absolutePath)
            )
            require(ok && dexFile.exists()) { "Failed to build sample host classes.dex" }

            FileOutputStream(targetFile).use { fos ->
                val countingOut = CountingOutputStream(BufferedOutputStream(fos, BUFFER_SIZE))
                ZipOutputStream(countingOut).use { zos ->
                    writeStoredAlignedEntry(zos, countingOut, "resources.arsc", arscBytes, 4L)
                    writeSmallestCompressedEntry(zos, "AndroidManifest.xml", manifestBytes)
                    writeSmallestCompressedEntry(zos, "classes.dex", dexFile.readBytes())
                }
            }
        } finally {
            workDir.deleteRecursively()
        }
    }

    private class CountingOutputStream(private val delegate: java.io.OutputStream) : java.io.OutputStream() {
        var bytesWritten: Long = 0L
            private set

        override fun write(b: Int) {
            delegate.write(b)
            bytesWritten += 1L
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            delegate.write(b, off, len)
            bytesWritten += len.toLong()
        }

        override fun flush() = delegate.flush()
        override fun close() = delegate.close()
    }
}
