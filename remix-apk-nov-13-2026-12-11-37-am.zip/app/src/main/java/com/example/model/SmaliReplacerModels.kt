package com.example.model

import java.io.File

/**
 * Details of a single Smali method that was assembled and replaced inside a target class.
 */
data class ReplacedSmaliMethodInfo(
    val classDescriptor: String = "",
    val methodName: String,
    val parameterTypes: List<String>,
    val returnType: String,
    val isDirectMethod: Boolean,
    val dexFileName: String
) {
    val name: String
        get() = methodName

    val fullSignature: String
        get() = "$name(${parameterTypes.joinToString("")})$returnType"
}

/**
 * Final result returned after `SmaliMethodReplacer` patches one or more classes across `classes*.dex`,
 * aligns `resources.arsc` (4-byte STORED), and signs with V1 + V2 + V3.
 */
data class SmaliPatchResult(
    val outputApkFile: File,
    val outputFileName: String,
    val packageName: String,
    val patchedClassDescriptors: List<String>,
    val modifiedDexFileNames: List<String>,
    val scannedDexFiles: List<String>,
    val replacedMethods: List<ReplacedSmaliMethodInfo>,
    val unmatchedMethodSignatures: List<String>,
    val totalMethodsInPatchedClasses: Int,
    val outputSizeBytes: Long,
    val isSignedV1V2V3: Boolean
) {
    val targetClassDescriptor: String
        get() = patchedClassDescriptors.joinToString(", ")

    val modifiedDexFileName: String
        get() = modifiedDexFileNames.joinToString(", ")

    val totalMethodsInTargetClass: Int
        get() = totalMethodsInPatchedClasses
}

/**
 * Progress stages for Tab 3 ("تعديل Smali").
 */
enum class SmaliReplacerStage(val titleAr: String) {
    IDLE("في انتظار اختيار ملف APK"),
    ASSEMBLING_SMALI("تجميع دوال Smali عبر org.smali:smali..."),
    SCANNING_DEX("فحص جميع ملفات classes*.dex والبحث عن الكلاسات المستهدفة..."),
    PATCHING_DEX("استبدال الدوال المستهدفة عبر dexlib2..."),
    REBUILDING_APK("إعادة حزم APK ومحاذاة resources.arsc (4-Byte)..."),
    SIGNING_APK("التوقيع الرقمي الشامل (V1 + V2 + V3)..."),
    COMPLETED("اكتمل تعديل الكلاسات ودوال Smali وتوقيع APK بنجاح!"),
    FAILED("فشلت عملية تعديل Smali")
}

/**
 * Immutable UI state for Tab 3 ("تعديل Smali") supporting multiple classes via `patches: Map<String, List<String>>`.
 */
data class SmaliReplacerUiState(
    val selectedApk: ApkFileInfo? = null,
    val detectedDexFiles: List<String> = emptyList(),
    val patches: Map<String, List<String>> = emptyMap(),
    val isProcessing: Boolean = false,
    val stage: SmaliReplacerStage = SmaliReplacerStage.IDLE,
    val progressPercent: Int = 0,
    val statusText: String = "",
    val logs: List<String> = emptyList(),
    val result: SmaliPatchResult? = null,
    val errorMessage: String? = null
)
