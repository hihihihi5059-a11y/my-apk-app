package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.ApkCompressorScreen
import com.example.ui.components.ApkPackageFixerScreen
import com.example.ui.components.SmaliReplacerScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.DeepNavyBorder
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.DeepNavySurfaceElevated
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.OnCyanAccent
import com.example.viewmodel.ApkCompressorViewModel
import com.example.viewmodel.ApkFixerViewModel
import com.example.viewmodel.SmaliReplacerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                ApkPackageFixerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkPackageFixerApp(
    viewModel: ApkFixerViewModel = viewModel(),
    compressorViewModel: ApkCompressorViewModel = viewModel(),
    smaliReplacerViewModel: SmaliReplacerViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val compressorUiState by compressorViewModel.uiState.collectAsStateWithLifecycle()
    val smaliUiState by smaliReplacerViewModel.uiState.collectAsStateWithLifecycle()

    var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }

    // Return to Tab 1 on system back press when on Tab 2
    BackHandler(enabled = selectedTabIndex != 0) {
        selectedTabIndex = 0
    }

    // Tab 1 SAF File Picker Launcher (100% untouched)
    val openApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.onApkFileSelected(context, uri)
        }
    }

    // Tab 1 SAF CreateDocument Launcher (100% untouched)
    val saveApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { destinationUri ->
        if (destinationUri != null) {
            val sourceFile = uiState.fixResult?.outputApkFile
            if (sourceFile != null && sourceFile.exists()) {
                context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                    output.flush()
                }
            }
        }
    }

    // Tab 2 SAF File Picker Launcher
    val openCompressorApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            compressorViewModel.onApkFileSelected(context, uri)
        }
    }

    // Tab 2 SAF CreateDocument Launcher
    val saveCompressorApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { destinationUri ->
        if (destinationUri != null) {
            val sourceFile = compressorUiState.result?.outputApkFile
            if (sourceFile != null && sourceFile.exists()) {
                context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                    output.flush()
                }
            }
        }
    }

    // Tab 3 SAF File Picker Launcher
    val openSmaliApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            smaliReplacerViewModel.onApkFileSelected(context, uri)
        }
    }

    // Tab 3 SAF CreateDocument Launcher
    val saveSmaliApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { destinationUri ->
        if (destinationUri != null) {
            val sourceFile = smaliUiState.result?.outputApkFile
            if (sourceFile != null && sourceFile.exists()) {
                context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                    output.flush()
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("main_scaffold"),
        containerColor = DeepNavyBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepNavySurface)
                    .border(BorderStroke(1.dp, DeepNavyBorder))
            ) {
                // 1. Top App Bar carrying the name "APK Package Fixer"
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CyanAccent.copy(alpha = 0.16f))
                                    .border(1.dp, CyanAccent.copy(alpha = 0.7f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (selectedTabIndex) {
                                        0 -> Icons.Default.Build
                                        1 -> Icons.Default.Compress
                                        else -> Icons.Default.Code
                                    },
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name), // "APK Package Fixer"
                                    style = MaterialTheme.typography.titleLarge,
                                    color = DarkTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.testTag("app_title")
                                )
                                Text(
                                    text = stringResource(R.string.app_subtitle),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DarkTextSecondary,
                                    maxLines = 1
                                )
                            }
                        }
                    },
                    actions = {
                        Surface(
                            color = CyanAccent.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "V1/V2/V3 SIGNER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanAccent,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DeepNavySurface
                    ),
                    modifier = Modifier.testTag("main_top_app_bar")
                )

                // Segmented 3-Tab Bar: Tab 1 ("إصلاح التوافق"), Tab 2 ("ضغط APK"), Tab 3 ("تعديل Smali")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(DeepNavySurfaceElevated)
                        .border(1.dp, DeepNavyBorder, RoundedCornerShape(14.dp))
                        .padding(4.dp)
                        .testTag("top_mode_tabs"),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isTab1 = selectedTabIndex == 0
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isTab1) CyanAccent else DeepNavySurfaceElevated)
                            .clickable { selectedTabIndex = 0 }
                            .testTag("tab_compatibility_fixer"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                tint = if (isTab1) OnCyanAccent else DarkTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "إصلاح التوافق",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isTab1) OnCyanAccent else DarkTextSecondary
                            )
                        }
                    }

                    val isTab2 = selectedTabIndex == 1
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isTab2) CyanAccent else DeepNavySurfaceElevated)
                            .clickable { selectedTabIndex = 1 }
                            .testTag("tab_apk_compressor"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Compress,
                                contentDescription = null,
                                tint = if (isTab2) OnCyanAccent else DarkTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "ضغط APK",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isTab2) OnCyanAccent else DarkTextSecondary
                            )
                        }
                    }

                    val isTab3 = selectedTabIndex == 2
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isTab3) CyanAccent else DeepNavySurfaceElevated)
                            .clickable { selectedTabIndex = 2 }
                            .testTag("tab_smali_replacer"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = if (isTab3) OnCyanAccent else DarkTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "تعديل Smali",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isTab3) OnCyanAccent else DarkTextSecondary
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        when (selectedTabIndex) {
            0 -> {
                // TAB 1: 100% Untouched APK Package Fixer Screen
                ApkPackageFixerScreen(
                    uiState = uiState,
                    onSelectApkClick = {
                        openApkLauncher.launch(
                            arrayOf(
                                "application/vnd.android.package-archive",
                                "application/octet-stream",
                                "*/*"
                            )
                        )
                    },
                    onGenerateSampleClick = {
                        viewModel.generateSampleApk(context)
                    },
                    onTargetVersionSelected = { version ->
                        viewModel.selectTargetVersion(version)
                    },
                    onToggleUpdateTargetSdk = { enabled ->
                        viewModel.setAlsoUpdateTargetSdk(enabled)
                    },
                    onFixAndRebuildClick = {
                        viewModel.startFixAndRebuild(context)
                    },
                    onInstallDirectlyClick = {
                        viewModel.installFixedApk(context)
                    },
                    onSaveFixedClick = {
                        val fileName = uiState.fixResult?.outputFileName ?: "Fixed_App.apk"
                        saveApkLauncher.launch(fileName)
                    },
                    onShareFixedClick = {
                        viewModel.shareFixedApk(context)
                    },
                    onDismissDialog = {
                        viewModel.dismissCompletionDialog()
                    },
                    onDismissError = {
                        viewModel.dismissError()
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            1 -> {
                // TAB 2: 100% Untouched Deep APK Size Compressor & Optimizer Screen
                ApkCompressorScreen(
                    uiState = compressorUiState,
                    onSelectApkClick = {
                        openCompressorApkLauncher.launch(
                            arrayOf(
                                "application/vnd.android.package-archive",
                                "application/octet-stream",
                                "*/*"
                            )
                        )
                    },
                    onGenerateSampleClick = {
                        compressorViewModel.generateSampleApkForCompression(context)
                    },
                    onToggleDexOptimization = { enabled ->
                        compressorViewModel.setStripDexDebugAndBloat(enabled)
                    },
                    onToggleKeepArEnOnly = { enabled ->
                        compressorViewModel.setKeepOnlyArEnLanguages(enabled)
                    },
                    onToggleWebpConversion = { enabled ->
                        compressorViewModel.setConvertImagesToWebp(enabled)
                    },
                    onToggleArm64Only = { enabled ->
                        compressorViewModel.setKeepOnlyArm64NativeLibs(enabled)
                    },
                    onStartCompressionClick = {
                        compressorViewModel.startDeepCompression(context)
                    },
                    onInstallDirectlyClick = {
                        compressorViewModel.installCompressedApk(context)
                    },
                    onSaveCompressedClick = {
                        val fileName = compressorUiState.result?.outputFileName ?: "Compressed_App.apk"
                        saveCompressorApkLauncher.launch(fileName)
                    },
                    onShareCompressedClick = {
                        compressorViewModel.shareCompressedApk(context)
                    },
                    onDismissError = {
                        compressorViewModel.dismissError()
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            else -> {
                // TAB 3: Multi-Class Flexible Smali Method Replacer Screen ("تعديل Smali")
                SmaliReplacerScreen(
                    uiState = smaliUiState,
                    onSelectApkClick = {
                        openSmaliApkLauncher.launch(
                            arrayOf(
                                "application/vnd.android.package-archive",
                                "application/octet-stream",
                                "*/*"
                            )
                        )
                    },
                    onGenerateSampleClick = {
                        smaliReplacerViewModel.generateSampleApkForSmaliReplacer(context)
                    },
                    onClassKeyChanged = { oldDesc, newDesc ->
                        smaliReplacerViewModel.updateClassDescriptorKey(oldDesc, newDesc)
                    },
                    onSmaliMethodChanged = { classDesc, methodIndex, code ->
                        smaliReplacerViewModel.updateSmaliMethodForClass(classDesc, methodIndex, code)
                    },
                    onAddMethodBlockToClass = { classDesc ->
                        smaliReplacerViewModel.addSmaliMethodBlockToClass(classDesc)
                    },
                    onRemoveMethodBlockFromClass = { classDesc, methodIndex ->
                        smaliReplacerViewModel.removeSmaliMethodBlockFromClass(classDesc, methodIndex)
                    },
                    onAddNewClassEntry = {
                        smaliReplacerViewModel.addNewTargetClassEntry()
                    },
                    onRemoveClassEntry = { classDesc ->
                        smaliReplacerViewModel.removeTargetClassEntry(classDesc)
                    },
                    onResetToDefaults = {
                        smaliReplacerViewModel.resetToCodeDefaults()
                    },
                    onApplyPatchAndSignClick = {
                        smaliReplacerViewModel.applySmaliPatchAndSign(context)
                    },
                    onInstallPatchedClick = {
                        smaliReplacerViewModel.installPatchedApk(context)
                    },
                    onSavePatchedClick = {
                        val fileName = smaliUiState.result?.outputFileName ?: "SmaliPatched_App.apk"
                        saveSmaliApkLauncher.launch(fileName)
                    },
                    onSharePatchedClick = {
                        smaliReplacerViewModel.sharePatchedApk(context)
                    },
                    onDismissError = {
                        smaliReplacerViewModel.dismissError()
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}
