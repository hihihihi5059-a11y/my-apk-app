package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.ApkFixerEngine
import com.example.engine.SmaliMethodReplacer
import com.example.model.SmaliReplacerStage
import com.example.model.SmaliReplacerUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class SmaliReplacerViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(
        SmaliReplacerUiState(
            patches = LinkedHashMap(SmaliMethodReplacer.DEFAULT_SMALI_PATCHES)
        )
    )
    val uiState: StateFlow<SmaliReplacerUiState> = _uiState.asStateFlow()

    fun updateClassDescriptorKey(oldClassDesc: String, newClassDesc: String) {
        _uiState.update { state ->
            val updated = LinkedHashMap<String, List<String>>()
            for ((k, v) in state.patches) {
                if (k == oldClassDesc) {
                    updated[newClassDesc] = v
                } else {
                    updated[k] = v
                }
            }
            state.copy(patches = updated)
        }
    }

    fun updateSmaliMethodForClass(classDesc: String, methodIndex: Int, newMethodCode: String) {
        _uiState.update { state ->
            val methods = state.patches[classDesc]?.toMutableList() ?: return@update state
            if (methodIndex in methods.indices) {
                methods[methodIndex] = newMethodCode
            }
            val updated = LinkedHashMap(state.patches)
            updated[classDesc] = methods
            state.copy(patches = updated)
        }
    }

    fun addSmaliMethodBlockToClass(classDesc: String) {
        _uiState.update { state ->
            val methods = state.patches[classDesc]?.toMutableList() ?: return@update state
            val nextIdx = methods.size + 1
            val template = """
                .method public customMethod$nextIdx()V
                    .locals 0

                    return-void
                .end method
            """.trimIndent()
            methods.add(template)
            val updated = LinkedHashMap(state.patches)
            updated[classDesc] = methods
            state.copy(patches = updated)
        }
    }

    fun removeSmaliMethodBlockFromClass(classDesc: String, methodIndex: Int) {
        _uiState.update { state ->
            val methods = state.patches[classDesc]?.toMutableList() ?: return@update state
            if (methods.size <= 1 || methodIndex !in methods.indices) return@update state
            methods.removeAt(methodIndex)
            val updated = LinkedHashMap(state.patches)
            updated[classDesc] = methods
            state.copy(patches = updated)
        }
    }

    fun addNewTargetClassEntry() {
        _uiState.update { state ->
            val nextClassNum = state.patches.size + 1
            val newClassKey = "Lcom/example/CustomTargetClass$nextClassNum;"
            val defaultMethod = """
                .method public isEnabled()Z
                    .locals 1

                    const/4 v0, 0x1
                    return v0
                .end method
            """.trimIndent()
            val updated = LinkedHashMap(state.patches)
            updated[newClassKey] = listOf(defaultMethod)
            state.copy(patches = updated)
        }
    }

    fun removeTargetClassEntry(classDesc: String) {
        _uiState.update { state ->
            if (state.patches.size <= 1) return@update state
            val updated = LinkedHashMap(state.patches)
            updated.remove(classDesc)
            state.copy(patches = updated)
        }
    }

    fun resetToCodeDefaults() {
        _uiState.update {
            it.copy(
                patches = LinkedHashMap(SmaliMethodReplacer.DEFAULT_SMALI_PATCHES)
            )
        }
    }

    fun onApkFileSelected(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    stage = SmaliReplacerStage.SCANNING_DEX,
                    progressPercent = 10,
                    statusText = "جاري قراءة ملف APK وفحص ملفات classes*.dex...",
                    errorMessage = null,
                    result = null
                )
            }

            try {
                val (apkInfo, dexList) = withContext(Dispatchers.IO) {
                    val displayName = resolveDisplayName(context, uri) ?: "Selected_Smali_Target.apk"
                    val importDir = File(context.cacheDir, "imported_smali_apks").apply { mkdirs() }
                    val localFile = File(importDir, displayName.replace(Regex("[^a-zA-Z0-9._-]"), "_"))

                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(localFile).use { output ->
                            input.copyTo(output, bufferSize = 64 * 1024)
                        }
                    } ?: throw IllegalStateException("تعذر فتح دفق القراءة لملف الـ APK المختار.")

                    val info = ApkFixerEngine.inspectApkFile(localFile, uri).copy(fileName = displayName)
                    val dexEntries = SmaliMethodReplacer.listDexEntriesInApk(localFile)
                    Pair(info, dexEntries)
                }

                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        detectedDexFiles = dexList,
                        isProcessing = false,
                        stage = SmaliReplacerStage.IDLE,
                        progressPercent = 0,
                        statusText = "تم تحميل ${apkInfo.fileName} (${dexList.size} ملف DEX)",
                        logs = listOf(
                            "✓ تم تحميل ملف APK: ${apkInfo.fileName} (${apkInfo.formattedSize})",
                            "• الحزمة (Package): ${apkInfo.packageName}",
                            "• ملفات DEX المكتشفة: ${dexList.joinToString(", ")}"
                        ),
                        result = null,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        stage = SmaliReplacerStage.FAILED,
                        progressPercent = 0,
                        errorMessage = "تعذر قراءة ملف APK: ${e.localizedMessage ?: "ملف غير صالح"}"
                    )
                }
            }
        }
    }

    fun generateSampleApkForSmaliReplacer(context: Context) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    stage = SmaliReplacerStage.SCANNING_DEX,
                    progressPercent = 20,
                    statusText = "جاري توليد ملف APK تجريبي متعدد الكلاسات والـ DEX...",
                    errorMessage = null,
                    result = null
                )
            }

            try {
                val (apkInfo, dexList) = withContext(Dispatchers.IO) {
                    val sampleDir = File(context.cacheDir, "imported_smali_apks").apply { mkdirs() }
                    val sampleFile = File(sampleDir, "Smali_Target_Demo_MultiDex.apk")
                    SmaliMethodReplacer.createSampleApkWithTargetClass(sampleFile)
                    val info = ApkFixerEngine.inspectApkFile(sampleFile)
                    val dexEntries = SmaliMethodReplacer.listDexEntriesInApk(sampleFile)
                    Pair(info, dexEntries)
                }

                _uiState.update {
                    it.copy(
                        selectedApk = apkInfo,
                        detectedDexFiles = dexList,
                        patches = LinkedHashMap(SmaliMethodReplacer.DEFAULT_SMALI_PATCHES),
                        isProcessing = false,
                        stage = SmaliReplacerStage.IDLE,
                        progressPercent = 0,
                        statusText = "تم تجهيز ملف APK التجريبي بنجاح (${dexList.joinToString(", ")})",
                        logs = listOf(
                            "✓ تم إنشاء ملف APK تجريبي: ${apkInfo.fileName}",
                            "• ملفات DEX: ${dexList.joinToString(", ")}",
                            "• الكلاسات المجهزة في DEFAULT_SMALI_PATCHES: ${SmaliMethodReplacer.DEFAULT_SMALI_PATCHES.keys.joinToString(", ")}"
                        ),
                        result = null,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        stage = SmaliReplacerStage.FAILED,
                        errorMessage = "تعذر إنشاء ملف APK التجريبي: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun applySmaliPatchAndSign(context: Context) {
        val currentState = _uiState.value
        val sourceApk = currentState.selectedApk ?: return
        if (currentState.isProcessing) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isProcessing = true,
                    stage = SmaliReplacerStage.ASSEMBLING_SMALI,
                    progressPercent = 5,
                    statusText = SmaliReplacerStage.ASSEMBLING_SMALI.titleAr,
                    logs = listOf("▶ بدء عملية تعديل الكلاسات ودوال Smali وتوقيع الـ APK..."),
                    result = null,
                    errorMessage = null
                )
            }

            try {
                val activePatches = currentState.patches.ifEmpty { SmaliMethodReplacer.DEFAULT_SMALI_PATCHES }
                val patchResult = SmaliMethodReplacer.replaceMethodsAndSignApk(
                    context = context,
                    sourceApk = sourceApk,
                    patches = activePatches,
                    onLog = { line ->
                        _uiState.update { state ->
                            state.copy(logs = state.logs + line)
                        }
                    },
                    onProgress = { stage, percent, status ->
                        _uiState.update { state ->
                            state.copy(
                                stage = stage,
                                progressPercent = percent,
                                statusText = status
                            )
                        }
                    }
                )

                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        stage = SmaliReplacerStage.COMPLETED,
                        progressPercent = 100,
                        statusText = SmaliReplacerStage.COMPLETED.titleAr,
                        result = patchResult,
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        stage = SmaliReplacerStage.FAILED,
                        progressPercent = 0,
                        statusText = SmaliReplacerStage.FAILED.titleAr,
                        logs = it.logs + "✖ خطأ: ${e.localizedMessage ?: "فشل غير متوقع"}",
                        errorMessage = "فشل تعديل Smali: ${e.localizedMessage ?: "تحقق من أسماء الكلاسات وصياغة الدوال"}"
                    )
                }
            }
        }
    }

    fun installPatchedApk(context: Context) {
        val outputFile = _uiState.value.result?.outputApkFile ?: return
        if (!outputFile.exists()) {
            _uiState.update { it.copy(errorMessage = "ملف APK المعدّل غير موجود.") }
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!context.packageManager.canRequestPackageInstalls()) {
                    val settingsIntent = Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${context.packageName}")
                    ).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(settingsIntent)
                    return
                }
            }

            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outputFile
            )

            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر تشغيل مثبّت الحزم: ${e.localizedMessage}")
            }
        }
    }

    fun sharePatchedApk(context: Context) {
        val outputFile = _uiState.value.result?.outputApkFile ?: return
        if (!outputFile.exists()) return

        try {
            val apkUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outputFile
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, apkUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(
                Intent.createChooser(shareIntent, "مشاركة ملف APK المعدّل").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "تعذر مشاركة ملف APK: ${e.localizedMessage}")
            }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun resolveDisplayName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0 && cursor.moveToFirst()) {
                    cursor.getString(nameIndex)
                } else {
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }
}
